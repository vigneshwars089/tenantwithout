﻿using DigiOPS.TechFoundation.MetricCalculator;
using DigiOPS.TechFoundation.ProvisioningManagement;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {           

        static void Main(string[] args)
        {

             char[] Operands = {'+','-','*','/'};
             List<object> Operators = new List<object>();
             List<object> Opera = new List<object>();
                   string formula = "a+b*100";
                  
                       object operatorqwq = formula.Split(Operands);
                    
                       Opera.Add(operatorqwq);
                       string digits = Regex.Replace(formula, @"[\w]", "");
                       int length = digits.Length;
                       List<string> symbols = new List<string>();
                       for (int i = 0; i < length; i++)
                       {
                           //Console.WriteLine(digits[i]);
                           symbols.Add(digits[i].ToString());
                       }
                       var output1 = Regex.Split(digits, @"");
                       Console.Write(output1);
                   Console.Write(Opera);
                   Console.Read();
          //  UtilizationMetric um = new UtilizationMetric();
          //  MetricInfo objminfo = new MetricInfo();
          //  MetricInfo objminfo1 = new MetricInfo();
          //  InputSource inp = new InputSource();
          //  Metricfactory mfact = new Metricfactory();
          //  inp.Source1 = 12;
          //  inp.Source2 = 2;
          //  objminfo.objInputSource.Add(inp);
          //  mfact.MetricHandler().validate().
          ////  objminfo1 = um.UtilizationMetricCalc(objminfo);
          //  Console.Write(objminfo1.objMetricResult[0].Result1);
          //  Console.Read();
        }
        //public  bool SetSetting(string Key, string Value)
        //{
        //    bool result = false;
        //    string contnstring=string.Empty;
        //    try
        //    {
        //        contnstring=ConfigurationManager.ConnectionStrings[Key].ToString();
        //        System.Configuration.Configuration config =    ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                
               
        //        if(contnstring!=null && contnstring!=" ")
        //            config.ConnectionStrings.ConnectionStrings.Remove(Key);
                                   
        //        config.ConnectionStrings.ConnectionStrings.Add(new ConnectionStringSettings(
        //                                                     Key, Value));

        //        config.Save(ConfigurationSaveMode.Modified, true);
        //        ConfigurationManager.RefreshSection("connectionStrings");

        //        contnstring = ConfigurationManager.ConnectionStrings[Key].ToString();
        //        //System.Configuration.Configuration config =
        //        //  ConfigurationManager.OpenExeConfiguration(
        //        //                       ConfigurationUserLevel.None);

        //        //config.AppSettings.Settings.Remove(Key);
        //        //var kvElem = new KeyValueConfigurationElement(Key, Value);
        //        //config.AppSettings.Settings.Add(kvElem);

        //        //// Save the configuration file.
        //        //config.Save(ConfigurationSaveMode.Modified);

        //        //// Force a reload of a changed section.
        //        //ConfigurationManager.RefreshSection("appSettings");
        //        if (contnstring.Equals(Value))
        //            result = true;
        //        else
        //            result = false;
        //    }
        //    finally
        //    { }
        //    return result;
        //} // function

        //public  string GetDecodedConnectionstring(string TenantName, String AppId)
        //{
        //    string result = "";
        //    Tenant objtent = new Tenant();

        //    // string oupt = string.Empty;

        //    try
        //    {
        //        if (!String.IsNullOrEmpty(TenantName) && TenantName != null && !String.IsNullOrEmpty(AppId) && AppId != null)
        //        {
        //            result = objtent.GetTenantConnectionString(TenantName, AppId);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message, ex.InnerException);
        //    }
        //    return result;

        //}
    }
}
