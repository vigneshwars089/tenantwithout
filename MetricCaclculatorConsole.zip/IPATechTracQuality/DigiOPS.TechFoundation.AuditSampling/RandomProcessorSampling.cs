﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace DigiOPS.TechFoundation.AuditSampling
{
    public class RandomProcessorSampling : BaseAuditSampling
    {

        public override TransactionListDetails SamplingLogic(TransactionListDetails objTransactionListDetails)
        {
            string Message = objTransactionListDetails.SamplingTechnique + " Processor Sampling";

            //Getting the sampling Period
            string SamplingPeriod = objTransactionListDetails.SamplingPeriod;

            //Getting the From and To Date Range
            DateTime ProcessedFrom = objTransactionListDetails.ProcessedFromDate;
            DateTime ProcessedTo = objTransactionListDetails.ProcessingToDate;


            //Getting the SamplingPercentage
            double SampPercentage = objTransactionListDetails.Percentage;

            //Getting the Transaction Total count
            int Total = objTransactionListDetails.Total;

            //Getting the Transaction List
            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists.Where(p => p.ProcessedDate >= ProcessedFrom && p.ProcessedDate <= ProcessedTo).ToList();

            //Getting the Processor Transaction Details
            var ProcessorAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;

            //Calculating the Sampling, Based on the Sampling Period
            if (SamplingPeriod == Constants.DAILY)
            {
                /*Grouping the Processors */
                var objGrpProcessor = from c in objTransactionLists
                                      group c by new { c.ProcessedBy, c.ProcessedDate } into Procgrp
                                      select new
                                      {
                                          ProcessedBy = Procgrp.Key.ProcessedBy,
                                          NoofTransaction = Procgrp.Count(),
                                          ProcessedDate = Procgrp.Key.ProcessedDate

                                      };

                /*Finding the Pending Details for Each Processor */
                var GetPendinglist = (from c in objGrpProcessor
                                      join d in ProcessorAllocatedLists on new { c.ProcessedBy, c.ProcessedDate } equals new { d.ProcessedBy, d.ProcessedDate }

                                      select new
                                      {
                                          TotalRecords = c.NoofTransaction,
                                          ProcessedBy = d.ProcessedBy,
                                          ProcessedDate = d.ProcessedDate,
                                          Allocated = d.Allocated,
                                          Pending = Math.Ceiling((c.NoofTransaction * SampPercentage) / 100)

                                      }).ToList();

                GetPendinglist = (from c in GetPendinglist
                                  select new
                                  {
                                      TotalRecords = c.TotalRecords,
                                      ProcessedBy = c.ProcessedBy,
                                      ProcessedDate = c.ProcessedDate,
                                      Allocated = c.Allocated,
                                      Pending = ((c.Pending <= c.Allocated) ? 0 : c.Pending - c.Allocated)

                                  }).ToList();

                /*Getting the transactions from each processors based on the pending */
                List<TransactionLists> objGetFinalTransactionLists1 = objTransactionLists.GroupBy(a => new { a.ProcessedBy, a.ProcessedDate })
                                        .SelectMany(g => g.Take((int)GetPendinglist.Where(b => (b.ProcessedBy == g.Key.ProcessedBy) && (b.ProcessedDate == g.Key.ProcessedDate))
                                            .Select(b => b.Pending).DefaultIfEmpty(0).Single())).ToList();

                objTransactionListDetails.TransactionLists = objGetFinalTransactionLists1;
            }
            else if (SamplingPeriod == Constants.Monthly)
            {
                /*Grouping the Processors */
                var objGrpProcessor = from c in objTransactionLists
                                      group c by new { c.ProcessedBy } into Procgrp
                                      select new
                                      {
                                          ProcessedBy = Procgrp.Key.ProcessedBy,
                                          NoofTransaction = Procgrp.Count()


                                      };


                /*Finding the Pending Details for Each Processor */
                var GetPendinglist = (from c in objGrpProcessor
                                      join d in ProcessorAllocatedLists on c.ProcessedBy equals d.ProcessedBy

                                      select new
                                      {
                                          TotalRecords = c.NoofTransaction,
                                          ProcessedBy = d.ProcessedBy,
                                          Allocated = d.Allocated,
                                          Pending = Math.Ceiling((c.NoofTransaction * SampPercentage) / 100)

                                      }).ToList();

                GetPendinglist = (from c in GetPendinglist
                                  select new
                                  {
                                      TotalRecords = c.TotalRecords,
                                      ProcessedBy = c.ProcessedBy,
                                      Allocated = c.Allocated,
                                      Pending = ((c.Pending <= c.Allocated) ? 0 : c.Pending - c.Allocated)

                                  }).ToList();

                /*Getting the transactions from each processors based on the pending */
                List<TransactionLists> objGetFinalTransactionLists1 = objTransactionLists.GroupBy(a => a.ProcessedBy)
                                        .SelectMany(g => g.Take((int)GetPendinglist.Where(b => b.ProcessedBy == g.Key)
                                            .Select(b => b.Pending).DefaultIfEmpty(0).Single())).ToList();

                objTransactionListDetails.TransactionLists = objGetFinalTransactionLists1;
            }


            return objTransactionListDetails;
        }


    }
}
