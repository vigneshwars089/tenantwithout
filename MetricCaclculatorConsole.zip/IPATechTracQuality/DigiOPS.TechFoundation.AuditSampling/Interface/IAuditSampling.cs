﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.AuditSampling
{
   public  interface IAuditSampling
    {
       TransactionListDetails SamplingLogic(TransactionListDetails TLD);
        
    }
}
