﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.Logging;
//using DigiOPS.TechFoundation.Security;
using Microsoft.Exchange.WebServices.Data;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseMailDataTransfer.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :BaseMailDataTransfer
    // Author : Sadhesh
    // Creation Date : 5/22/2017
    // Purpose : base class for Case Creation Through Outlook 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //22-May-2017    Sadhesh     CreateCaseforSourceData            Added CreateCases method  
    //22-May-2017    Sadhesh     DownloadtoClient            Download the Excel or PDF  
    //22-May-2017    Sadhesh     ReadfromSource            Read content from source file 
    //22-May-2017    Sadhesh     SavetoDestination            Save file to destination path
    //22-May-2017    Sadhesh     TransformSourceDataInfo           TransformSourceDataInfo
    //22-May-2017    Sadhesh     UploadToServer            Save to server 
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class OutlookDataTransfer : BaseMailDataTransfer
    {
       // ILoggingFactory objlog = new LoggingFactory();
        EmailCaseCreationDAO ECCDAO = new EmailCaseCreationDAO();
        public string _applicationError = string.Empty;


        List<CaseCreationInput> CaseCreationInputList = new List<CaseCreationInput>();

        public override DataTransferInfo CreateCaseforSourceData(EmailResponceInfo eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {

            return CreateCases(eInfo, MailFolderId, StatusId, caseID, subcaseid);



        }

        #region EMTCaseCreation
        /// <summary>
        /// main method for the EMT case creation
        /// </summary>
        /// <param name="eInfo"></param>
        /// <returns></returns>
        public DataTransferInfo CreateCases(EmailResponceInfo eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            DataTransferInfo objDataTransferout = new DataTransferInfo();
            try
            {

                CaseCreationInput CCInput = new CaseCreationInput();
                CCInput.Action = eInfo.Action;
                if (eInfo.CaseCreationInputList.Count != 0)
                {
                    foreach (var CCList in eInfo.CaseCreationInputList)
                    {
                        // CCInput.CaseIdKeyword = CCList.CaseIdKeyword;
                        // CCInput.currentStatus = CCList.currentStatus;
                        // CCInput.sCaseID = CCList.sCaseID;
                        // CCInput.caseID = CCList.caseID;
                        CCInput.ReceivedDate = CCList.ReceivedDate;
                        //CCInput.MailFolderId = CCList.MailFolderId;

                        // CCInput.StatusId = CCList.StatusId;
                        CCInput.Subject = CCList.Subject;
                        CCInput.Message = CCList.Message;
                        CCInput.Sender = CCList.Sender;
                        CCInput.Toadd = CCList.Toadd;
                        CCInput.CCaddress = CCList.CCaddress;
                        CCInput.BCCaddress = CCList.BCCaddress;
                        // CCInput.subcaseid = CCList.subcaseid;
                        CCInput.Priority = CCList.Priority;
                        CCInput.GUID = CCList.GUID;
                        CCInput.FileAttachmentName = CCList.FileAttachmentName;
                        CCInput.ItemAttachmentFileName = CCList.ItemAttachmentFileName;
                        CCInput.ScreenShotfileName = CCList.ScreenShotfileName;
                        CCInput.MailFileAttachmentContentBytes = CCList.MailFileAttachmentContentBytes;


                        eInfo.Result = validateEMTInput(CCInput, MailFolderId, StatusId, caseID, subcaseid);
                        if (eInfo.Result != null)
                        {
                            objDataTransferout.ResultMessage = eInfo.Result;
                            return objDataTransferout;
                        }

                    }
                }
                else
                {
                    eInfo.Result = "Case Creation Input List can not be null !";
                }
            }
            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            //return eInfo.Result;
            objDataTransferout.ResultMessage = eInfo.Result;
            return objDataTransferout;
        }


        /// <summary>
        /// validate the input which are passing to sp
        /// </summary>
        /// <param name="eInfo"></param>
        /// <returns></returns>
        public string validateEMTInput(CaseCreationInput eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            eInfo.ErrorMessage = new StringBuilder();
            try
            {
                if (eInfo == null)
                {
                    eInfo.ErrorMessage.Append("Email info Cannot be null ! \n");

                }
                else if (eInfo.ReceivedDate == null)
                {
                    eInfo.ErrorMessage.Append("Recieved Date is null ! \n");
                }
                //else if (eInfo.MailFolderId == "" || eInfo.MailFolderId == null)
                //{
                //    eInfo.ErrorMessage.Append("Please provide Mail Folder ID ! \n");
                //}
                else if (eInfo.Message == "" || eInfo.Message == null || eInfo.Subject == "" || eInfo.Subject == null)
                {
                    eInfo.ErrorMessage.Append("Mail Subject is null ! \n");
                }
                else if (eInfo.Sender == null || eInfo.Sender == "" || eInfo.Toadd == null || eInfo.Toadd == "")
                {
                    eInfo.ErrorMessage.Append("Sender Address/ To Address/ CC Address/ BCC Address should not be null ! \n");
                }

                if (eInfo.ErrorMessage.ToString() != "")
                {
                    return eInfo.ErrorMessage.ToString();
                }
                else
                {
                    CaseUpdation(eInfo, MailFolderId, StatusId, caseID, subcaseid);
                    return "Case Created Successfully";
                }
            }
            catch (Exception ex)
            {
              //  objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        /// <summary>
        /// depend on the current status Id it will call method for case creation
        /// </summary>
        /// <param name="eInfo"></param>
        public void CaseUpdation(CaseCreationInput eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            try
            {
                if (eInfo.Action.ToUpper().Trim() == "INSERT")
                {
                    ECCDAO.InsertMail(eInfo, MailFolderId, StatusId, caseID, subcaseid);
                }
                else if (eInfo.Action.ToUpper().Trim() == "UPDATE")
                {
                    ECCDAO.UpdateCases(eInfo, MailFolderId, StatusId, caseID, subcaseid);
                }
            }
            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        #endregion

        public override DataTransferInfo DownloadtoClient()
        {
            throw new NotImplementedException();
        }
         //EmailResponceInfo objResponse = new EmailResponceInfo();
         //   DataTransferInfo objDataInfo = new DataTransferInfo();
         //   objResponse = readMailBox(EMailInfo);
         //   objDataInfo.EmailResponseInfo = objResponse;
         //   return objDataInfo;
        //public override DataTransferInfo ReadAttachementfromSource()
        //{
        //    throw new NotImplementedException();
        //}
        public override DataTransferInfo ReadAttachementfromSource(EMailInfo emailInfo)
        {
            DataTransferInfo objDataInfo = new DataTransferInfo();

            SecureString sec_strPassword = new SecureString();

            emailInfo.strMailStarHeader = ExchangeConstants.STAR;
            emailInfo.CurrentTime = Convert.ToString(DateTime.Now);
            emailInfo.strMailStarHeader = emailInfo.strMailStarHeader + ExchangeConstants.NEW_LINE + "RunTime: " + emailInfo.CurrentTime;
            //emailInfo.filename = string.Empty;
            string EntityName = emailInfo.GetType().Name;
            var doneEvents = new List<ManualResetEvent>();
            var list = new List<int>();
            int s = 0;
            EmailResponceInfo email = new EmailResponceInfo();
            try
            {
                EmailInput input = new EmailInput();

                // Main loop for different mail box
                foreach (var emlist in emailInfo.EmailInputList)
                {
                    //input = GetInput(emlist);

                    input.SourceFolder = emlist.SourceFolder;
                    //emailInfo.strname = "cts";
                    input.MailHeader = ExchangeConstants.NEW_LINE + "Mail Box Name:" + input.SourceFolder + ExchangeConstants.NEW_LINE;
                    // emailInfo.EMailId = "Megha.Patil@cognizant.com";
                    input.EMailId = emlist.EMailId;
                    input.IgnoreList = emlist.IgnoreList;
                    input.DestinationIgnoreFolder = emlist.DestinationIgnoreFolder;
                    // input.Mailfolderid = emlist.Mailfolderid;
                    input.MailHeader = emlist.MailHeader + ExchangeConstants.NEW_LINE + "S.No" + "," + "Action" + "," + "CaseId" + "," + "FolderName" + "," + "ActualEml" + "," + "TargetEml" + "," + "ReceivedDate" + "," + "CreatedDate" + ExchangeConstants.NEW_LINE;
                    input.TimeZone = ((emlist.TimeZone != null && emlist.TimeZone != "") ? (emlist.TimeZone) : "");

                    MainBoxInfo mainInfo = new MainBoxInfo();
                    mainInfo.ServiceExchangeUrl = emlist.ServiceExchangeUrl;
                    mainInfo.ClientExVersion = emlist.ClientExVersion;
                    mainInfo.Domain = emlist.Domain;
                    mainInfo.LoginEMailId = emlist.LoginEMailId;
                    mainInfo.Password = emlist.Password;

                    mainInfo = GetInput(mainInfo);


                    var resetEvent = new ManualResetEvent(false);

                    list.Add(s);
                    var processorcount = Environment.ProcessorCount;


                    ThreadPool.QueueUserWorkItem(
                         new WaitCallback(x =>
                         {

                             email = ReadAttachment(new EmailInput
                             {
                                 //Mailfolderid = input.Mailfolderid,
                                 SourceFolder = input.SourceFolder,
                                 EMailId = input.EMailId,
                                 LoginEMailId = mainInfo.LoginEMailId,
                                 TimeZone = input.TimeZone,
                                 service = mainInfo.service,
                                 IgnoreList = input.IgnoreList,
                                 DestinationIgnoreFolder = input.DestinationIgnoreFolder
                             }
                            );

                             resetEvent.Set();

                         }), list[s]);


                    doneEvents.Add(resetEvent);

                    s++;

                }

                WaitHandle.WaitAll(doneEvents.ToArray());
                objDataInfo.EmailResponseInfo = email;
                return objDataInfo;
                
            }

            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        /// <summary>
        /// it will read the mails from mail boxes
        /// </summary>
        /// <param name="threadState"></param>
        /// <returns></returns>
        public EmailResponceInfo ReadAttachment(object threadState)
        {
            EmailResponceInfo emailInfo = new EmailResponceInfo();
            //FindMailOutput findMailOutput = ReadMail(threadState);

            var emailBoxInfo = (EmailInput)threadState;
            // string intmailfolderid = emailBoxInfo.Mailfolderid;
            string EMailBoxId = emailBoxInfo.EMailId;
            string LoginEMailId = emailBoxInfo.LoginEMailId;
            string TimeZone = emailBoxInfo.TimeZone;
            ExchangeService service = emailBoxInfo.service;
            int rv = 0;

            try
            {

                string FileName = string.Empty;
                string strSubject = string.Empty;
                string BodyText = "";
                string strFrom = string.Empty;
                string objTo = string.Empty;
                string objCC = "";
                string objBCC = "";

                string folder = string.Empty;
                string mailPath = ConfigurationSettings.AppSettings["MailPath"];

                folder = mailPath;
                DateTime dtrec;
                ShowMessage("Searching E-mail, please wait...");

                //WellKnownFolderName SourceFolder = emailBoxInfo.SourceFolder;

                Mailbox EMailBox = new Mailbox(EMailBoxId);
                FolderId FolderId = new FolderId(emailBoxInfo.SourceFolder, EMailBox);
                FolderId RootFolderId = new FolderId(WellKnownFolderName.MsgFolderRoot, EMailBox);
                System.Threading.Thread.Sleep(2000);


                // View creation with Cap limit of reading mails in Received Date Asc order 
                var iv = new ItemView(30);
                iv.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Ascending);


                FindItemsResults<Item> foundItems = service.FindItems(FolderId, iv);

                //Folder readmailFolder = GetFolderFromName(service, emailBoxInfo.DestinationFolder, RootFolderId);
                System.Threading.Thread.Sleep(2000);

                Folder unreadmailFolder = GetFolderFromName(service, emailBoxInfo.DestinationIgnoreFolder, RootFolderId);

                string dtMailPullingStartTime = DateTime.Now.ToLongTimeString();

                int flag = 0;
                foreach (EmailMessage item in foundItems)
                {

                    item.Load();
                    strFrom = string.Empty;
                    objTo = string.Empty;
                    objCC = string.Empty;
                    objBCC = string.Empty;
                    BodyText = "";
                    strSubject = string.Empty;

                    string[] str = new string[50];

                    if (item is EmailMessage)
                    {
                        bool ReadMoved = false;

                        EmailMessage foundEmail = (EmailMessage)item;
                        EmailMessage message = EmailMessage.Bind(service, new ItemId(item.Id.ToString()), new PropertySet(BasePropertySet.FirstClassProperties, ItemSchema.Attachments, ItemSchema.Body));


                        dtrec = foundEmail.DateTimeReceived;

                        if (message.Subject != null)
                            strSubject = Convert.ToString(message.Subject);


                        string id = message.Id.UniqueId.ToString();

                        int ignoreFlag = 0;
                        foreach (var content in emailBoxInfo.IgnoreList)
                        {
                            if (strSubject.ToLower().Contains(content.Item))
                            {
                                ignoreFlag = 1;
                                break;
                            }
                        }

                        if (ignoreFlag == 0)
                        {

                            if (message.Body != null)
                                BodyText = Convert.ToString(message.Body);
                            if (message.From.Address != null)
                                strFrom = Convert.ToString(message.From.Address);
                            if (message.ToRecipients != null)
                            {
                                for (int j = 0; j < message.ToRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objTo = objTo + ";" + message.ToRecipients[j].Address;
                                    else
                                        objTo = message.ToRecipients[j].Address;
                                }
                            }
                            if (message.CcRecipients != null)
                            {
                                for (int j = 0; j < message.CcRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objCC = objCC + ";" + message.CcRecipients[j].Address;
                                    else
                                        objCC = message.CcRecipients[j].Address;
                                }
                            }

                            bool Priority = (message.Importance.ToString() == "Low" || message.Importance.ToString() == "Normal" ? false : true);

                            if (!Priority)
                            {
                                if (strSubject.ToLower().Contains("urgent"))
                                {
                                    Priority = true;
                                }
                            }

                            objBCC = string.Empty;

                            StringBuilder mailShortInfo = new StringBuilder();
                            mailShortInfo.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append("From: ");
                            mailShortInfo.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append(strFrom + "<br/>");
                            mailShortInfo.Append("<b>Sent: </b>" + message.DateTimeSent.ToLongDateString() + " " + message.DateTimeSent.ToShortTimeString() + "<br/>");
                            mailShortInfo.Append("<b>To: </b>" + objTo.ToString() + "<br/>");
                            if (objCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Cc: </b>" + objCC.ToString() + "<br/>");
                            }
                            if (objBCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Bcc: </b>" + objBCC.ToString() + "<br/>");
                            }
                            mailShortInfo.Append("<b>Subject: </b>" + strSubject.ToString());
                            if (Priority)
                                mailShortInfo.Append("<br/><b>Importance: </b>" + message.Importance.ToString());
                            mailShortInfo.Append("</span>");
                            mailShortInfo.Append("</p></div><br/>");

                            string LOAN = string.Empty;
                            string loanno = string.Empty;

                            // GET FROM,TO,CC,BCC,SUBJECT..

                            if (BodyText != null)
                            {
                                if (BodyText.Contains("<html"))
                                {
                                    BodyText = concat(BodyText.ToString(), mailShortInfo.ToString());
                                }
                                else
                                {
                                    BodyText = mailShortInfo.ToString() + BodyText.ToString();

                                    string st = BodyText;
                                    st = BodyText.Replace("\r\n", "<br/>");
                                    st = st.Replace("\n", "<br/>");
                                    st = st.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
                                    BodyText = st;
                                }

                                LOAN = GetStringInBetween("Loan no:", "Adr :", BodyText);
                                loanno = HTMLToText(LOAN);
                            }
                            else
                            {
                                BodyText = "";
                                LOAN = "";
                                loanno = "";
                            }

                            string newSubject = strSubject;
                            string strCaseID = string.Empty;

                            //Checking Inline Images/screenshots

                            string sourceText = BodyText;
                            var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                                  string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),

                                        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                        RegexOptions.Multiline);

                            List<string> imgSrcs = new List<string>();
                            foreach (Match match in imgSrcMatches)
                            {
                                string[] Names = match.Groups[1].Value.Split('@');

                                imgSrcs.Add(Names[0].Replace("cid:", ""));

                            }

                            try
                            {
                                //if (imgSrcs.Count > 0)
                                //{
                                //    for (int i = 0; i < imgSrcs.Count; i++)
                                //    {
                                //        if (imgSrcs[i].ToString().Contains("\\"))
                                //        {
                                //            imgSrcs[i] = imgSrcs[i].ToString().Replace("\\", "/");
                                //        }

                                //        var imgmatchs = System.Text.RegularExpressions.Regex.Matches(BodyText,
                                //            string.Format("<img.+?src=[\"'](cid:" + imgSrcs[i].ToString() + ".+?)[\"'].*?>"),
                                //            RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                //            RegexOptions.Multiline);

                                //        foreach (Match match in imgmatchs)
                                //        {

                                //            if (!imgSrcs[i].ToString().Contains(".png"))
                                //                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString() + ".png");
                                //            else
                                //                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString());

                                //            break;
                                //        }

                                //    }
                                //}

                            }
                            catch (Exception ex)
                            {
                               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                                throw;
                            }

                            CaseCreationInput caseCreation = new CaseCreationInput();

                            caseCreation.ReceivedDate = dtrec;
                            // caseCreation.MailFolderId = intmailfolderid;
                            caseCreation.Subject = strSubject;
                            caseCreation.Message = BodyText;
                            caseCreation.Sender = strFrom;
                            caseCreation.Toadd = objTo.ToString();
                            caseCreation.CCaddress = objCC.ToString();
                            caseCreation.BCCaddress = objBCC.ToString();
                            caseCreation.Priority = Priority;
                            caseCreation.GUID = id;


                            if (message.Attachments.Count > 0)
                            {
                                FileAttachment[] attachments = null;
                                attachments = new FileAttachment[message.Attachments.Count];
                                int screenshotNo = 0;

                                foreach (Attachment attachment in message.Attachments)
                                {
                                    try
                                    {
                                        if (attachment is FileAttachment)
                                        {
                                            FileAttachment fileAttachment = attachment as FileAttachment;
                                            System.Threading.Thread.Sleep(2000);
                                            
                                            fileAttachment.Load();
                                            byte[] NewMailFileAttachmentContentBytes = fileAttachment.Content;

                                            
                                            bool isScreenshot = false;
                                            string ScreenShotfileName = "";

                                            //for (int i = 0; i < imgSrcs.Count; i++)
                                            //{
                                            //    if (imgSrcs[i].ToString() == fileAttachment.Name.ToString())
                                            //    {
                                            //        isScreenshot = true;
                                            //        if (!imgSrcs[i].ToString().Contains(".png"))
                                            //            ScreenShotfileName = "cid:" + imgSrcs[i].ToString() + ".png";
                                            //        else
                                            //            ScreenShotfileName = "cid:" + imgSrcs[i].ToString();
                                            //        break;
                                            //    }
                                            //}

                                            if (NewMailFileAttachmentContentBytes != null)
                                            {

                                                if (isScreenshot)
                                                {
                                                    caseCreation.ScreenShotfileName = ScreenShotfileName;
                                                    caseCreation.MailFileAttachmentContentBytes = NewMailFileAttachmentContentBytes;

                                                }
                                                else
                                                {
                                                    caseCreation.FileAttachmentName = fileAttachment.Name.ToString();
                                                    caseCreation.MailFileAttachmentContentBytes = NewMailFileAttachmentContentBytes;
                                                }
                                            }

                                        }
                                        else if (attachment is ItemAttachment)
                                        {
                                            //  Load attachment into memory and write out the subject.
                                            ItemAttachment itemAttachment = attachment as ItemAttachment;
                                            System.Threading.Thread.Sleep(2000);

                                            itemAttachment.Load(ItemSchema.Attachments);
                                            System.Threading.Thread.Sleep(2000);

                                            itemAttachment.Load(ItemSchema.MimeContent);

                                            /*21Aug2014: End*/

                                            MimeContent mc = itemAttachment.Item.MimeContent;

                                            // Convert it to bytes
                                            byte[] ItemAttachmentContentBytes = mc.Content;
                                            // convert array of bytes into file

                                            string AttachName = itemAttachment.Name.Replace("\"", " ").Replace("*", " ").Replace(@"/", " ").Replace(@"\", " ").Replace(":", " ").Replace("<", " ").Replace(">", " ").Replace("?", " ").Replace("|", " ");


                                            // added by ranjith on 05/15/2015 for msg file to open in the processing page
                                            FileStream objfileStream = new FileStream(folder + @"\" + AttachName + ".eml", FileMode.Create);
                                            objfileStream.Write(ItemAttachmentContentBytes, 0, ItemAttachmentContentBytes.Length);
                                            objfileStream.Close();
                                            FileName = (folder + @"\" + AttachName + ".eml");
                                            //encrypt
                                            caseCreation.ItemAttachmentFileName = FileName;
                                            caseCreation.MailFileAttachmentContentBytes = System.IO.File.ReadAllBytes(FileName);

                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                      //  objlog.GetLoggingHandler("Log4net").LogException(ex);
                                        throw;
                                    }
                                }
                            }

                            CaseCreationInputList.Add(caseCreation);


                        }
                        else
                        {
                            item.Move(unreadmailFolder.Id);

                        }
                    }

                }
                // return result;
                emailInfo.CaseCreationInputList = CaseCreationInputList;
                return emailInfo;

            }
            catch (Exception ex)
            {
                //objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            finally
            {

            }

        }

        #region readMailBox

        public override DataTransferInfo ReadfromSource(EMailInfo EMailInfo)
        {
            EmailResponceInfo objResponse = new EmailResponceInfo();
            DataTransferInfo objDataInfo = new DataTransferInfo();
            objResponse = readMailBox(EMailInfo);
            objDataInfo.EmailResponseInfo = objResponse;
            objDataInfo.ResultMessage = "Case Created Successfully";
            return objDataInfo;
        }

        /// <summary>
        /// it will read the mail boxes
        /// </summary>
        /// <param name="emailInfo"></param>
        /// <returns></returns>
        public EmailResponceInfo readMailBox(EMailInfo emailInfo)
        {
            SecureString sec_strPassword = new SecureString();

            emailInfo.strMailStarHeader = ExchangeConstants.STAR;
            emailInfo.CurrentTime = Convert.ToString(DateTime.Now);
            emailInfo.strMailStarHeader = emailInfo.strMailStarHeader + ExchangeConstants.NEW_LINE + "RunTime: " + emailInfo.CurrentTime;
            //emailInfo.filename = string.Empty;
            string EntityName = emailInfo.GetType().Name;
            var doneEvents = new List<ManualResetEvent>();
            var list = new List<int>();
            int s = 0;
            EmailResponceInfo email = new EmailResponceInfo();
            try
            {
                EmailInput input = new EmailInput();

                // Main loop for different mail box
                foreach (var emlist in emailInfo.EmailInputList)
                {
                    //input = GetInput(emlist);

                    input.SourceFolder = emlist.SourceFolder;
                    //emailInfo.strname = "cts";
                    input.MailHeader = ExchangeConstants.NEW_LINE + "Mail Box Name:" + input.SourceFolder + ExchangeConstants.NEW_LINE;
                    // emailInfo.EMailId = "Megha.Patil@cognizant.com";
                    input.EMailId = emlist.EMailId;
                    input.IgnoreList = emlist.IgnoreList;
                    input.DestinationIgnoreFolder = emlist.DestinationIgnoreFolder;
                    // input.Mailfolderid = emlist.Mailfolderid;
                    input.MailHeader = emlist.MailHeader + ExchangeConstants.NEW_LINE + "S.No" + "," + "Action" + "," + "CaseId" + "," + "FolderName" + "," + "ActualEml" + "," + "TargetEml" + "," + "ReceivedDate" + "," + "CreatedDate" + ExchangeConstants.NEW_LINE;
                    input.TimeZone = ((emlist.TimeZone != null && emlist.TimeZone != "") ? (emlist.TimeZone) : "");

                    MainBoxInfo mainInfo = new MainBoxInfo();
                    mainInfo.ServiceExchangeUrl = emlist.ServiceExchangeUrl;
                    mainInfo.ClientExVersion = emlist.ClientExVersion;
                    mainInfo.Domain = emlist.Domain;
                    mainInfo.LoginEMailId = emlist.LoginEMailId;
                    mainInfo.Password = emlist.Password;

                    mainInfo = GetInput(mainInfo);


                    var resetEvent = new ManualResetEvent(false);

                    list.Add(s);
                    var processorcount = Environment.ProcessorCount;


                    ThreadPool.QueueUserWorkItem(
                         new WaitCallback(x =>
                         {

                             email = FindEmail(new EmailInput
                             {
                                 //Mailfolderid = input.Mailfolderid,
                                 SourceFolder = input.SourceFolder,
                                 EMailId = input.EMailId,
                                 LoginEMailId = mainInfo.LoginEMailId,
                                 TimeZone = input.TimeZone,
                                 service = mainInfo.service,
                                 IgnoreList = input.IgnoreList,
                                 DestinationIgnoreFolder = input.DestinationIgnoreFolder
                             }
                            );

                             resetEvent.Set();

                         }), list[s]);


                    doneEvents.Add(resetEvent);

                    s++;

                }

                WaitHandle.WaitAll(doneEvents.ToArray());
                return email;
            }

            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

            
        public MainBoxInfo GetInput(MainBoxInfo emlist)
        {
            SecureString sec_strPassword = new SecureString();
            MainBoxInfo input = new MainBoxInfo();
            input.ServiceExchangeUrl = emlist.ServiceExchangeUrl;

            input.LoginEMailId = emlist.LoginEMailId;



            input.Domain = emlist.Domain;
            input.ClientExVersion = emlist.ClientExVersion;

            // emailInfo.LoginEMailId = "391099";


            OutlookDataTransfer miscObj2 = new OutlookDataTransfer();
            sec_strPassword = miscObj2.convertToSecureString(emlist.Password);



           // Console.WriteLine("Connecting to Exchange Online, please wait...");

            if (input.ClientExVersion.ToString().Trim() == "Exchange2013_SP1")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
            }
            else if (input.ClientExVersion.ToString().Trim() == "Exchange2007_SP1")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
            }
            else if (input.ClientExVersion.ToString().Trim() == "Exchange2010")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2010);
            }
            else if (input.ClientExVersion.ToString().Trim() == "Exchange2010_SP1")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
            }
            else if (input.ClientExVersion.ToString().Trim() == "Exchange2010_SP2")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
            }
            else if (input.ClientExVersion.ToString().Trim() == "Exchange2013")
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2013);
            }
            else
            {
                input.service = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
            }

            OutlookDataTransfer miscObj1 = new OutlookDataTransfer();
            input.service.Url = new Uri(input.ServiceExchangeUrl);

            if (input.Domain.ToString() != "")
                input.service.Credentials = new WebCredentials(input.LoginEMailId, miscObj1.convertToUNSecureString(sec_strPassword), input.Domain.ToString());
            else
                input.service.Credentials = new WebCredentials(input.LoginEMailId, miscObj1.convertToUNSecureString(sec_strPassword));
            input.service.TraceEnabled = false;
            return input;

        }

        public EmailResponceInfo CheckForUniqueId(object threadState)
        {
            EmailResponceInfo email = new EmailResponceInfo();
            bool ReadMoved = false;
            var moveMailInfo = (MoveMailsInput)threadState;
            string EMailBoxId = moveMailInfo.EMailId;
            ExchangeService service = moveMailInfo.service;
            Mailbox EMailBox = new Mailbox(EMailBoxId);
            

            // WellKnownFolderName SourceFolder = moveMailInfo.SourceFolder;

            FolderId FolderId = new FolderId(moveMailInfo.SourceFolder, EMailBox);
            FolderId RootFolderId = new FolderId(WellKnownFolderName.MsgFolderRoot, EMailBox);
            var iv = new ItemView(30);
            iv.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Ascending);
             

            FindItemsResults<Item> foundItems = service.FindItems(FolderId, iv);

            Folder readmailFolder = GetFolderFromName(service, moveMailInfo.DestinationFolder, RootFolderId);

            foreach (EmailMessage item in foundItems)
            {
                if (item is EmailMessage)
                {
                    EmailMessage foundEmail = (EmailMessage)item;
                    EmailMessage message = EmailMessage.Bind(service, new ItemId(item.Id.ToString()), new PropertySet(BasePropertySet.FirstClassProperties, ItemSchema.Attachments, ItemSchema.Body));
                    foreach (var guidlist in moveMailInfo.GUIDList)
                    {
                        if (message.Id.UniqueId.ToString() == guidlist.GUID.ToString())
                        {
                            item.Move(readmailFolder.Id);

                            ReadMoved = true;
                        }
                    }
                    //if (message.Id.UniqueId.ToString() == "AAMkADFjZDNkOWI1LTA5OTgtNGFjMC05MDlhLWRjODRlY2RhYTQ2MwBGAAAAAABuc125JE6hTIouyJgWzaoVBwCiYoxeXlQWQLoqERrsprxpAAAA4QVSAACiYoxeXlQWQLoqERrsprxpAAAXpOznAAA=")
                    //{
                    //    item.Move(readmailFolder.Id);

                    //    ReadMoved = true;
                    //}
                }
            }
            if (!ReadMoved)
            {
                email.Result = "Mails are not available to Move !!!";
            }
            else
            {
                email.Result = "Success !!!";
            }
            return email;

        }

        /// <summary>
        /// it will read the mails from mail boxes
        /// </summary>
        /// <param name="threadState"></param>
        /// <returns></returns>
        public EmailResponceInfo FindEmail(object threadState)
        {
            EmailResponceInfo emailInfo = new EmailResponceInfo();
            //FindMailOutput findMailOutput = ReadMail(threadState);

            var emailBoxInfo = (EmailInput)threadState;
            // string intmailfolderid = emailBoxInfo.Mailfolderid;
            string EMailBoxId = emailBoxInfo.EMailId;
            string LoginEMailId = emailBoxInfo.LoginEMailId;
            string TimeZone = emailBoxInfo.TimeZone;
            ExchangeService service = emailBoxInfo.service;
            int rv = 0;

            try
            {

                string FileName = string.Empty;
                string strSubject = string.Empty;
                string BodyText = "";
                string strFrom = string.Empty;
                string objTo = string.Empty;
                string objCC = "";
                string objBCC = "";

                string folder = string.Empty;
                string mailPath = ConfigurationSettings.AppSettings["MailPath"];

                folder = mailPath;
                DateTime dtrec;
               // ShowMessage("Searching E-mail, please wait...");

                //WellKnownFolderName SourceFolder = emailBoxInfo.SourceFolder;

                Mailbox EMailBox = new Mailbox(EMailBoxId);
                FolderId FolderId = new FolderId(emailBoxInfo.SourceFolder, EMailBox);
                FolderId RootFolderId = new FolderId(WellKnownFolderName.MsgFolderRoot, EMailBox);
                System.Threading.Thread.Sleep(2000);


                // View creation with Cap limit of reading mails in Received Date Asc order 
                var iv = new ItemView(30);
                iv.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Ascending);


                FindItemsResults<Item> foundItems = service.FindItems(FolderId, iv);

                //Folder readmailFolder = GetFolderFromName(service, emailBoxInfo.DestinationFolder, RootFolderId);
                System.Threading.Thread.Sleep(2000);

                Folder unreadmailFolder = GetFolderFromName(service, emailBoxInfo.DestinationIgnoreFolder, RootFolderId);

                string dtMailPullingStartTime = DateTime.Now.ToLongTimeString();

                int flag = 0;
                foreach (EmailMessage item in foundItems)
                {

                    item.Load();
                    strFrom = string.Empty;
                    objTo = string.Empty;
                    objCC = string.Empty;
                    objBCC = string.Empty;
                    BodyText = "";
                    strSubject = string.Empty;

                    string[] str = new string[50];

                    if (item is EmailMessage)
                    {
                        bool ReadMoved = false;

                        EmailMessage foundEmail = (EmailMessage)item;
                        EmailMessage message = EmailMessage.Bind(service, new ItemId(item.Id.ToString()), new PropertySet(BasePropertySet.FirstClassProperties, ItemSchema.Attachments, ItemSchema.Body));


                        dtrec = foundEmail.DateTimeReceived;

                        if (message.Subject != null)
                            strSubject = Convert.ToString(message.Subject);


                        string id = message.Id.UniqueId.ToString();

                        int ignoreFlag = 0;
                        foreach (var content in emailBoxInfo.IgnoreList)
                        {
                            if (strSubject.ToLower().Contains(content.Item))
                            {
                                ignoreFlag = 1;
                                break;
                            }
                        }

                        if (ignoreFlag == 0)
                        {

                            if (message.Body != null)
                                BodyText = Convert.ToString(message.Body);
                            if (message.From.Address != null)
                                strFrom = Convert.ToString(message.From.Address);
                            if (message.ToRecipients != null)
                            {
                                for (int j = 0; j < message.ToRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objTo = objTo + ";" + message.ToRecipients[j].Address;
                                    else
                                        objTo = message.ToRecipients[j].Address;
                                }
                            }
                            if (message.CcRecipients != null)
                            {
                                for (int j = 0; j < message.CcRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objCC = objCC + ";" + message.CcRecipients[j].Address;
                                    else
                                        objCC = message.CcRecipients[j].Address;
                                }
                            }

                            bool Priority = (message.Importance.ToString() == "Low" || message.Importance.ToString() == "Normal" ? false : true);

                            if (!Priority)
                            {
                                if (strSubject.ToLower().Contains("urgent"))
                                {
                                    Priority = true;
                                }
                            }

                            objBCC = string.Empty;

                            StringBuilder mailShortInfo = new StringBuilder();
                            mailShortInfo.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append("From: ");
                            mailShortInfo.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append(strFrom + "<br/>");
                            mailShortInfo.Append("<b>Sent: </b>" + message.DateTimeSent.ToLongDateString() + " " + message.DateTimeSent.ToShortTimeString() + "<br/>");
                            mailShortInfo.Append("<b>To: </b>" + objTo.ToString() + "<br/>");
                            if (objCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Cc: </b>" + objCC.ToString() + "<br/>");
                            }
                            if (objBCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Bcc: </b>" + objBCC.ToString() + "<br/>");
                            }
                            mailShortInfo.Append("<b>Subject: </b>" + strSubject.ToString());
                            if (Priority)
                                mailShortInfo.Append("<br/><b>Importance: </b>" + message.Importance.ToString());
                            mailShortInfo.Append("</span>");
                            mailShortInfo.Append("</p></div><br/>");

                            string LOAN = string.Empty;
                            string loanno = string.Empty;

                            // GET FROM,TO,CC,BCC,SUBJECT..

                            if (BodyText != null)
                            {
                                if (BodyText.Contains("<html"))
                                {
                                    BodyText = concat(BodyText.ToString(), mailShortInfo.ToString());
                                }
                                else
                                {
                                    BodyText = mailShortInfo.ToString() + BodyText.ToString();

                                    string st = BodyText;
                                    st = BodyText.Replace("\r\n", "<br/>");
                                    st = st.Replace("\n", "<br/>");
                                    st = st.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
                                    BodyText = st;
                                }

                                LOAN = GetStringInBetween("Loan no:", "Adr :", BodyText);
                                loanno = HTMLToText(LOAN);
                            }
                            else
                            {
                                BodyText = "";
                                LOAN = "";
                                loanno = "";
                            }

                            string newSubject = strSubject;
                            string strCaseID = string.Empty;

                            //Checking Inline Images/screenshots

                            string sourceText = BodyText;
                            var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                                  string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),

                                        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                        RegexOptions.Multiline);

                            List<string> imgSrcs = new List<string>();
                            foreach (Match match in imgSrcMatches)
                            {
                                string[] Names = match.Groups[1].Value.Split('@');

                                imgSrcs.Add(Names[0].Replace("cid:", ""));

                            }

                            try
                            {
                                if (imgSrcs.Count > 0)
                                {
                                    for (int i = 0; i < imgSrcs.Count; i++)
                                    {
                                        if (imgSrcs[i].ToString().Contains("\\"))
                                        {
                                            imgSrcs[i] = imgSrcs[i].ToString().Replace("\\", "/");
                                        }

                                        var imgmatchs = System.Text.RegularExpressions.Regex.Matches(BodyText,
                                            string.Format("<img.+?src=[\"'](cid:" + imgSrcs[i].ToString() + ".+?)[\"'].*?>"),
                                            RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                            RegexOptions.Multiline);

                                        foreach (Match match in imgmatchs)
                                        {

                                            if (!imgSrcs[i].ToString().Contains(".png"))
                                                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString() + ".png");
                                            else
                                                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString());

                                            break;
                                        }

                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                                throw;
                            }

                            CaseCreationInput caseCreation = new CaseCreationInput();

                            caseCreation.ReceivedDate = dtrec;
                            // caseCreation.MailFolderId = intmailfolderid;
                            caseCreation.Subject = strSubject;
                            caseCreation.Message = BodyText;
                            caseCreation.Sender = strFrom;
                            caseCreation.Toadd = objTo.ToString();
                            caseCreation.CCaddress = objCC.ToString();
                            caseCreation.BCCaddress = objBCC.ToString();
                            caseCreation.Priority = Priority;
                            caseCreation.GUID = id;


                            if (message.Attachments.Count > 0)
                            {
                                FileAttachment[] attachments = null;
                                attachments = new FileAttachment[message.Attachments.Count];
                                int screenshotNo = 0;

                                foreach (Attachment attachment in message.Attachments)
                                {
                                    try
                                    {
                                        if (attachment is FileAttachment)
                                        {
                                            FileAttachment fileAttachment = attachment as FileAttachment;
                                            System.Threading.Thread.Sleep(2000);

                                            fileAttachment.Load();
                                            byte[] NewMailFileAttachmentContentBytes = fileAttachment.Content;


                                            bool isScreenshot = false;
                                            string ScreenShotfileName = "";

                                            for (int i = 0; i < imgSrcs.Count; i++)
                                            {
                                                if (imgSrcs[i].ToString() == fileAttachment.Name.ToString())
                                                {
                                                    isScreenshot = true;
                                                    if (!imgSrcs[i].ToString().Contains(".png"))
                                                        ScreenShotfileName = "cid:" + imgSrcs[i].ToString() + ".png";
                                                    else
                                                        ScreenShotfileName = "cid:" + imgSrcs[i].ToString();
                                                    break;
                                                }
                                            }

                                            if (NewMailFileAttachmentContentBytes != null)
                                            {

                                                if (isScreenshot)
                                                {
                                                    caseCreation.ScreenShotfileName = ScreenShotfileName;
                                                    caseCreation.MailFileAttachmentContentBytes = NewMailFileAttachmentContentBytes;

                                                }
                                                else
                                                {
                                                    caseCreation.FileAttachmentName = fileAttachment.Name.ToString();
                                                    caseCreation.MailFileAttachmentContentBytes = NewMailFileAttachmentContentBytes;
                                                }
                                            }

                                        }
                                        else if (attachment is ItemAttachment)
                                        {
                                            //  Load attachment into memory and write out the subject.
                                            ItemAttachment itemAttachment = attachment as ItemAttachment;
                                            System.Threading.Thread.Sleep(2000);

                                            itemAttachment.Load(ItemSchema.Attachments);
                                            System.Threading.Thread.Sleep(2000);

                                            itemAttachment.Load(ItemSchema.MimeContent);

                                            /*21Aug2014: End*/

                                            MimeContent mc = itemAttachment.Item.MimeContent;

                                            // Convert it to bytes
                                            byte[] ItemAttachmentContentBytes = mc.Content;
                                            // convert array of bytes into file

                                            string AttachName = itemAttachment.Name.Replace("\"", " ").Replace("*", " ").Replace(@"/", " ").Replace(@"\", " ").Replace(":", " ").Replace("<", " ").Replace(">", " ").Replace("?", " ").Replace("|", " ");


                                            // added by ranjith on 05/15/2015 for msg file to open in the processing page
                                            FileStream objfileStream = new FileStream(folder + @"\" + AttachName + ".eml", FileMode.Create);
                                            objfileStream.Write(ItemAttachmentContentBytes, 0, ItemAttachmentContentBytes.Length);
                                            objfileStream.Close();
                                            FileName = (folder + @"\" + AttachName + ".eml");
                                            //encrypt
                                            caseCreation.ItemAttachmentFileName = FileName;
                                            caseCreation.MailFileAttachmentContentBytes = System.IO.File.ReadAllBytes(FileName);

                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                       // objlog.GetLoggingHandler("Log4net").LogException(ex);
                                        throw;
                                    }
                                }
                            }

                            CaseCreationInputList.Add(caseCreation);


                        }
                        else
                        {
                            item.Move(unreadmailFolder.Id);

                        }
                    }

                }
                // return result;
                emailInfo.CaseCreationInputList = CaseCreationInputList;
                return emailInfo;

            }
            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            finally
            {

            }

        }

        public Folder GetFolderFromName(ExchangeService service, String FolderName, FolderId rfRootFolderId)
        {
            Folder rtReturnFolder = null;
            try
            {
                FolderView fvFolderView = new FolderView(1);
                SearchFilter sfSearchFilter = new SearchFilter.IsEqualTo(FolderSchema.DisplayName, FolderName);
                FindFoldersResults ffResults = service.FindFolders(rfRootFolderId, sfSearchFilter, fvFolderView);
                if (ffResults.TotalCount == 1)
                {
                    rtReturnFolder = ffResults.Folders[0];
                }
                else
                {
                    throw new Exception("Parent Folder not found");

                }
            }
            catch (Exception ex)
            {
              //  objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return rtReturnFolder;
        }

        /// <summary>
        /// SecureString Method
        /// </summary>
        /// <param name="strPassword"></param>
        /// <returns></returns>
        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        /// <summary>
        /// SecureString method to retrive the data
        /// </summary>
        /// <param name="secstrPassword"></param>
        /// <returns></returns>
        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        static void ShowMessage(string message)
        {
            //Console.Clear();
            //Console.WriteLine("************************************************");
            //Console.WriteLine(message);
            //Console.WriteLine("************************************************");
        }

        public string concat(string str, string insertstr)
        {
            string retst = string.Empty;
            try
            {
                if (str.Contains("<body"))
                {
                    int ln = str.Length;
                    int pos = str.LastIndexOf("<body ");
                    if (pos == -1)
                    {
                        pos = str.LastIndexOf("<body");
                    }
                    int strlen = 0;

                    if (ln > 0)
                    {
                        for (int i = pos; i < ln; i++)
                        {
                            strlen = strlen + 1;
                            if (str[i] == '>')
                                break;
                        }
                        retst = str.Substring(0, pos + strlen) + insertstr + str.Substring(pos + strlen);
                    }
                }
                else
                {
                    retst = insertstr + str;
                }
            }
            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            return retst;
        }

        public string GetStringInBetween(string strBegin, string strEnd, string strSource)
        {
            string result = "";
            try
            {
                int iIndexOfBegin = strSource.IndexOf(strBegin);
                if (iIndexOfBegin != -1)
                {
                    strSource = strSource.Substring(iIndexOfBegin + strBegin.Length);
                    int iEnd = strSource.IndexOf(strEnd);
                    if (iEnd != -1)
                    {
                        if (strEnd == "")
                            result = strSource;
                        else
                            result = strSource.Substring(0, iEnd);
                    }
                }
            }
            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            return result;
        }

        public static string HTMLToText(string HTMLCode)
        {
            // Remove new lines since they are not visible in HTML
            HTMLCode = HTMLCode.Replace("\n", " ");

            // Remove tab spaces
            HTMLCode = HTMLCode.Replace("\t", " ");

            // Remove multiple white spaces from HTML
            HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");

            // Remove HEAD tag
            HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Remove any JavaScript
            HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
              , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Replace special characters like &, <, >, " etc.
            StringBuilder sbHTML = new StringBuilder(HTMLCode);
            // Note: There are many more special characters, these are just
            // most common. You can add new characters in this arrays if needed
            string[] OldWords = { "&nbsp;", "&amp;", "&quot;", "&lt;", "&gt;", "&reg;", "&copy;", "&bull;", "&trade;", "&#8211;" };
            string[] NewWords = { " ", "&", "\"", "<", ">", "®", "©", "•", "™", "-" };
            for (int i = 0; i < OldWords.Length; i++)
            {
                sbHTML.Replace(OldWords[i], NewWords[i]);
            }

            // Check if there are line breaks (<br>) or paragraph (<p>)
            sbHTML.Replace("<br>", "\n<br>");
            sbHTML.Replace("<br ", "\n<br ");
            sbHTML.Replace("<p ", "\n<p ");

            // Finally, remove all HTML tags and return plain text
            return System.Text.RegularExpressions.Regex.Replace(
              sbHTML.ToString(), "<[^>]*>", "");
        }

        #endregion

        public override DataTransferInfo SavetoDestination()
        {
            throw new NotImplementedException();
        }
        #region TransformSourceDataInfo
        public override DataTransferInfo TransformSourceDataInfo(MoveMailsInfo MoveMailsInfo)
        {
            EmailResponceInfo objResponse = new EmailResponceInfo();
            DataTransferInfo objDataInfo = new DataTransferInfo();
            objResponse = MoveMails(MoveMailsInfo);
            objDataInfo.EmailResponseInfo = objResponse;
            return objDataInfo;
            
        }
        public EmailResponceInfo MoveMails(MoveMailsInfo emailInfo)
        {
            SecureString sec_strPassword = new SecureString();


            var doneEvents = new List<ManualResetEvent>();
            var list = new List<int>();
            int s = 0;
            EmailResponceInfo email = new EmailResponceInfo();
            try
            {
                MoveMailsInput input = new MoveMailsInput();

                // Main loop for different mail box
                foreach (var emlist in emailInfo.EmailInputList)
                {
                    // input = GetInput(emlist);
                    input.SourceFolder = emlist.SourceFolder;
                    input.EMailId = emlist.EMailId;
                    input.DestinationFolder = emlist.DestinationFolder;
                    input.GUIDList = emlist.GUIDList;
                    MainBoxInfo mainInfo = new MainBoxInfo();
                    mainInfo.ServiceExchangeUrl = emlist.ServiceExchangeUrl;
                    mainInfo.ClientExVersion = emlist.ClientExVersion;
                    mainInfo.Domain = emlist.Domain;
                    mainInfo.LoginEMailId = emlist.LoginEMailId;
                    mainInfo.Password = emlist.Password;

                    mainInfo = GetInput(mainInfo);

                    var resetEvent = new ManualResetEvent(false);

                    list.Add(s);
                    var processorcount = Environment.ProcessorCount;


                    ThreadPool.QueueUserWorkItem(
                                new WaitCallback(x =>
                                {
                                    email = CheckForUniqueId(new MoveMailsInput
                                    {
                                        SourceFolder = input.SourceFolder,
                                        EMailId = input.EMailId,
                                        service = mainInfo.service,
                                        DestinationFolder = input.DestinationFolder,
                                        GUIDList = input.GUIDList
                                    }
                                      );

                                    resetEvent.Set();

                                }), list[s]);


                    doneEvents.Add(resetEvent);

                    s++;

                }

                WaitHandle.WaitAll(doneEvents.ToArray());
                return email;
            }

            catch (Exception ex)
            {
               // objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        #endregion

        public override DataTransferInfo UploadToServer()
        {
            throw new NotImplementedException();
        }
    }
}
