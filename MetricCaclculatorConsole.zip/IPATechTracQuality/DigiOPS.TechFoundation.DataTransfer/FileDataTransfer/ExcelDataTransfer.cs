﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Data;
using System.Data.OleDb;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Configuration;
using System.IO;
using System.Collections;
using System.Web.UI;
namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :ExcelDataTransfer.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :ExcelDataTransfer
    // Author : Sadhesh
    // Creation Date : 5/22/2017
    // Purpose : Case Creation Through Excel 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //22-May-2017    Sadhesh     CreateCaseforSourceData            Added CreateCases method  
    //22-May-2017    Sadhesh     DownloadtoClient            Download the Excel or PDF  
    //22-May-2017    Sadhesh     ReadfromSource            Read content from source file 
    //22-May-2017    Sadhesh     SavetoDestination            Save file to destination path
    //22-May-2017    Sadhesh     TransformSourceDataInfo           TransformSourceDataInfo
    //22-May-2017    Sadhesh     UploadToServer            Save to server 
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class ExcelDataTransfer : BaseDocuDataTransfer
    {
        
        Log4NetLogger ProxyLogger = new Log4NetLogger();
        TransRecordData record = new TransRecordData();
        BaseEntity objBase = new BaseEntity();
        List<BaseEntity> baseList = null;
        ILoggingFactory objlog = new LoggingFactory();
        DigiOPS.TechFoundation.DataAccessLayer.CaseHandler objCaseHandler = new DigiOPS.TechFoundation.DataAccessLayer.CaseHandler();
        string ciphertext = "";//System.Configuration.ConfigurationSettings.AppSettings[Constants.CIPHERPASSWORD];
        private int CurrentSubProcessId = 0;
        DataSet ds = new DataSet();
        private string CurrentUserId = string.Empty;

        public override DataTransferInfo CreateCaseforSourceData(ExcelTemplate objExcelTemplate)
        {
            if (objExcelTemplate.FilePath != null)
            {
                return CreateCaseByFile(objExcelTemplate);
            }
            else
            {
                return CreateCaseByByte(objExcelTemplate);
            }
        }
        public DataTransferInfo CreateCaseByFile(ExcelTemplate objExcelTemplate)
        {
            DataTransferInfo objout = new DataTransferInfo();
            var fileName = Path.GetFileName(objExcelTemplate.FilePath);
            var fileExtension = Path.GetExtension(objExcelTemplate.FilePath);
            string filePath = Path.GetFullPath(objExcelTemplate.FilePath);
            FileStream fileStream = new FileStream(filePath, FileMode.Open);

          //  byte[] myByteArray = new byte[10];
           // MemoryStream stream = new MemoryStream(myByteArray);

            MemoryFile file = new MemoryFile(fileStream, "application/octet-stream", fileName + "" + fileExtension);

            string strMessage = string.Empty;
            OleDbConnection objConn = null;
            OleDbCommand objCmd = new OleDbCommand();
            OleDbDataAdapter objDA = new OleDbDataAdapter();
            DataTable dtTableName = null;
            DataTable dtColumnName = null;
            DataTable dt = new DataTable();
            string CurrentUserID = objExcelTemplate.CurrentUserID;
            int SubProcessId = int.Parse(objExcelTemplate.SubProcessId);
            bool flag = true;
            try
            {
                if (file != null && file.ContentLength > 0)
                {


                    if ((fileExtension == ".xls") || (fileExtension == ".xlsx"))
                    {
                        string date = Convert.ToString(System.DateTime.Now);
                        date = date.Replace("/", "_").Replace(":", "_");
                        DataSet dsUpload = new DataSet();
                        var Errorpath = "";
                        fileName = fileName.Insert(fileName.IndexOf('.'), "_" + "_" + date + "_" + CurrentUserID + "_" + Convert.ToString(SubProcessId));
                        if (!Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload"))
                        {
                            Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload");
                        }
                        var path = System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload\\" + fileName;// Server.MapPath(ConfigurationManager.AppSettings["BULK_UPLD_PATH"] + fileName);
                        // var path = objExcelTemplate.FilePath;
                        file.SaveAs(path);

                        //String connString = "Provider=Microsoft.ACE.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 4.0;HDR=YES;IMEX=1;ImportMixedTypes=Text;TypeGuessRows=0;'";
                        String connString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;Importmixedtypes=text;typeguessrows=0;\"", path);
                        fileName = fileName.Insert(fileName.IndexOf('.'), "_ErrorLog");
                        Errorpath = "";//Server.MapPath(ConfigurationManager.AppSettings["BULK_UPLD_ERROR_PATH"] + fileName);

                        objConn = new OleDbConnection(connString);
                        objConn.Open();

                        dtTableName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        //Array of restrictions {TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE}
                        dtColumnName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, new object[] { null, null, "Template$", null });
                        //dtColumnName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, null);


                        if (dtTableName.Rows.Count > 0)
                        {
                            DataRow[] TableName = dtTableName.Select("TABLE_NAME = 'Template$'");
                            if (TableName.Length == 0)
                            {
                                strMessage = "Sheet Name is incorrect!";
                            }
                            else
                            {
                                objCmd.Connection = objConn;

                                objCmd.CommandText = "SELECT * From [Template$]";

                                objDA.SelectCommand = objCmd;

                                objDA.Fill(dt);

                                dt.TableName = "Data";

                                DataView view = new DataView(dtColumnName);
                                view.Sort = "ORDINAL_POSITION";

                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    dt.Columns[i].ColumnName = dt.Columns[i].ColumnName;
                                }

                                string strExcelDataxml = string.Empty;
                                using (TextWriter writer = new StringWriter())
                                {
                                    dt.WriteXml(writer);
                                    strExcelDataxml = writer.ToString();
                                }

                                string strExcelColumn = "";
                                string strColumn = "";
                                int k = 0;

                                foreach (DataRow row in view.ToTable().Rows)
                                {
                                    string strcolummn = row["COLUMN_NAME"].ToString();

                                    if (row["DATA_TYPE"].ToString() == "7")
                                    {
                                        strExcelColumn = strExcelColumn + "[" + strcolummn + "]  Datetimeoffset" + " ,";
                                        strColumn = strColumn + "Cast(" + "[" + strcolummn + "] as datetime) as [" + strcolummn + "] ,";
                                    }
                                    else
                                    {
                                        strExcelColumn = strExcelColumn + "[" + strcolummn + "]  NVarchar(Max)" + " ,";
                                        strColumn = strColumn + "[" + strcolummn + "] ,";
                                    }
                                    k++;
                                }

                                strExcelColumn = strExcelColumn.TrimEnd(',');
                                strColumn = strColumn.TrimEnd(',');
                                string ActionType = "";
                                string dateformatcon = "MM/dd/yyyy";//Convert.ToString(Session["DateFormat"]);
                                string UploadType = "M";
                                int BulkUploadId = 0;
                                Hashtable hstbl = new Hashtable();

                                hstbl.Add("FilePath", path ?? string.Empty);
                                hstbl.Add("FileExtention", fileExtension ?? string.Empty);
                                hstbl.Add("SubProcessID", Convert.ToString(SubProcessId));
                                hstbl.Add("CurrentUserID", CurrentUserID ?? string.Empty);
                                hstbl.Add("ErrorPath", Errorpath ?? string.Empty);
                                hstbl.Add("StrExcelColumn", strExcelColumn ?? string.Empty);
                                hstbl.Add("StrColumn", strColumn);
                                //hstbl.Add("StrExcelDataxml", strExcelDataxml.Replace("'", "''"));
                                hstbl.Add("StrExcelDataxml", strExcelDataxml);
                                hstbl.Add("ActionType", ActionType ?? null);
                                hstbl.Add("DateFormatCon", dateformatcon ?? null);
                                hstbl.Add("UploadType", UploadType ?? null);
                                hstbl.Add("BulkUploadId", BulkUploadId);

                                CaseHandler ObjBALBlkUpld = new CaseHandler();


                                dsUpload = ObjBALBlkUpld.ExcelUploadToDB(hstbl);

                                int intRecords = dsUpload.Tables.Count;
                                
                                if (intRecords == 1)
                                {
                                    if (dsUpload.Tables[0].Rows.Count > 0)
                                    {
                                        //using (UltraWebGrid ExcelErrorGridView = new UltraWebGrid())
                                        //{
                                        for (int i = 0; i < dsUpload.Tables[0].Columns.Count; i++)
                                        {
                                            dsUpload.Tables[0].Columns[i].ColumnName = dsUpload.Tables[0].Columns[i].ColumnName;
                                        }
                                        //ICollaborationFactory objCollaboration = new CollaborationFactory();
                                        //objCollaboration.GetExcelHandler().WriteToHtmlFormatExcel(dsUpload.Tables[0], Errorpath, "Error.xls");
                                        //objCollaboration = null;

                                        strMessage = "File uploaded successfully with valid records only. Please refer Log !";
                                         flag = false ;
                                    }
                                    else
                                    {
                                        strMessage = "File uploaded Successfully!";
                                    }
                                }
                                else if (intRecords == 2)
                                {

                                    if (dsUpload.Tables[0].Rows.Count > 0)
                                    {
                                        if (dsUpload.Tables[0].Rows[0][1].ToString() != "")
                                        {
                                            flag = false;
                                            strMessage = "File not uploaded!" + " Please Check the Processed date format as (mm/dd/yyyy hh:mm), Number format, rest all should be in text format";
                                        }
                                        else
                                        {


                                            if (dsUpload.Tables[1].Rows.Count > 0)
                                            {
                                                if (dsUpload.Tables[1].Rows[0][0].ToString() == "")
                                                {
                                                    strMessage = "Invalid File!";
                                                    flag = false;
                                                }
                                                else
                                                {
                                                    flag = false;
                                                    strMessage = dsUpload.Tables[1].Rows[0][0].ToString();
                                                }
                                            }

                                        }
                                    }
                                    else
                                    {
                                        if (dsUpload.Tables[1].Rows.Count > 0)
                                            strMessage = dsUpload.Tables[1].Rows[0][0].ToString();
                                    }

                                }

                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                strMessage = ex.Message.ToString();
            }
            objout.ResultStatus = flag;
            objout.ResultMessage = strMessage;
            return objout;
        }

        public DataTransferInfo CreateCaseByByte(ExcelTemplate objExcelTemplate)
        {
            DataTransferInfo objout = new DataTransferInfo();
            var fileName = Path.GetFileName(objExcelTemplate.FileName);
            var fileExtension = Path.GetExtension(objExcelTemplate.FileName);
           // string filePath = Path.GetFullPath(objExcelTemplate.FilePath);
           // FileStream fileStream = new FileStream(filePath, FileMode.Open);

           // byte[] myByteArray = new byte[10];
            MemoryStream stream = new MemoryStream(objExcelTemplate.FileContent);

            MemoryFile file = new MemoryFile(stream, "application/octet-stream", fileName + "" + fileExtension);
            
            string strMessage = string.Empty;
            OleDbConnection objConn = null;
            OleDbCommand objCmd = new OleDbCommand();
            OleDbDataAdapter objDA = new OleDbDataAdapter();
            DataTable dtTableName = null;
            DataTable dtColumnName = null;
            DataTable dt = new DataTable();
            string CurrentUserID = objExcelTemplate.CurrentUserID;
            int SubProcessId = int.Parse(objExcelTemplate.SubProcessId);
            bool flag = true;
            try
            {
                if (file != null && file.ContentLength > 0)
                {


                    if ((fileExtension == ".xls") || (fileExtension == ".xlsx"))
                    {
                        string date = Convert.ToString(System.DateTime.Now);
                        date = date.Replace("/", "_").Replace(":", "_");
                        DataSet dsUpload = new DataSet();
                        var Errorpath = "";
                        fileName = fileName.Insert(fileName.IndexOf('.'), "_" + "_" + date + "_" + CurrentUserID + "_" + Convert.ToString(SubProcessId));

                        if (!Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload"))
                        {
                            Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload");
                        }

                        var path = System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload\\" + fileName;// Server.MapPath(ConfigurationManager.AppSettings["BULK_UPLD_PATH"] + fileName);
                        // var path = objExcelTemplate.FilePath;
                        file.SaveAs(path);

                        //String connString = "Provider=Microsoft.ACE.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 4.0;HDR=YES;IMEX=1;ImportMixedTypes=Text;TypeGuessRows=0;'";
                        String connString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;Importmixedtypes=text;typeguessrows=0;\"", path);
                        fileName = fileName.Insert(fileName.IndexOf('.'), "_ErrorLog");
                        Errorpath = "";//Server.MapPath(ConfigurationManager.AppSettings["BULK_UPLD_ERROR_PATH"] + fileName);

                        objConn = new OleDbConnection(connString);
                        objConn.Open();

                        dtTableName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        //Array of restrictions {TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE}
                        dtColumnName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, new object[] { null, null, "Template$", null });
                        //dtColumnName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, null);


                        if (dtTableName.Rows.Count > 0)
                        {
                            DataRow[] TableName = dtTableName.Select("TABLE_NAME = 'Template$'");
                            if (TableName.Length == 0)
                            {
                                strMessage = "Sheet Name is incorrect!";
                            }
                            else
                            {
                                objCmd.Connection = objConn;

                                objCmd.CommandText = "SELECT * From [Template$]";

                                objDA.SelectCommand = objCmd;

                                objDA.Fill(dt);

                                dt.TableName = "Data";

                                DataView view = new DataView(dtColumnName);
                                view.Sort = "ORDINAL_POSITION";

                                for (int i = 0; i < dt.Columns.Count; i++)
                                {
                                    dt.Columns[i].ColumnName = dt.Columns[i].ColumnName;
                                }

                                string strExcelDataxml = string.Empty;
                                using (TextWriter writer = new StringWriter())
                                {
                                    dt.WriteXml(writer);
                                    strExcelDataxml = writer.ToString();
                                }

                                string strExcelColumn = "";
                                string strColumn = "";
                                int k = 0;

                                foreach (DataRow row in view.ToTable().Rows)
                                {
                                    string strcolummn = row["COLUMN_NAME"].ToString();

                                    if (row["DATA_TYPE"].ToString() == "7")
                                    {
                                        strExcelColumn = strExcelColumn + "[" + strcolummn + "]  Datetimeoffset" + " ,";
                                        strColumn = strColumn + "Cast(" + "[" + strcolummn + "] as datetime) as [" + strcolummn + "] ,";
                                    }
                                    else
                                    {
                                        strExcelColumn = strExcelColumn + "[" + strcolummn + "]  NVarchar(Max)" + " ,";
                                        strColumn = strColumn + "[" + strcolummn + "] ,";
                                    }
                                    k++;
                                }

                                strExcelColumn = strExcelColumn.TrimEnd(',');
                                strColumn = strColumn.TrimEnd(',');
                                string ActionType = "";
                                string dateformatcon = "MM/dd/yyyy";//Convert.ToString(Session["DateFormat"]);
                                string UploadType = "M";
                                int BulkUploadId = 0;
                                Hashtable hstbl = new Hashtable();

                                hstbl.Add("FilePath", path ?? string.Empty);
                                hstbl.Add("FileExtention", fileExtension ?? string.Empty);
                                hstbl.Add("SubProcessID", Convert.ToString(SubProcessId));
                                hstbl.Add("CurrentUserID", CurrentUserID ?? string.Empty);
                                hstbl.Add("ErrorPath", Errorpath ?? string.Empty);
                                hstbl.Add("StrExcelColumn", strExcelColumn ?? string.Empty);
                                hstbl.Add("StrColumn", strColumn);
                                //hstbl.Add("StrExcelDataxml", strExcelDataxml.Replace("'", "''"));
                                hstbl.Add("StrExcelDataxml", strExcelDataxml);
                                hstbl.Add("ActionType", ActionType ?? null);
                                hstbl.Add("DateFormatCon", dateformatcon ?? null);
                                hstbl.Add("UploadType", UploadType ?? null);
                                hstbl.Add("BulkUploadId", BulkUploadId);

                                CaseHandler ObjBALBlkUpld = new CaseHandler();


                                dsUpload = ObjBALBlkUpld.ExcelUploadToDB(hstbl);

                                int intRecords = dsUpload.Tables.Count;
                                strMessage = "File uploaded Successfully!";
                                if (intRecords == 1)
                                {
                                    if (dsUpload.Tables[0].Rows.Count > 0)
                                    {
                                        //using (UltraWebGrid ExcelErrorGridView = new UltraWebGrid())
                                        //{
                                        for (int i = 0; i < dsUpload.Tables[0].Columns.Count; i++)
                                        {
                                            dsUpload.Tables[0].Columns[i].ColumnName = dsUpload.Tables[0].Columns[i].ColumnName;
                                        }
                                        //ICollaborationFactory objCollaboration = new CollaborationFactory();
                                        //objCollaboration.GetExcelHandler().WriteToHtmlFormatExcel(dsUpload.Tables[0], Errorpath, "Error.xls");
                                        //objCollaboration = null;

                                        strMessage = "File uploaded successfully with valid records only. Please refer Log !";
                                        flag = false;
                                    }
                                    else
                                    {
                                        strMessage = "File uploaded Successfully!";
                                    }
                                }
                                else if (intRecords == 2)
                                {

                                    if (dsUpload.Tables[0].Rows.Count > 0)
                                    {
                                        if (dsUpload.Tables[0].Rows[0][1].ToString() != "")
                                        {
                                            flag = false;
                                            strMessage = "File not uploaded!" + " Please Check the Processed date format as (mm/dd/yyyy hh:mm), Number format, rest all should be in text format";
                                        }
                                        else
                                        {


                                            if (dsUpload.Tables[1].Rows.Count > 0)
                                            {
                                                if (dsUpload.Tables[1].Rows[0][0].ToString() == "")
                                                {
                                                    strMessage = "Invalid File!";
                                                    flag = false;
                                                }
                                                else
                                                {
                                                    flag = false;
                                                    strMessage = dsUpload.Tables[1].Rows[0][0].ToString();
                                                }
                                            }

                                        }
                                    }
                                    else
                                    {
                                        //if (dsUpload.Tables[1].Rows.Count > 0)
                                        //    strMessage = dsUpload.Tables[1].Rows[0][0].ToString();
                                    }

                                }

                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                strMessage = ex.Message.ToString();
            }
            finally
            {
               // strMessage = string.Empty;
                if (objConn != null)
                {
                    objConn.Close();
                    objConn.Dispose();
                }
                if (objCmd != null)
                {
                    objCmd.Dispose();
                }

                if (objCmd != null)
                {
                    objCmd.Dispose();
                }

                if (dtTableName != null)
                {
                    dtTableName.Dispose();
                }

                if (dtColumnName != null)
                {
                    dtColumnName.Dispose();
                }

                if (dt != null)
                {
                    dt.Dispose();
                }

            }
            objout.ResultStatus = flag;
            objout.ResultMessage = strMessage;
            return objout;
        }


        #region DownloadtoClient
        public override DataTransferInfo DownloadtoClient(string filePath, string sheetName, DataTransferInfo dataTransferInfo)
        {
            //string filename = dataTransferInfo.InputExcelFilePath;
            //string sheetName = dataTransferInfo.ExcelSheetName;
            dataTransferInfo.DataTable = ImportExcelToDataTable(filePath, sheetName, dataTransferInfo);

            return dataTransferInfo;
        }
        private DataTable ImportExcelToDataTable(string filePath, string sheetName, DataTransferInfo dataTransferInfo)
        {
            DataTable dtResult = null;
            var pathToExcel = filePath;// @"D:\IAE\Sample.xlsx";
            var connectionString = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES""", pathToExcel);
            try
            {
                using (OleDbConnection oleDbConnection = new OleDbConnection(connectionString))
                {
                    oleDbConnection.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    OleDbDataAdapter oleda = new OleDbDataAdapter();
                    DataSet ds = new DataSet();
                    DataTable dt = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    sheetName = sheetName + "$";//"Sheet1$";
                    cmd.Connection = oleDbConnection;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM [" + sheetName + "]";
                    oleda = new OleDbDataAdapter(cmd);
                    oleda.Fill(ds);
                    dtResult = ds.Tables[0];
                    oleDbConnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message);
            }
            return dtResult;
        }

        #endregion

        #region ReadfromSource
        public override DataTransferInfo ReadfromSource(CaseCreationInfo CaseCreationInfo)
        {
            DataTransferInfo objDataTransferInfoout = new DataTransferInfo();
            List<TransactionListView> objlistView = RetrieveTransactions(CaseCreationInfo);
            objDataTransferInfoout.objTransactionListView = objlistView;

            return objDataTransferInfoout;
        }

        public List<TransactionListView> RetrieveTransactions(CaseCreationInfo casecreationinfo)
        {
            casecreationinfo.sortOrder = null;
            casecreationinfo.sortColumn = null;
            casecreationinfo.startRowIndex = null;
            casecreationinfo.message = "";
            //CaseCreationInfo casecreationinfo  = new CaseCreationInfo();
            List<TransactionListView> objlistTrans = new List<TransactionListView>();
            objlistTrans = Retrieve(casecreationinfo);
            return objlistTrans;
            //return PartialView(Constants.Partial_TRANSACTIONS, GetTransactionsList(sortOrder, sortColumn, startRowIndex, message));
        }

        private List<TransactionListView> Retrieve(CaseCreationInfo casecreationinfo)
        {
            string sortOrder = null; string sortColumn = null; int? startRowIndex = null; string message = "";
            List<TransactionListView> obj = new List<TransactionListView>();
            try
            {
                int maximumRows = 0;
                BaseEntity objBase = new BaseEntity();
                TransactionListView objData = new TransactionListView();

                if (casecreationinfo.SUBPROCESSID != null)//httpContext.ApplicationInstance.Session[Constants.SUBPROCESSID] != null)
                {
                    CurrentSubProcessId = Convert.ToInt32(casecreationinfo.SUBPROCESSID);//httpContext.ApplicationInstance.Session[Constants.SUBPROCESSID]);
                }
                else
                {
                    CurrentSubProcessId = 0;
                }
                if (casecreationinfo.SYSUSERID != null)//.ApplicationInstance.Session[Constants.SYSUSERID] != null)
                {
                    CurrentUserId = Convert.ToString(casecreationinfo.SYSUSERID);//httpContext.ApplicationInstance.Session[Constants.SYSUSERID]);
                }
                else
                {
                    CurrentUserId = "0";
                }

                int LoggedInUserId = Convert.ToInt32(CurrentUserId);

                maximumRows = Convert.ToInt16(ConfigurationSettings.AppSettings[Constants.PAGESIZE]);
                objData.SortColumn = !(string.IsNullOrEmpty(sortColumn)) ? sortColumn : Constants.DEFAULT_SORTCOLUMN_RECORDID;
                objData.SubProcessId = CurrentSubProcessId;
                objData.StartRowIndex = startRowIndex.HasValue ? startRowIndex.Value : 1;
                objData.SortOrder = !(string.IsNullOrEmpty(sortOrder)) ? sortOrder : Constants.DEFAULT_ORDERBY;
                objData.MaximumRows = maximumRows;
                objData.CurrentUserID = Convert.ToInt16(CurrentUserId);
                // objBase = (TransactionListViewModal)objData;
                //// objBase = (TransactionListViewModal)objData;
                // objBase.CurrentUserID = LoggedInUserId;
                // TransactionListViewModal objTrans = (TransactionListViewModal)objBase;
                ds = objCaseHandler.GetTransactionList(objData);
                if (ds.Tables.Count != 0)
                {
                    if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
                    {
                        if (ds.Tables[0].Rows.Count <= 0)
                            return null;
                        else
                            baseList = MapToTransactionList(ds);
                    }
                }

                //List<BaseTransportEntity> objBaseList = objBAL.GetEntityList(objBase);

                obj = baseList.Cast<TransactionListView>().ToList();


                if (obj.Any())
                {
                    obj[0].StartRowIndex = startRowIndex.HasValue ? startRowIndex.Value : 1;
                    obj[0].SortOrder = !(string.IsNullOrEmpty(sortOrder)) ? sortOrder : Constants.DEFAULT_ORDERBY;
                    obj[0].SortColumn = !(string.IsNullOrEmpty(sortColumn)) ? sortColumn : Constants.DEFAULT_SORTCOLUMN_RECORDID;
                    obj[0].MaximumRows = maximumRows;
                    obj[0].CustomMessage = message;
                }
            }
            // catch (ConfigurationErrorsException ex)
            //{
            //    ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            //}
            catch (InvalidCastException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentNullException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (NullReferenceException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return obj;
        }

        internal List<BaseEntity> MapToTransactionList(DataSet ds)
        {
            ProxyLogger.Log.Info(" Transaction List to Entity List - Calling.");
            string ciphertext = System.Configuration.ConfigurationSettings.AppSettings["CIPHERPASSWORD"];
            List<BaseEntity> baseEntityList = new List<BaseEntity>();
            TransactionListViewList transactionList = new TransactionListViewList();

            int columncnt = ds.Tables[0].Columns.Count;
            bool flag = false;
            int i;
            TransactionListView transaction;
            string type = "";
            foreach (DataRow dr in (ds.Tables[0].Rows))
            {
                i = 0;
                transaction = new TransactionListView();
                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    type = (dc.DataType).FullName;

                    if (dc.ColumnName == "TotalRows")
                    {
                        if (!flag)
                        {
                            transaction.TotalRows = Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i]);
                            flag = true;
                        }
                    }
                    else
                    {
                        switch (type)
                        {
                            case "System.Int32":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.Int64":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToInt64(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.Int16":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToInt16(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.String":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
                                break;
                            case "System.Boolean":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToBoolean(dr[i] == DBNull.Value ? false : dr[i])));
                                break;
                            case "System.Object":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
                                break;
                            case "System.DateTime":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTime.Parse(dr[i].ToString()).ToString())));
                                break;
                            case "System.smalldatetime":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTime.Parse(dr[i].ToString()).ToString())));
                                break;
                            case "System.DateTimeOffset":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTimeOffset.Parse(dr[i].ToString()).DateTime.ToString())));
                                break;
                            case "System.Bit":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToBoolean(dr[i] == DBNull.Value ? false : dr[i])));
                                break;
                            case "System.Decimal":
                                transaction.TransactionList.Add(new TransList(dc.ColumnName, Convert.ToDecimal(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            default:
                                ProxyLogger.Log.Info("Unable to map the datatype (" + type + ") to list in TransactionCreationMapper.MapToTransactionList.");
                                break;
                        }
                    }
                    i = i + 1;
                }
                transactionList.TransactionLists.Add(transaction);
            }
            baseEntityList = transactionList.TransactionLists.Cast<BaseEntity>().ToList();
            //  proxyLogger.Log.Info(" Transaction List to Entity List - Called.");
            return baseEntityList;
        }

        #endregion

        public override DataTransferInfo SavetoDestination()
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo TransformSourceDataInfo(DataTransferInfo dataTransferinfo)
        {
            DataTransferInfo objDataTransferInfoout = new DataTransferInfo();
            Export(dataTransferinfo);
            objDataTransferInfoout.Message = "Created Successfully";
            return objDataTransferInfoout;
        }

        #region UploadToServer
        public override DataTransferInfo UploadToServer(CaseCreationInfo CaseCreationInfo)
        {
            DataTransferInfo objDataTransferInfoout = Update(CaseCreationInfo);

            return objDataTransferInfoout;
        }

        public DataTransferInfo Update(CaseCreationInfo casecreationinfo)
        {
            DataTransferInfo objDataTransferout = new DataTransferInfo();
            string Search = "";
            string result = null;
            int subprocessid = CurrentSubProcessId;
            string subprocess = string.Empty;
            string RecordNum = casecreationinfo.UpdateTransactionRecordId;
            string action = Constants.EDIT;
            try
            {
                if (Search == "")
                {
                    Search = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(Search, ciphertext));
                }
                RecordNum = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(RecordNum.ToString(), ciphertext));
                subprocess = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(subprocessid.ToString(), ciphertext));
                action = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(action.ToString(), ciphertext));

                List<TransRecordData> lstRecord = new List<TransRecordData>();
                StringBuilder sb = new StringBuilder();
                string viewname = objBase.ViewName;
                record = (TransRecordData)objBase;
                lstRecord.Add(record);
                int RecordId = record.RecordId;

                sb.Append("<root>");

                foreach (TransRecordData item in lstRecord)
                {
                    sb.Append(item.ToXml());
                }
                sb.Append("</root>");
                result = objCaseHandler.SetTransRecordData("UPDATE", sb.ToString(), RecordId, viewname);

                //if (Request.IsAjaxRequest())
                //{
                //   // return Json(new { redirectToUrl = Url.Action("Home", new { SubProcessId = subprocess, RecordId = RecordNum, ActionName = action, SearchPage = Search }) });
                //}


            }
            catch (InvalidCastException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentNullException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (NullReferenceException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            //  RedirectToAction("Home", new { SubProcessId = subprocess, RecordId = RecordNum, ActionName = action, SearchPage = Search });
            //return result;
            objDataTransferout.ResultMessage = result;
            return objDataTransferout;
        }

        #endregion

        public void Export(DataTransferInfo dataTransferinfo)
        {
            switch (dataTransferinfo.ExcelExportType.ToString())
            {
                case "Html":
                    {
                        WriteToHtmlFormatExcel(dataTransferinfo);
                        break;
                    }
                case "Excel":
                    {
                        WriteToOLEDBExcel(dataTransferinfo);
                        break;
                    }
            }
        }
        private void WriteToHtmlFormatExcel(DataTransferInfo dataTransferInfo)
        {
            string sTab = "";
            StringBuilder sbResponse = new StringBuilder();

            try
            {
                DataTable dtExcelData = dataTransferInfo.DataTable;
                string storePath = dataTransferInfo.DestinationExcelFilePath;
                string sheetName = dataTransferInfo.ExcelSheetName;
                using (StringWriter sWData = new StringWriter(sbResponse))
                {
                    using (HtmlTextWriter hTextWriter = new HtmlTextWriter(sWData))
                    {
                        if (dtExcelData != null)
                        {
                            hTextWriter.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN "">");
                            //hTextWriter.Write("<meta charset='UTF-8'>");
                            hTextWriter.Write("<meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>");
                            hTextWriter.Write("<font style='font-size:10.5pt; font-family:Calibri;'>");
                            hTextWriter.Write("<BR><BR><BR>");
                            hTextWriter.Write("<Table name='" + sheetName + "' border='1' bgColor='#106A86' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.5pt; font-family:Calibri; background:#EEEEEE;'> <TR>");
                            if (dtExcelData.Rows.Count > 0)
                            {
                                sTab = "";
                                foreach (DataColumn dtColumn in dtExcelData.Columns)
                                {
                                    hTextWriter.Write("<Td bgColor='#106A86'>");
                                    hTextWriter.Write("<B>");
                                    hTextWriter.Write("<font color='#FFFFFF'>" + System.Web.HttpUtility.HtmlEncode(sTab + dtColumn.ColumnName) + "</font>");
                                    sTab = "\t";
                                    hTextWriter.Write("</B>");
                                    hTextWriter.Write("</Td>");
                                }

                                hTextWriter.Write("</TR>");

                                foreach (DataRow dRow in dtExcelData.Rows)
                                {
                                    hTextWriter.Write("<TR>");

                                    sTab = "";
                                    for (int j = 0; j < dtExcelData.Columns.Count; j++)
                                    {
                                        hTextWriter.Write("<Td>");
                                        hTextWriter.Write(System.Web.HttpUtility.HtmlEncode(sTab + Convert.ToString(dRow[j])));
                                        sTab = "\t";
                                        hTextWriter.Write("</Td>");
                                    }

                                    hTextWriter.Write("</TR>");
                                }
                            }
                            else
                            {
                                hTextWriter.Write("<Td bgColor='#106A86'>");
                                hTextWriter.Write("<B>");
                                hTextWriter.Write("<font color='#FFFFFF'>No records found</font>");
                                hTextWriter.Write("</B>");
                                hTextWriter.Write("</Td>");
                                hTextWriter.Write("</TR>");
                            }

                            hTextWriter.Write("</Table>");
                            hTextWriter.Write("</font>");

                        }
                        else
                        {
                            dataTransferInfo.ErrorMessage = new StringBuilder();
                            dataTransferInfo.ErrorMessage.Append("WriteToHtmlFormatExcel :: dtExcelData is null");
                        }

                        using (System.IO.TextWriter tWriteToExcelFile = new System.IO.StreamWriter(storePath))
                        {
                            tWriteToExcelFile.Write(sbResponse.ToString());
                            tWriteToExcelFile.Flush();
                            tWriteToExcelFile.Close();
                        }
                    }
                    sWData.Dispose();
                    sWData.Close();
                }
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);

            }
            finally
            {
                if (sbResponse != null)
                    sbResponse = null;

                sTab = null;

                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }


        private void WriteToOLEDBExcel(DataTransferInfo dataTransferInfo)
        {
            string connString = string.Empty;
            string sqlInsert = string.Empty;
            string sqlCreate = string.Empty;
            try
            {
                DataTable dtExcelData = dataTransferInfo.DataTable;
                string storePath = dataTransferInfo.DestinationExcelFilePath;
                string sheetName = dataTransferInfo.ExcelSheetName + "$";

                //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + storePath + ";Extended Properties='Excel 12.0;ReadOnly=False;HDR=YES;'";
                connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0 Xml;HDR=YES;'", storePath);

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();

                    DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    //conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    if (schemaTable.Rows.Count > 0)
                    {
                        DataRow schemaRow = schemaTable.Rows[0];
                        string sheet = schemaRow["TABLE_NAME"].ToString();

                        if (!sheet.EndsWith("_"))
                        {
                            using (OleDbCommand cmd = new OleDbCommand())
                            {
                                cmd.Connection = conn;

                                sqlInsert = GetSQLString(dtExcelData, sheetName, "INSERT", dataTransferInfo);
                                if (!string.IsNullOrWhiteSpace(sqlInsert))
                                {
                                    cmd.CommandText = sqlInsert;
                                    cmd.ExecuteNonQuery();
                                }

                                cmd.Dispose();
                            }
                        }
                    }
                    else
                    {
                        using (OleDbCommand cmd = new OleDbCommand())
                        {
                            cmd.Connection = conn;
                            sqlCreate = GetSQLString(dtExcelData, sheetName, "CREATE", dataTransferInfo);
                            if (!string.IsNullOrWhiteSpace(sqlCreate))
                            {
                                cmd.CommandText = sqlCreate;
                                cmd.ExecuteNonQuery();
                            }

                            sqlInsert = GetSQLString(dtExcelData, sheetName, "INSERT", dataTransferInfo);
                            if (!string.IsNullOrWhiteSpace(sqlInsert))
                            {
                                cmd.CommandText = sqlInsert;
                                cmd.ExecuteNonQuery();
                            }

                            cmd.Dispose();
                        }
                    }
                    conn.Close();
                }
            }
            catch (OleDbException ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                connString = null;
                sqlInsert = null;
                sqlCreate = null;
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        private string GetSQLString(DataTable dtExcelData, string sheetName, string type, DataTransferInfo dataTransferInfo)
        {
            string sColumnName = string.Empty;
            string sRowValue = string.Empty;
            string sqlSnippet = string.Empty;

            try
            {
                if (dtExcelData != null && dtExcelData.Rows.Count >= 1)
                {
                    if (type == "INSERT")
                    {
                        sqlSnippet = string.Format("INSERT INTO [{0}] (", sheetName);

                        foreach (DataColumn dcTemplate in dtExcelData.Columns)
                        {
                            if (string.IsNullOrWhiteSpace(sColumnName))
                                sColumnName = "[" + dcTemplate.ColumnName + "]";
                            else
                                sColumnName = sColumnName + ", [" + dcTemplate.ColumnName + "]";
                        }
                        sqlSnippet = string.Format("{0}{1}) VALUES (", sqlSnippet, sColumnName);

                        foreach (DataRow drTemplate in dtExcelData.Rows)
                        {
                            if (string.IsNullOrWhiteSpace(sRowValue))
                            {
                                for (int j = 0; j < dtExcelData.Columns.Count; j++)
                                {
                                    if (string.IsNullOrWhiteSpace(sRowValue))
                                    {
                                        //sRowValue = "'" + HttpContext.Current.Server.HtmlEncode(Convert.ToString(drTemplate[j])) + "'";
                                        sRowValue = "'" + Convert.ToString(drTemplate[j]) + "'";
                                    }
                                    else
                                    {
                                        //sRowValue = sRowValue + ", '" + HttpContext.Current.Server.HtmlEncode(Convert.ToString(drTemplate[j])) + "'";
                                        sRowValue = sRowValue + ", '" + Convert.ToString(drTemplate[j]) + "'";
                                    }
                                }
                            }
                        }
                        sqlSnippet = string.Format("{0}{1}) ", sqlSnippet, sRowValue);
                    }
                    else
                    {
                        sqlSnippet = string.Empty;
                        if (!string.IsNullOrWhiteSpace(sheetName) && sheetName.Length > 1)
                        {
                            sqlSnippet = string.Format("CREATE TABLE [{0}] (", sheetName.Substring(0, sheetName.Length - 1));

                            foreach (DataColumn dcTemplate in dtExcelData.Columns)
                            {
                                if (string.IsNullOrWhiteSpace(sColumnName))
                                    sColumnName = "[" + dcTemplate.ColumnName + "] TEXT";
                                else
                                    sColumnName = sColumnName + ", [" + dcTemplate.ColumnName + "] TEXT";
                            }
                            sqlSnippet = string.Format("{0}{1})", sqlSnippet, sColumnName);
                        }
                    }
                }
                else
                {
                    dataTransferInfo.ErrorMessage = new StringBuilder();
                    dataTransferInfo.ErrorMessage.Append("WriteToOLEDBExcel :: GetSQLString :: dtExcelData is null");
                }
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                sColumnName = null;
                sRowValue = null;
            }
            return sqlSnippet;
        }

    }
}
