﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseCaseCreation.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :BaseCaseCreation
    // Author : Megha
    // Creation Date : 5/9/2017
    // Purpose : base class of the EMTCaseCreation, TrackworkCaseCreation and CaseHandling
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //9-May-2017    Megha     CreateCases            Added CreateCases method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class BaseCaseCreation : ICaseCreation
    {
        ILoggingFactory objlog = new LoggingFactory();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eInfo"></param>
        public virtual void CaseUpdation(CaseCreationInput eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {

        }

      

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eInfo"></param>
        /// <returns></returns>
      public string validateInput(CaseCreationInput eInfo)
      {         
          return null;
      }
            
        /// <summary>
        /// 
        /// </summary>
        /// <param name="casecreationinfo"></param>
        /// <returns></returns>
      public virtual string Update(CaseCreationInfo casecreationinfo)
      {
          return null;
      }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="casecreationinfo"></param>
        /// <returns></returns>
      public virtual string Delete(CaseCreationInfo casecreationinfo)
      {
          return null;
      }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="casecreationinfo"></param>
      public virtual void Search(CaseCreationInfo casecreationinfo)
      {
          
      }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="casecreationinfo"></param>
      public virtual void Purge(CaseCreationInfo casecreationinfo)
      {
         
      }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="elementdata"></param>
        /// <returns></returns>
      public virtual string CreateCases(ElementDatas elementdata)
      {
          string ErrorMessage = string.Empty;

          try
          {
              if (elementdata==null)
              {
                  ErrorMessage = "Email info Cannot be null ! \n";

              }
              else if (elementdata.CreationType.ToUpper().Trim() != "QUART")
              {
                  ErrorMessage = "Case Creation Type should not be null and it Should be QUART ! \n";
              }
              if (ErrorMessage != "")
              {
                  return ErrorMessage;
              }
          }
          catch (Exception ex)
          {
              objlog.GetLoggingHandler("Log4net").LogException(ex);
              throw;
          }
          return ErrorMessage;
      }
     
    }


}
