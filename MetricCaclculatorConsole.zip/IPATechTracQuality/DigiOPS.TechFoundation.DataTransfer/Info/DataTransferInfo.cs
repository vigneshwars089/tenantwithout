﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public class DataTransferInfo : BaseInfo
    {
        public string AppName { get; set; }
        public string ResultMessage { get; set; }
        public DataTable DataTable { get; set; }
        public string InputExcelFilePath { get; set; }
        public string DestinationExcelFilePath { get; set; }
        public string ExcelSheetName { get; set; }
        public string ExcelExportType { get; set; }
        public EmailResponceInfo EmailResponseInfo { get; set; }
        public List<TransactionListView> objTransactionListView { get; set; }
    }
    
    public struct S_DataTransferExcelTypes
    {
        public const string Excel = "Excel";
    }

    public struct S_DataTransferPDFTypes
    {
        public const string PDF = "PDF";
    }

    public struct s_DataTransferExcelExportTypes
    {
        public const string Html = "Html";
        public const string Excel = "Excel";
    }

    public class ExcelTemplate
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string SubProcessId { get; set; }
        public string CurrentUserID { get; set; }
        public byte[] FileContent { get; set; }
        public string AppID { get; set; }

    }


    public class MemoryFile : HttpPostedFileBase
    {
        Stream stream;
        string contentType;
        string fileName;

        public MemoryFile(Stream stream, string contentType, string fileName)
        {
            this.stream = stream;
            this.contentType = contentType;
            this.fileName = fileName;
        }

        public override int ContentLength
        {
            get { return (int)stream.Length; }
        }

        public override string ContentType
        {
            get { return contentType; }
        }

        public override string FileName
        {
            get { return fileName; }
        }

        public override Stream InputStream
        {
            get { return stream; }
        }

        public override void SaveAs(string filename)
        {
            using (var file = File.Open(filename, FileMode.CreateNew))
                stream.CopyTo(file);
        }
    }
}
