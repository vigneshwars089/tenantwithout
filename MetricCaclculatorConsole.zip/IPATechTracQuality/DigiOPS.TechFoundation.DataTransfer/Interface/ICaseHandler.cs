﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface ICaseHandler
      {
       // string Create(ElementDatas elementdata);
       // //List<TransactionListViewModal> RetrieveTransactions(CaseCreationInfo casecreationinfo);
       //// List<TransactionListViewModal> Retrieve(CaseCreationInfo casecreationinfo);
       // string Update(CaseCreationInfo casecreationinfo);
       // string Delete(CaseCreationInfo casecreationinfo);
       // void Search(CaseCreationInfo casecreationinfo);
       // void Purge(CaseCreationInfo casecreationinfo);
        

    }
}
