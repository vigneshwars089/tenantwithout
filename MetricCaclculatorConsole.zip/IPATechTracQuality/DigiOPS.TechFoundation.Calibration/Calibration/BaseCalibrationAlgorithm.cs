﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
    public class BaseCalibrationAlgorithm : ICalibrationAlgorithm
    {

        public virtual ScoringOutput GetCalibartionScore(CalibrationScoreInfo objCalScoreInfo)
        {
            return null;
        }
        public ScoringOutput CalibrationValidation(CalibrationScoreInfo objCalScoreInfo)
        {
            ScoringOutput objOutput = new ScoringOutput();
            objOutput.ResultStatus = false;
            objOutput.ErrorMessage = new StringBuilder();

            int flag = 0;

            CalibrationDetailsEntity objCalDetails = new CalibrationDetailsEntity();

            if (objCalScoreInfo==null)
            {
                objOutput.ErrorMessage.Append("Calibration Entity can not be Null.");
                objOutput.ResultStatus = false;
                return objOutput;
            }
            else if ((objCalScoreInfo._calibrationType.ToUpper().Trim() == "" || String.IsNullOrEmpty(objCalScoreInfo._calibrationType.ToUpper().Trim())))
            {
                objOutput.ErrorMessage.Append("Calibration Type is Not Provided.");
                objOutput.ResultStatus = false;
                return objOutput;

            }           
            else
            {
                if ((objCalScoreInfo._calibrationType.ToUpper().Trim() == "CONFIGURED" || objCalScoreInfo._calibrationType.ToUpper().Trim() == "RUNTIME"))
                {
                    if (objCalScoreInfo._calibrationType.ToUpper().Trim() == "CONFIGURED")
                    {
                        if (objCalScoreInfo.CombinedAccuracyList.Count() == 0)
                        {
                            flag = 3;
                        }
                        else
                        {
                            foreach (var item in objCalScoreInfo.CombinedAccuracyList)
                            {
                                objCalDetails.InternalRatingId = item.InternalRatingId;
                                objCalDetails.ExternalRatingId = item.ExternalRatingId;
                                objCalDetails.CriticalityType = item.CriticalityType;

                                if (objCalDetails.InternalRatingId == 0 || objCalDetails.ExternalRatingId == 0 || objCalDetails.CriticalityType == "" || String.IsNullOrEmpty(objCalDetails.CriticalityType))
                                {
                                    flag = 1;
                                }
                               
                            }
                        }
                        
                    }
                    else if (objCalScoreInfo._calibrationType.ToUpper().Trim() == "RUNTIME")
                    {
                        foreach (var item in objCalScoreInfo.CombinedAccuracyList)
                        {                           
                            objCalDetails.CriticalityType = item.CriticalityType;

                            if (objCalDetails.CriticalityType == "" || String.IsNullOrEmpty(objCalDetails.CriticalityType))
                            {
                                flag = 1;
                            }
                            
                        }                 
                    }
                   
                    if(flag==3)
                    {
                        objOutput.ErrorMessage.Append("Combined Accuracy List is Not Provided");
                        objOutput.ResultStatus = false;
                    }
                    else if (flag == 1)
                    {
                        objOutput.ErrorMessage.Append("Internal Rating ID / External Rating ID / Criticality Type is not provided");
                        objOutput.ResultStatus = false;
                    }                    
                    else if(flag==0)
                    {
                        objOutput = GetCalibartionScore(objCalScoreInfo);
                        objOutput.ResultStatus = true;
                    }
                   
                }
                else
                {
                    objOutput.ErrorMessage.Append("Calibration Type is not in the Standard Format.");
                    objOutput.ResultStatus = false;
                }

            }
            return objOutput;
        }

    }
}
