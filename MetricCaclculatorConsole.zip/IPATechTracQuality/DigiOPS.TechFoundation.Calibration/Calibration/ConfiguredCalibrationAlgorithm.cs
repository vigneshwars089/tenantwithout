﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
  public class ConfiguredCalibrationAlgorithm: BaseCalibrationAlgorithm
    {
      public override ScoringOutput GetCalibartionScore(CalibrationScoreInfo objCalScoreInfo)
      {
         
          ScoringOutput objScoringOutput = new ScoringOutput();

          List<CalibrationDetailsEntity> CombinedAuditedList = (from c in objCalScoreInfo.IntAuditedList
                                                                join d in objCalScoreInfo.ExtAuditedList on c.DOId equals d.DOId
                                                                select new CalibrationDetailsEntity
                                                            {
                                                               DOId=c.DOId,
                                                               ParentDOId=c.ParentDOId,
                                                               DOGroupID=c.DOGroupID,
                                                               InternalRatingId=c.SelectedRatingId,
                                                               ExternalRatingId=d.SelectedRatingId
                                                            }).ToList();

          List<DetailsEntity> FinalAuditedList = (from config in objCalScoreInfo.CombinedAccuracyList
                                                       join comb in CombinedAuditedList
                                                       on new { config.DOGroupID, config.InternalRatingId, config.ExternalRatingId }
                                                       equals new { comb.DOGroupID, comb.InternalRatingId, comb.ExternalRatingId }
                                                  select new DetailsEntity
                                                       {
                                                           //DOId=comb.DOId,
                                                           ParentDOId=comb.ParentDOId,
                                                           DOGroupID=comb.DOGroupID,
                                                           //InternalRatingId=comb.InternalRatingId,
                                                           //ExternalRatingId=comb.ExternalRatingId,
                                                           //CombinedRatingId=config.CombinedRatingId,
                                                           MaxWeightage=config.MaxWeightage,
                                                           GivenWeightage=config.GivenWeightage,
                                                          // DefectNA=config.DefectNA,
                                                           CriticalityType=config.CriticalityType,
                                                           GroupWeightage=config.GroupWeightage,
                                                           //CalculatedGroupWeightage=config.CalculatedGroupWeightage

                                                       }
                                                       ).ToList();
          ScoringInfo scoInfo = new ScoringInfo();
          scoInfo.AuditedList = FinalAuditedList;

          scoInfo._IsCriticalApp = objCalScoreInfo._IsCriticalApp;
          scoInfo._strScoringLogic = objCalScoreInfo._strScoringLogic;
          scoInfo._strAuditlogic = objCalScoreInfo._strAuditlogic;

          IScoringAlgorithmFactory fs = new ScoringAlgorithmFactory();
          IScoringAlgorithm score = fs.GetScoringHandler(scoInfo);

          objScoringOutput = score.Validation(scoInfo);

          return objScoringOutput;
      }
    }
}
