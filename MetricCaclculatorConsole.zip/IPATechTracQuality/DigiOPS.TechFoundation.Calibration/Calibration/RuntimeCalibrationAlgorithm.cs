﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
   public class RuntimeCalibrationAlgorithm: BaseCalibrationAlgorithm
    {
       public override ScoringOutput GetCalibartionScore(CalibrationScoreInfo objCalScoreInfo)
       {
           
           ScoringOutput objScoringOutput = new ScoringOutput();

           List<DetailsEntity> FinalAuditedList = (from config in objCalScoreInfo.CombinedAccuracyList                                                
                                                   
                                                   select new DetailsEntity
                                                   {
                                                       //DOId = config.DOId,
                                                       ParentDOId = config.ParentDOId,
                                                       DOGroupID = config.DOGroupID,
                                                       MaxWeightage = config.MaxWeightage,
                                                       GivenWeightage = config.GivenWeightage,
                                                      // DefectNA = config.DefectNA,
                                                       CriticalityType = config.CriticalityType,
                                                       GroupWeightage = config.GroupWeightage,
                                                     //  CalculatedGroupWeightage = config.CalculatedGroupWeightage
                                                   }
                                                   ).ToList();

           ScoringInfo scoInfo = new ScoringInfo();
           scoInfo.AuditedList = FinalAuditedList;
           scoInfo._strScoringLogic = objCalScoreInfo._strScoringLogic;
           scoInfo._strAuditlogic = objCalScoreInfo._strAuditlogic;

           IScoringAlgorithmFactory fs = new ScoringAlgorithmFactory();
           IScoringAlgorithm score = fs.GetScoringHandler(scoInfo);
           objScoringOutput = score.Validation(scoInfo);

           return objScoringOutput;
       }
    }
}
