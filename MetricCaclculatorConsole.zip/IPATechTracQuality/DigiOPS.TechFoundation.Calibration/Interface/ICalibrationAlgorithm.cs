﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Calibration;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
   public interface ICalibrationAlgorithm
    {
      // ScoringOutput GetCalibartionScore(CalibrationScoreInfo objCalScoreInfo);
       ScoringOutput CalibrationValidation(CalibrationScoreInfo objCalScoreInfo);
    }
}
