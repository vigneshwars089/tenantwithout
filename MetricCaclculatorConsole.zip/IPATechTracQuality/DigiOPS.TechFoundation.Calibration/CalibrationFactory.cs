﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Calibration
{

    public struct S_calibrationType
    {

        public const string Configure = "CONFIGURED";
        public const string Runtime = "RUNTIME";
       
    }

    public class CalibrationFactory : ICalibrationFactory
    {
        public ICalibrationAlgorithm GetCalibratorHandler(CalibrationScoreInfo objCalScoreInfo)
       {
           if (objCalScoreInfo==null)
           {
               return new BaseCalibrationAlgorithm();
           }
           else if (objCalScoreInfo._calibrationType == "" || String.IsNullOrEmpty(objCalScoreInfo._calibrationType))
           {
               return new BaseCalibrationAlgorithm();
           }
           else if (objCalScoreInfo._calibrationType.ToUpper().Trim() != "CONFIGURED" && objCalScoreInfo._calibrationType.ToUpper().Trim() != "RUNTIME")
           {
               return new BaseCalibrationAlgorithm();
           }
           else
           {
               switch (objCalScoreInfo._calibrationType.ToUpper().Trim())
               {
                   case S_calibrationType.Configure:
                       return new ConfiguredCalibrationAlgorithm();
                   case S_calibrationType.Runtime:
                       return new RuntimeCalibrationAlgorithm();
                   default:
                       return null;
               }
               
           }
           
       
       }
    }
}
