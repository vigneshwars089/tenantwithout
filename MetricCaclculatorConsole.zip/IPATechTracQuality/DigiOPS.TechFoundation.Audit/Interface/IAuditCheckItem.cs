﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Audit
{
    public interface IAuditCheckItem
    {
        string AddAuditCheckItems(AuditCheckItemsInfo objDo);
        string CopyDefOpp(CheckItemEntity objDo);
        List<AuditConfigEntity> GetAuditCheckItems(AuditConfigEntity objaudconfig);
        List<CheckItemEntity> GetDefectOppList(CheckItemEntity objDo);
        AuditCheckItemsInfo GetCTQItems(AuditCheckItemsInfo objDo);
        List<RootCauseEntity> GetRCList(RootCauseEntity objsubDo);
        string SetRootCause(RootCauseEntity objsubDo);
        string SetAuditRatingandGroup(AuditRatingInfo AuditRatingInfo);
        string AddeditDefectOpportunity(CheckItemEntity objDo);
        string SetAuditRating(RatingEntity objrating);
        List<RatingEntity> GetAuditRating(RatingEntity objratingentity);

        string SetAuditRatingGroup(RatingGroupEntity objratinggrp);
        List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp);
        List<RatingEntity> GetRatingList(RatingEntity objratingentity);

        List<CombinedAccuracyEntity> GetAuditDetailList(CombinedAccuracyEntity caEntity);
        List<List<CombinedAccuracyEntity>> GetAuditRatingList(CombinedAccuracyEntity caEntity);
        string SetCombinedAccuracy(CombinedAccuracyEntity caEntity);
    }
}

