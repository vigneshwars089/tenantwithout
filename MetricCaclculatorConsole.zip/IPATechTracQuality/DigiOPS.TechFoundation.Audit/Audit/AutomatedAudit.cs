﻿
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Audit
{
    public class AutomatedAudit : IAutomatedAudit
    {

        AudotmatedAuditDataAccess objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess();

        //public List<DataElementEntity> GetTransactionFromAllSource(DataElementInfo objdataeleinfo)
        // {
        //   List<DataElementEntity> objdataeleentlist = new List<DataElementEntity>();
        //    List<List<DataElementEntity>> objlist = new List<List<DataElementEntity>>();
        //  //  DataElementInfo objdelmntinfo = new DataElementInfo();
        //    objlist = obj.GetConfigurationHandler("Manual", "DataElementConfiguration").GetDataElements(objdataeleinfo);
        //    objdataeleentlist = objlist[0];
        //    return objdataeleentlist;
        // }

        public List<ServiceOutput> AuditDataElements(List<DataelementAutomatedAuditEntity> ExpectedParamlist, List<DataelementAutomatedAuditEntity> ActualParamlist)
        {
            //  List<List<ServiceOutput>> objlistlistop = new List<List<ServiceOutput>>();
            List<ServiceOutput> objlistop = new List<ServiceOutput>();
            ServiceOutput objoutput = new ServiceOutput();
            DataelementAutomatedAuditEntity ActualParam = new DataelementAutomatedAuditEntity();
            DataelementAutomatedAuditEntity ExpectedParam = new DataelementAutomatedAuditEntity();
            string exp = string.Empty;
            string actual = string.Empty;
            if (ExpectedParamlist != null && ActualParamlist != null)
            {
                if (ExpectedParamlist.Count == ActualParamlist.Count)
                {
                    for (int j = 0; j < ActualParamlist.Count(); j++)
                    {
                        ActualParam = ActualParamlist[j];
                        ExpectedParam = ExpectedParamlist[j];
                        int c = ExpectedParam.GetType().GetProperties().Count();

                        var propsOfExpected = ExpectedParam.GetType().GetProperties();

                        if (ActualParam.ElementId == ExpectedParam.ElementId)
                        {
                            object ex = ExpectedParam.ElementData;//propsOfExpected[0].GetValue(ExpectedParam, null);

                            object ac = ActualParam.ElementData;//propsOfExpected[0].GetValue(ActualParam, null);
                            if (ex != null && ac != null)
                            {
                                exp = ex.ToString();
                                actual = ac.ToString();
                            }
                            objoutput = new ServiceOutput();
                            objoutput.ElementId = ActualParam.ElementId;//propsOfExpected[0].Name;
                            objoutput.RecordID = ActualParam.RecordId;
                            if (ex == null || ac == null)
                            {
                                if (ex == null && ac == null)
                                    objoutput.Comments = "Both Input's are null";
                                else if (ex == null)
                                    objoutput.Comments = "Expected Field is null";
                                else
                                    objoutput.Comments = "Actual Field is null";
                                objoutput.ResultStatus = false;
                                objlistop.Add(objoutput);
                            }
                            else if (exp == actual)
                            {

                                objoutput.ActualValue = actual;
                                objoutput.ExpectedValue = exp;
                                objoutput.ResultStatus = true;
                                objlistop.Add(objoutput);
                            }
                            else
                            {

                                objoutput.ActualValue = actual;
                                objoutput.ExpectedValue = exp;
                                objoutput.ResultStatus = false;
                                objlistop.Add(objoutput);
                            }
                        }


                    }
                }//objlistlistop.Add(objlistop);
            }
            return objlistop;
        }

        public List<List<DataelementAutomatedAuditEntity>> GetDataElementBasedonSource(int RecordID)
        {
            List<List<DataelementAutomatedAuditEntity>> objdataeleentlist = new List<List<DataelementAutomatedAuditEntity>>();
            objdataeleentlist = objAudotmatedAuditdataaccess.GetDataElement(RecordID);
            return objdataeleentlist;
        }

        public List<DataelementAutomatedAuditEntity> AutoAuditFindingData(int RecordID)
        {
            List<DataelementAutomatedAuditEntity> objdataeleentlist = new List<DataelementAutomatedAuditEntity>();
            objdataeleentlist = objAudotmatedAuditdataaccess.GetAutoAuditFindingData(RecordID);
            return objdataeleentlist;
        }

        public int InsertintoAuditFindingData(List<ServiceOutput> objservoutlist)
        {
            int result = 0;
            //  foreach (var a in objservoutlist)
            result = objAudotmatedAuditdataaccess.SetAutoAuditedElement(objservoutlist);
            return result;
        }
        public int InsertintoAuditFindingDataStatus(ServiceOutput objservoutlist)
        {
            int result = 0;
            //  foreach (var a in objservoutlist)
            result = objAudotmatedAuditdataaccess.SetAutoAuditedElementStatus(objservoutlist);
            return result;
        }





    }
}
