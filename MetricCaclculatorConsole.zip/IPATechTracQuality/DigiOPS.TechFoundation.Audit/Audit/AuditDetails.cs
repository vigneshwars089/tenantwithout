﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;
//using System.Web.UI;

////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :AuditDetails.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :AuditDetails
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This method is used to get audit details.
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////

namespace DigiOPS.TechFoundation.Audit
{
    public class AuditDetails:IAuditDetails
    {

        AuditDetailsDataAccess addao = new AuditDetailsDataAccess();

        public  List<List<AuditDetailsEntity>> GetAuditDetails(AuditDetailsEntity objauddet)
        {
           
           return addao.GetAuditDetails(objauddet);
        }
        public List<SubDefectDetailsEntity> GetRCList(SubDefectDetailsEntity objsubdo)
        {
            return addao.GetRCList(objsubdo);
        }

        public  AuditDOEntity GetAuditDeleteStatus(AuditDOEntity objauditdo)
        {
            return addao.GetAuditDeleteStatus(objauditdo);
        }

        public bool IsAttachmentRequired(AuditDOEntity objauditdo)
        {
            return addao.IsAttachmentRequired(objauditdo);
        }
        public  AuditDOEntity GetQCStatus(AuditDOEntity objauditdo)
        {
            return addao.GetQCStatus(objauditdo);

       }

        public  string SetAuditDetails(AuditDOEntity objAuditDetailsEntity)
        {
            return addao.SetAuditDetails(objAuditDetailsEntity);
        }

   
       
    }
}
