﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :ManualCombinedAccuracy.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :ManualCombinedAccuracy
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to configure CombinedAccuracy .
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{


    public class ManualCombinedAccuracy : BaseAuditCheckItem
    {
        CombinedAccuracyDataAccess caDAOCA = new CombinedAccuracyDataAccess();

        public override List<CombinedAccuracyEntity> GetAuditDetailList(CombinedAccuracyEntity caEntity)
        {
            
                return caDAOCA.GetAuditDetailList(caEntity);
            
        }


        public override List<List<CombinedAccuracyEntity>> GetAuditRatingList(CombinedAccuracyEntity caEntity)
        {
           
            return caDAOCA.GetAuditRatingList(caEntity);
        }

        public override string SetCombinedAccuracy(CombinedAccuracyEntity caEntity)
        {
            return caDAOCA.SetCombinedAccuracy(caEntity);
        }

        
    }
}
