﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Logging;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :ManualRootCause.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :ManualRootCause
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to configure RootCause .
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public class ManualRootCause : BaseAuditCheckItem
    {
        RootCauseDataAccess doDAO = new RootCauseDataAccess();
        
        public override string SetRootCause(RootCauseEntity objsubDo)
        {
            return doDAO.SetRootCause(objsubDo);

        }
        public override List<RootCauseEntity> GetRCList(RootCauseEntity objsubDo)
        {

            return doDAO.GetRCList(objsubDo);
        }
      
    }
}
