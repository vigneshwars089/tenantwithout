﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseAuditCheckItem.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :BaseAuditCheckItem
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will declare fourteen virtual methods which will be implemented by ManualAuditRating,ManualCheckitem,ManualCombinedAccuracy and ManualRootCause for configuring checkitems. 
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public class BaseAuditCheckItem : IAuditCheckItem
    {
        public virtual string AddAuditCheckItems(AuditCheckItemsInfo objDo)
        {
            return null;
        }
        public virtual string CopyDefOpp(CheckItemEntity objDo)
        {
            return null;
        }
        public virtual string AddeditDefectOpportunity(CheckItemEntity objDo)
        {

            return null;

        }
        public virtual AuditCheckItemsInfo GetCTQItems(AuditCheckItemsInfo objDo)
        {
            return null;
        }
        public virtual List<AuditConfigEntity> GetAuditCheckItems(AuditConfigEntity objaudconfig)
        {
            return null;
        }
        public virtual List<CheckItemEntity> GetDefectOppList(CheckItemEntity objDo)
        {
            return null;
        }
        public virtual List<RootCauseEntity> GetRCList(RootCauseEntity objsubDo)
        {
            return null;
        }
        public virtual string SetRootCause(RootCauseEntity objsubDo)
        {
            return null;
        }

        public virtual string SetAuditRating(RatingEntity objrating)
        {
            throw new NotImplementedException();
        }
        public virtual string SetAuditRatingandGroup(AuditRatingInfo AuditRatingInfo)
        {
            throw new NotImplementedException();
        }

        public virtual List<RatingEntity> GetAuditRating(RatingEntity objratingentity)
        {
            throw new NotImplementedException();
        }

        public virtual string SetAuditRatingGroup(RatingGroupEntity objratinggrp)
        {
            throw new NotImplementedException();
        }

        public virtual List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp)
        {
            throw new NotImplementedException();
        }

        public virtual List<RatingEntity> GetRatingList(RatingEntity objratingentity)
        {
            throw new NotImplementedException();
        }

        public virtual List<CombinedAccuracyEntity> GetAuditDetailList(CombinedAccuracyEntity caEntity)
        {
            throw new NotImplementedException();
        }

        public virtual List<List<CombinedAccuracyEntity>> GetAuditRatingList(CombinedAccuracyEntity caEntity)
        {
            throw new NotImplementedException();
        }

        public virtual string SetCombinedAccuracy(CombinedAccuracyEntity caEntity)
        {
            throw new NotImplementedException();
        }
    }
}
