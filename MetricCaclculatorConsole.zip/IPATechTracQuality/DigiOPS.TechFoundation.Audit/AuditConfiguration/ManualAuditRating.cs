﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :ManualAuditRating.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :ManualAuditRating
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to configure AuditRating .
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public class ManualAuditRating : BaseAuditCheckItem
    {
        RatingDataAccess ratingdao = new RatingDataAccess();
        //RatingEntity objratingentity = new RatingEntity();
        // RatingGroupEntity objratinggrp = new RatingGroupEntity();
        string result = string.Empty;
        //DataTable _dt = new DataTable();

        //List<string> l1 = new List<string>();

        public override string SetAuditRating(RatingEntity objrating)
        {

            return ratingdao.SetAuditRating(objrating);

        }
        public override string SetAuditRatingandGroup(AuditRatingInfo AuditRatingInfo)
        {

            return ratingdao.SetRatings(AuditRatingInfo);

        }
        public override string SetAuditRatingGroup(RatingGroupEntity objratgrp)
        {

            return ratingdao.SetAuditRatingGroup(objratgrp);

        }

        public override List<RatingEntity> GetAuditRating(RatingEntity objratingentity)
        {
            return ratingdao.GetAuditRating(objratingentity);

        }

        public override List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp)
        {

            return ratingdao.GetAuditRatingGroup(objratinggrp);

        }

        public override List<RatingEntity> GetRatingList(RatingEntity objratingentity)
        {

            return ratingdao.GetRatingList(objratingentity);

        }


    }
}
