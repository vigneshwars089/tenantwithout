﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Xml.Linq;
using DigiOPS.TechFoundation.DataTransfer;
namespace DigiOPS.TechFoundation.Configuration
{
    public abstract class BaseConfiguration : IConfiguration
    {
        public abstract string Configuration(string ExcelFilePath, string ExcelTemplate, string Errorpath);
       //{
       //    throw new NotImplementedException();
       //}

       public Dictionary<string, DataTable> ReadExcelData(ExcelTemplate excelTemplate, string ExcelFilePath)
       {
           try
           {
               Dictionary<string, DataTable> dicDT = new Dictionary<string, DataTable>();
               FileStream stream = File.Open(ExcelFilePath, FileMode.Open, FileAccess.Read);
               IExcelDataReader excelReader = null;

               if (ExcelFilePath.ToLower().EndsWith("xlsx"))
                   excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream); //Reading from a OpenXml Excel file (2007 format; *.xlsx)
               else if (ExcelFilePath.ToLower().EndsWith("xls"))
                   excelReader = ExcelReaderFactory.CreateBinaryReader(stream); //Reading from a binary Excel file ('97-2003 format; *.xls)
               DataSet result = excelReader.AsDataSet();
               excelReader.IsFirstRowAsColumnNames = false;
               if (excelTemplate.Workbook.Count > 0 && result.Tables.Count > 0)
               {
                   for (int i = 0; i < excelTemplate.Workbook[0].WorkSheet.Count; i++)
                   {
                      DataTable dTab = new DataTable();
                       dTab.TableName = excelTemplate.Workbook[0].WorkSheet[i].WorkSheetName;
                       //inserting the header row
                       for (int Col = 0; Col < excelTemplate.Workbook[0].WorkSheet[i].columnTemplate.Count; Col++)
                           dTab.Columns.Add(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate[Col].Col_header_name);
                       int TabIndex = GetTableIndex(result.Tables, dTab.TableName);
                       if (TabIndex >= 0)
                       {
                           DataTable tempTab = result.Tables[TabIndex].Rows.Cast<DataRow>().
                                                           Where(row => !row.ItemArray.
                                                               All(field => field is System.DBNull)).
                                                           CopyToDataTable();
                           foreach (var column in result.Tables[TabIndex].Columns.Cast<DataColumn>().ToArray())
                           {
                               if (result.Tables[TabIndex].AsEnumerable().All(dr => dr.IsNull(column)))
                                   result.Tables[TabIndex].Columns.Remove(column);
                           }

                           int HeaderStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Header_Row_No.ToString()) - 1;
                           int DataStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Data_Start_Row) - 1;
                           dTab = ReadDataToTable(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate, tempTab, dTab, HeaderStartRow, DataStartRow);

                       }
                       dTab.AcceptChanges();
                       dicDT.Add(dTab.TableName.ToString(), dTab);
                   }
               }
               excelReader.Close();
               //                log.InfoFormat("BGV Reading completed for the file: {0}", ExcelFilePath);
               return dicDT;
           }
           catch (Exception ex)
           {
               //        log.Error(ex.Message);
               //       log.Error(ex.StackTrace);
               throw ex;
           }
       }

       public int GetTableIndex(DataTableCollection dataTableCollection, string sheetName)
       {
           for (int ctr = 0; ctr <= dataTableCollection.Count && ctr < dataTableCollection.Count; ctr++)
           {
               if (dataTableCollection[ctr].TableName.Trim().ToLower() == sheetName.Trim().ToLower())
                   return ctr;
           }
           return -1;
       }
       public int GetHeaderStartRow(string DataStartRowVal, DataTable tempTab, List<ColumnTemplate> columnTemplates)
       {
           try
           {
               int ColHeaderRow = -1;
               Dictionary<string, int> ColHeaderDict = new Dictionary<string, int>();
               if (DataStartRowVal == null)
                   return ColHeaderRow;
               else
               {
                   if (int.TryParse(DataStartRowVal.Trim(), out ColHeaderRow))
                       return ColHeaderRow;
                   else
                   {
                       foreach (ColumnTemplate colTemplate in columnTemplates)
                       {
                           bool flag = false;
                           string columnheadername = colTemplate.Col_header_name;
                           for (int row = 0; row < tempTab.Rows.Count; row++)
                           {
                               for (int col = 0; col < tempTab.Columns.Count; col++)
                               {
                                   string colName = tempTab.Rows[row].ItemArray[col].ToString().Trim().ToUpper();
                                   if (colName == columnheadername.Trim().ToUpper())
                                   {
                                       ColHeaderDict.Add(columnheadername, row);
                                       break;
                                   }
                               }
                               if (flag)
                                   break;
                           }
                       }
                       ColHeaderRow = Convert.ToInt32(ColHeaderDict.OrderByDescending(r => r.Value)
                                       .Select(r => r.Value)
                                       .Take(1));
                       return ColHeaderRow;
                   }
               }
           }
           catch (Exception ex)
           {
               // log.Error(ex.Message);
               // log.Error(ex.StackTrace);
               throw ex;
           }
       }

       public DataTable ReadDataToTable(List<ColumnTemplate> columnTemplates, DataTable tempTab, DataTable dTab, int HeaderStartRow, int DataStartRow)
       {
           try
           {
               int rowRange = tempTab.Rows.Count;
               int colRange = tempTab.Columns.Count;
               Dictionary<int, string> columnIndex = new Dictionary<int, string>();
               foreach (ColumnTemplate colTemplate in columnTemplates)
               {
                   if (colTemplate.Readiability.Equals("T"))
                   {
                       string columnheadername = colTemplate.Col_header_name;
                       int columnnumber = -1;
                       for (int j = 0; j < colRange; j++)
                       {
                           string colName = tempTab.Rows[HeaderStartRow].ItemArray[j].ToString().Trim().ToUpper();
                           if (colName == columnheadername.Trim().ToUpper())
                           {
                               columnnumber = j;
                               break;
                           }
                       }
                       if (columnnumber != -1)
                           columnIndex.Add(columnnumber, "T");
                       else
                           columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "F");
                   }
                   else
                       columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "T");
               }

               //Extract Data
               for (int rowIndex = DataStartRow; rowIndex < rowRange; rowIndex++)
               {
                   DataRow dRow = dTab.NewRow();
                   int colinc = 0;
                   foreach (var pair in columnIndex)
                   {
                       if (pair.Key <= colRange && pair.Value == "T")
                       {
                           dRow[colinc++] = tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString().Trim();
                           //Console.WriteLine(tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString());
                       }
                       else
                           dRow[colinc++] = string.Empty;
                   }
                   if (!dRow.ItemArray.All(i => (i is DBNull || string.Compare(i as string, string.Empty) == 0)))
                   {
                       dTab.Rows.Add(dRow);
                       dTab.AcceptChanges();
                   }
               }
           }
           catch (Exception ex)
           {
               //log.Error(ex.Message);
               //log.Error(ex.StackTrace);
               throw ex;
           }
           return dTab;
       }

       public void WriteToExcel(DataTable dtExcelData, string Errorpath, string sheetName)
       {
           //string strMessage = "";
           //ICollaborationFactory objCollaboration = new CollaborationFactory();
           //objCollaboration.GetExcelHandler().WriteToHtmlFormatExcel(dtExcelData, Errorpath, sheetName);
           //objCollaboration = null;
           DataTransferInfo dataTransferinfo = new DataTransferInfo();
           dataTransferinfo.ExcelExportType = "Excel";
           dataTransferinfo.DataTable=dtExcelData;
           dataTransferinfo.DestinationExcelFilePath=Errorpath;
           dataTransferinfo.ExcelSheetName = sheetName;
           ICaseCreationFactory ccft = new CaseCreationFactory();
           ccft.CaseCreationHandler("QUART").GetDataTransferHandler("Excel").Export(dataTransferinfo);
                



           //strMessage = "File uploaded successfully with valid records only. Please refer Log !";
           //return strMessage;
       }

    }
}
