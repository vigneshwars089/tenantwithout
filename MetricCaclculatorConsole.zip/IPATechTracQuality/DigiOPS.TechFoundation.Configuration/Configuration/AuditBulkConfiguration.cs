﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Configuration
{
    public class AuditBulkConfiguration : BaseCustomConfiguration
    {
             
        string SheetName = "Template";
        LoggingFactory objloggingfactory = new LoggingFactory();
        LogInfo objlog = new LogInfo();

        public override string Configuration(string ExcelFilePath, string ExcelTemplate, string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo, byte[] bt)
        {
            string strMessage = "";
            DataSet ds=new DataSet();
            Dictionary<string, DataTable> dictData = new Dictionary<string, DataTable>();
            try
            {

                //string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
                string ExcelTemplateSource = ExcelSourceTemplate;
                ExcelTemplate excelTemplate = new ExcelTemplate();
                string strDataSet = string.Empty;
                string strProcDetails = string.Empty;
                string strError = string.Empty;


                excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
                excelTemplate.Workbook = new List<WorkbookTemplate>()
                        {
                            excelTemplate.Workbook.Where(W=>W.Template_Name==ExcelTemplate).SingleOrDefault()
                        };

              
                dictData = ReadExcelData(excelTemplate, ExcelFilePath,bt);
                DataTable dt1 = dictData["RatingType"];
                DataTable dt2 = dictData["RatingGroup"];
                DataTable dt3 = dictData["Category"];
                DataTable dt4 = dictData["Heading"];
                DataTable dt5 = dictData["CTQ"];
                DataTable dt6 = dictData["SubDefect1"];
                DataTable dt7 = dictData["SubDefect2"];
                DataTable dt8 = dictData["SubDefect3"];
                DataTable dt9 = dictData["SubDefect4"];
                DataTable dt10 = dictData["SubDefect5"];
                DataTable dt11 = dictData["CombinedAccuracy"];

                DataSet objTablesData = new DataSet();

                objTablesData.Tables.Add(dt1);
                objTablesData.Tables.Add(dt2);
                objTablesData.Tables.Add(dt3);
                objTablesData.Tables.Add(dt4);
                objTablesData.Tables.Add(dt5);
                objTablesData.Tables.Add(dt6);
                objTablesData.Tables.Add(dt7);
                objTablesData.Tables.Add(dt8);
                objTablesData.Tables.Add(dt9);
                objTablesData.Tables.Add(dt10);
                objTablesData.Tables.Add(dt11);

                AuditConfigurationDAO AC = new AuditConfigurationDAO(objBaseInfo.AppID,objBaseInfo.TenantID);
                ds = AC.InsertAuditConfigDetails(objTablesData);

                int errorCount = 0;
                foreach (DataTable dtExcelData in ds.Tables)
                {
                    if (dtExcelData.Rows.Count > 0)
                    {
                        WriteToExcel(dtExcelData, Errorpath + dtExcelData.TableName + ".xls", SheetName);
                        errorCount = errorCount + 1;
                    }
                }
                if (errorCount > 0)
                {
                    strMessage = "2";
                }
                else
                {
                    strMessage = "1";
                }
               
            }

            catch (Exception excep)
            {
               
                objloggingfactory.GetLoggingHandler("Log4net").LogException(excep); 
                throw excep;
            }

            return strMessage;
        }
              
    }
}
