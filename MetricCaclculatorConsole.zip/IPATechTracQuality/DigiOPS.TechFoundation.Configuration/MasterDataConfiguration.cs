﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
   public class MasterDataConfiguration : BaseCustomConfiguration
    {
       public override void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements)
        {

        }

       public override void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value)
        {

        }
    }
}
