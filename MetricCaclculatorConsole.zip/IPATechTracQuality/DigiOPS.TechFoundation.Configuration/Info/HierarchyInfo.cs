﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
    public class HierarchyInfo : BaseInfo
    {
        
        public int _ParentID { get; set; }
        public int _ID { get; set; }
        public int _Name { get; set; }
        public int _LevelName { get; set; }
        public int _LevelNumber { get; set; }
        
    }

  


}
