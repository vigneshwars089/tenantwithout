﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Configuration
{
    public class DataElementConfiguration : BaseCustomConfiguration
    {
        DataElementDataAccess dataelmntda = new DataElementDataAccess();
        /// <summary>
        /// Method to Configure Data Element Based On Data Element Entity
        /// </summary>
        /// <returns>string- returns the success/failure message upon adding/editing the dataelement</returns>
        public override string AddUpdateDataElement(List<DataElementEntity> DataElements)
        {
            return dataelmntda.AddUpdateDataElement(DataElements);
        }

        /// <summary>
        /// used to delete the dataelement
        /// </summary>
        /// <param name="processid">int</param>
        /// <param name="ModifiedBy">string</param>
        /// <param name="eventAction">string</param>
        /// <returns>ActionResult- returns the success/failure message upon deletion of process</returns>
        //public override string DeleteDataelemnt(int ElemtId, string eventAction, string modifiedBy,string AppID, int TenantID)
        //{
        //    DataElementEntity datent = new DataElementEntity();
        //    datent.ElementId = ElemtId;
        //    datent.eventAction = eventAction;
        //    datent.modifiedBy = modifiedBy;
        //    datent.AppID = AppID;
        //    datent.TenantID = TenantID;
        //    return dataelmntda.DeleteDataElement(datent);

        //}
        /// <summary>
        /// Method to get Data Element Collection List
        /// </summary>
        /// <param name="_obj">DataElementInfo</param>
        /// <returns>List<List<DataElementEntity>></returns>
        public override List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj)
        {
            return dataelmntda.GetDataElements(_obj);
        }
        public override List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, int TenantID)
        {
            return dataelmntda.GetChildStaticConditions(configid, AppID, TenantID);
        }
        public override List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, int TenantID)
        {
            return dataelmntda.GetDataElementStaticCondition(subprocessid, AppID, TenantID);
        }
        public override string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, int TenantID)
       {
           return dataelmntda.UpdateStaticConditions(objConditions,  AppID,  TenantID);
       }
        public override List<DataElementEntity> GetDirectAuditLevelList(int SubProcessID, string AppID, int TenantID)
        {
            return dataelmntda.GetDirectAuditLevelList(SubProcessID, AppID, TenantID);
        }
        public override string SetRanking(ElementSequence ElementSequence, string AppID, int TenantID)
        {
            return dataelmntda.SetRanking(ElementSequence, AppID, TenantID);
        }
        public override string AddList(CodesEntity ListItem)
        {
            return dataelmntda.AddList(ListItem);
        }
        public override CodeGroupEntity GetAddListViewModel(CodeGroupEntity _Codes)
        {
            return dataelmntda.GetCodesList(_Codes);
        }
        public override bool IsAutoAudit(DataElementInfo obj)
        {
            return dataelmntda.IsAutoAudit(obj);
        }
        public override string DeleteDataelemnt(List<DataElementEntity> DataElements, string modifiedBy, string AppID, int TenantID)
        {
            return dataelmntda.DeleteDataElement(DataElements, modifiedBy, AppID, TenantID);

        } 
          public override List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj)
        {
            return dataelmntda.GetDataElementRecordList(_Obj);

        } 

    }
}
