﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Configuration
{
    public class WorkflowQCConfiguration : BaseCustomConfiguration
    {
        WorkflowConfigDataAccess wrkflwconfigda = new WorkflowConfigDataAccess();

        /// <summary>
        /// Method to Save Workflow Configuration
        /// </summary>
        /// <param name="objconfig">WorkflowConfigurationEntity</param>
        /// <returns>ActionResult</returns>
        public override string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig)
        {
            return wrkflwconfigda.AddUpdateWorkflowQC(objconfig);
        }
        /// <summary>
        /// Method To Get Configuration Details Based On SubProcessID
        /// </summary>
        /// <param name="objinfo">WorkflowConfigInfo</param>
        /// <returns>ActionResult</returns>
        public override List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo)
        {
            return wrkflwconfigda.GetWrkflowConfig(objinfo);
        }
    }
}
