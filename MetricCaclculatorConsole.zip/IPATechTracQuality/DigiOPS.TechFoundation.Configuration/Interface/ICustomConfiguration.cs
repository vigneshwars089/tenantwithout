﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
    public interface ICustomConfiguration
    {
        void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements);
        void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value);
        string Configuration(string ExcelFilePath, string ExcelTemplate, string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo, byte[] bt);
        string AddUpdateProgram(ProgramEntity programEnt);
        string DeleteProgram(int programid, string modifiedby, string eventAction, string AppID, int TenantID);
        List<List<ProgramEntity>> GetProgramList(ManualHierarchyInfo objinfo);
        string AddUpdateProcess(ProcessEntity objprocess);
        string DeleteProcess(int processid, string eventAction, string ModifiedBy, string AppID, int TenantID);
        List<ProcessEntity> GetProcessList(ManualHierarchyInfo objinfo);
        string AddUpdateSubProcess(SubProcessEntity objsubprocess);
        string DeleteSubProcess(int subprocessid, string eventAction, string ModifiedBy, string ModifiedDate, string AppID, int TenantID);
        List<SubProcessEntity> GetSubProcessList(ManualHierarchyInfo objinfo);
        List<List<ProcessEntity>> GetProcessUsergrp(ManualHierarchyInfo objinfo);
        string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig);
        List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo);
        string AddUpdateDataElement(List<DataElementEntity> DataElements);
        //string DeleteDataelemnt(int ElemtId, string eventAction, string modifiedBy, string AppID, int TenantID);
        List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj);
        DataSet BulkUploadDataElement(Template objtemplate);
        List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, int TenantID);
        List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, int TenantID);
        string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, int TenantID);
        List<DataElementEntity>  GetDirectAuditLevelList(int SubProcessID, string AppID, int TenantID);
        string SetRanking(ElementSequence ElementSequence, string AppID, int TenantID);
        string AddList(CodesEntity ListItem);
        CodeGroupEntity GetAddListViewModel(CodeGroupEntity _Codes);
        bool IsAutoAudit(DataElementInfo obj);
        string DeleteDataelemnt(List<DataElementEntity> DataElements, string modifiedBy, string AppID, int TenantID);
        List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj);
    }
}
