﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
   public class ConfigurationLevelFactory : IConfigurationLevelFactory
    {
       public IBulkUploadConfigFactory ConfigurationLevel(string ConfigLevel)
        {
            IBulkUploadConfigFactory objConfiguration = null;

            switch (ConfigLevel)
            {
                case Constants.MANUAL:
                    objConfiguration = null;
                    break;
                case Constants.BULKUPLOAD:
                    objConfiguration = new BulkUploadConfigFactory();
                    break;
               
            }
            return objConfiguration;
        }

       IBulkUploadConfigFactory IConfigurationLevelFactory.ConfigurationLevel(string ConfigLevel)
       {
           throw new NotImplementedException();
       }
    }
}
