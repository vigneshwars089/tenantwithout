﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public interface IEmailReading
    {
        void readMail(EMailInfo emailInfo);
    }
}
