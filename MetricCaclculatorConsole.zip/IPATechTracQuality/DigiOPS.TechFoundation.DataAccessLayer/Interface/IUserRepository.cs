﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public  interface IUserRepository
    {
        UserMgmtInfo Create(UserInfo objUserInfo);
        UserMgmtInfo Read(UserInfo objUserInfo);
        UserMgmtInfo Update(UserInfo objUserInfo);
        UserMgmtInfo Delete(UserInfo objUserInfo);
        
        string ConnectionString { get; set; }
        bool ValidateCredentials(UserInfo objUserInfo);
        int AssignRole(UserRoleInfo objUserInfo);
        int UpdateUserRole(UserRoleInfo objUserInfo);
        int DeleteUserRole(UserRoleInfo objRoleInfo);
        int LockAccount(string UserId, bool IsAccountLocked, string Token, DateTime TokenExpirationTime);
        int ValidateAccountLock(string UserId, bool IsAccountLocked, string Token);
        int IsAccountLocked(string UserId);
    }
}
