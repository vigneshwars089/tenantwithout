﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using System.IO;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class HierarchyDataAccess
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        HierarchyDAO HierarchyDAO = null;
       

        public HierarchyDataAccess(BaseInfo objBaseInfo)
        {

            HierarchyDAO = new HierarchyDAO(objBaseInfo.AppID, objBaseInfo.TenantID);
        }
       
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :AllocationDataAccess.cs
        // Namespace : DigiOps.TechFoundation.DataAccessLayer
        // Class Name(s) :AllocationDataAccess
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/6/2017
        // Purpose : AllocationDataAccess added for Allocation Component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        // xx-xxx-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public DataSet InsertHierarchyrans(DataSet objData,BaseInfo objBaseInfo)
        {
            string createRecVal = string.Empty;
            DataSet dsResult = new DataSet();
                       
            DataSet datasets = new DataSet();
            try
            {
                string error = "";               
                int i = 0;

                foreach (DataTable table in objData.Tables)
                {
                    DataTable dt = new DataTable();
                   string strExcelDataxml = string.Empty;
                    using (TextWriter writer = new StringWriter())
                    {
                        objData.Tables[i].WriteXml(writer);
                        strExcelDataxml = writer.ToString();
                    }

                   // HierarchyDAO HierarchyDAO = new HierarchyDAO(objBaseInfo.AppID,objBaseInfo.TenantID);
                    dt = HierarchyDAO.InsertHierarchyDetails(table.TableName.ToString(), strExcelDataxml);
                   
                    datasets.Tables.Add(dt.Copy());
                   
                    i = i + 1;
                }
               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return datasets;
        }
        public string SerializeToString(object value)
        {
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamepsaces);
                string str = stream.ToString().Replace("<TransactionListResponse>\r\n ", "");
                str = str.Replace("\r\n</TransactionListResponse>", "");

                return str;

            }
        }
       
    }
}
