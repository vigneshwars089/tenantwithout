﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using System.IO;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AuditConfigurationDAO
    {
        LoggingFactory objloggingfactory = new LoggingFactory();
        LogInfo objlog = new LogInfo();
        private string __connectionString = "";
        string error = "";
        string table = "TemptblAuditBulkUpload";
        string SDO = "TEMPtblSubDefectDO";
        string RT = "TEMPtblRatingType";
        string RG = "TemptblRating";
        string CA = "TEMPtblCombinedAccuracy";
        //string strC = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        public AuditConfigurationDAO()
        {
            __connectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;

        }
        public AuditConfigurationDAO(string appId, int tenantId)
        {
           // __connectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            ConnectionString conn = new ConnectionString();
            __connectionString = conn.GetConnectionString(appId, tenantId);

        }
        public DataSet GetExcelTemplate()
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(__connectionString);
                connection.Open();
                DataSet ds = new DataSet();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "GET_EXCEL_TEMPLATE";
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if ((connection != null) && (connection.State == ConnectionState.Open))
                {
                    connection.Close();
                }
            }
        }
        //public virtual string excelreader(DataSet result1)
        //{
        //    SqlConnection conStr = new SqlConnection(strC);
        //    using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
        //    {
        //        try
        //        {
        //            bulkcopy.DestinationTableName = table;
        //            bulkcopy.BatchSize = result1.Tables[0].Rows.Count;
        //            conStr.Open();
        //            bulkcopy.WriteToServer(result1.Tables[0]);
        //            bulkcopy.Close();
        //            conStr.Close();
        //            error = "Inserted Successfully";
        //        }
        //        catch (Exception ex)
        //        {
        //            error = "Table Content Out of bounds";

        //        }

        //        return error;
        //    }

        //}

        public DataSet InsertAuditConfigDetails(DataSet ds)
        {
            DataSet dataSet = new DataSet();            
            foreach (DataTable table in ds.Tables)
            {
                if (table.TableName == "RatingType")
                {
                    Ratingtype(table);
                    dataSet = RatingTypeValidation();
                }
                else if (table.TableName == "RatingGroup")
                {
                    Ratinggroup(table);
                    dataSet = RatingTypeValidation();
                }
                else if (table.TableName == "Category" || table.TableName == "Heading" || table.TableName == "CTQ")
                {
                    defectopportunity(table);
                    dataSet = DefectSubDefectValidation();
                }
                else if (table.TableName == "SubDefect1" || table.TableName == "SubDefect2" || table.TableName == "SubDefect3" || table.TableName == "SubDefect4" || table.TableName == "SubDefect5")
                {
                    subdefectopportunity(table);
                    dataSet = DefectSubDefectValidation();
                }
                else if (table.TableName == "CombinedAccuracy")
                {
                    CombinedAccuracy(table);
                    dataSet = CombinedAccuracyValidation();
                }
            }
            return ds;
        }

        public virtual string defectopportunity(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = table;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    //bulkupload();
                    bulkcopy.Close();
                    conStr.Close();
                    error = "Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }

        }

        public virtual string subdefectopportunity(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = SDO;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    //Subdefect();
                    bulkcopy.Close();
                    conStr.Close();
                    error = "Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }

        }


        public virtual string Ratingtype(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = RT;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                   // Rating();
                    bulkcopy.Close();
                    conStr.Close();
                    error = "Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }
        }

        public virtual string Ratinggroup(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = RG;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    //Rating();
                    bulkcopy.Close();
                    conStr.Close();
                    error = "Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }
        }

        public string CombinedAccuracy(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = CA;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                   // CombinedAccuracy();
                    bulkcopy.Close();
                    conStr.Close();
                    error = "Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }
        }

        public DataSet DefectSubDefectValidation()
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(__connectionString);
                connection.Open();
                DataSet ds = new DataSet();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "BUlkUploadDO";
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if ((connection != null) && (connection.State == ConnectionState.Open))
                {
                    connection.Close();
                }
            }
        }

        public DataSet RatingTypeValidation()
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(__connectionString);
                connection.Open();
                DataSet ds = new DataSet();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "RatingBulkUpload";
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if ((connection != null) && (connection.State == ConnectionState.Open))
                {
                    connection.Close();
                }
            }
        }

        public DataSet CombinedAccuracyValidation()
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(__connectionString);
                connection.Open();
                DataSet ds = new DataSet();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "CombinedAccuracyBulkUpload";
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if ((connection != null) && (connection.State == ConnectionState.Open))
                {
                    connection.Close();
                }
            }
        }

        //public DataSet Subdefect()
        //{
        //    SqlConnection connection = null;
        //    try
        //    {
        //        connection = new SqlConnection(__connectionString);
        //        connection.Open();
        //        DataSet ds = new DataSet();
        //        using (SqlCommand command = connection.CreateCommand())
        //        {
        //            command.CommandText = "BUlkUploadDO";
        //            command.CommandType = CommandType.StoredProcedure;
        //            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
        //            {
        //                adapter.Fill(ds);
        //            }
        //        }
        //        return ds;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if ((connection != null) && (connection.State == ConnectionState.Open))
        //        {
        //            connection.Close();
        //        }
        //    }
        //}
    }
    }






