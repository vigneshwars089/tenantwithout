﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.IO;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{

    /// <summary>
    /// Combined Audit DAO
    /// </summary>
    public class CombinedAuditDAO
    {
        private string dbConnectionString = string.Empty;
        ConnectionString connectionstring = new ConnectionString();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        /// <summary>
        /// Default Constructor for Combined Audit
        /// </summary>
        public CombinedAuditDAO()
        {
            // dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];

        }

        /// <summary>
        /// Method to Get Combined Accuracy Audit Details List
        /// </summary>
        /// <param name="objDOEntity"></param>
        /// <returns></returns>
        public DataTable GetAuditDetailList(CombinedAccuracyEntity objDOEntity)
        {
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            DataSet _ds = new DataSet();
            try
            {

                string spName = string.Empty;
                spName = "USP_GET_AUDITDODETAILS";
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AUDITDODETAILS", SqlConnection);
                    command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objDOEntity.subProcessId;
                    command.Parameters.Add("@iId", SqlDbType.Int).Value = objDOEntity.id;
                    command.Parameters.Add("@iLevel", SqlDbType.Int).Value = objDOEntity.LevelId;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                //Hashtable hs = new Hashtable();
                //hs.Add("@iSubProcessId", objDOEntity.subProcessId);
                //hs.Add("@iId", objDOEntity.id);
                //hs.Add("@iLevel", objDOEntity.LevelId);
                //DBHelper db = new DBHelper();
                //_ds = db.SelectDataSet(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw; // new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (InvalidOperationException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (SqlException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        } 
              
        */
            return _ds.Tables[0];
        }

        /// <summary>
        /// Method to Get Audit Rating List
        /// </summary>
        /// <param name="objDOEntity"></param>
        /// <returns></returns>
        public DataSet GetAuditRatingList(CombinedAccuracyEntity objDOEntity)
        {
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            DataSet _ds = new DataSet();
            try
            {

                string spName = string.Empty;
                spName = "USP_GET_AUDITDORATINGDETAILS";
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AUDITDORATINGDETAILS", SqlConnection);
                    command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objDOEntity.subProcessId;
                    command.Parameters.Add("@iDOId", SqlDbType.Int).Value = objDOEntity.id;
                    command.Parameters.Add("@iHEADINGDOId", SqlDbType.Int).Value = objDOEntity.HeadingID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                //Hashtable hs = new Hashtable();
                //hs.Add("@iSubProcessId", objDOEntity.subProcessId);
                //hs.Add("@iDOId", objDOEntity.id);
                //hs.Add("@iHEADINGDOId", objDOEntity.HeadingID);
                //DBHelper db = new DBHelper();
                //_ds = db.SelectDataSet(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw; //  new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (InvalidOperationException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (SqlException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
             */
            return _ds;
        }

        /// <summary>
        /// Method to SEt Combined Accuracy
        /// </summary>
        /// <param name="objDOEntity"></param>
        /// <returns></returns>
        public string SetCombinedAccuracy(CombinedAccuracyEntity objDOEntity)
        {
            object message = null;
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            try
            {
                string resultValue = "-1";
                string spName = string.Empty;
                spName = "USP_SET_AUDITCOMBINEDACCURACY";
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_AUDITCOMBINEDACCURACY", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("@xmlData", SqlDbType.NText).Value = objDOEntity.xmlTag;
                    command.Parameters.Add("@iD", SqlDbType.Int).Value = objDOEntity.id;
                    command.Parameters.Add("@sOpertaionName", SqlDbType.VarChar).Value = objDOEntity.ActionName;
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }
                // Hashtable hs = new Hashtable();

                // hs.Add("@xmlData", objDOEntity.xmlTag);
                // hs.Add("@iD", objDOEntity.id);
                // hs.Add("@sOpertaionName", objDOEntity.ActionName);
                //// hs.Add("@RETURN_VALUE", 0);
                // DBHelper db = new DBHelper();
                //message = db.SelectSingleValue(spName, hs);          
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (InvalidOperationException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (SqlException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        } */
            return message.ToString();
        }
    }
}
