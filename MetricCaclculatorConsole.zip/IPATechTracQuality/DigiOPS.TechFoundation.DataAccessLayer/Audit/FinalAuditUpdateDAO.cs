﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Xml;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class FinalAuditUpdateDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        //protected Logger proxyLogger = new Logger();
        /// <summary>To get the database credentials from the configuration file</summary> 
        public FinalAuditUpdateDAO()
        {
           // dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }
        /// <summary>To get the Audit defect opportunities for the selected Transaction</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetAuditDetailsList(BaseTransportEntity _Obj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetAuditDetailsList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("FinalAuditUpdateDAO - GetAuditDetailsList - Called.");
            try
            {

                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_AUDITDEFECTOPPORTUNTIES, sqlConnection);
                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw; //new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw; //new QuartException(ex.Message, ex.InnerException);
            }/*
            catch (QuartException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            }
              * */
        }

        public DataTable GetAuditQCStatus(AuditDOEntity _QCstatusObj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("FinalAuditUpdateDAO - GetAuditQCStatus - Called.");
            try
            {
                //AuditDOEntity _QCstatusObj = new AuditDOEntity();
                //_QCstatusObj = _Obj;

                string spName = string.Empty;
                DataTable _dt = new DataTable();

                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                spName = "GET_QS_CORRECTIONSTATUS";

                    //SqlConnection.Open();
                    //SqlCommand command = new SqlCommand(Constants.GET_QS_CORRECTIONSTATUS, SqlConnection);
                    //command.Parameters.Add(Constants.PAR_iAuditFindingId, SqlDbType.Int).Value = (_QCstatusObj.iAuditFindingId == 0) ? 0 : _QCstatusObj.iAuditFindingId;
                    //command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = _QCstatusObj.eventAction;
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.VarChar, 500);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);
                    //command.CommandType = CommandType.StoredProcedure;
                    //SqlDataAdapter adp = new SqlDataAdapter(command);
                    //adp.Fill(_dt);
                //}
                Hashtable hs=new Hashtable();
                hs.Add("@iAuditFindingId", _QCstatusObj.iAuditFindingId);
                hs.Add("@szOpertaionName", _QCstatusObj.eventAction);
                hs.Add("@iReturnValue", 0);
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;


            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
        }


        public DataTable GetAuditAndDeleteStatus(AuditDOEntity _DeletestatusObj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetAuditDeleteStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("FinalAuditUpdateDAO - GetAuditDeleteStatus - Called.");
            try
            {
                //AuditDOEntity _DeletestatusObj = new AuditDOEntity();
                //_DeletestatusObj = _Obj;

                string spName = string.Empty;
                DataTable _dt = new DataTable();
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USE_GET_AUDIT_AND_DELETE_STATUS", SqlConnection);
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (_DeletestatusObj.iAuditId == 0) ? 0 : _DeletestatusObj.iAuditId;
                //    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                //    outprm.Direction = ParameterDirection.Output;
                //    command.Parameters.Add(outprm);

                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                spName = "USE_GET_AUDIT_AND_DELETE_STATUS";
                Hashtable hs = new Hashtable();
                hs.Add("@iAuditId", _DeletestatusObj.iAuditId);
                hs.Add("@iReturnValue", 0);
                DBHelper db=new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;
            }/*
            catch (QuartException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            }
              * */
            catch (Exception ex)
            {
                throw;
            }
        }


        public DataTable GetAuditSubDefectList(SubDefectDetailsEntity _SubDefObj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetAuditSubDefectList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("FinalAuditUpdateDAO - GetAuditSubDefectList - Called.");
            try
            {
                //SubDefectDetailsEntity _SubDefObj = new SubDefectDetailsEntity();
                //_SubDefObj = _Obj;
                string spName = string.Empty;
                DataTable _dt = new DataTable();
                //SqlCommand command = null;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
               // {
                 //   sqlConnection.Open();
                    if (_SubDefObj.eventAction == "Normal")
                    {
                        spName="USP_GET_AUDITSUBDEFECTOPPORTUNITY";
                        //command = new SqlCommand(Constants.SP_GET_AUDITSUBDEFECTOPPORTUNITY, sqlConnection);
                    }
                    else
                    {
                        spName="USP_GET_AUDITSUBDEFECTOPPORTUNITYQSCORRECTION";
                        //command = new SqlCommand("USP_GET_AUDITSUBDEFECTOPPORTUNITYQSCORRECTION", sqlConnection);
                    }
                //    command.Parameters.Add(Constants.PAR_iDOId, SqlDbType.Int).Value = (_SubDefObj.DOId == 0) ? 0 : _SubDefObj.DOId;
                //    command.Parameters.Add(Constants.PAR_iParentSubDOId, SqlDbType.Int).Value = (_SubDefObj.ParentSubDOId == 0) ? 0 : _SubDefObj.ParentSubDOId;
                //    command.Parameters.Add(Constants.PAR_iAuditFindingId, SqlDbType.Int).Value = (_SubDefObj.AuditFindingId == 0) ? 0 : _SubDefObj.AuditFindingId;
                //    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
                //    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                //    outprm.Direction = ParameterDirection.Output;
                //    command.Parameters.Add(outprm);
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                    Hashtable hs = new Hashtable();
                    hs.Add("@iDOId", _SubDefObj.DOId);
                    hs.Add("@iParentSubDOId", _SubDefObj.ParentSubDOId);
                    hs.Add("@iAuditFindingId", _SubDefObj.AuditFindingId);
                    hs.Add("@iSubProcessId", _SubDefObj._SubProcessID);
                    hs.Add("@iReturnValue", 0);
                    DBHelper db = new DBHelper();
                    _dt = db.SelectDataTable(spName, hs);
                  
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
        }

        public DataTable GetAuditHeadingDetailsList(TransactionDetailsEntity _Obj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetAuditHeadingDetailsList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("FinalAuditUpdateDAO - GetAuditHeadingDetailsList - Called.");
            try
            {

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USP_GET_AUDITHEADINGDETAILS", SqlConnection);
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = _Obj.AuditId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                spName = "USP_GET_AUDITHEADINGDETAILS";
                Hashtable hs = new Hashtable();
                hs.Add("@iAuditId", _Obj.AuditId);
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;
            }/*
            catch (QuartException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            }
              * */
            catch (Exception ex)
            {
                throw;
            }
        }



        /// <summary>To Get the list of the audit defect opportunities selected of the Record</summary> 
        /// <returns>Dataset</returns>
        public DataSet GetEntityListcollection(AuditDetailsEntity _obj)
        {
            objloginfo.Message = ("FinalAuditUpdateDAO - GetEntityListcollection - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("FinalAuditUpdateDAO - GetEntityListcollection - Called.");
            try
            {
                //AuditDetailsEntity _AuditDetailObj = new AuditDetailsEntity();
                //_AuditDetailObj = _obj;
                DataSet _ds = new DataSet();
                string spName = string.Empty;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //    SqlCommand command = null;
                //    command = new SqlCommand("USP_GET_AUDITDEFECTOPPORTUNITY_FinalAuditUpdate", sqlConnection);
                //    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_obj._SubProcessID == 0) ? 0 : _obj._SubProcessID;
                //    command.Parameters.Add(Constants.PAR_iSystemUserId, SqlDbType.Int).Value = (_obj.CurrentUserID == 0) ? 0 : _obj.CurrentUserID;
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (_AuditDetailObj.iAuditId == 0) ? 0 : _AuditDetailObj.iAuditId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_ds);
                //}
                spName = "USP_GET_AUDITDEFECTOPPORTUNITY_FinalAuditUpdate";
                Hashtable hs = new Hashtable();
                hs.Add("@iSubProcessId", _obj._SubProcessID);
                hs.Add("@iSystemUserId", _obj.CurrentUserID);
                hs.Add("@iAuditId", _obj.iAuditId);
                DBHelper db = new DBHelper();
                _ds = db.SelectDataSet(spName, hs);
                return _ds;
            }

            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw; //new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }/*
            catch (QuartException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            }
              * */
        }
        /// <summary>To set the All Audit details of the Transaction to the database</summary> 
        /// <returns>string</returns>
        public string SetAuditDetail(AuditDOEntity auditedData)
        {
            //string resultValue = "-1";
            objloginfo.Message = ("FinalAuditUpdateDAO - SetAuditDetail - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("FinalAuditUpdateDAO - SetAuditDetail - Called.");
            try
            {
                //AuditDOEntity auditedData = new AuditDOEntity();
                //auditedData = auditDOEntity;
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                string spName=string.Empty;

                auditedData.xmlAuditDO = new XElement("AuditDOData",
                 auditedData.AuditedList.Select(i => new XElement("DO",
                     new XAttribute("DOId", i.DOId),
                     new XAttribute("DOGroupID", i.DOGroupID),
                     new XAttribute("SelectedRatingId", i.SelectedRatingId),
                     new XAttribute("GivenWeightage", i.GivenWeightage),
                     new XAttribute("ActualWeightage", i.ActualWeightage),
                     new XAttribute("CalulatedWeightage", i.CalulatedWeightage),
                     new XAttribute("MaxWeightage", i.MaxWeightage),
                     new XAttribute("ParentDOId", i.ParentDOId),
                     new XAttribute("AuditFindingId", i.iAuditFindingId == 0 ? 0 : i.iAuditFindingId),
                     new XAttribute("AuditorId", i.CurrentUserID == 0 ? 0 : i.CurrentUserID),
                     new XAttribute("szComments", (i.CTQComments == null) ? "" : i.CTQComments),
                     new XAttribute("SubProcessID", auditedData._SubProcessID),
                     new XAttribute("CorrectEmployee", i.CorrectEmployee),
                     new XAttribute("HasSubDefects", i.HasSubDefects),
                     new XAttribute("ErrorField", i.ErrorField),
                     new XAttribute("CriticalityType", i.CriticalityType)
                 )));

                auditedData.xmlAuditGroupDO = new XElement("AuditGroupDO",
                 auditedData.AuditedGroupList.Select(i => new XElement("GroupDO",
                     new XAttribute("HeadingDOId", i.HeadingDOId),
                     new XAttribute("DOGroupID", i.GroupID),
                     new XAttribute("NoofApplicable", i.NoofApplicable),
                     new XAttribute("NoofError", i.NoofError),
                     new XAttribute("CalculatedGroupWeightage", i.CalculatedGroupWeightage),
                     new XAttribute("SumGroupWeightage", i.SumGroupWeightage)

                 )));

                auditedData.xmlAuditSubDO = new XElement("AuditSubDOData",
                    auditedData.AuditedList.Where(i => i.SelectedSubDefect1Id != 0)
                        .Select(i => new XElement("SubDO",
                        new XAttribute("DOId", i.DOId),
                        new XAttribute("SubDefectId", i.SelectedSubDefect1Id)
                    )),
                    auditedData.AuditedList.Where(i => i.SelectedSubDefect2Id != 0)
                    .Select(i => new XElement("SubDO",
                        new XAttribute("DOId", i.DOId),
                        new XAttribute("SubDefectId", i.SelectedSubDefect2Id)
                    ))

                 );

                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                   // sqlConnection.Open();
                
                spName="USP_SET_AUDITFINDINGDATA_FinalAuditUpdate";

                    //SqlCommand command = new SqlCommand("USP_SET_AUDITFINDINGDATA_FinalAuditUpdate", sqlConnection);
                    //command.CommandType = CommandType.StoredProcedure;

                if (!string.IsNullOrEmpty(Convert.ToString(auditedData.eventAction)) && auditedData.eventAction.Equals(Constants.ACTION_Insert))
                        root.Add(new XAttribute("iAuditId", 0));
                    else
                        root.Add(new XAttribute("iAuditId", Convert.ToString(auditedData.iAuditId)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.iAuditFindingId)))
                        root.Add(new XAttribute("iAuditFindingId", Convert.ToString(auditedData.iAuditFindingId) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.AuditFeedback)))
                        root.Add(new XAttribute("szAuditFeedBack", Convert.ToString(auditedData.AuditFeedback)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.FatalStatus)))
                        root.Add(new XAttribute("szFatalStatus", Convert.ToString(auditedData.FatalStatus)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TATFeedback)))
                        root.Add(new XAttribute("szTATFeedback", Convert.ToString(auditedData.TATFeedback)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TATFeedbackComments)))
                        root.Add(new XAttribute("szTATFeedbackComments", Convert.ToString(auditedData.TATFeedbackComments)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.AuditNotes)))
                        root.Add(new XAttribute("szAuditNotes", Convert.ToString(auditedData.AuditNotes)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.ApproverComments)))
                        root.Add(new XAttribute("szApproverComments", Convert.ToString(auditedData.ApproverComments)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.UploadFilePath)))
                        root.Add(new XAttribute("szUploadFilePath", Convert.ToString(auditedData.UploadFilePath)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.RecommendationComments)))
                        root.Add(new XAttribute("szRecommendationComments", Convert.ToString(auditedData.RecommendationComments)));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.ApprovalStatus)))
                        root.Add(new XAttribute("szApprovalStatus", Convert.ToString(auditedData.ApprovalStatus)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.QualityScore)))
                        root.Add(new XAttribute("fQualityScore", Convert.ToString(auditedData.QualityScore)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.FieldQualityScore)))
                        root.Add(new XAttribute("fFieldQualityScore", Convert.ToString(auditedData.FieldQualityScore)));

                    //command.Parameters.Add(Constants.PAR_xmlAuditDO, SqlDbType.Xml).Value = (auditedData.xmlAuditDO == null) ? null : auditedData.xmlAuditDO.ToString();

                    //command.Parameters.Add("@xmlAuditGroupDO", SqlDbType.Xml).Value = (auditedData.xmlAuditGroupDO == null) ? null : auditedData.xmlAuditGroupDO.ToString();

                    //command.Parameters.Add(Constants.PAR_xmlAuditSubDO, SqlDbType.Xml).Value = (auditedData.xmlAuditSubDO == null) ? null : auditedData.xmlAuditSubDO.ToString();


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalOpp)))
                        root.Add(new XAttribute("iTotDO_Cnt", Convert.ToString(auditedData.TotalOpp) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppOpp)))
                        root.Add(new XAttribute("iTotAppDO_Cnt", Convert.ToString(auditedData.TotalAppOpp) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalNotAppOpp)))
                        root.Add(new XAttribute("iTotNotAppDO_Cnt", Convert.ToString(auditedData.TotalNotAppOpp) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppDefects)))
                        root.Add(new XAttribute("iTotAppDOWithDefects_Cnt", Convert.ToString(auditedData.TotalAppDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppNoDefects)))
                        root.Add(new XAttribute("iTotAppDOWithNoDefects_Cnt", Convert.ToString(auditedData.TotalAppNoDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalHeadings)))
                        root.Add(new XAttribute("iTotHeadings_Cnt", Convert.ToString(auditedData.TotalHeadings) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadings)))
                        root.Add(new XAttribute("iTotAppHeadings_Cnt", Convert.ToString(auditedData.TotalAppHeadings) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalNotAppHeadings)))
                        root.Add(new XAttribute("iTotNotAppHeadings_Cnt", Convert.ToString(auditedData.TotalNotAppHeadings) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadingsDefects)))
                        root.Add(new XAttribute("iTotAppHeadingsWithDefects_Cnt", Convert.ToString(auditedData.TotalAppHeadingsDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadingsNoDefects)))
                        root.Add(new XAttribute("iTotAppHeadingsWithNoDefects_Cnt", Convert.ToString(auditedData.TotalAppHeadingsNoDefects) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalOpp_W)))
                        root.Add(new XAttribute("fTotDO_Wt", Convert.ToString(auditedData.TotalOpp_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppOpp_W)))
                        root.Add(new XAttribute("fTotAppDO_Wt", Convert.ToString(auditedData.TotalAppOpp_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalNotAppOpp_W)))
                        root.Add(new XAttribute("fTotNotAppDO_Wt", Convert.ToString(auditedData.TotalNotAppOpp_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppDefects_W)))
                        root.Add(new XAttribute("fTotAppDOWithDefects_Wt", Convert.ToString(auditedData.TotalAppDefects_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppNoDefects_W)))
                        root.Add(new XAttribute("fTotAppDOWithNoDefects_Wt", Convert.ToString(auditedData.TotalAppNoDefects_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalHeadings_W)))
                        root.Add(new XAttribute("fTotHeadings_Wt", Convert.ToString(auditedData.TotalHeadings_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadings_W)))
                        root.Add(new XAttribute("fTotAppHeadings_Wt", Convert.ToString(auditedData.TotalAppHeadings_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalNotAppHeadings_W)))
                        root.Add(new XAttribute("fTotNotAppHeadings_Wt", Convert.ToString(auditedData.TotalNotAppHeadings_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadingsDefects_W)))
                        root.Add(new XAttribute("fTotAppHeadingsWithDefects_Wt", Convert.ToString(auditedData.TotalAppHeadingsDefects_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.TotalAppHeadingsNoDefects_W)))
                        root.Add(new XAttribute("fTotAppHeadingsWithNoDefects_Wt", Convert.ToString(auditedData.TotalAppHeadingsNoDefects_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.CurrentUserID)))
                        root.Add(new XAttribute("iAuditedBy", Convert.ToString(auditedData.CurrentUserID) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData._SubProcessID)))
                        root.Add(new XAttribute("iSubProcessId", Convert.ToString(auditedData._SubProcessID)));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.ViewName)))
                        root.Add(new XAttribute("ViewName", Convert.ToString(auditedData.ViewName)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditedData.eventAction)))
                        root.Add(new XAttribute("szOpertaionName", Convert.ToString(auditedData.eventAction)));


                    Parent.Add(root);
                    //command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Float, 100);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);

                    //command.ExecuteNonQuery();
                    //resultValue = outprm.Value.ToString();
                    Hashtable hs = new Hashtable();                 

                    hs.Add("@xmlAuditDO", auditedData.xmlAuditDO.ToString());
                    hs.Add("@xmlAuditGroupDO", auditedData.xmlAuditGroupDO.ToString());
                    hs.Add("@xmlAuditSubDO", auditedData.xmlAuditSubDO.ToString());
                    hs.Add("@ExcelData", Convert.ToString(Parent));
                    hs.Add("@iReturnValue", 0);

                    DBHelper db = new DBHelper();
                    object message=db.SelectSingleValue(spName,hs);
                    auditedData.CombinedQualityScore = message.ToString();
                    return message.ToString();
                                             
            }
            catch (XmlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }/*
            catch (QuartException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            }
              * */
           // return resultValue;
        }
    }
}

