﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Xml;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// FeedBack Audit DAO
    /// </summary>
    public class FeedbackAuditDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
      
        //private Logger proxyLogger = new Logger();
        //private string dbConnectionString = string.Empty;

        /// <summary>
        /// FeedBackAuditDAO
        /// </summary>
        public FeedbackAuditDAO()
        {
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }

        /// <summary>
        /// Method to Get FeedBack Audit Trans List
        /// </summary>
        /// <param name="objBase"></param>
        /// <returns></returns>
        public DataSet GetFeedbackAuditTransList(FeedbackAuditList objBase)
        {
            objloginfo.Message = ("GetFeedbackAuditTransList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetFeedbackAuditTransList - Called.");
            try
            {
                DataSet ds = new DataSet();
                DataTable resultdt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AUDITTRANSLIST_BYAUDITTYPE", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iSubProcessId", SqlDbType.VarChar).Value = objBase.SubProcessId.ToString();
                    command.Parameters.Add("@iProcessorID", SqlDbType.VarChar).Value = objBase.UserId;
                    command.Parameters.Add("@processedDate", SqlDbType.VarChar).Value = objBase.ProcessedDate.Value.ToString("yyyy-MM-dd");

                    command.Parameters.Add("@processedToDate", SqlDbType.VarChar).Value = objBase.ProcessedToDate.Value.ToString("yyyy-MM-dd");

                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objBase.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objBase.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objBase.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objBase.SortColumn;
                    command.Parameters.Add("@AuditTypeId", SqlDbType.VarChar).Value = objBase.AuditTypeId;                    

                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(ds);
                }
                return ds;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}

        }
        /// <summary>
        /// Method to Get Audit TypeList
        /// </summary>
        /// <param name="objBase"></param>
        /// <returns></returns>
        public DataTable GetAuditTypeList(FeedbackAuditList objBase)
        {
            objloginfo.Message = ("GetAuditTypeList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetAuditTypeList - Called.");
            try
            {
                DataSet ds = new DataSet();

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AUDITTYPEDETAILS", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objBase.SubProcessId;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(ds);
                }
                return ds.Tables[0];
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
                /*
            catch (QuartException ex)
            {
                throw new QuartException(ex.Message, ex.InnerException);
            }
                 * */

        }

        /// <summary>
        /// Method to Get AuditFinding by Audit 
        /// </summary>
        /// <param name="objBase"></param>
        /// <returns></returns>
        public DataSet GetAuditFindingbyAudit(AuditRework objBase)
        {
            objloginfo.Message = ("GetAuditFindingbyAudit - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetAuditFindingbyAudit - Called.");
            try
            {
                DataSet ds = new DataSet();
                DataTable resultdt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AUDITFINDING_BYAUDITID", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@AuditId", SqlDbType.VarChar).Value = objBase.AuditId;                 

                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(ds);
                }
                return ds;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
                /*
            catch (QuartException ex)
            {
                throw new QuartException(ex.Message, ex.InnerException);
            }
                 * */

        }

        /// <summary>
        /// Method to Set Rework Audit 
        /// </summary>
        /// <param name="objDOEntity"></param>
        /// <returns></returns>
        public string SetReworkAudit(AuditRework objDOEntity)
        {
            objloginfo.Message = ("SetReworkAudit - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("SetReworkAudit - Called.");
            try
            {
                string resultValue = "-1";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_AUDITREWORKDETAILS", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("@AuditId", SqlDbType.Int).Value = objDOEntity.AuditId;
                    command.Parameters.Add("@RecordId", SqlDbType.Int).Value = objDOEntity.RecordId;
                    command.Parameters.Add("@AuditFindingId", SqlDbType.Int).Value = objDOEntity.AuditFindingId;
                    command.Parameters.Add("@ReworkComments", SqlDbType.VarChar).Value = objDOEntity.ReworkComments;
                    command.Parameters.Add("@SubProcessId", SqlDbType.Int).Value = objDOEntity.SubProcessId;
                    command.Parameters.Add("@UserId", SqlDbType.Int).Value = objDOEntity.UserId;
                    command.Parameters.Add("@IsReworkReq", SqlDbType.Int).Value = objDOEntity.IsReworkReq;
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }
                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
                /*
            catch (QuartException ex)
            {
                throw new QuartException(ex.Message, ex.InnerException);
            }
                 * */

        }
    }
}
