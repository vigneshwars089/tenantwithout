﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Xml.Linq;
using System.IO;
using System.Collections;
//using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Collections.Generic;
using System.Linq;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class DefectOpportunityDAO
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        public string dbConnectionString = string.Empty;
        // private Logger proxyLogger = new Logger();

        // LogInfo proxyLogger = new LogInfo();
        // ILoggingFactory objLogging = new LoggingFactory();

        public DefectOpportunityDAO()
        {
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];

            //  Utility.Conversion.GetDecodedConnectionstring();
        }



        /// <summary>
        /// this method used for creating, updating and deleting the subprocess details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public string SetDefectOpportunity(AuditCheckItemsInfo objDOEntity)
        {
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            objloginfo.Message = ("SetDefectOpportunity - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            object message = null;
            string resultValue = "-1";

            try
            {

                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    string spName = string.Empty;

                    if (objDOEntity.AuditCheckItemList != null)
                    {
                        objDOEntity.xmlAuditCheckItem = new XElement("AuditDOData",
                   objDOEntity.AuditCheckItemList.Select(i => new XElement("DO",
                       new XAttribute("iDOId", i.CheckItemId),
                       new XAttribute("szDisplayName", i.CheckItemName),
                        new XAttribute("szDODesc", i.CheckItemDescription),
                         new XAttribute("szOLDODesc", i.OLCheckItemDescription),
                          new XAttribute("szCheckItemGUID", i.CheckItemGUID)



                   )));
                    }
                    if (objDOEntity.AuditRootCauseList != null)
                    {
                        objDOEntity.xmlAuditRootCauseItem = new XElement("RootCauseData",
                        objDOEntity.AuditRootCauseList.Select(i => new XElement("RootCause",
                             new XAttribute("iSubDOId", i.RootCauseId),
                            new XAttribute("iDOId", i.ParentCheckItemId),
                            new XAttribute("szDisplayName", i.RootCauseItemName),
                             new XAttribute("szOLDisplayName", i.OLRootCauseItemName),
                              new XAttribute("szCheckItemGUID", i.CheckItemGUID),
                               new XAttribute("iParentId", i.ParentRootCauseId),
                               new XAttribute("iLevel", i.Level),
                               new XAttribute("szSubdoIDGUID", i.RootCauseGUID),
                               new XAttribute("szParentDOIDGUID", i.ParentRootCauseGUID)

                        )));
                    }


                    spName = "USP_SET_AUDITCONFIGDOMASTER";
                    SqlCommand command = new SqlCommand(spName, SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    if (objDOEntity.xmlAuditCheckItem != null)
                    {
                        command.Parameters.Add("@xmlDO", SqlDbType.Xml).Value = objDOEntity.xmlAuditCheckItem.ToString();
                    }
                    else
                    {
                        command.Parameters.Add("@xmlDO", SqlDbType.Xml).Value = "<AuditDOData/>";
                    }
                    command.Parameters.Add("@xmlRootCauseDO", SqlDbType.Xml).Value = objDOEntity.xmlAuditRootCauseItem.ToString();
                    command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objDOEntity.SubProcessId;
                    command.Parameters.Add("@bIsActive", SqlDbType.Bit).Value = objDOEntity.IsActive;
                    command.Parameters.Add("@iCreatedBy", SqlDbType.Int).Value = objDOEntity.CreatedBy;
                    command.Parameters.Add("@iModifiedBy", SqlDbType.Int).Value = objDOEntity.ModifiedBy;
                    command.Parameters.Add("@sOperationName", SqlDbType.VarChar).Value = objDOEntity.OperationName;
                    command.Parameters.Add("@IsEditMode", SqlDbType.Bit).Value = objDOEntity.IsEditMode;
                    command.Parameters.Add("@CategoryId", SqlDbType.Int).Value = objDOEntity.CategoryId;
                    command.Parameters.Add("@CategoryDisplayName", SqlDbType.VarChar).Value = objDOEntity.CategoryDisplayName;
                    command.Parameters.Add("@CategoryIsactive", SqlDbType.Bit).Value = objDOEntity.CategoryIsactive;
                    command.Parameters.Add("@CriticalityType", SqlDbType.VarChar).Value = objDOEntity.CriticalityType;
                    command.Parameters.Add("@HeadId", SqlDbType.Int).Value = objDOEntity.HeadId;
                    command.Parameters.Add("@HeadDisplayName", SqlDbType.VarChar).Value = (objDOEntity.HeadDisplayName != null) ? objDOEntity.HeadDisplayName : "";
                    command.Parameters.Add("@HeadingIsactive", SqlDbType.Bit).Value = objDOEntity.HeadingIsactive;
                    command.Parameters.Add("@CriticalityId", SqlDbType.Int).Value = objDOEntity.CriticalityId;
                    command.Parameters.Add("@RatingGroupId", SqlDbType.Int).Value = objDOEntity.RatingGroupId;
                    command.Parameters.Add("@CheckItemGroupName", SqlDbType.VarChar).Value = objDOEntity.CheckItemGroupName;
                    command.Parameters.Add("@CheckItemGroupId", SqlDbType.Int).Value = objDOEntity.CheckItemGroupId;
                    command.Parameters.Add("@CheckitemGroupIsactive", SqlDbType.Bit).Value = objDOEntity.CheckitemGroupIsactive;
                    command.Parameters.Add("@GrpAuditingLogic", SqlDbType.Int).Value = objDOEntity.AuditingLogicId;
                    command.Parameters.Add("@DeleteCTQIDs", SqlDbType.VarChar).Value = objDOEntity.DeleteCTQIDs;
                    command.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    // command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    // outprm.Direction = ParameterDirection.Output;
                    // command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }






                //Hashtable hs = new Hashtable();

                //hs.Add("@xmlDO", objDOEntity.xmlAuditCheckItem);
                //hs.Add("@xmlRootCauseDO", objDOEntity.xmlAuditCheckItem);
                //hs.Add("@iSubProcessId", objDOEntity.SubProcessId);
                //hs.Add("@bIsActive", objDOEntity.ModifiedDate);
                //hs.Add("@iCreatedBy", objDOEntity.ModifiedDate);
                //hs.Add("@iModifiedBy", objDOEntity.ModifiedDate);
                //hs.Add("@sOperationName", objDOEntity.OperationName);
                //hs.Add("@IsEditMode", objDOEntity.IsEditMode);
                //hs.Add("@CategoryId", objDOEntity.CategoryId);
                //hs.Add("@CategoryDisplayName", objDOEntity.CategoryDisplayName);
                //hs.Add("@HeadId", objDOEntity.HeadId);
                //hs.Add("@HeadDisplayName", objDOEntity.HeadDisplayName);
                //hs.Add("@CriticalityId", objDOEntity.CriticalityId);
                //hs.Add("@RatingGroupId", objDOEntity.RatingGroupId);
                //hs.Add("@CheckItemGroupName", objDOEntity.CheckItemGroupName);
                //hs.Add("@CheckItemGroupId", objDOEntity.CheckItemGroupId);

                //DBHelper db = new DBHelper();
                //message = db.SelectSingleValue(spName, hs);


            }

            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
  catch (QuartException ex)
  {
      throw new QuartException(ex.Message, ex.InnerException);
  }
  */
            // return message.ToString();
            return resultValue;

        }

        /// <summary>
        /// this method used for creating, updating and deleting the subprocess details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public string AddeditDefectOpportunity(CheckItemEntity objDOEntity = null)
        {
            //  proxyLogger.Log.Info("SetDefectOpportunity - Called.");
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            string resultValue = "-1";
            int level = objDOEntity.Level;
            XElement Parent = new XElement("root");
            try
            {

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_AUDITDOMASTER", sqlConnection);


                    XElement root = new XElement("xmlArguments");
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DOId)))
                        root.Add(new XAttribute("iDOId", Convert.ToString(objDOEntity.DOId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DODesc)))
                        root.Add(new XAttribute("szDODesc", Convert.ToString(objDOEntity.DODesc)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DisplayName)))
                        root.Add(new XAttribute("szDisplayName", Convert.ToString(objDOEntity.DisplayName)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.IsCritical)))
                        root.Add(new XAttribute("bIsCritical", Convert.ToString(objDOEntity.IsCritical)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.IsHeading)))
                        root.Add(new XAttribute("bIsHeading", Convert.ToString(objDOEntity.IsHeading)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.Level)))
                        root.Add(new XAttribute("iLevel", Convert.ToString(objDOEntity.Level)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ParentDOId)))
                        root.Add(new XAttribute("iParentDOId", Convert.ToString(objDOEntity.ParentDOId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.RatingGroupID)))
                        root.Add(new XAttribute("iRatingGroupId", Convert.ToString(objDOEntity.RatingGroupID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.RatingID)))
                        root.Add(new XAttribute("iRatingId", Convert.ToString(objDOEntity.RatingID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.HeadingID_DOId)))
                        root.Add(new XAttribute("iHeadingID_DOId", Convert.ToString(objDOEntity.HeadingID_DOId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CheckpointID_DOId)))
                        root.Add(new XAttribute("iCheckpointID_DOId", Convert.ToString(objDOEntity.CheckpointID_DOId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DOGroupID)))
                        root.Add(new XAttribute("iDOGroupID", Convert.ToString(objDOEntity.DOGroupID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.Weightage)))
                        root.Add(new XAttribute("fWeightage", Convert.ToString(objDOEntity.Weightage)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ScoringLogic)))
                        root.Add(new XAttribute("iScoringLogic", Convert.ToString(objDOEntity.ScoringLogic)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CategoryID_DOId)))
                        root.Add(new XAttribute("iCategoryDOId", Convert.ToString(objDOEntity.CategoryID_DOId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SubProcessId)))
                        root.Add(new XAttribute("iSubProcessId", Convert.ToString(objDOEntity.SubProcessId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.IsActive)))
                        root.Add(new XAttribute("bIsActive", Convert.ToString(objDOEntity.IsActive)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CreatedBy)))
                        root.Add(new XAttribute("iCreatedBy", Convert.ToString(objDOEntity.CreatedBy)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ModifiedBy)))
                        root.Add(new XAttribute("iModifiedBy", Convert.ToString(objDOEntity.ModifiedBy)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ActionName)))
                        root.Add(new XAttribute("sOpertaionName", Convert.ToString(objDOEntity.ActionName)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CriticalityType)))
                        root.Add(new XAttribute("szCriticalityType", Convert.ToString(objDOEntity.CriticalityType)));



                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("@dsCreatedDate", SqlDbType.SmallDateTime).Value = objDOEntity.CreatedDate;

                    command.Parameters.Add("@dsModifiedDate", SqlDbType.SmallDateTime).Value = objDOEntity.ModifiedDate;

                    Parent.Add(root);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }


            }
            catch (ArgumentException ex)
            {
                //  throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                //  throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                //  throw new QuartException(ex.Message, ex.InnerException);
            }

            return resultValue;
        }
        public string CopyDefectOpportunity(CheckItemEntity objDOEntity)
        {
            objloginfo.Message = ("CopyDefectOpportunity - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            object message = null;
            //proxyLogger.Log.Info("CopyDefectOpportunity - Called.");
            // string resultValue = "-1";
            try
            {
                string spName = string.Empty;
                spName = "USP_SET_COPYDEFECTOPPORTUNITY";
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USP_SET_COPYDEFECTOPPORTUNITY", SqlConnection);
                //    command.CommandType = CommandType.StoredProcedure;


                //command.Parameters.Add("@CheckpointIDs", SqlDbType.VarChar).Value = objDOEntity.CopiedCheckpoints;
                //command.Parameters.Add("@iHeadingID_DOId", SqlDbType.Int).Value = objDOEntity.HeadingID_DOId;
                //command.Parameters.Add("@iCategoryDOId", SqlDbType.Int).Value = objDOEntity.CategoryID_DOId;
                //command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objDOEntity.SubProcessId;
                //command.Parameters.Add("@iCreatedBy", SqlDbType.Int).Value = objDOEntity.CreatedBy;
                //command.Parameters.Add("@dsCreatedDate", SqlDbType.SmallDateTime).Value = objDOEntity.CreatedDate;
                //command.Parameters.Add("@iModifiedBy", SqlDbType.Int).Value = objDOEntity.ModifiedBy;
                //command.Parameters.Add("@dsModifiedDate", SqlDbType.SmallDateTime).Value = objDOEntity.ModifiedDate;

                //command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                //command.ExecuteNonQuery();
                //resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();

                Hashtable hs = new Hashtable();

                hs.Add("@CheckpointIDs", objDOEntity.CopiedCheckpoints);
                hs.Add("@iHeadingID_DOId", objDOEntity.HeadingID_DOId);
                hs.Add("@iCategoryDOId", objDOEntity.CategoryID_DOId);
                hs.Add("@iSubProcessId", objDOEntity.SubProcessId);
                hs.Add("@iCreatedBy", objDOEntity.CreatedBy);
                hs.Add("@dsCreatedDate", objDOEntity.CreatedDate);
                hs.Add("@iModifiedBy", objDOEntity.ModifiedBy);
                hs.Add("@dsModifiedDate", objDOEntity.ModifiedDate);
                // hs.Add("@RETURN_VALUE", 0);

                DBHelper db = new DBHelper();
                message = db.SelectSingleValue(spName, hs);

                // }


            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLoggerLog.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }

            return message.ToString();
            // return resultValue;
        }

        /// <summary>
        /// Method to Get Entity by Record
        /// </summary>
        /// <param name="_Obj">AuditConfigEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetAuditEntityRecordByEntity(AuditConfigEntity _Obj)
        {
            objloginfo.Message = ("GetAuditEntityRecordByEntity - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetAuditEntityRecordByEntity - Called.");
            // DataTable dt = new DataTable();
            DataSet _ds = new DataSet();
            try
            {
                string spName = string.Empty;
                spName = "usp_Get_AuditConfig";
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //    SqlCommand command = new SqlCommand("usp_Get_AuditConfig", sqlConnection);
                //    command.Parameters.Add("@SubProcessID", SqlDbType.Int).Value = _Obj.SubProcessId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_ds);
                //}

                Hashtable hs = new Hashtable();

                hs.Add("@SubProcessID", _Obj.SubProcessId);

                DBHelper db = new DBHelper();
                _ds = db.SelectDataSet(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;//new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        */
            return _ds.Tables[0];
        }
        /// <summary>
        /// Method to Set Sub Defect opportunity
        /// </summary>
        /// <param name="objDOEntity">SubDefectEntity</param>
        /// <returns>string</returns>
        public string SetRC(RootCauseEntity objDOEntity)
        {
            objloginfo.Message = ("SetSubDefectOpportunity - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("SetSubDefectOpportunity - Called.");
            //string resultValue = "-1";
            XElement Parent = new XElement("root");
            XElement root = new XElement("xmlArguments");
            object message = null;
            try
            {
                string spName = string.Empty;
                spName = "USP_SET_AUDITSUBDOMASTER";
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                // {
                //  sqlConnection.Open();
                //  SqlCommand command = new SqlCommand("USP_SET_AUDITSUBDOMASTER", sqlConnection);
                //  command.CommandType = CommandType.StoredProcedure;

                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SubDOId)))
                    root.Add(new XAttribute("iSubDOId", Convert.ToString(objDOEntity.SubDOId)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DOId)))
                    root.Add(new XAttribute("iDOId", Convert.ToString(objDOEntity.DOId)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.Level)))
                    root.Add(new XAttribute("iLevel", Convert.ToString(objDOEntity.Level)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DisplayName)))
                    root.Add(new XAttribute("szDisplayName", Convert.ToString(objDOEntity.DisplayName)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ParentSubDOId)))
                    root.Add(new XAttribute("iParentSubDOId", Convert.ToString(objDOEntity.ParentSubDOId)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SubProcessId)))
                    root.Add(new XAttribute("iSubProcessId", Convert.ToString(objDOEntity.SubProcessId)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.IsActive)))
                    root.Add(new XAttribute("bIsActive", (objDOEntity == null) ? 0 : (objDOEntity.IsActive == true ? 1 : 0)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CreatedBy)))
                    root.Add(new XAttribute("iCreatedBy", Convert.ToString(objDOEntity.CreatedBy)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ModifiedBy)))
                    root.Add(new XAttribute("iModifiedBy", Convert.ToString(objDOEntity.ModifiedBy)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ActionName)))
                    root.Add(new XAttribute("sOpertaionName", Convert.ToString(objDOEntity.ActionName)));
                if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.IsDefault)))
                    root.Add(new XAttribute("bIsDefault", (objDOEntity == null) ? 0 : (objDOEntity.IsDefault == true ? 1 : 0)));

                Parent.Add(root);
                //command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Parent.ToString();

                //command.Parameters.Add("@dsCreatedDate", SqlDbType.SmallDateTime).Value = objDOEntity.CreatedDate;
                //command.Parameters.Add("@dsModifiedDate", SqlDbType.SmallDateTime).Value = objDOEntity.ModifiedDate;
                //command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                //command.ExecuteNonQuery();
                //resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();

                Hashtable hs = new Hashtable();
                hs.Add("@ExcelData", Convert.ToString(Parent));
                hs.Add("@dsCreatedDate", objDOEntity.CreatedDate);
                hs.Add("@dsModifiedDate", objDOEntity.ModifiedDate);
                // hs.Add("@RETURN_VALUE", 0);

                DBHelper db = new DBHelper();
                message = db.SelectSingleValue(spName, hs);
            }



            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;//new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        */
            return message.ToString();
        }
        /// <summary>
        /// Method to Get Defect oppourtunityList
        /// </summary>
        /// <param name="objDOEntity">DefectOpportunityEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetDefectOpportunityList(CheckItemEntity objDOEntity)
        {
            objloginfo.Message = ("GetDefectOpportunityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetDefectOpportunityList - Called.");
            DataTable _dt = new DataTable();
            int level = objDOEntity.Level;
            XElement Parent = new XElement("root");
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            try
            {
                string spName = string.Empty;
                Hashtable hs = new Hashtable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = null;
                    XElement root = new XElement("xmlArguments");

                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.StartRowIndex)))
                        root.Add(new XAttribute("StartRowIndex", Convert.ToString(objDOEntity.StartRowIndex) ?? "1"));

                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.MaximumRows)))
                        root.Add(new XAttribute("MaximumRows", Convert.ToString(objDOEntity.MaximumRows) ?? "10"));

                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SortOrder)))
                        root.Add(new XAttribute("SortOrder", Convert.ToString(objDOEntity.SortOrder) ?? "ASC"));

                    if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SortColumn)))
                        root.Add(new XAttribute("SortColumn", Convert.ToString(objDOEntity.SortColumn) ?? String.Empty));

                    if (objDOEntity.Level != 10)
                    {
                        // spName = "USP_GET_AUDITDOMASTER";
                        command = new SqlCommand("USP_GET_AUDITDOMASTER", sqlConnection);


                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DOId)))
                            root.Add(new XAttribute("iDOId", Convert.ToString(objDOEntity.DOId) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.Level)))
                            root.Add(new XAttribute("iLevel", Convert.ToString(objDOEntity.Level) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.ParentDOId)))
                            root.Add(new XAttribute("iParentDOId", Convert.ToString(objDOEntity.ParentDOId)) ?? null);
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SubProcessId)))
                            root.Add(new XAttribute("iSubProcessId", Convert.ToString(objDOEntity.SubProcessId)) ?? null);
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.DOGroupID)))
                            root.Add(new XAttribute("iDOGroupID", Convert.ToString(objDOEntity.DOGroupID) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.RatingID)))
                            root.Add(new XAttribute("iRatingID", Convert.ToString(objDOEntity.RatingID)) ?? null);
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.HeadingID_DOId)))
                            root.Add(new XAttribute("HeadingID", Convert.ToString(objDOEntity.HeadingID_DOId) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CheckpointID_DOId)))
                            root.Add(new XAttribute("CheckpointID", Convert.ToString(objDOEntity.CheckpointID_DOId) ?? null));


                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.CategoryID_DOId)) && objDOEntity.CategoryID_DOId != 0)
                            root.Add(new XAttribute("CategoryID", Convert.ToString(objDOEntity.CategoryID_DOId)));

                        Parent.Add(root);
                        command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Parent.ToString();
                        //  hs.Add("@ExcelData", Convert.ToString(Parent));
                    }
                    else
                    {
                        // spName = "usp_Get_HeadingSearch";
                        command = new SqlCommand("usp_Get_HeadingSearch", sqlConnection);
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SearchStr)))
                            root.Add(new XAttribute("Searchstr", Convert.ToString(objDOEntity.SearchStr) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SelectedProcessId)))
                            root.Add(new XAttribute("ProcessID", Convert.ToString(objDOEntity.SelectedProcessId) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SubProcessId)))
                            root.Add(new XAttribute("SubprocessID", Convert.ToString(objDOEntity.SubProcessId) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.SelectedProgramId)))
                            root.Add(new XAttribute("ProgramID", Convert.ToString(objDOEntity.SelectedProgramId) ?? null));
                        if (!string.IsNullOrEmpty(Convert.ToString(objDOEntity.HeadingID_DOId)))
                            root.Add(new XAttribute("headingID", Convert.ToString(objDOEntity.HeadingID_DOId) ?? null));

                        root.Add(new XAttribute("SearchType", string.Empty));
                        Parent.Add(root);

                        hs.Add("@ExcelData", Convert.ToString(Parent));
                        command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Parent.ToString();

                    }
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                    //DBHelper db = new DBHelper();
                    //_dt = db.SelectDataTable(spName, hs);
                }

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        */
            return _dt;

        }
        /// <summary>
        /// Method to get SubDefect oppourtunityList
        /// </summary>
        /// <param name="objDOEntity">SubDefectEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetRootCauseList(RootCauseEntity objDOEntity)
        {
            objloginfo.Message = ("GetSubDefectOpportunityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetSubDefectOpportunityList - Called.");
            DataTable _dt = new DataTable();
            try
            {
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //  sqlConnection.Open();
                string spName = string.Empty;
                spName = "USP_GET_AuditSubDOMaster";
                //SqlCommand command = new SqlCommand("USP_GET_AuditSubDOMaster", sqlConnection);
                //command.Parameters.Add("@iSubDOId", SqlDbType.Int).Value = objDOEntity.SubDOId;
                //command.Parameters.Add("@iDOId", SqlDbType.Int).Value = objDOEntity.DOId;
                //command.Parameters.Add("@iLevel", SqlDbType.Int).Value = objDOEntity.Level;
                //command.Parameters.Add("@iParentSubDOId", SqlDbType.Int).Value = objDOEntity.ParentSubDOId;
                //command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objDOEntity.StartRowIndex;
                //command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objDOEntity.MaximumRows;
                //command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objDOEntity.SortOrder;
                //command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objDOEntity.SortColumn;
                //command.CommandType = CommandType.StoredProcedure;
                //SqlDataAdapter adp = new SqlDataAdapter(command);
                //adp.Fill(_dt);
                //    }
                Hashtable hs = new Hashtable();
                hs.Add("@iSubDOId", objDOEntity.SubDOId);
                hs.Add("@iDOId", objDOEntity.DOId);
                hs.Add("@iLevel", objDOEntity.Level);
                hs.Add("@iParentSubDOId", objDOEntity.ParentSubDOId);
                hs.Add("@StartRowIndex", objDOEntity.StartRowIndex);
                hs.Add("@MaximumRows", objDOEntity.MaximumRows);
                hs.Add("@SortOrder", objDOEntity.SortOrder);
                hs.Add("@SortColumn", objDOEntity.SortColumn);

                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        */
            return _dt;
        }

        /// <summary>
        /// Method to get SubDefect oppourtunityList
        /// </summary>
        /// <param name="objDOEntity">SubDefectEntity</param>
        /// <returns>DataTable</returns>
        public DataSet GetCTQItems(AuditCheckItemsInfo objDOEntity)
        {
            dbConnectionString = connectionstring.GetConnectionString(objDOEntity.AppID, objDOEntity.TenantID);
            objloginfo.Message = ("GetSubDefectOpportunityList - Called.");

            DataSet _ds = new DataSet();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_AuditDOandRCAList", sqlConnection);
                    command.Parameters.Add("@CategoryID", SqlDbType.Int).Value = objDOEntity.CategoryId;
                    command.Parameters.Add("@headingID", SqlDbType.Int).Value = objDOEntity.HeadId;
                    command.Parameters.Add("@iLevel", SqlDbType.Int).Value = 3;
                    command.Parameters.Add("@SubprocessID", SqlDbType.Int).Value = objDOEntity.SubProcessId;
                    command.Parameters.Add("@iRatingGroupID", SqlDbType.Int).Value = objDOEntity.RatingGroupId;
                    command.Parameters.Add("@iCTQGroupID", SqlDbType.Int).Value = objDOEntity.CheckItemGroupId;
                    command.Parameters.Add("@CriticalityType", SqlDbType.VarChar).Value = objDOEntity.CriticalityType;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }


            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            return _ds;
        }

    }
}
