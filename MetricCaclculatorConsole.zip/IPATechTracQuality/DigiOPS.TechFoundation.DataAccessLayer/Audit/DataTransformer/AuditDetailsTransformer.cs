﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   internal class AuditDetailsTransformer
    {
       internal List<AuditDetailsEntity> mapToDefectOpportunity(DataSet _ds)
        {
            List<AuditDetailsEntity> baseEntityList = new List<AuditDetailsEntity>();
            if (_ds.Tables.Count == 1)
            {
                baseEntityList = (from p in _ds.Tables[0].AsEnumerable()
                                  select new AuditDetailsEntity
                                  {
                                      isDeleted = Convert.ToBoolean(p["IsDeleted"] == DBNull.Value ? 0 : p["IsDeleted"]),

                                  }).ToList();
            }
            else if (_ds.Tables.Contains("Table") && _ds.Tables.Contains("Table1"))
            {
                baseEntityList = (from p in _ds.Tables[0].AsEnumerable()
                                  select new AuditDetailsEntity
                                  {
                                      DOId = p.Table.Columns.Contains("iDOId") == true ? Convert.ToInt32(p["iDOId"] == DBNull.Value ? 0 : p["iDOId"]) : 0,
                                      DisplayName = p.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]) : string.Empty,
                                      szDODesc = p.Table.Columns.Contains("szDoDesc") == true ? Convert.ToString(p["szDoDesc"] == DBNull.Value ? string.Empty : p["szDoDesc"]) : string.Empty,
                                      IsCritical = p.Table.Columns.Contains("bIsCritical") == true ? Convert.ToBoolean(p["bIsCritical"] == DBNull.Value ? false : p["bIsCritical"]) : false,
                                      CriticalityType = p.Table.Columns.Contains("szCriticalityType") == true ? Convert.ToString(p["szCriticalityType"] == DBNull.Value ? string.Empty : p["szCriticalityType"]) : string.Empty,
                                      DOGroupID = p.Table.Columns.Contains("iDOGroupID") == true ? Convert.ToInt32(p["iDOGroupID"] == DBNull.Value ? 0 : p["iDOGroupID"]) : 0,
                                      DOType = p.Table.Columns.Contains("szDOType") == true ? Convert.ToString(p["szDOType"] == DBNull.Value ? string.Empty : p["szDOType"]) : string.Empty,
                                      HasSubDefects = p.Table.Columns.Contains("bHasSubDO") == true ? Convert.ToBoolean(p["bHasSubDO"] == DBNull.Value ? false : p["bHasSubDO"]) : false,
                                      Level = p.Table.Columns.Contains("iLevel") == true ? Convert.ToInt32(p["iLevel"] == DBNull.Value ? 0 : p["iLevel"]) : 0,
                                      GroupWeightage = p.Table.Columns.Contains("GroupWeightage") == true ? Convert.ToSingle(p["GroupWeightage"] == DBNull.Value ? 0 : p["GroupWeightage"]) : 0,
                                      MaxWeightage = p.Table.Columns.Contains("fMaxWeightage") == true ? Convert.ToSingle(p["fMaxWeightage"] == DBNull.Value ? 0 : p["fMaxWeightage"]) : 0,
                                      ParentDOId = p.Table.Columns.Contains("iParentDOId") == true ? Convert.ToInt32(p["iParentDOId"] == DBNull.Value ? 0 : p["iParentDOId"]) : 0,
                                      SelectedRatingId = p.Table.Columns.Contains("iRatingId") == true ? Convert.ToInt32(p["iRatingId"] == DBNull.Value ? 0 : p["iRatingId"]) : 0,
                                      SelectedSubDefect1Id = p.Table.Columns.Contains("SelectedSubDefect1") == true ? Convert.ToInt32(p["SelectedSubDefect1"] == DBNull.Value ? 0 : p["SelectedSubDefect1"]) : 0,
                                      SelectedSubDefect2Id = p.Table.Columns.Contains("SelectedSubDefect2") == true ? Convert.ToInt32(p["SelectedSubDefect2"] == DBNull.Value ? 0 : p["SelectedSubDefect2"]) : 0,
                                      SelectedSubDefect3Id = p.Table.Columns.Contains("SelectedSubDefect3") == true ? Convert.ToInt32(p["SelectedSubDefect3"] == DBNull.Value ? 0 : p["SelectedSubDefect3"]) : 0,
                                      SelectedSubDefect4Id = p.Table.Columns.Contains("SelectedSubDefect4") == true ? Convert.ToInt32(p["SelectedSubDefect4"] == DBNull.Value ? 0 : p["SelectedSubDefect4"]) : 0,
                                      SelectedSubDefect5Id = p.Table.Columns.Contains("SelectedSubDefect5") == true ? Convert.ToInt32(p["SelectedSubDefect5"] == DBNull.Value ? 0 : p["SelectedSubDefect5"]) : 0,
                                      DefaultSubDefect1Id = p.Table.Columns.Contains("DefaultSubDefect1") == true ? Convert.ToInt32(p["DefaultSubDefect1"] == DBNull.Value ? 0 : p["DefaultSubDefect1"]) : 0,
                                      DefaultSubDefect2Id = p.Table.Columns.Contains("DefaultSubDefect2") == true ? Convert.ToInt32(p["DefaultSubDefect2"] == DBNull.Value ? 0 : p["DefaultSubDefect2"]) : 0,
                                      DefaultSubDefect3Id = p.Table.Columns.Contains("DefaultSubDefect3") == true ? Convert.ToInt32(p["DefaultSubDefect3"] == DBNull.Value ? 0 : p["DefaultSubDefect3"]) : 0,
                                      DefaultSubDefect4Id = p.Table.Columns.Contains("DefaultSubDefect4") == true ? Convert.ToInt32(p["DefaultSubDefect4"] == DBNull.Value ? 0 : p["DefaultSubDefect4"]) : 0,
                                      DefaultSubDefect5Id = p.Table.Columns.Contains("DefaultSubDefect5") == true ? Convert.ToInt32(p["DefaultSubDefect5"] == DBNull.Value ? 0 : p["DefaultSubDefect5"]) : 0,
                                      CorrectEmployee = p.Table.Columns.Contains("CorrectEmployee") == true ? Convert.ToInt32(p["CorrectEmployee"] == DBNull.Value ? 0 : p["CorrectEmployee"]) : 0,
                                      ErrorField = p.Table.Columns.Contains("ErrorField") == true ? Convert.ToInt32(p["ErrorField"] == DBNull.Value ? 0 : p["ErrorField"]) : 0,
                                      CTQComments = p.Table.Columns.Contains("CTQComments") == true ? Convert.ToString(p["CTQComments"] == DBNull.Value ? string.Empty : p["CTQComments"]) : string.Empty,
                                      RatingType = (from p1 in _ds.Tables[1].Select(" iDOId = '" + Convert.ToString(p["iDOId"]) + "'").AsEnumerable()
                                                    select new TransDropDown
                                                    {
                                                        Value = p1.Table.Columns.Contains("iRatingId") == true ? Convert.ToString(p1["iRatingId"] == DBNull.Value ? 0 : p1["iRatingId"]) : "0",
                                                        Text = p1.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p1["szDisplayName"] == DBNull.Value ? 0 : p1["szDisplayName"]) : "0",
                                                        Score = p1.Table.Columns.Contains("Weightage") == true ? Convert.ToString(p1["Weightage"] == DBNull.Value ? string.Empty : p1["Weightage"]) : string.Empty,
                                                        IsNA = p1.Table.Columns.Contains("bIsNotApplicable") == true ? Convert.ToBoolean(p1["bIsNotApplicable"]) : false,
                                                        IsSelected = p1.Table.Columns.Contains("iRatingId") == true ? (Convert.ToString(p1["iRatingId"] == DBNull.Value ? 0 : p1["iRatingId"]) == Convert.ToString(p["iRatingId"] == DBNull.Value ? 0 : p["iRatingId"]) ? true : false) : false
                                                    }).Cast<TransDropDown>().ToList(),
                                      SubDefectlevel1 = (from p2 in _ds.Tables[4].Select(" iDOId = '" + Convert.ToString(p["iDOId"]) + "' AND iParentSubDOId = 0").AsEnumerable()
                                                         select new TransDropDown
                                                         {
                                                             Value = p2.Table.Columns.Contains("iSubDOId") == true ? Convert.ToString(p2["iSubDOId"] == DBNull.Value ? 0 : p2["iSubDOId"]) : "0",
                                                             Text = p2.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p2["szDisplayName"] == DBNull.Value ? 0 : p2["szDisplayName"]) : string.Empty
                                                         }).Cast<TransDropDown>().ToList(),
                                      SubDefectList = (from p3 in _ds.Tables[4].AsEnumerable()
                                                       select new SubDefectDetailsEntity
                                                       {
                                                           SubDOId = p3.Table.Columns.Contains("iSubDOId") == true ? Convert.ToInt32(p3["iSubDOId"] == DBNull.Value ? 0 : p3["iSubDOId"]) : 0,
                                                           DOId = p3.Table.Columns.Contains("iDOId") == true ? Convert.ToInt32(p3["iDOId"] == DBNull.Value ? 0 : p3["iDOId"]) : 0,
                                                           ParentSubDOId = p3.Table.Columns.Contains("iParentSubDOId") == true ? Convert.ToInt32(p3["iParentSubDOId"] == DBNull.Value ? 0 : p3["iParentSubDOId"]) : 0,
                                                           Level = p3.Table.Columns.Contains("iLevel") == true ? Convert.ToInt32(p3["iLevel"] == DBNull.Value ? 0 : p3["iLevel"]) : 0
                                                       }).Cast<SubDefectDetailsEntity>().ToList(),
                                  }).ToList();
            }
            return baseEntityList;

        }

       internal List<AuditDetailsEntity> mapToHeadingDetails(DataSet _ds)
        {
            List<AuditDetailsEntity> baseEntityList = new List<AuditDetailsEntity>();
            if (_ds.Tables.Contains("Table2") && _ds.Tables.Contains("Table3") && _ds.Tables.Contains("Table7"))
            {
                baseEntityList = (from p in _ds.Tables[2].AsEnumerable()
                                  select new TransactionDetailsEntity
                                  {
                                      RecordId = p.Table.Columns.Contains("iRecordId") == true ? Convert.ToInt32(p["iRecordId"] == DBNull.Value ? 0 : p["iRecordId"]) : 0,
                                      Process = p.Table.Columns.Contains("szProcessName") == true ? Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]) : string.Empty,
                                      SubProcess = p.Table.Columns.Contains("SubProcessName") == true ? Convert.ToString(p["SubProcessName"] == DBNull.Value ? string.Empty : p["SubProcessName"]) : string.Empty,
                                      Program = p.Table.Columns.Contains("ProgramName") == true ? Convert.ToString(p["ProgramName"] == DBNull.Value ? string.Empty : p["ProgramName"]) : string.Empty,
                                      ProcessedBy = p.Table.Columns.Contains("ProcessedByName") == true ? Convert.ToString(p["ProcessedByName"] == DBNull.Value ? string.Empty : p["ProcessedByName"]) : string.Empty,
                                      ProcessedDate = p.Table.Columns.Contains("dsProcessedDate") == true ? Convert.ToString(p["dsProcessedDate"] == DBNull.Value ? string.Empty : p["dsProcessedDate"]) : string.Empty,
                                      Reference = p.Table.Columns.Contains("szCoreTransStatusDesc") == true ? Convert.ToString(p["szCoreTransStatusDesc"] == DBNull.Value ? string.Empty : p["szCoreTransStatusDesc"]) : string.Empty,
                                      AuditId = p.Table.Columns.Contains("iAuditId") == true ? Convert.ToInt32(p["iAuditId"] == DBNull.Value ? 0 : p["iAuditId"]) : 0,
                                      AuditTypeId = p.Table.Columns.Contains("iAuditTypeId") == true ? Convert.ToInt32(p["iAuditTypeId"] == DBNull.Value ? 0 : p["iAuditTypeId"]) : 0,
                                      AuditTypeName = p.Table.Columns.Contains("szAuditTypeName") == true ? Convert.ToString(p["szAuditTypeName"] == DBNull.Value ? string.Empty : p["szAuditTypeName"]) : string.Empty,
                                      AuditWorkFlowId = p.Table.Columns.Contains("iAuditWorkflowId") == true ? Convert.ToInt32(p["iAuditWorkflowId"] == DBNull.Value ? 0 : p["iAuditWorkflowId"]) : 0,
                                      AuditStatusId = p.Table.Columns.Contains("iStatusId") == true ? Convert.ToInt32(p["iStatusId"] == DBNull.Value ? 0 : p["iStatusId"]) : 0,
                                      AuditStatus = p.Table.Columns.Contains("AuditStatus") == true ? Convert.ToString(p["AuditStatus"] == DBNull.Value ? string.Empty : p["AuditStatus"]) : string.Empty,
                                      AuditLogicType = p.Table.Columns.Contains("szAuditingLogicType") == true ? Convert.ToString(p["szAuditingLogicType"] == DBNull.Value ? string.Empty : p["szAuditingLogicType"]) : string.Empty,
                                      ScoringLogicType = p.Table.Columns.Contains("szScoringLogicType") == true ? Convert.ToString(p["szScoringLogicType"] == DBNull.Value ? string.Empty : p["szScoringLogicType"]) : string.Empty,
                                      SubDefectLevel = p.Table.Columns.Contains("bySubDefectLevel") == true ? Convert.ToInt32(p["bySubDefectLevel"] == DBNull.Value ? 0 : p["bySubDefectLevel"]) : 0,
                                      CopySubdefectLevel = p.Table.Columns.Contains("iCopySubdefectLevel") == true ? Convert.ToInt32(p["iCopySubdefectLevel"] == DBNull.Value ? 0 : p["iCopySubdefectLevel"]) : 0,


                                      IsEmployeeApp = p.Table.Columns.Contains("bIsEmpNeeded") == true ? Convert.ToBoolean(p["bIsEmpNeeded"] == DBNull.Value ? false : p["bIsEmpNeeded"]) : false,
                                      IsCriticalApp = p.Table.Columns.Contains("bIsCritcalityNeeded") == true ? Convert.ToBoolean(p["bIsCritcalityNeeded"] == DBNull.Value ? false : p["bIsCritcalityNeeded"]) : false,
                                      IsTATApp = p.Table.Columns.Contains("bIsTATNeeded") == true ? Convert.ToBoolean(p["bIsTATNeeded"] == DBNull.Value ? false : p["bIsTATNeeded"]) : false,
                                      TotCorrectEmployee = p.Table.Columns.Contains("CorrectEmployee") == true ? Convert.ToInt32(p["CorrectEmployee"] == DBNull.Value ? 0 : p["CorrectEmployee"]) : 0,
                                      IsLineApp = p.Table.Columns.Contains("bIsLineNeeded") == true ? Convert.ToBoolean(p["bIsLineNeeded"] == DBNull.Value ? false : p["bIsLineNeeded"]) : false,
                                      bIsLineApplicable = p.Table.Columns.Contains("bIsProgramLineNeeded") == true ? Convert.ToBoolean(p["bIsProgramLineNeeded"] == DBNull.Value ? false : p["bIsProgramLineNeeded"]) : false,
                                      iSubCategory = p.Table.Columns.Contains("iSubcategoryID") == true ? Convert.ToInt32(p["iSubcategoryID"] == DBNull.Value ? 0 : p["iSubcategoryID"]) : 0,
                                      TotLines = p.Table.Columns.Contains("Line") == true ? Convert.ToInt32(p["Line"] == DBNull.Value ? 0 : p["Line"]) : 0,
                                      iPageCntData = p.Table.Columns.Contains("PageCntData") == true ? Convert.ToInt32(p["PageCntData"] == DBNull.Value ? 0 : p["PageCntData"]) : 0,

                                      AuditFindingId = p.Table.Columns.Contains("iAuditFindingId") == true ? Convert.ToInt32(p["iAuditFindingId"] == DBNull.Value ? 0 : p["iAuditFindingId"]) : 0,
                                      PrevQualityScore = p.Table.Columns.Contains("fQualityScorePrev") == true ? Math.Round(Convert.ToSingle(p["fQualityScorePrev"] == DBNull.Value ? 0 : p["fQualityScorePrev"]), 2) : 0,
                                      QualityScore = p.Table.Columns.Contains("fQualityScore") == true ? Convert.ToSingle(p["fQualityScore"] == DBNull.Value ? 0 : p["fQualityScore"]) : 0,
                                      PrevFieldQualityScore = p.Table.Columns.Contains("fFieldQualityScorePrev") == true ? Math.Round(Convert.ToSingle(p["fFieldQualityScorePrev"] == DBNull.Value ? 0 : p["fFieldQualityScorePrev"]), 2) : 0,
                                      FieldQualityScore = p.Table.Columns.Contains("fFieldQualityScore") == true ? Math.Round(Convert.ToSingle(p["fFieldQualityScore"] == DBNull.Value ? 0 : p["fFieldQualityScore"]), 2) : 0,
                                      AuditFeedback = p.Table.Columns.Contains("AuditFeedBack") == true ? Convert.ToString(p["AuditFeedBack"] == DBNull.Value ? string.Empty : p["AuditFeedBack"]) : string.Empty,
                                      SelectedFatalStatus = p.Table.Columns.Contains("szFatalStatus") == true ? Convert.ToString(p["szFatalStatus"] == DBNull.Value ? string.Empty : p["szFatalStatus"]) : string.Empty,
                                      UploadFilePath = p.Table.Columns.Contains("UploadFilePath") == true ? Convert.ToString(p["UploadFilePath"] == DBNull.Value ? string.Empty : p["UploadFilePath"]) : string.Empty,
                                      ApproverComments = p.Table.Columns.Contains("ApproverComments") == true ? Convert.ToString(p["ApproverComments"] == DBNull.Value ? string.Empty : p["ApproverComments"]) : string.Empty,
                                      RecommendationComments = p.Table.Columns.Contains("RecommendationComments") == true ? Convert.ToString(p["RecommendationComments"] == DBNull.Value ? string.Empty : p["RecommendationComments"]) : string.Empty,
                                      ApprovalStatus = p.Table.Columns.Contains("ApprovalStatus") == true ? Convert.ToString(p["ApprovalStatus"] == DBNull.Value ? string.Empty : p["ApprovalStatus"]) : string.Empty,
                                      TATFeedbackComments = p.Table.Columns.Contains("TATFeedbackComments") == true ? Convert.ToString(p["TATFeedbackComments"] == DBNull.Value ? string.Empty : p["TATFeedbackComments"]) : string.Empty,
                                      SelectedTATFeedback = p.Table.Columns.Contains("szTATFeedback") == true ? Convert.ToString(p["szTATFeedback"] == DBNull.Value ? string.Empty : p["szTATFeedback"]) : string.Empty,
                                      InternalAuditorName = p.Table.Columns.Contains("InternalAuditorName") == true ? Convert.ToString(p["InternalAuditorName"] == DBNull.Value ? string.Empty : p["InternalAuditorName"]) : string.Empty,
                                      IsCTQComments = p.Table.Columns.Contains("blsProgramCTQCommentsNeeded") == true ? Convert.ToBoolean(p["blsProgramCTQCommentsNeeded"] == DBNull.Value ? false : p["blsProgramCTQCommentsNeeded"]) : false,
                                      DynamicElementList = (from p1 in _ds.Tables[3].Select(" iRecordId = '" + Convert.ToString(p["iRecordId"]) + "'").AsEnumerable()
                                                            select new DynamicElementEntity
                                                            {
                                                                szElementName = p1.Table.Columns.Contains("szElementName") == true ? Convert.ToString(p1["szElementName"] == DBNull.Value ? string.Empty : p1["szElementName"]) : string.Empty,
                                                                sznElementData = p1.Table.Columns.Contains("sznElementData") == true ? Convert.ToString(p1["sznElementData"] == DBNull.Value ? string.Empty : p1["sznElementData"]) : string.Empty,
                                                            }).Cast<DynamicElementEntity>().ToList(),
                                      ButtonDisableList = (from p2 in _ds.Tables[7].AsEnumerable()
                                                           select new AuditDetailsEntity
                                                           {
                                                               isbtnDisable = p2.Table.Columns.Contains("btnDisable") == true ? Convert.ToBoolean(p2["btnDisable"] == DBNull.Value ? 0 : p2["btnDisable"]) : false,

                                                           }).Cast<AuditDetailsEntity>().ToList(),
                                  }).Cast<AuditDetailsEntity>().ToList();
            }
            return baseEntityList;


        }

       internal List<AuditDetailsEntity> mapToAuditNotesDetails(DataSet _ds)
        {
            List<AuditDetailsEntity> baseEntityList = new List<AuditDetailsEntity>();
            if (_ds.Tables.Contains("Table5"))
            {
                baseEntityList = (from p in _ds.Tables[5].AsEnumerable()
                                  select new AuditNotesEntity
                                  {
                                      NoteId = p.Table.Columns.Contains("iAuditNotesId") == true ? Convert.ToInt32(p["iAuditNotesId"] == DBNull.Value ? 0 : p["iAuditNotesId"]) : 0,
                                      szNotes = p.Table.Columns.Contains("szComment") == true ? Convert.ToString(p["szComment"] == DBNull.Value ? string.Empty : p["szComment"]) : string.Empty,
                                      NotesCreateBy = p.Table.Columns.Contains("iCreatedBy") == true ? Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]) : string.Empty,
                                      NotesCreatedDate = p.Table.Columns.Contains("dsCreatedDate") == true ? Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]) : DateTime.MinValue,
                                  }).Cast<AuditDetailsEntity>().ToList();
            }
            return baseEntityList;
        }

       internal List<AuditDetailsEntity> mapToCombinedConfiguration(DataSet _ds)
        {
            List<AuditDetailsEntity> baseEntityList = new List<AuditDetailsEntity>();
            if (_ds.Tables.Contains("Table6"))
            {
                baseEntityList = (from p in _ds.Tables[6].AsEnumerable()
                                  select new CombinedAccuracyEntityViewModel
                                  {
                                      IsCombinedConfigurationDone = p.Table.Columns.Contains("CombinedConfiguration") == true ? Convert.ToBoolean(p["CombinedConfiguration"] == DBNull.Value ? 0 : p["CombinedConfiguration"]) : false,

                                  }).Cast<AuditDetailsEntity>().ToList();
            }
            return baseEntityList;



        }

       internal List<SubDefectDetailsEntity> MapToDropDownList(DataTable dt)
        {
            List<SubDefectDetailsEntity> EntityList = new List<SubDefectDetailsEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlist
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<SubDefectDetailsEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlist
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<SubDefectDetailsEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlist
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<SubDefectDetailsEntity>().ToList();

            }

            return EntityList;
        }

       internal AuditDOEntity GetAuditAndDeleteStatus(DataTable dt)
        {
            AuditDOEntity obj = new AuditDOEntity();
            obj = (from p in dt.AsEnumerable()
                   select new AuditDOEntity
                   {
                       isDeleted = Convert.ToBoolean(p["bIsDeleted"] == DBNull.Value ? 0 : p["bIsDeleted"]),
                       isAudited = Convert.ToBoolean(p["bIsAudited"] == DBNull.Value ? 0 : p["bIsAudited"])
                   }).FirstOrDefault();
            return obj;
        }

       internal AuditDOEntity GetStatus(DataTable dt)
        {
            AuditDOEntity obj = new AuditDOEntity();
            obj = (from p in dt.AsEnumerable()
                   select new AuditDOEntity
                   {
                       isPicked = Convert.ToBoolean(p["bIsApprovalStatus"] == DBNull.Value ? 0 : p["bIsApprovalStatus"]),

                   }).FirstOrDefault();
            return obj;
        }

    }
}
