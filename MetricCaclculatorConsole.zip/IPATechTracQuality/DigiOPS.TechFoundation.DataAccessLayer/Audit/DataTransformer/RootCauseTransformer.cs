﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class RootCauseTransformer
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        internal List<RootCauseEntity> MapToRCConfig(DataTable dt)
        {
            objloginfo.Message = ("MapToSubDefectOppConfig to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToSubDefectOppConfig to Entity List - Calling.");
            List<RootCauseEntity> baseEntityList = new List<RootCauseEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new RootCauseEntity
                              {
                                  SubDOId = Convert.ToInt32(p["iSubDOId"] == DBNull.Value ? 0 : p["iSubDOId"]),
                                  DOId = Convert.ToInt32(p["CheckpointID"] == DBNull.Value ? 0 : p["CheckpointID"]),
                                  DisplayName = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),
                                  CategoryID_DOId = Convert.ToInt32(p["CategoryID"] == DBNull.Value ? 0 : p["CategoryID"]),
                                  HeadingID_DOId = Convert.ToInt32(p["HeadingID"] == DBNull.Value ? 0 : p["HeadingID"]),
                                  Level = Convert.ToInt32(p["iLevel"] == DBNull.Value ? 0 : p["iLevel"]),
                                  ParentSubDOId = Convert.ToInt32(p["iParentSubDOId"] == DBNull.Value ? 0 : p["iParentSubDOId"]),
                                  SubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  IsActive = Convert.ToBoolean(p["bIsActive"] != DBNull.Value ? p["bIsActive"] : false),
                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  IsDefault = Convert.ToBoolean(p["bIsDefault"] != DBNull.Value ? p["bIsDefault"] : false),
                                  Isdefaultneeded = Convert.ToBoolean(p["defaultneeded"] != DBNull.Value ? p["defaultneeded"] : false),
                              }).ToList();
            objloginfo.Message = ("MapToSubDefectOppConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToSubDefectOppConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<RootCauseEntity> MapToDropDownList(DataTable dt)
        {
            List<RootCauseEntity> EntityList = new List<RootCauseEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TranDropDown
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<RootCauseEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TranDropDown
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<RootCauseEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TranDropDown
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<RootCauseEntity>().ToList();

            }

            return EntityList;
        }

    }
}
