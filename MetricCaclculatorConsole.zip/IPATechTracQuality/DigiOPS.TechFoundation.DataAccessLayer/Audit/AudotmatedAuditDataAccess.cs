﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AudotmatedAuditDataAccess
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        AudotmatedAuditDAO objautomateddao = new AudotmatedAuditDAO();


        public List<List<DataelementAutomatedAuditEntity>> GetDataElement(int recordid)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataSet ds = new DataSet();
            List<DataelementAutomatedAuditEntity> objoutputOCR = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> objoutputLOS = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> objoutputLoanNo = new List<DataelementAutomatedAuditEntity>();
            List<List<DataelementAutomatedAuditEntity>> objoutput = new List<List<DataelementAutomatedAuditEntity>>();
            try
            {
                ds = objautomateddao.GetDataElement(recordid);
                if (ds != null)
                {
                    dt = ds.Tables[0];
                    dt1 = ds.Tables[1];
                    dt2 = ds.Tables[2];
                    if (dt.Rows.Count <= 0)
                        return null;
                    objoutputOCR = MapDataElemntEntity(dt1);
                    objoutputLOS = MapDataElemntEntity(dt);
                    objoutputLoanNo = MapDataElemntEntity(dt2);
                    objoutput.Add(objoutputOCR);
                    objoutput.Add(objoutputLOS);
                    objoutput.Add(objoutputLoanNo);
                }
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);               
                throw ex;
            }
        }    

        public List<DataelementAutomatedAuditEntity> GetAutoAuditFindingData(int recordid)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable dt = new DataTable();           
            List<DataelementAutomatedAuditEntity> objoutput = new List<DataelementAutomatedAuditEntity>();
            try
            {
                dt = objautomateddao.GetAutoAuditFindingData(recordid);                
                if (dt.Rows.Count <= 0)
                    return null;
                objoutput = MapDataElemntEntity(dt);
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }

        public int SetAutoAuditedElement(List<ServiceOutput> objservoutlist)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int result=0;
            string output = null;
            try
            {
                foreach (var a in objservoutlist)
                {
                    output = objautomateddao.SetAutoAuditedElement(a.RecordID, a.ElementId, a.ExpectedValue, a.ActualValue, a.ResultStatus, a.CreatedBy, a.ModifiedBy, a.AuditStatusId, a.SubDefects, a.Comments);
                    if (output != null)
                        result = Convert.ToInt32(output);

                }
              //  output = objautomateddao.SetAutoAuditedElementtotblARD(recordid, elementid, elementocr, elementlos, matchstatus, createdby, modifiedby, statusid);
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
            return result;
        }
        public int SetAutoAuditedElementStatus(ServiceOutput objservoutlist)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int  output = 0;
            //int recordid = 0, elementid = 0, createdby = 0, modifiedby = 0, statusid = 0;
            //string elementocr = null, elementlos = null;
            //bool matchstatus = false;
            try
            {
                 output = objautomateddao.SetAutoAuditedElementtotblARD(objservoutlist.RecordID, objservoutlist.ElementId,objservoutlist.ActualValue, objservoutlist.ExpectedValue,objservoutlist.ResultStatus, objservoutlist.CreatedBy, objservoutlist.ModifiedBy, objservoutlist.AuditStatusId,objservoutlist.QCNotes);
            }          
            
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
            return output;
        }

        public List<DataelementAutomatedAuditEntity> GetToAutomateAuditLOSData(int subprocessid)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAutoAuditFindingData - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable dt = new DataTable();
            List<DataelementAutomatedAuditEntity> objoutput = new List<DataelementAutomatedAuditEntity>();
            try
            {
                dt = objautomateddao.GetToAutomateAuditLOSData(subprocessid);
                if (dt.Rows.Count <= 0)
                    return null;
                objoutput = MapDataElemntEntity(dt);
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }
        internal List<DataelementAutomatedAuditEntity> MapDataElemntEntity(DataTable dt)
        {
            List<DataelementAutomatedAuditEntity> baseEntityList = new List<DataelementAutomatedAuditEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new DataelementAutomatedAuditEntity
                              {
                                  ElementId = p.Table.Columns.Contains("iElementId") == true ? Convert.ToInt32(p["iElementId"] == DBNull.Value ? 0 : p["iElementId"]) : 0,
                                  ElementData = p.Table.Columns.Contains("sznElementData") == true ? Convert.ToString(p["sznElementData"] == DBNull.Value ? string.Empty : p["sznElementData"]) : string.Empty,                                 
                                  TransactionSource = p.Table.Columns.Contains("szSource") == true ? Convert.ToString(p["szSource"] == DBNull.Value ? string.Empty : p["szSource"]) : string.Empty,
                                  RecordId = p.Table.Columns.Contains("iRecordId") == true ? Convert.ToInt32(p["iRecordId"] == DBNull.Value ? 0 : p["iRecordId"]) : 0,
                                  ValueOfLoanNumber = p.Table.Columns.Contains("szLoanNumber") == true ? Convert.ToString(p["szLoanNumber"] == DBNull.Value ? string.Empty : p["szLoanNumber"]) : string.Empty,
                              }).ToList();

            return baseEntityList;
        }

        

    }
}
