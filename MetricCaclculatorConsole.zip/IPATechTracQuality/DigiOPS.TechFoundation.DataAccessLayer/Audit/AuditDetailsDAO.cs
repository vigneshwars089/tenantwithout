﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
//using Quart.BusinessEntity;
//using Quart.Utility;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Xml;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Collections;
using System.IO;
//using Quart.BusinessEntity.TransactionCreation;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Audit Details DAO
    /// </summary>
    public class AuditDetailsDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
      
       
        /// <summary>To get the database credentials from the configuration file</summary> 
        public AuditDetailsDAO()
        {
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }
        /// <summary>To get the Audit defect opportunities for the selected Transaction</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetAuditDetailsList(BaseTransportEntity _Obj)
        {
           objloginfo.Message= ("AuditDetailsDAO - GetAuditDetailsList - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                 
            try
            {

                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"

                    SqlCommand command = new SqlCommand(Constants.SP_GET_AUDITDEFECTOPPORTUNTIES, sqlConnection);
                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    SqlDataAdapter adp = new SqlDataAdapter(command);

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                //objloginfo.Message = ("AuditDetailsDAO - GetAuditDetailsList - Called.");
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // objlogger.Log.Error(ex.Message);  proxyLogger.Log.Error(ex.StackTrace);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }
            
        catch (InvalidOperationException ex)
        {
            objlog.GetLoggingHandler("Log4net").LogException(ex); // proxyLogger.Log.Error(ex.StackTrace);
             throw;// new QuartException(ex.Message, ex.InnerException);
        }
        catch (ArgumentException ex)
        {
            objlog.GetLoggingHandler("Log4net").LogException(ex); // proxyLogger.Log.Error(ex.StackTrace);
             throw;// new QuartException(ex.Message, ex.InnerException);
        }
            /*
        catch (QuartException ex)
        {
            // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
            throw new QuartException(ex.Message, ex.InnerException);
        }
             * */
        }
        /// <summary>To Get the Audit mailing details of the Record</summary> 
        /// <returns>DataSet</returns>
        //public DataSet GetAuditMailingDetails(BaseTransportEntity _Obj)
        //{
        //    objloginfo.Message = ("AuditDetailsDAO - GetAuditMailingDetails - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditMailingDetails - Called.");
        //    try
        //    {
        //        SendMailEntity MailData = new SendMailEntity();
        //        MailData = (SendMailEntity)_Obj;
        //        DataSet _ds = new DataSet();
        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

        //            if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
        //                QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"

        //            sqlConnection.Open();
        //            SqlCommand command = new SqlCommand(Constants.SP_GET_AUDITMAILERDETAILS, sqlConnection);
        //            command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
        //            command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (MailData.iAuditId == 0) ? 0 : MailData.iAuditId;
        //            command.Parameters.Add(Constants.PAR_iMailTypeId, SqlDbType.Int).Value = (MailData.iMailTypeId == 0) ? 0 : MailData.iMailTypeId;
        //            command.CommandType = CommandType.StoredProcedure;
        //            command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_ds);
        //        }
        //        return _ds;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //            //new QuartException(ex.Message, ex.InnerException);
        //    }
                
        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw; //new QuartException(ex.Message, ex.InnerException);
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw; //new QuartException(ex.Message, ex.InnerException);
        //    }
        //        /*
        //    catch (QuartException ex)
        //    {
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw new QuartException(ex.Message, ex.InnerException);
        //    }
        //         * */
        //}

        //Added for Rating Difference Email Trigger
        //public DataSet GetRatingDifferenceMailingDetails(BaseTransportEntity _Obj)
        //{
        //    objloginfo.Message = ("AuditDetailsDAO - GetRatingDifferenceMailingDetails - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    // proxyLogger.Log.Info("AuditDetailsDAO - GetRatingDifferenceMailingDetails - Called.");
        //    try
        //    {
        //        SendMailEntity MailData = new SendMailEntity();
        //        MailData = (SendMailEntity)_Obj;
        //        DataSet _ds = new DataSet();
        //        using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            SqlConnection.Open();
        //            SqlCommand command = new SqlCommand("Usp_Get_RatingDifference_MAILERDETAILS", SqlConnection);
        //            command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
        //            command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (MailData.iAuditId == 0) ? 0 : MailData.iAuditId;
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_ds);
        //        }
        //        return _ds;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //            //new QuartException(ex.Message, ex.InnerException);
        //    }
               
        //    catch (InvalidOperationException ex)
        //    {
        //         objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //         throw;// new QuartException(ex.Message, ex.InnerException);
        //    }
        //    catch (ArgumentException ex)
        //    {
        //         objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //         throw;// new QuartException(ex.Message, ex.InnerException);
        //    }
        //        /*
        //    catch (QuartException ex)
        //    {
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw new QuartException(ex.Message, ex.InnerException);
        //    } */
        //}

        //End of Change

        public DataTable GetAuditQCStatus(AuditDOEntity _Obj)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditQCStatus - Called.");
            try
            {
                //AuditDOEntity _QCstatusObj = new AuditDOEntity();
                //_QCstatusObj = _Obj;

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand(Constants.GET_QS_CORRECTIONSTATUS, SqlConnection);
                //    //command.Parameters.Add(Constants.PAR_iAuditFindingId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
                //    command.Parameters.Add(Constants.PAR_iAuditFindingId, SqlDbType.Int).Value = (_QCstatusObj.iAuditFindingId == 0) ? 0 : _QCstatusObj.iAuditFindingId;
                //    command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = _QCstatusObj.eventAction;
                //    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.VarChar, 500);
                //    outprm.Direction = ParameterDirection.Output;
                //    command.Parameters.Add(outprm);
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                spName = "GET_QS_CORRECTIONSTATUS";
                Hashtable hs = new Hashtable();
                hs.Add("@iAuditFindingId", _Obj.iAuditFindingId);
                hs.Add("@szOpertaionName", _Obj.eventAction);
                hs.Add("@iReturnValue", 0);
               
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;
              
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
        }


        public DataTable GetAuditAndDeleteStatus(AuditDOEntity _DeletestatusObj)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditDeleteStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditDeleteStatus - Called.");
            try
            {
                //AuditDOEntity _DeletestatusObj = new AuditDOEntity();
                //_DeletestatusObj = _Obj;

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USE_GET_AUDIT_AND_DELETE_STATUS", SqlConnection);
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (_DeletestatusObj.iAuditId == 0) ? 0 : _DeletestatusObj.iAuditId;
                //    command.Parameters.Add("@iAudittypeId", SqlDbType.Int).Value = (_DeletestatusObj.iAuditTypeID == 0) ? 0 : _DeletestatusObj.iAuditTypeID;
                //    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                //    outprm.Direction = ParameterDirection.Output;
                //    command.Parameters.Add(outprm);

                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                spName = "USE_GET_AUDIT_AND_DELETE_STATUS";
                Hashtable hs = new Hashtable();
                hs.Add("@iAuditId", _DeletestatusObj.iAuditId);
                hs.Add("@iAudittypeId", _DeletestatusObj.iAuditTypeID);
                hs.Add("@iReturnValue", 0);
               
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;
               
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;
                    //new QuartException(ex.Message, ex.InnerException);
            }
        }

        public bool AttachmentRequired(int subprocessid)
        {
            objloginfo.Message = ("AuditDetailsDAO - AttachmentRequired - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - AttachmentRequired - Called.");
            try
            {

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //    SqlCommand command = new SqlCommand(Constants.SP_GET_ATTACHMENTREQUIRED, sqlConnection);
                //    command.Parameters.Add("@subProcessid", SqlDbType.Int).Value = subprocessid;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                spName = "USP_GET_ATTACHMENTREQUIRED";
                Hashtable hs = new Hashtable();
                hs.Add("@subProcessid", subprocessid);
               
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                    if (_dt.Rows.Count > 0)
                        return (bool)_dt.Rows[0][0];
                    else
                        return true;
                //}
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }
                
            catch (InvalidOperationException ex)
            {
                 objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                 objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
            catch (QuartException ex)
            {
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            } */
        }

        /// <summary>To set the mail information details for the Audit </summary> 
        /// <returns>string</returns> 
        //public string SetAuditMailingDetails(BaseTransportEntity _Obj)
        //{
        //    string resultValue = "-1";
        //    objloginfo.Message = ("AuditDetailsDAO - SetAuditMailingDetails - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    // proxyLogger.Log.Info("AuditDetailsDAO - SetAuditMailingDetails - Called.");
        //    try
        //    {
        //        SendMailEntity MailData = new SendMailEntity();
        //        MailData = (SendMailEntity)_Obj;

        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            sqlConnection.Open();
        //            SqlCommand command = new SqlCommand("USP_SET_AUDITMAILTRACKER", sqlConnection);
        //            command.CommandType = CommandType.StoredProcedure;
        //            command.Parameters.Add("@iAuditMailTrackerId", SqlDbType.Int).Value = (MailData.iAuditMailTackerId == 0) ? 0 : MailData.iAuditMailTackerId;
        //            command.Parameters.Add("@szSentTo", SqlDbType.VarChar).Value = (MailData.szSentTo == null) ? null : MailData.szSentTo;
        //            command.Parameters.Add("@szSentCC", SqlDbType.VarChar).Value = (MailData.szSentCC == null) ? null : MailData.szSentCC;
        //            command.Parameters.Add("@szSentFrom", SqlDbType.VarChar).Value = (MailData.szSentFrom == null) ? null : MailData.szSentFrom;
        //            command.Parameters.Add("@szSentSubj", SqlDbType.VarChar).Value = (MailData.szSentSubj == null) ? null : MailData.szSentSubj;
        //            command.Parameters.Add("@bMailSent", SqlDbType.Bit).Value = (MailData.bMailSent == null) ? false : MailData.bMailSent;
        //            command.Parameters.Add(Constants.PAR_iSystemUserId, SqlDbType.Int).Value = _Obj.CurrentUserID;
        //            SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
        //            outprm.Direction = ParameterDirection.Output;
        //            command.Parameters.Add(outprm);

        //            command.ExecuteNonQuery();
        //            resultValue = outprm.Value.ToString();
        //        }

        //        return resultValue;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw; // new QuartException(ex.Message, ex.InnerException);
        //    }
                
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw;// new QuartException(ex.Message, ex.InnerException);
        //    }
        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw;// new QuartException(ex.Message, ex.InnerException);
        //    }
        //    catch (InvalidCastException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw;// new QuartException(ex.Message, ex.InnerException);
        //    }
        //        /*
        //    catch (QuartException ex)
        //    {
        //        // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
        //        throw new QuartException(ex.Message, ex.InnerException);
        //    } */
        //}
        /// <summary>To Get the Audit subdefects list of the Transaction</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetAuditSubDefectList(SubDefectDetailsEntity _SubDefObj)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditSubDefectList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditSubDefectList - Called.");
            try
            {
                //SubDefectDetailsEntity _SubDefObj = new SubDefectDetailsEntity();
                //_SubDefObj = _Obj;
                string spName=string.Empty;
                DataTable _dt = new DataTable();
                //SqlCommand command = null;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();

                //    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                //    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                //    {
                      string  QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"
                    //}

                    //if (_SubDefObj.eventAction == "CopyNormal")
                    //{
                    //    command = new SqlCommand("USP_GET_AUDITCopySUBDEFECTOPPORTUNITY", sqlConnection);
                    //          command.Parameters.Add("@level", SqlDbType.Int).Value = (_SubDefObj.CopyLevel== 0) ? 0 : _SubDefObj.CopyLevel;
        
                    //}
                    //else
                        if (_SubDefObj.eventAction == "Normal")
                    {
                        spName="USP_GET_AUDITSUBDEFECTOPPORTUNITY";
                           // command = new SqlCommand(Constants.SP_GET_AUDITSUBDEFECTOPPORTUNITY, sqlConnection);

                    }

                    else
                    {
                            spName="USP_GET_AUDITSUBDEFECTOPPORTUNITYQSCORRECTION";
                        //command = new SqlCommand("USP_GET_AUDITSUBDEFECTOPPORTUNITYQSCORRECTION", sqlConnection);
                    }
                    //command.Parameters.Add(Constants.PAR_iDOId, SqlDbType.Int).Value = (_SubDefObj.DOId == 0) ? 0 : _SubDefObj.DOId;
                    //command.Parameters.Add(Constants.PAR_iParentSubDOId, SqlDbType.Int).Value = (_SubDefObj.ParentSubDOId == 0) ? 0 : _SubDefObj.ParentSubDOId;
                    //command.Parameters.Add(Constants.PAR_iAuditFindingId, SqlDbType.Int).Value = (_SubDefObj.AuditFindingId == 0) ? 0 : _SubDefObj.AuditFindingId;
                    //command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_SubDefObj._SubProcessID == 0) ? 0 : _SubDefObj._SubProcessID;
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);
                    //command.CommandType = CommandType.StoredProcedure;
                    //command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    //SqlDataAdapter adp = new SqlDataAdapter(command);
                    //adp.Fill(_dt);
               // }
                        Hashtable hs = new Hashtable();
                        hs.Add("@iDOId", _SubDefObj.DOId);
                        hs.Add("@iParentSubDOId", _SubDefObj.ParentSubDOId);
                        hs.Add("@iAuditFindingId", _SubDefObj.AuditFindingId);
                        hs.Add("@iSubProcessId", _SubDefObj._SubProcessID);
                        hs.Add("@iReturnValue", 0);
                        
                        DBHelper db = new DBHelper();
                        _dt = db.SelectDataTable(spName, hs);
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw; //  new QuartException(ex.Message, ex.InnerException);
            }
        }
      
        public DataTable GetAuditHeadingDetailsList(TransactionDetailsEntity _Obj)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditHeadingDetailsList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditHeadingDetailsList - Called.");
            try
            {

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USP_GET_AUDITHEADINGDETAILS", SqlConnection);
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = _Obj.AuditId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                spName = "USP_GET_AUDITHEADINGDETAILS";
                Hashtable hs = new Hashtable();
                hs.Add("@iAuditId", _Obj.AuditId);
                
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
        }



        /// <summary>To Get the list of the audit defect opportunities selected of the Record</summary> 
        /// <returns>Dataset</returns>
        public DataSet GetEntityListcollection(AuditDetailsEntity _obj)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetEntityListcollection - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetEntityListcollection - Called.");
            try
            {
                //AuditDetailsEntity _AuditDetailObj = new AuditDetailsEntity();
                //_AuditDetailObj = _obj;
                DataSet _ds = new DataSet();

                string spName = string.Empty;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                //    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                //    {
                       string  QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"
                    //}

                    //sqlConnection.Open();
                    //SqlCommand command = null;
                    if (_obj.ViewName == "ADMINAPPROVAL")
                    {
                        spName = "USP_GET_AUDITDEFECTOPPORTUNITYQSCORRECTION";
                        //command = new SqlCommand("USP_GET_AUDITDEFECTOPPORTUNITYQSCORRECTION", sqlConnection);
                    }
                    else
                    {
                        spName = "USP_GET_AUDITDEFECTOPPORTUNITY";
                        //command = new SqlCommand(Constants.SP_GET_AUDITDEFECTOPPORTUNTIES, sqlConnection);
                    }

                //    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_obj._SubProcessID == 0) ? 0 : _obj._SubProcessID;
                //    command.Parameters.Add(Constants.PAR_iSystemUserId, SqlDbType.Int).Value = (_obj.CurrentUserID == 0) ? 0 : _obj.CurrentUserID;
                //    command.Parameters.Add(Constants.PAR_iAuditId, SqlDbType.Int).Value = (_AuditDetailObj.iAuditId == 0) ? 0 : _AuditDetailObj.iAuditId;
                //    command.Parameters.Add(Constants.PAR_AuditorID, SqlDbType.Int).Value = (_AuditDetailObj.iAuditorId == 0) ? 0 : _AuditDetailObj.iAuditorId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_ds);
                //}
                    Hashtable hs = new Hashtable();
                    hs.Add("@iSubProcessId", _obj._SubProcessID);
                    hs.Add("@iSystemUserId", _obj.CurrentUserID);
                    hs.Add("@iAuditId", _obj.iAuditId);
                    hs.Add("@iAuditorid", _obj.iAuditorId);
                                   
                    DBHelper db = new DBHelper();
                    _ds = db.SelectDataSet(spName, hs);
                return _ds;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw; // new QuartException(ex.Message, ex.InnerException);
            }
                
            catch (ArgumentException ex)
            {
                 objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                 objlog.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
            catch (QuartException ex)
            {
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw new QuartException(ex.Message, ex.InnerException);
            } */
        }
        /// <summary>To set the All Audit details of the Transaction to the database</summary> 
        /// <returns>string</returns>
        public string SetAuditDetail(AuditDOEntity auditDOEntity)
        {
           // string resultValue = "-1";
           // SqlCommand command = null;
            objloginfo.Message = ("AuditDetailsDAO - SetAuditDetail - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - SetAuditDetail - Called.");
            try
            {
                //AuditDOEntity auditedData = new AuditDOEntity();
                //auditedData = (AuditDOEntity)auditDOEntity;
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");

                auditDOEntity.xmlAuditDO = new XElement("AuditDOData",
                 auditDOEntity.AuditedList.Select(i => new XElement("DO",
                     new XAttribute("DOId", i.DOId),
                     new XAttribute("DOGroupID", i.DOGroupID),
                     new XAttribute("SelectedRatingId", i.SelectedRatingId),
                     new XAttribute("GivenWeightage", i.GivenWeightage),
                     new XAttribute("ActualWeightage", i.ActualWeightage),
                     new XAttribute("CalulatedWeightage", i.CalulatedWeightage),
                     new XAttribute("MaxWeightage", i.MaxWeightage),
                     new XAttribute("ParentDOId", i.ParentDOId),
                     new XAttribute("AuditFindingId", i.iAuditFindingId == 0 ? 0 : i.iAuditFindingId),
                     new XAttribute("AuditorId", i.iAuditorId),
                     new XAttribute("szComments", (i.CTQComments == null) ? "" : i.CTQComments),
                     new XAttribute("SubProcessID", auditDOEntity._SubProcessID),
                     new XAttribute("CorrectEmployee", i.CorrectEmployee),
                     new XAttribute("HasSubDefects", i.HasSubDefects),
                     new XAttribute("ErrorField", i.ErrorField),
                     new XAttribute("CriticalityType", (i.CriticalityType == null) ? "" : i.CriticalityType)
                 )));

                auditDOEntity.xmlAuditGroupDO = new XElement("AuditGroupDO",
                 auditDOEntity.AuditedGroupList.Select(i => new XElement("GroupDO",
                     new XAttribute("HeadingDOId", i.HeadingDOId),
                     new XAttribute("DOGroupID", i.GroupID),
                     new XAttribute("NoofApplicable", i.NoofApplicable),
                     new XAttribute("NoofError", i.NoofError),
                     new XAttribute("CalculatedGroupWeightage", i.CalculatedGroupWeightage),
                     new XAttribute("SumGroupWeightage", i.SumGroupWeightage)

                 )));

                auditDOEntity.xmlAuditSubDO = new XElement("AuditSubDOData",
                                  auditDOEntity.AuditedList.Where(i => i.SelectedSubDefect1Id != 0)
                                      .Select(i => new XElement("SubDO",
                                      new XAttribute("DOId", i.DOId),
                                      new XAttribute("SubDefectId", i.SelectedSubDefect1Id),
                                      new XAttribute("CopyLevel", "")
                                  )),
                                  auditDOEntity.AuditedList.Where(i => i.SelectedSubDefect2Id != 0)

                                  .Select(i => new XElement("SubDO",
                                      new XAttribute("DOId", i.DOId),
                                      new XAttribute("SubDefectId", i.SelectedSubDefect2Id),
                                      new XAttribute("CopyLevel", "")
                                  ))
                                  ,
                                  auditDOEntity.AuditedList.Where(i => i.SelectedSubDefect3Id != 0)
                                  .Select(i => new XElement("SubDO",
                                      new XAttribute("DOId", i.DOId),
                                      new XAttribute("SubDefectId", i.SelectedSubDefect3Id),
                                      new XAttribute("CopyLevel", i.CopyLevel3)
                                  ))
                                  ,
                                  auditDOEntity.AuditedList.Where(i => i.SelectedSubDefect4Id != 0)
                                  .Select(i => new XElement("SubDO",
                                      new XAttribute("DOId", i.DOId),
                                      new XAttribute("SubDefectId", i.SelectedSubDefect4Id),
                                      new XAttribute("CopyLevel", i.CopyLevel4)
                                  ))
                                  ,
                                  auditDOEntity.AuditedList.Where(i => i.SelectedSubDefect5Id != 0)
                                  .Select(i => new XElement("SubDO",
                                      new XAttribute("DOId", i.DOId),
                                      new XAttribute("SubDefectId", i.SelectedSubDefect5Id),
                                      new XAttribute("CopyLevel", i.CopyLevel5)
                                  ))


                 );

                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                    //string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    //if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                    //{
                    string QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"
                   // }
                    string spName = string.Empty;

                    //sqlConnection.Open();
                    if (auditDOEntity.iAuditTypeID == 6 || auditDOEntity.iAuditTypeID == 7)
                    {
                       spName=  Constants.SP_SET_AUDITFINDINGDATA_CALIBRATION;
                        //command = new SqlCommand(Constants.SP_SET_AUDITFINDINGDATA_CALIBRATION, sqlConnection);
                        //command.CommandType = CommandType.StoredProcedure;
                    }
                    else
                    {
                        spName = Constants.SP_SET_AUDITFINDINGDATA;
                        //command = new SqlCommand(Constants.SP_SET_AUDITFINDINGDATA, sqlConnection);
                        //command.CommandType = CommandType.StoredProcedure;
                    }
                   

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.eventAction)) && auditDOEntity.eventAction.Equals(Constants.ACTION_Insert))
                        root.Add(new XAttribute("iAuditId", 0));
                    else
                        root.Add(new XAttribute("iAuditId", Convert.ToString(auditDOEntity.iAuditId)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.iAuditFindingId)))
                        root.Add(new XAttribute("iAuditFindingId", Convert.ToString(auditDOEntity.iAuditFindingId) ?? "0"));
                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.iAuditTypeID)))
                        root.Add(new XAttribute("iAuditTypeID", Convert.ToString(auditDOEntity.iAuditTypeID) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.iRecordID)))
                        root.Add(new XAttribute("iRecordID", Convert.ToString(auditDOEntity.iRecordID) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.iRoleID)))
                        root.Add(new XAttribute("iRoleID", Convert.ToString(auditDOEntity.iRoleID) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.AuditFeedback)))
                        root.Add(new XAttribute("szAuditFeedBack", Convert.ToString(auditDOEntity.AuditFeedback)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.FatalStatus)))
                        root.Add(new XAttribute("szFatalStatus", Convert.ToString(auditDOEntity.FatalStatus)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TATFeedback)))
                        root.Add(new XAttribute("szTATFeedback", Convert.ToString(auditDOEntity.TATFeedback)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TATFeedbackComments)))
                        root.Add(new XAttribute("szTATFeedbackComments", Convert.ToString(auditDOEntity.TATFeedbackComments)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.AuditNotes)))
                        root.Add(new XAttribute("szAuditNotes", Convert.ToString(auditDOEntity.AuditNotes)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.ApproverComments)))
                        root.Add(new XAttribute("szApproverComments", Convert.ToString(auditDOEntity.ApproverComments)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.UploadFilePath)))
                        root.Add(new XAttribute("szUploadFilePath", Convert.ToString(auditDOEntity.UploadFilePath)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.RecommendationComments)))
                        root.Add(new XAttribute("szRecommendationComments", Convert.ToString(auditDOEntity.RecommendationComments)));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.ApprovalStatus)))
                        root.Add(new XAttribute("szApprovalStatus", Convert.ToString(auditDOEntity.ApprovalStatus)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.QualityScore)))
                        root.Add(new XAttribute("fQualityScore", Convert.ToString(auditDOEntity.QualityScore)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.FieldQualityScore)))
                        root.Add(new XAttribute("fFieldQualityScore", Convert.ToString(auditDOEntity.FieldQualityScore)));

                    //command.Parameters.Add(Constants.PAR_xmlAuditDO, SqlDbType.Xml).Value = (auditDOEntity.xmlAuditDO == null) ? null : auditDOEntity.xmlAuditDO.ToString();

                    //command.Parameters.Add("@xmlAuditGroupDO", SqlDbType.Xml).Value = (auditDOEntity.xmlAuditGroupDO == null) ? null : auditDOEntity.xmlAuditGroupDO.ToString();

                    //command.Parameters.Add(Constants.PAR_xmlAuditSubDO, SqlDbType.Xml).Value = (auditDOEntity.xmlAuditSubDO == null) ? null : auditDOEntity.xmlAuditSubDO.ToString();


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalOpp)))
                        root.Add(new XAttribute("iTotDO_Cnt", Convert.ToString(auditDOEntity.TotalOpp) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppOpp)))
                        root.Add(new XAttribute("iTotAppDO_Cnt", Convert.ToString(auditDOEntity.TotalAppOpp) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalNotAppOpp)))
                        root.Add(new XAttribute("iTotNotAppDO_Cnt", Convert.ToString(auditDOEntity.TotalNotAppOpp) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppDefects)))
                        root.Add(new XAttribute("iTotAppDOWithDefects_Cnt", Convert.ToString(auditDOEntity.TotalAppDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppNoDefects)))
                        root.Add(new XAttribute("iTotAppDOWithNoDefects_Cnt", Convert.ToString(auditDOEntity.TotalAppNoDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalHeadings)))
                        root.Add(new XAttribute("iTotHeadings_Cnt", Convert.ToString(auditDOEntity.TotalHeadings) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadings)))
                        root.Add(new XAttribute("iTotAppHeadings_Cnt", Convert.ToString(auditDOEntity.TotalAppHeadings) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalNotAppHeadings)))
                        root.Add(new XAttribute("iTotNotAppHeadings_Cnt", Convert.ToString(auditDOEntity.TotalNotAppHeadings) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadingsDefects)))
                        root.Add(new XAttribute("iTotAppHeadingsWithDefects_Cnt", Convert.ToString(auditDOEntity.TotalAppHeadingsDefects) ?? "0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadingsNoDefects)))
                        root.Add(new XAttribute("iTotAppHeadingsWithNoDefects_Cnt", Convert.ToString(auditDOEntity.TotalAppHeadingsNoDefects) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalOpp_W)))
                        root.Add(new XAttribute("fTotDO_Wt", Convert.ToString(auditDOEntity.TotalOpp_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppOpp_W)))
                        root.Add(new XAttribute("fTotAppDO_Wt", Convert.ToString(auditDOEntity.TotalAppOpp_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalNotAppOpp_W)))
                        root.Add(new XAttribute("fTotNotAppDO_Wt", Convert.ToString(auditDOEntity.TotalNotAppOpp_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppDefects_W)))
                        root.Add(new XAttribute("fTotAppDOWithDefects_Wt", Convert.ToString(auditDOEntity.TotalAppDefects_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppNoDefects_W)))
                        root.Add(new XAttribute("fTotAppDOWithNoDefects_Wt", Convert.ToString(auditDOEntity.TotalAppNoDefects_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalHeadings_W)))
                        root.Add(new XAttribute("fTotHeadings_Wt", Convert.ToString(auditDOEntity.TotalHeadings_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadings_W)))
                        root.Add(new XAttribute("fTotAppHeadings_Wt", Convert.ToString(auditDOEntity.TotalAppHeadings_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalNotAppHeadings_W)))
                        root.Add(new XAttribute("fTotNotAppHeadings_Wt", Convert.ToString(auditDOEntity.TotalNotAppHeadings_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadingsDefects_W)))
                        root.Add(new XAttribute("fTotAppHeadingsWithDefects_Wt", Convert.ToString(auditDOEntity.TotalAppHeadingsDefects_W) ?? "0.0"));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.TotalAppHeadingsNoDefects_W)))
                        root.Add(new XAttribute("fTotAppHeadingsWithNoDefects_Wt", Convert.ToString(auditDOEntity.TotalAppHeadingsNoDefects_W) ?? "0.0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.CurrentUserID)))
                        root.Add(new XAttribute("iAuditedBy", Convert.ToString(auditDOEntity.CurrentUserID) ?? "0"));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity._SubProcessID)))
                        root.Add(new XAttribute("iSubProcessId", Convert.ToString(auditDOEntity._SubProcessID)));


                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.ViewName)))
                        root.Add(new XAttribute("ViewName", Convert.ToString(auditDOEntity.ViewName)));

                    if (!string.IsNullOrEmpty(Convert.ToString(auditDOEntity.eventAction)))
                        root.Add(new XAttribute("szOpertaionName", Convert.ToString(auditDOEntity.eventAction)));


                    Parent.Add(root);
                    //command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                   // SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);
                    //command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    //command.ExecuteNonQuery();
                    //resultValue = outprm.Value.ToString();
               // }

                   

                   Hashtable hs = new Hashtable();                 

                    hs.Add("@xmlAuditDO", auditDOEntity.xmlAuditDO.ToString());
                    hs.Add("@xmlAuditGroupDO", auditDOEntity.xmlAuditGroupDO.ToString());
                    hs.Add("@xmlAuditSubDO", auditDOEntity.xmlAuditSubDO.ToString());
                    hs.Add("@ExcelData", Convert.ToString(Parent));
                    hs.Add("@iReturnValue", 0);

                    DBHelper db = new DBHelper();
                    object message=db.ExecuteNonQuery(spName,hs);
                    return message.ToString();

            }
            catch (XmlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);                
                throw; 
            }
                
            catch (SqlException ex)
            {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ArgumentException ex)
            {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidCastException ex)
            {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);               
                throw;
            }
               
           
           // return resultValue;
        }
     
    }
}
