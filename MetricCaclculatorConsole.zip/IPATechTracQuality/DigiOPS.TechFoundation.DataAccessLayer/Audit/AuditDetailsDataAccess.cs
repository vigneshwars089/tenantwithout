﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class AuditDetailsDataAccess
    {
        AuditDetailsDAO addao = new AuditDetailsDAO();
        AuditDetailsTransformer addettran = new AuditDetailsTransformer();

        public List<List<AuditDetailsEntity>> GetAuditDetails(AuditDetailsEntity objauddet)
        {
            List<List<AuditDetailsEntity>> listcoll = new List<List<AuditDetailsEntity>>();
            // AuditDetailsEntity objauddet = new AuditDetailsEntity();
            DataSet ds = new DataSet();
            ds = addao.GetEntityListcollection(objauddet);
            if (ds.Tables.Count <= 0)
                return listcoll;
            if (ds.Tables.Count == 1)
            {
                if (ds.Tables[0].Rows.Count > 0)
                    listcoll.Add(addettran.mapToDefectOpportunity(ds));
            }
            else
            {
                if (ds.Tables[0].Rows.Count >= 0 && ds.Tables[1].Rows.Count >= 0)
                    listcoll.Add(addettran.mapToDefectOpportunity(ds));
                if (ds.Tables[2].Rows.Count >= 0 && ds.Tables[3].Rows.Count >= 0 && ds.Tables[7].Rows.Count >= 0)
                    listcoll.Add(addettran.mapToHeadingDetails(ds));
                listcoll.Add(addettran.mapToAuditNotesDetails(ds));
                if (ds.Tables[6].Rows.Count >= 0)
                    listcoll.Add(addettran.mapToCombinedConfiguration(ds));
            }
            return listcoll;
        }

        public List<SubDefectDetailsEntity> GetRCList(SubDefectDetailsEntity objsubdo)
        {
            //List<TransDropDown> lstSubDefect = null;
            List<SubDefectDetailsEntity> baseList = null;
            //SubDefectDetailsEntity objsubdefect = new SubDefectDetailsEntity();
            DataTable dt = new DataTable();
            dt = addao.GetAuditSubDefectList(objsubdo);
            if (dt.Rows.Count <= 0)
                return baseList;
            //return lstSubDefect;
            else
            {
                baseList = addettran.MapToDropDownList(dt);
                // lstSubDefect = baseList.Cast<TransDropDown>.ToList();
                //return lstSubDefect;
                return baseList;
            }
        }

        public AuditDOEntity GetAuditDeleteStatus(AuditDOEntity objauditdo)
        {
            //AuditDOEntity objauditdo = null;
            AuditDOEntity auditdo = new AuditDOEntity();
            DataTable dt = new DataTable();
            dt = addao.GetAuditAndDeleteStatus(objauditdo);
            if (dt.Rows.Count <= 0)
                return auditdo;
            else
            {
                auditdo = addettran.GetAuditAndDeleteStatus(dt);
                return auditdo;
            }
        }

        public bool IsAttachmentRequired(AuditDOEntity objauditdo)
        {
            bool required = true;
            //TransactionRecordDetailsEntity objtransdet = new TransactionRecordDetailsEntity();
            int subprocessid = objauditdo._SubProcessID;
            required = addao.AttachmentRequired(subprocessid);
            return required;
        }
        public AuditDOEntity GetQCStatus(AuditDOEntity objauditdo)
        {
            AuditDOEntity auditdo = new AuditDOEntity();
            DataTable dt = new DataTable();
            dt = addao.GetAuditQCStatus(objauditdo);
            if (dt.Rows.Count <= 0)
                return auditdo;
            else
            {
                auditdo = addettran.GetStatus(dt);
                return auditdo;
            }

        }

        public string SetAuditDetails(AuditDOEntity objAuditDetailsEntity)
        {
            string createRecVal = string.Empty;
            createRecVal = addao.SetAuditDetail(objAuditDetailsEntity);
            return createRecVal;
        }
    }
}
