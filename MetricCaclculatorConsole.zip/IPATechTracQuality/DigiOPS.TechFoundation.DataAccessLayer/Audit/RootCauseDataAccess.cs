﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class RootCauseDataAccess
    {
        DefectOpportunityDAO doDAO = new DefectOpportunityDAO();
        RootCauseTransformer rootcauseda = new RootCauseTransformer();
        public  string SetRootCause(RootCauseEntity objsubDo)
        {
            string createRecVal = string.Empty;
            createRecVal = doDAO.SetRC(objsubDo);
            return createRecVal;

        }
        public List<RootCauseEntity> GetRCList(RootCauseEntity objsubDo)
        {
            DataTable dt = new DataTable();
            List<RootCauseEntity> baseList = null;
            dt = doDAO.GetRootCauseList(objsubDo);
            if (dt.Rows.Count <= 0)
                return baseList;
            if (!objsubDo.isDropdowndetails)
            {
                baseList = rootcauseda.MapToRCConfig(dt);
            }
            else
            {
                baseList = rootcauseda.MapToDropDownList(dt);
            }
            return baseList;
        }

    }
}
