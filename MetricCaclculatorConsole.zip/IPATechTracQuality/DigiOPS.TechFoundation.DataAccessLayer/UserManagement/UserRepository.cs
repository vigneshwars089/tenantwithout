﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :UserRepository.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :UserRepository
    // Author : Sadhesh
    // Creation Date : 6/14/2017
    // Purpose : base class
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //14-Jun-2017    Sadhesh     Create            Create user 
    //14-Jun-2017    Sadhesh     Read              Read user
    //14-Jun-2017    Sadhesh     Update            update user
    //14-Jun-2017    Sadhesh     Delete            delete user

    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public abstract class UserRepository : IUserRepository
    {

        public virtual UserMgmtInfo Create(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            return objinfo;
        }

        public virtual UserMgmtInfo Read(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            return objinfo;
        }

        public virtual UserMgmtInfo Update(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            return objinfo;
        }

        public virtual UserMgmtInfo Delete(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            return objinfo;
        }



        public string ConnectionString
        {
            get;
            set;
        }


        public virtual bool ValidateCredentials(UserInfo objUserInfo)
        {
            return false;
        }


        public virtual int AssignRole(UserRoleInfo objUserInfo)
        {
            return 0;
        }

        public virtual int UpdateUserRole(UserRoleInfo objUserInfo)
        {
            return 0;
        }

        public virtual int DeleteUserRole(UserRoleInfo objRoleInfo)
        {
            return 0;
        }


        public virtual int LockAccount(string UserId, bool IsAccountLocked, string Token, DateTime TokenExpirationTime)
        {
            return 0;
        }

        public virtual int ValidateAccountLock(string UserId, bool IsAccountLocked, string Token)
        {
            return 0;
        }
        public virtual int IsAccountLocked(string UserId)
        {
            return 0;
        }


    }
}
