﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class EMTConfigurationRepository
    {
        LoggingFactory objloggingfactory = new LoggingFactory();
        public DataSet BindActiveMailBox(int CountryId, string LoggedInUserId, int LoggedInUserRoleId)
        {           
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@COUNTRYID", CountryId);
                hs.Add("@LoggedInUserId", LoggedInUserId);
                hs.Add("@LoggedInUserRoleId", LoggedInUserRoleId);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
            return new DBHelper().SelectDataSet("USP_BIND_COUNTRY_BASED_EMAILBOX", hs);
        }

        public int MapUserMailBox(string UserId, int MailBoxId, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", UserId);
                hs.Add("@MailBoxId", MailBoxId);
                hs.Add("@LoggedinUserId", LoginId);
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | MapUserMailBox()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_USER_MAILBOXMAP", hs));
        }

        public int ConfigureRemaindertoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_REMAINDER_MAILBOXADD", hs));
        }
        public int ConfigureCategorytoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_CATEGORY_MAILBOXADD", hs));
        }

        public DataSet GridMailBoxMapBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_USERS", hs);
        }
        public DataSet GridMailBoxRemainderBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_REMAINDER", hs);
        }
        public DataSet GridMailBoxcategoryBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_CATEGORY", hs);
        }

        public DataSet UserWiseMailBoxMapGridBind(string UserId, string ddlCountryId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserId", UserId);
                hs.Add("@CountryId", ddlCountryId);
            }
            catch (Exception ex)
            {
                // //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UserWiseMailBoxMapGridBind()");
            }
            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_USERS_BY_USERWISE", hs);
        }

        public int UpdateUserMailBoxMap(string UserMailBoxMapId, string UserId, int MailBoxId, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UsermailBoxMappingId", UserMailBoxMapId);
                hs.Add("@UserID", UserId);
                hs.Add("@MailBoxId", MailBoxId);
                hs.Add("@LoggedinUserId", LoginId);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateUserMailBoxMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_MAILBOXMAPPED_USERS", hs));
        }

        public int UpdateConfigureRemaindertoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_REMAINDERMAILBOXMAPPED", hs));
        }

        public int UpdateConfigurecategorytoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_CATEGORYMAILBOXMAPPED", hs));
        }


        public int DeleteMailBoxMap(string hddnMBMapId, string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UsermailBoxMappingId", hddnMBMapId);
                hs.Add("@USERID", UserId);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteMailBoxMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_DELETE_MAILBOXMAPPED_USERS", hs));
        }

        public int InsertMailLoginDetails(string MailId, string encryptConfirmPassword, int Locked, int Active)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EMAILID", MailId);
                hs.Add("@PASSWORD", encryptConfirmPassword);
                hs.Add("@ISLOCKED", Locked);
                hs.Add("@ISACTIVE", Active);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | InsertMailLoginDetails()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_EMAILBOXLOGINDETAILS_CONFIGURATION", hs));
        }

        public DataSet GridEmailBoxLoginDetailsBind()
        {
            return new DBHelper().SelectDataSet("USP_GET_EMAILBOXLOGINDETAILS_DETAILS");
        }

        public int UpdateMailBoxLoginDetails(string EmailBoxLoginDetailID, string MailId, string EncryptConfirmPassword, int Locked, int Active)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EmailBoxLoginDetailId", EmailBoxLoginDetailID);
                hs.Add("@PASSWORD", EncryptConfirmPassword);
                hs.Add("@EMAILID", MailId);
                hs.Add("@ISLOCKED", Locked);
                hs.Add("@ISACTIVE", Active);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateMailBoxLoginDetails()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_EMAILBOXLOGINDETAIL", hs));
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable hs)
        {
            return new DBHelper().SelectDataSet("USP_GetCountryByUserId_For_Dashboard", hs);
        }

        public int ConfigureEscalationMatrix(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_EscalationMatrix_ADD", hs));
        }
        public int UpdateConfigureEscalationMatrix(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_EscalationMatrix_UPDATE", hs));
        }
        public DataSet GridEscalationMatrixBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_EscaltionMatrix_SELECT", hs);
        }

        public int DeleteEscalationMatrixMap(string hddnMBMapId, string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EscalationMasterId", hddnMBMapId);
                // hs.Add("@USERID", UserId);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteEscalationMatrixMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_EscalationMatrix_DELETE", hs));
        }

        public int UpdateConfigureFieldstoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UpdateConfigureFields", hs));
        }

        public DataSet GridMailBoxFieldBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_FIELDS", hs);
        }

        public DataSet BindFieldType()
        {
            return new DBHelper().SelectDataSet("USP_GET_FIELDTYPE");
        }
        public DataSet GetFieldDataandValidationType(Int32 FieldTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@FieldTypeID", FieldTypeID);
            }
            catch (Exception ex)
            {
                // //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetFieldDataandValidationType()");
            }
            return new DBHelper().SelectDataSet("USP_GETFIELDDATAANDVALIDATIONTYPE", hs);
        }

        public DataSet Getfieldname(Int32 intFieldMasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@intFieldMasterID", intFieldMasterID);
            }
            catch (Exception ex)
            {
                //   //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | Getfieldname()");
            }
            return new DBHelper().SelectDataSet("USP_Getfieldname", hs);
        }

        public DataSet BindFieldName(Int32 intFieldMasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@intFieldMasterID", intFieldMasterID);
            }
            catch (Exception ex)
            {
                // //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | BindFieldName()");
            }
            return new DBHelper().SelectDataSet("USP_BindFieldName", hs);
        }

        public DataSet GetDefaultListValues(Int32 intFieldTypeId, Int32 DynamicDropdownId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@FieldMasterID", intFieldTypeId);
                hs.Add("@DynamicDropdownId", DynamicDropdownId);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetDefaultListValues()");
            }
            return new DBHelper().SelectDataSet("USP_GetDefaultListValues", hs);
        }

        public DataSet USP_GetConfigureFieldsValidationType_Result(Int32 fldDataTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@FieldDataTypeID", fldDataTypeID);
            }
            catch (Exception ex)
            {
                ////errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | USP_GetConfigureFieldsValidationType_Result()");
            }
            return new DBHelper().SelectDataSet("USP_GETCONFIGUREFIELDSVALIDATIONTYPE", hs);
        }

        public DataSet GetDatetimeFormat(Int32 ValidationTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@ValidationTypeID", ValidationTypeID);
            }
            catch (Exception ex)
            {
                // //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetDatetimeFormat()");
            }
            return new DBHelper().SelectDataSet("USP_GETDATTIMEFORMAT", hs);
        }

        public int ConfigureFieldtoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_InsertConfigureFields", hs));
        }

        public int ConfigureOptiontoField(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_ConfigureOptiontoField", hs));
        }

        public int UpdateOptionstoFields(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UpdateOption", hs));
        }

        public DataSet GetOptionvalue(Int32 FieldmasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {

                hs.Add("@FieldmasterID", FieldmasterID);
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetOptionvalue()");
            }
            return new DBHelper().SelectDataSet("USP_GetOptionvalue", hs);
        }
        //Pranay 11 August 2016 ---Adding method for adding acknowledgeMail Template
        public int ConfigureAcknowledgetoMailbox(Hashtable htUserData)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_Acknowledge_MAILBOXADD", htUserData));
        }

        //Pranay 16 August 2016--Adding method for binding acknowlegded mailbox in gridview
        public DataSet GridMailBoxAcknowledgeBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_ACKNOWLEDGE", hs);
        }

        //Pranay 16 August 2016--Adding method for updating acknowlegded mailbox
        public int UpdateConfigureAcknowledgetoMailbox(Hashtable htUserData)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_ACKNOWLEDGEMAILBOXMAPPED", htUserData));
        }


        //Pranay 20 October 2016 -- Method for adding Reference for future user
        public int ConfigureReferencetoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_REFERENCE_MAILBOXADD", hs));
        }

        //Pranay 21 October 2016--update method for referenceUpdate(Folder Structure(Patheon CR))
        public int UpdateConfigureReferencetoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_UPDATE_REFERENCEMAILBOXMAPPED", hs));
        }

        //Pranay 21 October 2016--update method for referenceUpdate(Folder Structure(Patheon CR))
        public DataSet GridMailBoxReferenceBind(Hashtable hs)
        {

            return new DBHelper().SelectDataSet("USP_SELECT_MAILBOXMAPPED_REFERENCE", hs);
        }
        public DataSet GetDynamicPageControls(Hashtable hs)
        {
            return new DBHelper().SelectDataSet("USP_GetDynamicControlstoDataEntry", hs);
        }

       

 
    }
}
