﻿using System;
using System.Linq;
using System.Xml.Linq;
using System.Xml;
//using Quart.BusinessEntity;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data;
//using Quart.Utility;
using System.Configuration;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Reflection;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Data Element DAO
    /// </summary>
    public class DataElementDAO : IDataElementConfigurationRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        //private string dbConnectionString = string.Empty;
        //protected Logger proxyLogger = new Logger();

        /// <summary>
        /// Database connection
        /// </summary>

        public DataElementDAO(string appId, int TenantId)
        {
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId); 
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
        }

        public DataTable GetDataElementRecordList(DataElementEntity _Obj)
        {
            objloginfo.Message = ("DataElementDAO - GetDataElementRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("DataElementDAO - GetDataElementRecordList - Called.");
            DataTable _dt = new DataTable();
            try
            {

                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_TRANSELEMENTLIST, SqlConnection);
                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                //return _dt;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw ex;
            }
            return _dt;
        }


        //public DataTable GetDirectAuditLevelList(BaseTransportEntity _Obj)
        //{
        //    proxyLogger.Log.Info("DataElementDAO - GetDirectAuditLevelList - Called.");
        //    try
        //    {
        //        DataTable _dt = new DataTable();
        //        using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            SqlConnection.Open();
        //            SqlCommand command = new SqlCommand("USP_GET_DIRECT_AUDIT_LEVEL", SqlConnection);
        //            command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (_Obj._SubProcessID == 0) ? 0 : _Obj._SubProcessID;
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_dt);
        //        }
        //        return _dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw ex;
        //    }
        //}
      
        /// <summary>
        /// Medthod to Get CUD DataElement Record
        /// </summary>
        /// <param name="DataElementEnt">BaseTransportEntity</param>
        /// <returns>string</returns>
        public string CUDDataElementRecord(DataElementEntity _DataElement)
        {
            string resultValue = "-1";
            XElement Parent = new XElement("root");
            XElement root = new XElement("xmlArguments");
            objloginfo.Message = ("DataElementDAO - GetDataElementRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("DataElementDAO - CUDDataElementRecord - Called.");
            try
            {
               // DataElementEntity _DataElement = new DataElementEntity();
                //_DataElement = (DataElementEntity)DataElementEnt;
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_TRANSELEMENTCONFIG, SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;


                    root.Add(new XAttribute("iElementId", (_DataElement.eventAction == Constants.ACTION_Insert) ? 0 : _DataElement.ElementId));

                    if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.ElementName)))
                        root.Add(new XAttribute("szElementName", Convert.ToString(_DataElement.ElementName)));
                    if (!string.IsNullOrEmpty(_DataElement.Description))
                        root.Add(new XAttribute("szDescription", Convert.ToString(_DataElement.Description)));
                    if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.FieldType)))
                        root.Add(new XAttribute("FieldType", Convert.ToString(_DataElement.FieldType)));
                    if (!string.IsNullOrEmpty(_DataElement.minRange))
                        root.Add(new XAttribute("szminRange", Convert.ToString(_DataElement.minRange)));
                    if (!string.IsNullOrEmpty(_DataElement.maxRange))
                        root.Add(new XAttribute("szmaxRange", Convert.ToString(_DataElement.maxRange)));
                        root.Add(new XAttribute("iElementTypeId", (_DataElement.ElementTypeId == 0) ? 0 : _DataElement.ElementTypeId));
                    
                    if (_DataElement.DataTypeId.Equals(0))
                        root.Add(new XAttribute("iDataTypeId", 0));
                    else
                        root.Add(new XAttribute("iDataTypeId", Convert.ToString(_DataElement.DataTypeId)));

                    if (!string.IsNullOrEmpty(_DataElement.splChars))
                        root.Add(new XAttribute("szSplChars", Convert.ToString(_DataElement.splChars)));
                   
                        root.Add(new XAttribute("iElementLength", (_DataElement.ElementLength == 0) ? 0 : _DataElement.ElementLength));

                    if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.CodeGroupId)))
                        root.Add(new XAttribute("szCodeGroupId", Convert.ToString(_DataElement.CodeGroupId)));

                    root.Add(new XAttribute("iSequenceNo", (_DataElement.SequenceNo == 0) ? 0 : _DataElement.SequenceNo));
                    root.Add(new XAttribute("bMandatoryElement", _DataElement.MandatoryElement));
                    root.Add(new XAttribute("bAuditFormElement", _DataElement.AuditFormElement));
                    root.Add(new XAttribute("bUniqueElement", _DataElement.UniqueElement));
                    root.Add(new XAttribute("bGridViewElement", _DataElement.GridViewElement));
                    root.Add(new XAttribute("bReportableField", _DataElement.IsReportField));
                    root.Add(new XAttribute("bComparisonId", _DataElement.ComparisonID));
                    root.Add(new XAttribute("bSearchableElement", _DataElement.SearchableElement));
                    root.Add(new XAttribute("bSamplingThreshold", _DataElement.SamplingThreshold));
                    root.Add(new XAttribute("bIsDirectAuditLevel", _DataElement.IsDirectAuditLevel));

                    if (_DataElement.DirectAuditLevelId.Equals(0))
                        root.Add(new XAttribute("iDirectAuditLevelId", "0"));
                    else
                        root.Add(new XAttribute("iDirectAuditLevelId", _DataElement.DirectAuditLevelId));
                                                         
                    if (!string.IsNullOrEmpty(_DataElement.minAuditRange))
                        root.Add(new XAttribute("szMinAuditRange", Convert.ToString(_DataElement.minAuditRange)));
                    if (!string.IsNullOrEmpty(_DataElement.maxAuditRange))
                        root.Add(new XAttribute("szMaxAuditRange", Convert.ToString(_DataElement.maxAuditRange)));
                    if (!string.IsNullOrEmpty(_DataElement.minSamplingRange))
                        root.Add(new XAttribute("szMinSamplingRange", Convert.ToString(_DataElement.minSamplingRange)));
                    if (!string.IsNullOrEmpty(_DataElement.maxSamplingRange))
                        root.Add(new XAttribute("szMaxSamplingRange", Convert.ToString(_DataElement.maxSamplingRange)));
                    if (!string.IsNullOrEmpty(_DataElement.DataEntryRoleId))
                        root.Add(new XAttribute("szRoleIds", Convert.ToString(_DataElement.DataEntryRoleId)));
                    else
                        root.Add(new XAttribute("szRoleIds", string.Empty));

                    root.Add(new XAttribute("iSubProcessId", (_DataElement._SubProcessID == 0) ? 0 : _DataElement._SubProcessID));

                    root.Add(new XAttribute("bIsActive", true));

                    if (!string.IsNullOrEmpty(_DataElement.createdBy))
                        root.Add(new XAttribute("iCreatedBy", _DataElement.createdBy));

                    if (!string.IsNullOrEmpty(_DataElement.modifiedBy))
                        root.Add(new XAttribute("iModifiedBy", _DataElement.modifiedBy));
                   // if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.ElementName)))
                        root.Add(new XAttribute("bIsSamplingConfigured", Convert.ToString(_DataElement.isSamplingconfigured)));
                    root.Add(new XAttribute("bIsPurgingField", _DataElement.IsPurgingField)); 
                    root.Add(new XAttribute("szOpertaionName", Convert.ToString(_DataElement.eventAction)));
                    root.Add(new XAttribute("iRectrictedElementCount", Convert.ToString(_DataElement._ElementCount)));
                   // if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.ElementName)))
                        root.Add(new XAttribute("bIsSamplingConfigured", Convert.ToString(_DataElement.isSamplingconfigured)));
                        root.Add(new XAttribute("bIsPurgingField", _DataElement.IsPurgingField)); 
                    Parent.Add(root);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }

               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return resultValue;
        }


        /// <summary>
        /// Sets sequence of data elemnents
        /// </summary>
        /// <param name="action"></param>
        /// <param name="DataelemenmtEntSeq"></param>
        /// <returns>sequences data elements</returns>
        public string SetUpdateSequence(ElementSequence DataElementEntSeq)
        {
            string resultValue = "-1";
            objloginfo.Message = ("DataElementDAO - GetDataElementRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("DataElementDAO - SetUpdateSequence - Called.");
            try
            {
              //  ElementSequence _ElementSeq = new ElementSequence();
              //  _ElementSeq = (ElementSequence)DataElementEntSeq;

                XElement xml = new XElement("ElementSequence",
               DataElementEntSeq.ElementList.Select(i => new XElement("Element",
                   new XAttribute("ElementId", i.ElementId),
                   new XAttribute("SequenceNo", i.SequenceNo),
                   new XAttribute("ElementName", i.ElementName)
               )));

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_TRANSELEMENTSEQUENCE, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (DataElementEntSeq._SubProcessID == 0) ? 0 : DataElementEntSeq._SubProcessID;
                    command.Parameters.Add(Constants.PAR_xmlParam, SqlDbType.Xml).Value = (xml == null) ? null : xml.ToString();
                    command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = DataElementEntSeq.eventAction;
                    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }

             
            }
            catch (XmlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
             //   throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return resultValue;
        }


        //public DataTable GetDataTypeList(BaseTransportEntity _Obj)
        //{
        //    proxyLogger.Log.Info("DataElementDAO - GetDataTypeList - Called.");
        //    try
        //    {
        //        DataTable _dt = new DataTable();
        //        using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            SqlConnection.Open();
        //            SqlCommand command = new SqlCommand(Constants.SP_GET_DATATYPE, SqlConnection);
        //            command.Parameters.Add(Constants.PAR_iElementTypeId, SqlDbType.Int).Value = _Obj.Id;
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_dt);
        //        }
        //        return _dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw ex;
        //    }
        //}

        /// <summary>
        ///Loads entity list collection
        /// </summary>
        /// <param name="action"></param>
        /// <param name="_Obj"></param>
        /// <returns>dataset</returns>
        public DataSet GetEntityListcollection(DataElementInfo _obj)
        {
            objloginfo.Message = ("DataElementDAO - GetEntityListcollection - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataSet _ds = new DataSet();
           // proxyLogger.Log.Info("DataElementDAO - GetEntityListcollection - Called.");
            try
            {
                
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_TRANS_ELE_CONFIG_COL, sqlConnection);
                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.SmallInt).Value = (_obj.SubProcessId == 0) ? 0 : _obj.SubProcessId;
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = _obj.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = _obj.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = _obj.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = _obj.SortColumn;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return _ds;
        }
        /// <summary>
        /// Used to get static conditions under subprocess
        /// </summary>
        /// <param name="configid"></param>
        /// <returns></returns>        
        public List<DataElementStaticConditon> GetChildStaticConditions(int configid)
        {
            objloginfo.Message = ("DataElementDAO - GetStaticConditions - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            List<DataElementStaticConditon> conditionsList = new List<DataElementStaticConditon>();
            //proxyLogger.Log.Info("DataElementDAO - GetStaticConditions - Called.");
            try
            {
                DataSet _ds = new DataSet();
               
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_UPDATE_CHILDSTATICCONDITIONS, sqlConnection);
                    command.Parameters.Add("@configid", SqlDbType.Int).Value = configid;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                    if (_ds != null && _ds.Tables.Count > 0)
                    {
                        DataTable temp = _ds.Tables[0].Clone();

                        foreach (DataRow dr in _ds.Tables[0].Rows)
                        {
                            int elementid = Convert.ToInt32(dr["iTransElementStaticId"]);
                            int totalCondtions = Convert.ToInt32(_ds.Tables[0].Select("iTransElementStaticId=" + elementid).Count());
                            if (totalCondtions == 1)
                                temp.ImportRow(dr);
                            if (totalCondtions > 1)
                            {
                                if (Convert.ToInt32(temp.Select("iTransElementStaticId=" + elementid).Count()) > 0)
                                {
                                    DataRow existingRow = temp.Select("iTransElementStaticId=" + elementid).First();
                                    if (existingRow["bStaticElementConditionValue"].ToString().ToLower() == "yes")
                                        temp.ImportRow(dr);
                                }
                                else if (dr["bStaticElementConditionValue"].ToString().ToLower() == "yes" || dr["iOrder"].ToString().ToLower() == "1")
                                    temp.ImportRow(dr);
                            }
                        }
                        conditionsList = (from DataRow dr in temp.Rows
                                          select new DataElementStaticConditon()
                                          {
                                              ConfigId = Convert.ToInt32(dr["iTransElementStaticConfigId"]),
                                              FieldDescription = dr["szStaticElementCondition"].ToString(),
                                              YesOrNO = dr["bStaticElementConditionValue"].ToString(),
                                          }).ToList();
                    }

                   
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
              //  throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
              //  throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return conditionsList;
        }
        /// <summary>
        /// Used to get static conditions under subprocess
        /// </summary>
        /// <param name="subProcessid"></param>
        /// <returns></returns>

        public List<DataElementStaticConditon> GetStaticConditions(int subProcessid)
        {
            objloginfo.Message = ("DataElementDAO - GetStaticConditions - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("DataElementDAO - GetStaticConditions - Called.");
            List<DataElementStaticConditon> conditionsList = new List<DataElementStaticConditon>();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_STATICCONDITIONS, sqlConnection);
                    command.Parameters.Add("@subProcessid", SqlDbType.Int).Value = subProcessid;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                    DataTable temp = _ds.Tables[0].Clone();

                    foreach (DataRow dr in _ds.Tables[0].Rows)
                    {
                        int elementid = Convert.ToInt32(dr["iTransElementStaticId"]);
                        int totalCondtions = Convert.ToInt32(_ds.Tables[0].Select("iTransElementStaticId=" + elementid).Count());
                        if (totalCondtions == 1)
                            temp.ImportRow(dr);
                        if (totalCondtions > 1)
                        {
                            if (Convert.ToInt32(temp.Select("iTransElementStaticId=" + elementid).Count()) > 0)
                            {
                                DataRow existingRow = temp.Select("iTransElementStaticId=" + elementid).First();
                                if (existingRow["bStaticElementConditionValue"].ToString().ToLower() == "yes")
                                    temp.ImportRow(dr);
                            }
                            else if (dr["bStaticElementConditionValue"].ToString().ToLower() == "yes" || dr["iOrder"].ToString().ToLower() == "1")
                                temp.ImportRow(dr);
                        }
                    }

                  

                    conditionsList = (from DataRow dr in temp.Rows
                                      select new DataElementStaticConditon()
                                      {
                                          ConfigId = Convert.ToInt32(dr["iTransElementStaticConfigId"]),
                                          FieldDescription = dr["szStaticElementCondition"].ToString(),
                                          YesOrNO = dr["bStaticElementConditionValue"].ToString(),
                                      }).ToList();

                   
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            return conditionsList;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        /// <summary>
        /// Used to updated static conditions
        /// </summary>
        /// <param name="objConditions"></param>
        /// <returns></returns>
        public string UpdateStaticConditions(List<DataElementStaticConditon> objConditions)
        {
            string resultValue = "";
            objloginfo.Message = ("DataElementDAO - SetUpdateSequence - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int result=0;

           // proxyLogger.Log.Info("DataElementDAO - SetUpdateSequence - Called.");
            try
            {

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_UPDATE_STATICCONDITIONS, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    DataTable dt = DataElementDAO.ToDataTable(objConditions);
                    command.Parameters.AddWithValue("NewCondtionsTable", dt);
                    result = command.ExecuteNonQuery();
                    if (result > 0)
                        resultValue = "Updated successfully.";
                    else
                        if (result == 0)
                            resultValue = "No changes made.";
                        else
                            resultValue = "Updated failed.";
                }

               
            }
            catch (XmlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            return resultValue;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }

        public DataTable GetDirectAuditLevelList(int SubProcessID )
        {
            objloginfo.Message = ("DataElementDAO - GetStaticConditions - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("DataElementDAO - GetDirectAuditLevelList - Called.");
            DataTable _dt = new DataTable();
            try
            {
               
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_DIRECT_AUDIT_LEVEL", SqlConnection);
                    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (SubProcessID == 0) ? 0 : SubProcessID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
               
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw ex;
            }
            return _dt;
        }
        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public DataSet ExcelUploadToDB(Hashtable hstbl)
        {

            DataSet dsRecords = new DataSet();
            try
            {

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    var BulkUdCount = ConfigurationManager.AppSettings["BULK_UPLD_MAX_COUNT"];
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["BulkUploadQueryExecTimeout"];
                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.BULKUPLOADQUERYEXECTIMEOUT;
                    sqlConnection.Open();

                    if (hstbl.ContainsKey("ActionType") && Convert.ToString(hstbl["ActionType"]).Equals("User"))
                    {
                        SqlCommand command = new SqlCommand(Constants.SP_SET_BULKUPLOADDATA_USERTEMPLATE, sqlConnection);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FilePath") ? Convert.ToString(hstbl["FilePath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEEXTN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FileExtention") ? Convert.ToString(hstbl["FileExtention"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_SUBPROCESS, SqlDbType.VarChar).Value = (hstbl.ContainsKey("SubProcessID") ? Convert.ToString(hstbl["SubProcessID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_UPLOADBY, SqlDbType.VarChar).Value = (hstbl.ContainsKey("CurrentUserID") ? Convert.ToString(hstbl["CurrentUserID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_ERRORPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPath") ? Convert.ToString(hstbl["ErrorPath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELCOLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelColumn") ? Convert.ToString(hstbl["StrExcelColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_COLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrColumn") ? Convert.ToString(hstbl["StrColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELDATA, SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelDataxml") ? Convert.ToString(hstbl["StrExcelDataxml"]) : string.Empty);
                        //Added for HC-CR1 for User Group-Usermapping using Bulk Upload
                        command.Parameters.Add("@ErrorFilePathGroup", SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPathGroup") ? Convert.ToString(hstbl["ErrorPathGroup"]) : string.Empty);
                        command.Parameters.Add("@ExcelUserGroupmapColumn", SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelGroupMapColumn") ? Convert.ToString(hstbl["StrExcelGroupMapColumn"]) : string.Empty);
                        command.Parameters.Add("@UserGroupColumn", SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrGroupMapColumn") ? Convert.ToString(hstbl["StrGroupMapColumn"]) : string.Empty);
                        command.Parameters.Add("@ExcelUserGroupmapData", SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelUserGroupMapDataxml") ? Convert.ToString(hstbl["StrExcelUserGroupMapDataxml"]) : string.Empty);
                        command.Parameters.Add("@ErrorFilePathRole", SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPathRole") ? Convert.ToString(hstbl["ErrorPathRole"]) : string.Empty);
                        command.Parameters.Add("@ExcelUserRolemapColumn", SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelRoleMapColumn") ? Convert.ToString(hstbl["StrExcelRoleMapColumn"]) : string.Empty);
                        command.Parameters.Add("@UserRoleColumn", SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrRoleMapColumn") ? Convert.ToString(hstbl["StrRoleMapColumn"]) : string.Empty);
                        command.Parameters.Add("@ExcelUserRolemapData", SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelUserRoleMapDataxml") ? Convert.ToString(hstbl["StrExcelUserRoleMapDataxml"]) : string.Empty);
                        command.Parameters.Add("@ProgramId", SqlDbType.VarChar).Value = (hstbl.ContainsKey("ProgramID") ? Convert.ToString(hstbl["ProgramID"]) : string.Empty);
                        //End of Change
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                        SqlDataAdapter adp = new SqlDataAdapter(command);
                        adp.Fill(dsRecords);
                    }
                    //Added for HC-CR1 for data elements bulk upload
                    else if (hstbl.ContainsKey("ActionType") && Convert.ToString(hstbl["ActionType"]).Equals("DataElement"))
                    {
                        SqlCommand command = new SqlCommand("USP_SET_BULKUPLOAD_DATAELEMENTCONFIG", sqlConnection);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FilePath") ? Convert.ToString(hstbl["FilePath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEEXTN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FileExtention") ? Convert.ToString(hstbl["FileExtention"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_SUBPROCESS, SqlDbType.Int).Value = (hstbl.ContainsKey("SubProcessID") ? Convert.ToString(hstbl["SubProcessID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_UPLOADBY, SqlDbType.VarChar).Value = (hstbl.ContainsKey("CurrentUserID") ? Convert.ToString(hstbl["CurrentUserID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_ERRORPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPath") ? Convert.ToString(hstbl["ErrorPath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELCOLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelColumn") ? Convert.ToString(hstbl["StrExcelColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_COLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrColumn") ? Convert.ToString(hstbl["StrColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELDATA, SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelDataxml") ? Convert.ToString(hstbl["StrExcelDataxml"]) : string.Empty);
                        command.Parameters.Add("@maxElementUploadCount", SqlDbType.VarChar).Value = (hstbl.ContainsKey("MaximumDECount") ? Convert.ToString(hstbl["MaximumDECount"]) : string.Empty);
                        command.Parameters.Add("@RestrictedElementName", SqlDbType.VarChar).Value = (hstbl.ContainsKey("RestrictedElementName") ? Convert.ToString(hstbl["RestrictedElementName"]) : string.Empty);
                        command.CommandType = CommandType.StoredProcedure;
                        //command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                        command.CommandTimeout = 0;
                        SqlDataAdapter adp = new SqlDataAdapter(command);
                        adp.Fill(dsRecords);
                    }
                    //End of Change
                    else
                    {
                        SqlCommand command = new SqlCommand(Constants.SP_SET_BULKUPLOADDATA, sqlConnection);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FilePath") ? Convert.ToString(hstbl["FilePath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEEXTN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FileExtention") ? Convert.ToString(hstbl["FileExtention"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_SUBPROCESS, SqlDbType.VarChar).Value = (hstbl.ContainsKey("SubProcessID") ? Convert.ToString(hstbl["SubProcessID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_UPLOADBY, SqlDbType.VarChar).Value = (hstbl.ContainsKey("CurrentUserID") ? Convert.ToString(hstbl["CurrentUserID"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_ERRORPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPath") ? Convert.ToString(hstbl["ErrorPath"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELCOLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelColumn") ? Convert.ToString(hstbl["StrExcelColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_COLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrColumn") ? Convert.ToString(hstbl["StrColumn"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELDATA, SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelDataxml") ? Convert.ToString(hstbl["StrExcelDataxml"]) : string.Empty);
                        command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_DATEFORMATCON, SqlDbType.VarChar).Value = (hstbl.ContainsKey("DateFormatCon") ? Convert.ToString(hstbl["DateFormatCon"]) : string.Empty);
                        command.Parameters.Add("@UploadType", SqlDbType.VarChar).Value = (hstbl.ContainsKey("UploadType") ? Convert.ToString(hstbl["UploadType"]) : string.Empty);
                        command.Parameters.Add("@iBulkUploadId", SqlDbType.VarChar).Value = (hstbl.ContainsKey("BulkUploadId") ? Convert.ToString(hstbl["BulkUploadId"]) : string.Empty);
                        command.Parameters.Add("@maxBulkUploadCount", SqlDbType.VarChar).Value = BulkUdCount;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandTimeout = 0;
                        SqlDataAdapter adp = new SqlDataAdapter(command);
                        adp.Fill(dsRecords);
                    }
                }

              

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (FormatException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (OverflowException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                ////proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                ////throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}

            return dsRecords;

        }


        /// <summary>
        /// Method to Get Code List
        /// </summary>
        /// <param name="_obj">BaseTransportEntity</param>
        /// <returns>DataSet</returns>
        public DataSet GetCodesList(CodeGroupEntity _Codes)
        {
            DataSet _dt = new DataSet();
            try
            {
                //CodeGroupEntity _Codes = new CodeGroupEntity();
                //_Codes = (CodeGroupEntity)_obj;
              
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_CODESDATALIST_BYID, SqlConnection);
                    command.Parameters.Add(Constants.PAR_iElementId, SqlDbType.Int).Value = (_Codes.ElementID == null) ? 0 : Convert.ToInt32(_Codes.ElementID);
                    command.Parameters.Add(Constants.PAR_ViewName, SqlDbType.VarChar).Value = DBNull.Value;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
              
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
              //  throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (FormatException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (OverflowException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return _dt;
        }
        /// <summary>
        /// Method to SetCodesData
        /// </summary>
        /// <param name="_obj">BaseTransportEntity</param>
        /// <returns>string</returns>
        public string SetCodesData(CodesEntity _Codes)
        {
            string resultValue = "-1";
            try
            {
               // CodesEntity _Codes = new CodesEntity();
               // _Codes = (CodesEntity)_obj;
                DataTable _dt = new DataTable();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_CODESDATA, SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(Constants.PAR_iCodeId, SqlDbType.Int).Value = (_Codes.eventAction == Constants.ACTION_Insert) ? 0 : _Codes.CodeId;
                    command.Parameters.Add(Constants.PAR_szCodeValue, SqlDbType.VarChar).Value = (_Codes.CodeValue == null) ? null : _Codes.CodeValue;
                    command.Parameters.Add(Constants.PAR_szCodeDesc, SqlDbType.VarChar).Value = (_Codes.CodeDesc == null) ? null : _Codes.CodeDesc;
                    command.Parameters.Add(Constants.PAR_szCodeGroupId, SqlDbType.VarChar).Value = (_Codes.CodeGroupId == null) ? null : _Codes.CodeGroupId;
                    command.Parameters.Add(Constants.PAR_iCreatedBy, SqlDbType.Int).Value = (_Codes.createdBy == null) ? 0 : Convert.ToInt32(_Codes.createdBy);
                    command.Parameters.Add(Constants.PAR_iModifiedBy, SqlDbType.Int).Value = (_Codes.modifiedBy == null) ? 0 : Convert.ToInt32(_Codes.modifiedBy);
                    command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = _Codes.eventAction;
                    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }

              
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (FormatException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (OverflowException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return resultValue;
        }

        public bool IsAutoAudit(DataElementInfo objdataelementinfo)
        {
            bool result=false;
            DataTable _dt = new DataTable();
            using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
            {
                SqlConnection.Open();
                SqlCommand command = new SqlCommand("USP_GET_AUDITCONFIG", SqlConnection);
               // command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (objdataelementinfo.SubProcessId == 0) ? 0 : objdataelementinfo.SubProcessId;
                command.Parameters.Add("@SubProcessID", SqlDbType.Int).Value = (objdataelementinfo.SubProcessId == 0) ? 0 : objdataelementinfo.SubProcessId;
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter adp = new SqlDataAdapter(command);
                adp.Fill(_dt);
               // DataTable temp = _dt;

                foreach (DataRow dr in _dt.Rows)
                {
                    result = Convert.ToBoolean(dr["bisAutoAudit"] == DBNull.Value ? false : dr["bisAutoAudit"]);
                     //result = Convert.ToBoolean(dr["bisAutoAudit"])?false :bISAutoAudit);
                   // result = Convert.ToBoolean(dr["bISAutoAudit"]?0);
                }
               
            }
            return result;

        }

        public string DeleteDataelementRecords(string DataElementIDs, int ModifiedBy)
        {
            string resultValue = "-1";
            using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand("USP_DELETE_TRANSELEMENTCONFIG", sqlConnection);
                command.CommandType = CommandType.StoredProcedure;

                //    command.Parameters.Add(Constants.PAR_iSubProcessId, SqlDbType.Int).Value = (DataElementEntSeq._SubProcessID == 0) ? 0 : DataElementEntSeq._SubProcessID;
                command.Parameters.Add("DataElementIDS", SqlDbType.VarChar).Value = DataElementIDs;
                command.Parameters.Add("iModifiedBy", SqlDbType.Int).Value = ModifiedBy;
                SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                outprm.Direction = ParameterDirection.Output;
                command.Parameters.Add(outprm);

                command.ExecuteNonQuery();
                resultValue = outprm.Value.ToString();
            }
            return resultValue;

        } 

    }
}
