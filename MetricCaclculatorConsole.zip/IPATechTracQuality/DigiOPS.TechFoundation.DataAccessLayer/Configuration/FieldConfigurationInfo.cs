﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
    public class FieldConfigurationInfo : ConfigurationInfo
    { }

    //    public string ElementSQLDataType { get; set; }
    //    public string CodeGroupId { get; set; }





    //    public Boolean IsEditMode { get; set; }

    //    public string minSamplingRange { get; set; }
    //    public string maxSamplingRange { get; set; }
    //    public string minAuditRange { get; set; }
    //    public string maxAuditRange { get; set; }
    //    public string DataEntryRoleId { get; set; }


    //    public int selectedDataTypeId { get; set; }
    //    public string selectedDataTypeName { get; set; }
    //    public int selectedDataElementTypeId { get; set; }
    //    public string selectedDataElementTypeName { get; set; }
    //    public int selectedDataEntryRoleId { get; set; }
    //    public string selectedDataEntryRoleName { get; set; }
    //    public string RoleNames { get; set; }
    //    public string FieldType { get; set; }


    //    public string RoleName { get; set; }
    //    public string CaseID { get; set; }
    //    public int CountryID { get; set; }
    //    public int MailBoxID { get; set; }
    //    public string UserId { get; set; }
    //    public string fieldname { get; set; }
    //    public string FieldAliasName { get; set; }
    //    public string FieldTypeID { get; set; }
    //    // public string FieldType { get; set; }
    //    public string FieldDataTypeID { get; set; }
    //    public long ValidationTypeID { get; set; }
    //    public long FieldPrivilageId { get; set; }
    //    public int TextLength { get; set; }
    //    public bool Mandatory { get; set; }
    //    public bool chkactive { get; set; }
    //    public long FieldMaxLength { get; set; }
    //    public long FieldMasterId { get; set; }
    //    public string defaultValue { get; set; }
    //    public string btnMap { get; set; }
    //    public string Value { get; set; }
    //    public string DynamicFieldMasterId { get; set; }
    //}
    public class DataElementEntity : ConfigurationInfo ////DyanamicField
    {

        public int ElementId { get; set; }
        public string ElementName { get; set; }
        public string DisplayName { get; set; }
        public int ElementTypeId { get; set; }
        public string ElementTypeName { get; set; }
        public Boolean ElementIsList { get; set; }
        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public string ElementSQLDataType { get; set; }
        public string CodeGroupId { get; set; }
        public int SequenceNo { get; set; }
        public Boolean MandatoryElement { get; set; }
        public Boolean AuditFormElement { get; set; }
        public Boolean UniqueElement { get; set; }
        public int ElementLength { get; set; }
        public Boolean SearchableElement { get; set; }
        public Boolean IsReportField { get; set; }
        public Boolean GridViewElement { get; set; }
        public Boolean SamplingThreshold { get; set; }
        public Boolean IsDirectAuditLevel { get; set; }
        public int DirectAuditLevelId { get; set; }
        public string DirectAuditLevel { get; set; }

        public Boolean isActive { get; set; } // Quart
        public DateTime effectiveFrom { get; set; }
        public DateTime effectiveTo { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public Boolean IsEditMode { get; set; }
        public string splChars { get; set; }
        public string minSamplingRange { get; set; }
        public string maxSamplingRange { get; set; }
        public string minAuditRange { get; set; }
        public string maxAuditRange { get; set; }
        public string DataEntryRoleId { get; set; }
        public int selectedProgramId { get; set; }
        public string selectedProgramName { get; set; }
        public int selectedProcessId { get; set; }
        public string selectedProcessName { get; set; }
        public int selectedSubProcessId { get; set; }
        public string selectedSubProcessName { get; set; }
        public int selectedDataTypeId { get; set; }
        public string selectedDataTypeName { get; set; }
        public int selectedDataElementTypeId { get; set; }
        public string selectedDataElementTypeName { get; set; }
        public int selectedDataEntryRoleId { get; set; }
        public string selectedDataEntryRoleName { get; set; }
        public string RoleNames { get; set; }
        public string FieldType { get; set; }

        public string RoleName { get; set; } //Emt
        public string CaseID { get; set; }
        public int CountryID { get; set; }
        public int MailBoxID { get; set; }
        public string UserId { get; set; }
        public string fieldname { get; set; }
        public string FieldAliasName { get; set; }
        public string FieldTypeID { get; set; }
        // public string FieldType { get; set; }
        public string FieldDataTypeID { get; set; }
        public long ValidationTypeID { get; set; }
        public long FieldPrivilageId { get; set; }
        public int TextLength { get; set; }
        public bool Mandatory { get; set; }
        public bool chkactive { get; set; }
        public long FieldMaxLength { get; set; }
        public long FieldMasterId { get; set; }
        public string defaultValue { get; set; }
        public string btnMap { get; set; }
        public string Value { get; set; }
        public string DynamicFieldMasterId { get; set; }
    }

    [Serializable]
    public class ConfigurationEntity : ConfigurationInfo
    {
        // Workflow Configuration Properties 
        public int WorkflowConfigID { get; set; } /* Primary */

        public int SubProcessID { get; set; }
        public int TransactionTypeID { get; set; }
        public int iSubCategoryId { get; set; }

        public bool IsCoreTransactionStatusRequired { get; set; }
        public bool IsCoreTransactionStatusReasonRequired { get; set; }

        public bool IsInternalExternalAuditRequired { get; set; }
        public bool IsExternalAuditRequired { get; set; }


        public bool IsDirectBusinessAuditRequired { get; set; }

        public bool bIsExternalAudit { get; set; }

        public bool isBusiAutoAllocationSamplingRequired { get; set; }

        public bool isExternalAutoAllocationSamplingRequired { get; set; }

        public int AuditConfigId { get; set; }  /* */

        public string AuditingLogicType { get; set; }
        public string ScoringLogicType { get; set; }

        public bool IsEmpNeeded { get; set; }
        public bool bIsLineApplicable { get; set; }

        public int SubDefectLevel { get; set; }

        public string SamplingType { get; set; }
        public string ExternalSamplingType { get; set; }
        public string BusinessSamplingType { get; set; }


        // Common Properties for Workflow Configuration & Audit Configuration

        public bool IsEditAllowed { get; set; }

        public bool IsActive { get; set; }

        public string Action { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }

        public string EntityName { get; set; }
        public bool EntitySavedStatus { get; set; }
        public string ErrorMessage { get; set; }
        //added by sathish
        public string ReworkRequiredFor { get; set; }
        public string ReworkupdateNeedFor { get; set; }
        public string ManualAllocationRequiredFor { get; set; }
        public bool IsSuperVisorAuditRequired { get; set; }
        public bool IsAutoSamplingRequired { get; set; }
        public bool IsTotalVolumeAuditRequired { get; set; }

        public string szSamplingMethodInternal { get; set; }
        public string szSamplingMethodBusiness { get; set; }


    }



}
