﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Data;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class ManualHierarchyConfigurationRepository : IManualHierarchyConfigurationRepository
    {
        public virtual string CUDProgramRecord(ProgramEntity _Program)
        {
            return null;
        }
        public virtual string SetProcessRecord(ProcessEntity _Process)
        {
            return null;
        }
        public virtual DataTable GetProcessEntityList(ManualHierarchyInfo objinfo)
        {
            return null;
        }
        public virtual string SetSubProcessRecord(SubProcessEntity objSubprocess)
        {
            return null;
        }
        public virtual DataTable GetSubProcessList(ManualHierarchyInfo objinfo)
        {
            return null;
        }
        public virtual DataSet GetEntityListcollection(ManualHierarchyInfo objinfo)
        {
            return null;
        }
         public virtual DataSet GetEntityListcollectionProgram(ManualHierarchyInfo _obj)
        {
            return null;
        }
        
    }
}
