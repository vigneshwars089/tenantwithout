﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Collections;
using System.IO;
using System.Data;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class WorkflowConfigDataAccess
    {
        WorkflowAuditConfigDAO wrkdao = null;
        WorkflowAuditConfigurationTransformer wrkflwtrans = new WorkflowAuditConfigurationTransformer();
        public string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig)
        {
            wrkdao = new WorkflowAuditConfigDAO(objconfig.AppID, objconfig.TenantID);
            string createRecVal = string.Empty;
            createRecVal = wrkdao.SetWorkflowAuditConfiguration(objconfig);
            return createRecVal;
        }
        public List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo)
        {
            wrkdao = new WorkflowAuditConfigDAO(objinfo.AppID, objinfo.TenantID);
            List<WorkflowConfigurationEntity> listwrkflow = new List<WorkflowConfigurationEntity>();
            DataTable dt = new DataTable();
            dt = wrkdao.GetEntityRecordByEntity(objinfo);
            if (dt.Rows.Count <= 0)
                return listwrkflow;
            else
            {
                listwrkflow = wrkflwtrans.MapToWorkflowAuditConfigList(dt);
                return listwrkflow;
            }
        }
    }
}
