﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class DataElementDataAccess
    {
        DataElementDAO dataelmntdao = null;
        DataElementTransformer dataelmnttrans = new DataElementTransformer();
        DataElementEntity dtent = new DataElementEntity();
        
        public string AddUpdateDataElement(List<DataElementEntity> DataElements)
        {
            string createRecVal = string.Empty;
            dtent.ErrorMessage = new StringBuilder();
            foreach (var a in DataElements)
            {
                dataelmntdao = new DataElementDAO(a.AppID,a.TenantID);

                createRecVal = dataelmntdao.CUDDataElementRecord(a);
               
                if(!(Convert.ToInt32(createRecVal)==1))
                {
                    dtent.ErrorMessage.Append(a.ElementName+" "+"Dataelement operation failed \n");
                }
                createRecVal = createRecVal + " "+dtent.ErrorMessage.ToString();
            }
            return createRecVal;
        }

        //public string DeleteDataElement(DataElementEntity datent)
        //{
        //    string createRecVal = string.Empty;
            
        //        dataelmntdao = new DataElementDAO(datent.AppID, datent.TenantID);

        //        createRecVal = dataelmntdao.CUDDataElementRecord(datent);

        //    return createRecVal;
        //}
        public List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj)
        {
            DataTable dt = new DataTable();
            List<DataElementEntity> list = new List<DataElementEntity>();
            dataelmntdao = new DataElementDAO(_Obj.AppID, _Obj.TenantID);
            dt = dataelmntdao.GetDataElementRecordList(_Obj);
            if (dt.Rows.Count <= 0)
                return list;
            else
            {
                list = dataelmnttrans.MapToDataElementList(dt);
                return list;
            }
        }
        public List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj)
        {
            dataelmntdao = new DataElementDAO(_obj.AppID, _obj.TenantID);
            List<List<DataElementEntity>> listdataelmnt = new List<List<DataElementEntity>>();
            DataSet ds = new DataSet();
            ds = dataelmntdao.GetEntityListcollection(_obj);
            if (ds.Tables.Count <= 0)
                return listdataelmnt;
            else
            {
                listdataelmnt.Add(dataelmnttrans.MapToDataElementList(ds.Tables[0]));
                listdataelmnt.Add(dataelmnttrans.MapToDropDownList(ds.Tables[1]));
                listdataelmnt.Add(dataelmnttrans.MapToDropDownList(ds.Tables[2]));
                return listdataelmnt;
            }
            
        }
        public DataSet BulkUploadDataElement(Hashtable hstbl, string AppID, int TenantID)
        {
            DataSet ds = new DataSet();
            dataelmntdao = new DataElementDAO(AppID,TenantID);
            ds = dataelmntdao.ExcelUploadToDB(hstbl);
            return ds;
        }
        public List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, int TenantID)
        {
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            List<DataElementStaticConditon> listdataelmnt = new List<DataElementStaticConditon>();
            listdataelmnt = dataelmntdao.GetChildStaticConditions(configid);
            return listdataelmnt;
        }
        public List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, int TenantID)
        {
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            List<DataElementStaticConditon> listdataelmnt = new List<DataElementStaticConditon>();
            listdataelmnt = dataelmntdao.GetStaticConditions(subprocessid);
            return listdataelmnt;
        }
        public string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, int TenantID)
        {
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            string result = null;
            result = dataelmntdao.UpdateStaticConditions(objConditions);
            return result;
        }
        public List<DataElementEntity> GetDirectAuditLevelList(int SubProcessID, string AppID, int TenantID)
        {
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            List<DataElementEntity> baseList = new List<DataElementEntity>();
            DataTable dt = new DataTable();
            dt = dataelmntdao.GetDirectAuditLevelList(SubProcessID);
            if (dt.Rows.Count <= 0)
                return baseList;
            baseList = dataelmnttrans.MapToDropDownList(dt);
                return baseList;
        }
        public string SetRanking(ElementSequence ElementSequence, string AppID, int TenantID)
        {
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            string result = null;
            result = dataelmntdao.SetUpdateSequence(ElementSequence);
            return result;
        }
        public string AddList(CodesEntity ListItem)
        {
            dataelmntdao = new DataElementDAO(ListItem.AppID, ListItem.TenantID);
            string result = null;
            result = dataelmntdao.SetCodesData(ListItem);
            return result;
        }
        public CodeGroupEntity GetCodesList(CodeGroupEntity _Codes)
        {
            dataelmntdao = new DataElementDAO(_Codes.AppID, _Codes.TenantID);
            CodeGroupEntity objcodes = new CodeGroupEntity();
            DataSet ds = new DataSet();
            ds = dataelmntdao.GetCodesList(_Codes);
            if (ds.Tables[0].Rows.Count <= 0)
                return objcodes;
            else
            {
                objcodes = dataelmnttrans.MapToCodesList(ds);
                return objcodes;
            }
        }

        public bool IsAutoAudit(DataElementInfo obj)
        {
            dataelmntdao = new DataElementDAO(obj.AppID, obj.TenantID);
            bool result = false;
            result = dataelmntdao.IsAutoAudit(obj);
            return result;
        }

    

    public string DeleteDataElement(List<DataElementEntity> DataElements,string ModifiedBy,string AppID,int TenantID)
        {
            string createRecVal = string.Empty;
            string Elementids = string.Empty;
          
            dataelmntdao = new DataElementDAO(AppID, TenantID);
            foreach (var a in DataElements)
            {
                if (Elementids != string.Empty)
                {
                    Elementids = Elementids+","+a.ElementId;
                }
                else
                {
                    Elementids = a.ElementId.ToString();
                }
              
            }
            createRecVal = dataelmntdao.DeleteDataelementRecords(Elementids,Convert.ToInt32(ModifiedBy));
            return createRecVal;
        } 

    }
}
