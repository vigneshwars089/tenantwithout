﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Utilities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{

    public class CaseProcessingDAO
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        System.Text.Encoding enc = System.Text.Encoding.UTF8;
        private string myConnection = string.Empty;
        //private DataSet dsStatus;
        public CaseProcessingDAO()
        {
            //myConnection = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            myConnection = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }

        public void LockEmail(int EmailBoxType, string EmailId)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_LockEmail");
                    attachcommand.Parameters.Add(new SqlParameter("EmailBoxType", EmailBoxType));
                    attachcommand.Parameters.Add(new SqlParameter("EmailId", EmailId));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                //ExceptionHelper.HandleException(ex);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_Insert_EMailDetails");
                    attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTo", EMailTo));
                    attachcommand.Parameters.Add(new SqlParameter("EMailCc", EMailCc));
                    attachcommand.Parameters.Add(new SqlParameter("Subject", Subject));
                    attachcommand.Parameters.Add(new SqlParameter("EMailBody", EMailBody));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTypeId", EMailTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailSentDate", EMailSentDate));
                    attachcommand.Parameters.Add(new SqlParameter("SentStatus", SentStatus));
                    attachcommand.Parameters.Add(new SqlParameter("plainbody", plainbody));
                    attachcommand.Parameters.Add(new SqlParameter("ishighimp", ishighimp));
                    //attachcommand.Parameters.Add(new SqlParameter("IsVip",isVIP));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                //ExceptionHelper.HandleException(ex);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public CaseInfo LoadCaseDetails(Int64 caseID)
        {
            CaseInfo objEmailCaseInfo = new CaseInfo();
            DataSet ds = new DataSet();
            try
            {
                string spname = string.Empty;
                Hashtable hs = new Hashtable();
                spname = "USP_GetCaseDetails";
                hs.Add("@CASEID", caseID);
                DBHelper db = new DBHelper();
                ds = db.SelectDataSet(spname, hs);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    objEmailCaseInfo.CaseId = Convert.ToInt64(ds.Tables[0].Rows[0]["CaseId"]);
                    objEmailCaseInfo.EmailReceivedDate = ds.Tables[0].Rows[0]["EMAILRECEIVEDDATE"].ToString();
                    objEmailCaseInfo.EmailFrom = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                    //  objEmailCaseInfo.EmailTo = ds.Tables[0].Rows[0]["EMailTo"].ToString();
                    objEmailCaseInfo.EmailCc = ds.Tables[0].Rows[0]["EMailCc"].ToString();
                    //  objEmailCaseInfo.EmailBcc = ds.Tables[0].Rows[0]["EMailBcc"].ToString();
                    objEmailCaseInfo.Subject = ds.Tables[0].Rows[0]["Subject"].ToString();
                    objEmailCaseInfo.IsUrgent = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsUrgent"].ToString());
                    objEmailCaseInfo.EmailBody = ds.Tables[0].Rows[0]["EMailBody"].ToString();
                    objEmailCaseInfo.IsManual = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsManual"].ToString());
                    objEmailCaseInfo.StatusId = ds.Tables[0].Rows[0]["StatusId"].ToString();
                    objEmailCaseInfo.AssignedToId = ds.Tables[0].Rows[0]["AssignedToID"].ToString();
                    objEmailCaseInfo.AssignedTo = ds.Tables[0].Rows[0]["AssignedTo"].ToString();
                    objEmailCaseInfo.QCUserId = ds.Tables[0].Rows[0]["QCUSERID"].ToString();
                    objEmailCaseInfo.QCAssignedTo = ds.Tables[0].Rows[0]["QCAssignedTo"].ToString();
                    objEmailCaseInfo.EmailBoxName = ds.Tables[0].Rows[0]["EmailBoxName"].ToString();
                    objEmailCaseInfo.EmailBoxAddress = ds.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                    objEmailCaseInfo.EmailBoxId = ds.Tables[0].Rows[0]["EMAILBOXID"].ToString();
                    objEmailCaseInfo.ClassificationDescription = ds.Tables[0].Rows[0]["ClassifiactionDescription"].ToString();
                    objEmailCaseInfo.Status = ds.Tables[0].Rows[0]["STATUSDESCRIPTION"].ToString();


                    //  objEmailCaseInfo.IsVipMail = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsVipMail"].ToString());
                    objEmailCaseInfo.CaseType = ds.Tables[0].Rows[0]["EMAILTYPE"].ToString();
                    if (ds.Tables[0].Rows[0]["ForwardedToGMB"] != null && ds.Tables[0].Rows[0]["ForwardedToGMB"].ToString() != "")
                        objEmailCaseInfo.ForwardedToGmb = Convert.ToBoolean(ds.Tables[0].Rows[0]["ForwardedToGMB"]);
                    if (ds.Tables[0].Rows[0]["ParentCaseId"] != null && ds.Tables[0].Rows[0]["ParentCaseId"].ToString() != "")
                        objEmailCaseInfo.ParentCaseId = Convert.ToInt32(ds.Tables[0].Rows[0]["ParentCaseId"]);
                    objEmailCaseInfo.IsMailTriggerRequired = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISMAILTRIGGERREQUIRED"]);
                    objEmailCaseInfo.IsQCRequired = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISQCREQUIRED"]);
                    objEmailCaseInfo.CategoryId = Convert.ToInt32(ds.Tables[0].Rows[0]["CategoryId"]);
                    objEmailCaseInfo.SubprocessName = ds.Tables[0].Rows[0]["SubprocessName"].ToString();
                }
                return objEmailCaseInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        public int UpdateOnReassign(long CaseId, String AssignedTo, String LoggedInUserId)
        {
            int result;
            try
            {
                Hashtable hsReAssign = new Hashtable();
                hsReAssign.Add("@AllocatedToId", AssignedTo);
                hsReAssign.Add("@CaseIds", CaseId);
                hsReAssign.Add("@LoggedInUserId", LoggedInUserId);
                DBHelper db = new DBHelper();
                result = db.ExecuteNonQuery("USP_UpdateOnReassign", hsReAssign);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return result;

        }

        public List<ConversationInfo> LoadConversationDetails(Int64 CaseId)
        {
            DataSet dsConversationDetails = new DataSet();
            List<ConversationInfo> lstConversationInfo = new List<ConversationInfo>();
            try
            {
                Hashtable hsCaseId = new Hashtable();
                hsCaseId.Add("@CaseId", CaseId);
                DBHelper db = new DBHelper();
                dsConversationDetails = db.SelectDataSet("USP_GetConversationList", hsCaseId);
                if (dsConversationDetails.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in dsConversationDetails.Tables[0].Rows)
                    {
                        ConversationInfo objConversationInfo = new ConversationInfo();
                        objConversationInfo.Id = Convert.ToInt32(dr["CONVERSATIONID"]);
                        objConversationInfo.EmailDate = (dr["ConversationDate"]).ToString();
                        objConversationInfo.EmailFrom = dr["EMAILFROM"].ToString();
                        objConversationInfo.EmailTo = dr["EMailTo"].ToString();
                        objConversationInfo.EmailCc = dr["EMailCc"].ToString();
                        objConversationInfo.EmailBcc = dr["EMailBcc"].ToString();
                        objConversationInfo.Subject = dr["Subject"].ToString();
                        //objConversationInfo.Content = (byte[])dr["Content"];
                        objConversationInfo.Content = enc.GetString((byte[])dr["Content"]);
                        objConversationInfo.ConversationType = dr["AttachmentType"].ToString();
                        objConversationInfo.CreatedDate = dr["CREATEDDATE"].ToString();
                        lstConversationInfo.Add(objConversationInfo);
                    }

                }
                return lstConversationInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        public List<AttachmentInfo> LoadAttachmentDetails(Int64 ConversationId)
        {
            List<AttachmentInfo> lstAttachmentInfo = new List<AttachmentInfo>();
            DataSet dsAttachmentDetails = new DataSet();
            try
            {
                Hashtable hsConversationId = new Hashtable();
                hsConversationId.Add("@ConversationId", ConversationId);
                DBHelper db = new DBHelper();
                dsAttachmentDetails = db.SelectDataSet("USP_GetAttachmentList", hsConversationId);
                foreach (DataRow dr in dsAttachmentDetails.Tables[0].Rows)
                {
                    AttachmentInfo objAttachmentInfo = new AttachmentInfo();
                    objAttachmentInfo.Id = Convert.ToInt32(dr["ATTACHMENTID"]);
                    objAttachmentInfo.FileName = (dr["FileName"].ToString());
                    objAttachmentInfo.FileContent = (byte[])dr["Content"];
                    objAttachmentInfo.AttachmentType = dr["ATTACHMENTTYPE"].ToString();
                    objAttachmentInfo.CreatedDate = dr["CREATEDDATE"].ToString();
                    lstAttachmentInfo.Add(objAttachmentInfo);
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return lstAttachmentInfo;


        }

        public List<AttachmentInfo> LoadInlineAttachmentDetails(Int64 ConversationId)
        {
            List<AttachmentInfo> lstAttachmentInfo = new List<AttachmentInfo>();
            DataSet dsInlineAttachmentDetails = new DataSet();
            try
            {
                Hashtable hsConversationId = new Hashtable();
                hsConversationId.Add("@ConversationId", ConversationId);
                DBHelper db = new DBHelper();
                dsInlineAttachmentDetails = db.SelectDataSet("USP_GetInlineAttachmentList", hsConversationId);
                foreach (DataRow dr in dsInlineAttachmentDetails.Tables[0].Rows)
                {
                    AttachmentInfo objAttachmentInfo = new AttachmentInfo();
                    objAttachmentInfo.Id = Convert.ToInt32(dr["ATTACHMENTID"]);
                    objAttachmentInfo.FileName = (dr["FileName"].ToString());
                    objAttachmentInfo.FileContent = (byte[])dr["Content"];
                    objAttachmentInfo.AttachmentType = dr["ATTACHMENTTYPE"].ToString();
                    DateTime CreatDate = DateTime.Parse(dr["CREATEDDATE"].ToString());
                    objAttachmentInfo.CreatedDate = CreatDate.ToString("dd/MM/yyyy HH:mm:ss");
                    lstAttachmentInfo.Add(objAttachmentInfo);
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return lstAttachmentInfo;

        }

        public List<CommentsInfo> GetComments(long CaseId)
        {
            List<CommentsInfo> lstCommentsInfo = new List<CommentsInfo>();
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@CASEID", CaseId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetComments", hsParams);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    CommentsInfo objCommentsInfo = new CommentsInfo();
                    objCommentsInfo.CommentDescription = dr["COMMENTS"].ToString();
                    objCommentsInfo.CommentedBy = dr["USERNAME"].ToString();
                    objCommentsInfo.CommentedDate = dr["CREATEDDATE"].ToString();
                    lstCommentsInfo.Add(objCommentsInfo);
                }
                return lstCommentsInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public List<AuditInfo> GetAuditLog(long CaseId)
        {
            List<AuditInfo> lstAuditInfo = new List<AuditInfo>();
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@CASEID", CaseId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetCaseAuditLog", hsParams);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    AuditInfo objAuditInfo = new AuditInfo();
                    objAuditInfo.FromStatus = dr["FromStatus"].ToString();
                    objAuditInfo.ToStatus = dr["ToStatus"].ToString();
                    objAuditInfo.ActionBy = dr["UserName"].ToString();
                    objAuditInfo.FromDate = dr["StartTime"].ToString();
                    objAuditInfo.ToDate = dr["EndTime"].ToString();
                    lstAuditInfo.Add(objAuditInfo);
                }

                return lstAuditInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public List<CategoryInfo> GetCategory(long EmailBoxId)
        {
            List<CategoryInfo> lstCategoryInfo = new List<CategoryInfo>();
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@Emailboxid", EmailBoxId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetCategorybyEmailboxid", hsParams);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    CategoryInfo objCategoryInfo = new CategoryInfo();
                    objCategoryInfo.CategoryId = Convert.ToInt32(dr["EmailboxCategoryId"]);
                    objCategoryInfo.CategoryDescription = dr["Category"].ToString();
                    lstCategoryInfo.Add(objCategoryInfo);
                }
                return lstCategoryInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public List<StatusTransitionInfo> GetStatusTransition(int SubProcessId, int UserRoleId)
        {
            List<StatusTransitionInfo> lstStatusTransitionInfo = new List<StatusTransitionInfo>();
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@SubProcessId", SubProcessId);
                hsParams.Add("@UserRoleId", UserRoleId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetStatusTransitionBySubProcessIdAndRoleId", hsParams);


                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    StatusTransitionInfo objStatusTransitionInfo = new StatusTransitionInfo();
                    objStatusTransitionInfo.SubProcessId = Convert.ToInt32(dr["SubProcessId"]);
                    objStatusTransitionInfo.UserRoleID = Convert.ToInt32(dr["UserRoleId"]);
                    objStatusTransitionInfo.FromStatusID = Convert.ToInt32(dr["FromStatusId"]);
                    objStatusTransitionInfo.FromStatus = Convert.ToString(dr["FromStatus"]);
                    objStatusTransitionInfo.ToStatusID = Convert.ToInt32(dr["ToStatusId"]);
                    objStatusTransitionInfo.ToStatus = Convert.ToString(dr["ToStatus"]);

                    lstStatusTransitionInfo.Add(objStatusTransitionInfo);
                }
                return lstStatusTransitionInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public SignatureInfo GetSignature(string UserId)
        {
            SignatureInfo objSignatureInfo = new SignatureInfo();
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@Userid", UserId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GET_SIGNATURE", hsParams);
                objSignatureInfo.SignatureID = Convert.ToInt32(ds.Tables[0].Rows[0]["SignID"]);
                objSignatureInfo.Signature = (ds.Tables[0].Rows[0]["Signature"]).ToString();
                objSignatureInfo.LastModifiedDate = (ds.Tables[0].Rows[0]["LastModifiedOn"].ToString());
                return objSignatureInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        public int DeleteDraft(long CaseId)
        {

            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@Caseid", CaseId);
                DBHelper db = new DBHelper();
                return db.DeleteData("USP_DeleteTotalDraft", hs);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

        public int UpdateCaseDetails(CaseInfo objCaseInfo, String ModifiedBy, DateTime ModifiedDate)
        {
            try
            {
                Hashtable hsCaseDetails = new Hashtable();
                hsCaseDetails.Add("@CASEID", objCaseInfo.CaseId);
                hsCaseDetails.Add("@STATUS", objCaseInfo.StatusId);
                hsCaseDetails.Add("@COMMENTS", objCaseInfo.Comments);
                hsCaseDetails.Add("@USERID", ModifiedBy);
                hsCaseDetails.Add("@STARTTIME", ModifiedDate);
                hsCaseDetails.Add("@Category", objCaseInfo.CategoryId);
                DBHelper db = new DBHelper();
                return db.UpdateData("USP_UpdateCaseDetails", hsCaseDetails);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public int InsertEmailConversation(ConversationInfo objConversationInfo, long CaseId)
        {
            try
            {
                Hashtable hsConversationDetails = new Hashtable();
                hsConversationDetails.Add("@Subject", objConversationInfo.Subject);
                hsConversationDetails.Add("@From_Add", objConversationInfo.EmailFrom);
                hsConversationDetails.Add("@Toaddress", objConversationInfo.EmailTo);
                hsConversationDetails.Add("@CCaddress", objConversationInfo.EmailCc);
                hsConversationDetails.Add("@BCCaddress", objConversationInfo.EmailBcc);
                hsConversationDetails.Add("@CaseId", CaseId);
                hsConversationDetails.Add("@AttachmentName", "");
                hsConversationDetails.Add("@ContentType", "text/html");
                hsConversationDetails.Add("@AttachmentData", HelperMethods.GetBytes(objConversationInfo.Content));
                hsConversationDetails.Add("@AttachmentType", 1);
                hsConversationDetails.Add("@ConversationDate", objConversationInfo.CreatedDate);
                hsConversationDetails.Add("@CreatedBy", objConversationInfo.CreatedBy);
                DBHelper db = new DBHelper();
                return Convert.ToInt32(db.SelectSingleValue("USP_Insert_Mail_Conversation", hsConversationDetails));
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public void InsertAttachments(List<AttachmentInfo> lstAttachments, long ConversationId, String UserId)
        {
            try
            {
                DBHelper db = new DBHelper();
                foreach (AttachmentInfo at in lstAttachments)
                {
                    DbCommand attachcommand = db.Db.GetStoredProcCommand("USP_Insert_Mail_Attachment");
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentName", at.FileName));
                    attachcommand.Parameters.Add(new SqlParameter("ContentType", at.ContentType));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentData", at.FileContent));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentType", at.AttachmentTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("ConversationId", ConversationId));
                    attachcommand.Parameters.Add(new SqlParameter("CreatedBy", UserId));
                    db.Db.ExecuteNonQuery(attachcommand);
                    attachcommand = null;
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public int UpdateForwardToGMB(long CaseId, bool ForwardToGMB)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@CASEID", CaseId);
            hsCaseDetails.Add("@ForwardToGMB", ForwardToGMB);
            DBHelper db = new DBHelper();
            return db.UpdateData("USP_UpdateForwardToGMB", hsCaseDetails);
        }

        public List<Int64> GetAllChildCaseIds(long CaseId)
        {
            List<Int64> lstChildCases = new List<long>();
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@ParentCaseId", CaseId);
            DBHelper db = new DBHelper();
            DataSet ds = db.SelectDataSet("USP_GetAllChildCaseDetails", hsCaseDetails);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    lstChildCases.Add(Convert.ToInt64(dr["CaseId"]));
                }
            }
            return lstChildCases;
        }

        public MailBoxInfo GetEmailBoxDetails(int EMailBoxId)
        {
            MailBoxInfo objMailBoxInfo = new MailBoxInfo();
            try
            {

                Hashtable hsParams = new Hashtable();
                hsParams.Add("@EMailBoxId", EMailBoxId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetEmailBoxDetails", hsParams);
                objMailBoxInfo.EMailId = ds.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                objMailBoxInfo.LoginEMailId = ds.Tables[0].Rows[0]["LOGINEMAILID"].ToString();
                objMailBoxInfo.Password = ds.Tables[0].Rows[0]["PASSWORD"].ToString();
                objMailBoxInfo.IsLocked = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISLOCKED"]);
                objMailBoxInfo.ServiceExchangeUrl = ds.Tables[0].Rows[0]["EMAILFOLDERPATH"].ToString();

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return objMailBoxInfo;
        }

        public ConversationInfo GetConversationDetails(long ConversationId)
        {
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@ConversationId", ConversationId);
                DBHelper db = new DBHelper();
                DataSet ds = db.SelectDataSet("USP_GetConversationByConversationId", hsParams);
                DataRow dr = ds.Tables[0].Rows[0];
                ConversationInfo objConversationInfo = new ConversationInfo();
                objConversationInfo.Id = Convert.ToInt32(dr["CONVERSATIONID"]);
                objConversationInfo.EmailDate = (dr["ConversationDate"]).ToString();
                objConversationInfo.EmailFrom = dr["EMAILFROM"].ToString();
                objConversationInfo.EmailTo = dr["EMailTo"].ToString();
                objConversationInfo.EmailCc = dr["EMailCc"].ToString();
                objConversationInfo.EmailBcc = dr["EMailBcc"].ToString();
                objConversationInfo.Subject = dr["Subject"].ToString();
                objConversationInfo.Content = enc.GetString((byte[])dr["Content"]);
                objConversationInfo.ConversationType = dr["AttachmentType"].ToString();
                objConversationInfo.CreatedDate = dr["CREATEDDATE"].ToString();
                return objConversationInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public List<ControlValues> GetControlValuesForBinding(int FieldMasterID)
        {
            List<ControlValues> lstControlValues = new List<ControlValues>();
            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@FieldMasterId", FieldMasterID);
                DBHelper db = new DBHelper();
                DataSet dsControlValues = db.SelectDataSet("USP_GETDynamicDropDownValues", hs);
                if (dsControlValues.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in dsControlValues.Tables[0].Rows)
                    {
                        ControlValues objControlValues = new ControlValues();
                        objControlValues.optionText = Convert.ToString(dr["OptionText"]);
                        objControlValues.optionValue = Convert.ToString(dr["OptionValue"]);
                        lstControlValues.Add(objControlValues);
                    }
                }
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return lstControlValues;
        }

        public List<DynamicFieldsInfo> GetDynamicFieldsInfo(long CaseId)
        {
            try
            {
                Hashtable hsParams = new Hashtable();
                hsParams.Add("@CaseID", CaseId);
                DBHelper db = new DBHelper();
                DataSet dsDynamicFields = db.SelectDataSet("USP_GetDynamicControlstoDataEntry", hsParams);
                List<DynamicFieldsInfo> lstDynamicFieldsInfo = new List<DynamicFieldsInfo>();
                if (dsDynamicFields.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in dsDynamicFields.Tables[0].Rows)
                    {
                        DynamicFieldsInfo objDynamicFieldsInfo = new DynamicFieldsInfo();

                        objDynamicFieldsInfo.FieldMasterID = Convert.ToInt32(dr["FieldMasterID"]);
                        objDynamicFieldsInfo.FieldValue = dr["value"].ToString();
                        objDynamicFieldsInfo.DynamicFieldID = dr["DynamicFieldMaster_ID"].ToString();
                        objDynamicFieldsInfo.FieldName = dr["FieldName"].ToString();
                        objDynamicFieldsInfo.FieldType = dr["FieldType"].ToString();
                        objDynamicFieldsInfo.TextLength = dr["TextLength"].ToString();
                        objDynamicFieldsInfo.FieldValidationType = dr["ValidationType"].ToString();
                        objDynamicFieldsInfo.FieldPrevilegeName = dr["FieldPrivilegeName"].ToString();
                        objDynamicFieldsInfo.FieldAliasName = dr["FieldAliasName"].ToString();

                        lstDynamicFieldsInfo.Add(objDynamicFieldsInfo);

                    }
                }
                return lstDynamicFieldsInfo;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }
    }
}
