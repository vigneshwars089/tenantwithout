﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class CaseHandlerDataAccess : CaseHandlerRepository
    {
        CaseHandler objCaseHandler = new CaseHandler();
        LoggingFactory objlog = new LoggingFactory();
        public override string SetTransRecordData(string action, string sb, int recordid, string viewname)
        {
            string SetTransRecord = string.Empty;

            try
            {
                SetTransRecord = objCaseHandler.SetTransRecordData(action, sb, recordid, viewname);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SetTransRecord;
        }

        public override string DeleteTransaction(Entities.TransRecordData objRecord)
        {
            string DelTransRecord = string.Empty;

            try
            {
                DelTransRecord = objCaseHandler.DeleteTransaction(objRecord);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return DelTransRecord;
        }

        public override System.Data.DataSet GetTransactionList(Entities.TransactionListView objBase)
        {
            DataSet GetTransactionRecord = new DataSet();

            try
            {
                GetTransactionRecord = objCaseHandler.GetTransactionList(objBase);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return GetTransactionRecord;
        }
    }
}
