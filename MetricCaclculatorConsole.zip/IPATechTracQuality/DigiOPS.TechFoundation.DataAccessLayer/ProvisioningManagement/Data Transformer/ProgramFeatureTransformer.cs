﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class ProgramFeatureTransformer
    {
        internal List<ProgramFeatureSetUp> MapToProgramFeatureList(DataTable dt)
        {
            List<ProgramFeatureSetUp> baseEntityList = new List<ProgramFeatureSetUp>();

            baseEntityList = (from p in dt.AsEnumerable()
                              select new ProgramFeatureSetUp
                              {
                                  ProgramFeatureSetUpId = Convert.ToInt32(p["iProgramFeaturesSetUpId"] == DBNull.Value ? 0 : p["iProgramFeaturesSetUpId"]),
                                  ProgramId = Convert.ToInt16(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  IsSupervisorAuditApplicable = Convert.ToBoolean(p["bIsSupervisorAuditApplicable"] == DBNull.Value ? false : p["bIsSupervisorAuditApplicable"]),
                                  AuditLogicId = Convert.ToString(p["szAuditingLogic"] == DBNull.Value ? string.Empty : p["szAuditingLogic"]),
                                  ScoringLogicId = Convert.ToString(p["szScoringLogic"] == DBNull.Value ? string.Empty : p["szScoringLogic"]),
                                  IsEmployeeApplicable = Convert.ToBoolean(p["bIsEmployeeApplicable"] == DBNull.Value ? false : p["bIsEmployeeApplicable"]),
                                  IsLinesApplicable = Convert.ToBoolean(p["bIsLineApplicable"] == DBNull.Value ? false : p["bIsLineApplicable"]),
                                  IsDataEntryByAuditorEnable = Convert.ToBoolean(p["bIsEnableDataEntryByAuditor"] == DBNull.Value ? false : p["bIsEnableDataEntryByAuditor"]),
                                  IsPeerToPeerAuditInfoEnable = Convert.ToBoolean(p["bIsEnablePeerToPeerAuditInfo"] == DBNull.Value ? false : p["bIsEnablePeerToPeerAuditInfo"]),
                                  NoOfElement = Convert.ToInt32(p["iNoOfElement"] == DBNull.Value ? 0 : p["iNoOfElement"]),
                                  SystemEffectId = Convert.ToString(p["szSystemEffects"] == DBNull.Value ? string.Empty : p["szSystemEffects"]),
                                  IsDefaultRating = Convert.ToBoolean(p["bIsDefaultRating"] == DBNull.Value ? false : p["bIsDefaultRating"]),
                                  IsStratifiedSampling = Convert.ToBoolean(p["bIsStratifiedSamplingRequired"] == DBNull.Value ? false : p["bIsStratifiedSamplingRequired"]),
                                  IsSamplingFrozen = Convert.ToBoolean(p["bIsFreezingOfSamples"] == DBNull.Value ? false : p["bIsFreezingOfSamples"]),
                                  IsFatalErrorApplicable = Convert.ToBoolean(p["bIsFatalErrorApplicable"] == DBNull.Value ? 0 : p["bIsFatalErrorApplicable"]),
                                  IsCriticalityApplicable = Convert.ToBoolean(p["bIsDOCriticality"] == DBNull.Value ? 0 : p["bIsDOCriticality"]),
                                  IsDaylimitforcorrectionApplicable = Convert.ToBoolean(p["bIsDayNeedforCorrection"] == DBNull.Value ? 0 : p["bIsDayNeedforCorrection"]),
                                  IsSLAActivityApplicable = Convert.ToBoolean(p["bIsSLAActivityApplicable"] == DBNull.Value ? 0 : p["bIsSLAActivityApplicable"]),
                                  IsTotalVolumeApplicable = Convert.ToBoolean(p["bIsTotalVolumeApplicable"] == DBNull.Value ? 0 : p["bIsTotalVolumeApplicable"]),
                                  IsFeedbackMailTriggerApplicable = Convert.ToBoolean(p["bIsMailTriggerRequired"] == DBNull.Value ? false : p["bIsMailTriggerRequired"]),
                                  IsReworkRemainderMailTgrApplicable = Convert.ToBoolean(p["bIsReworkRemainderMailRequired"] == DBNull.Value ? false : p["bIsReworkRemainderMailRequired"]),
                                  MaxNoOfRemainder = Convert.ToInt32(p["iMaxRemainderCnt"] == DBNull.Value ? 0 : p["iMaxRemainderCnt"]),
                                  MailFrequency = Convert.ToInt32(p["iMailSchedulerFrequency"] == DBNull.Value ? 0 : p["iMailSchedulerFrequency"]),
                                  MailBoxName = Convert.ToString(p["szMailboxName"] == DBNull.Value ? string.Empty : p["szMailboxName"]),
                                  AuditTypes = Convert.ToString(p["szAuditTypes"] == DBNull.Value ? string.Empty : p["szAuditTypes"]),
                                  IsExternalSamplingFrozen = Convert.ToBoolean(p["bIsFreezingOfExternalSamples"] == DBNull.Value ? false : p["bIsFreezingOfExternalSamples"]),
                                  MaxCorrectionCnt = Convert.ToInt32(p["iMaxCorrectionCnt"] == DBNull.Value ? 0 : p["iMaxCorrectionCnt"]),
                                  MaxCorrectionDaysCnt = Convert.ToInt32(p["iMaxCorrectionDayCnt"] == DBNull.Value ? 0 : p["iMaxCorrectionDayCnt"]),
                                  IsMetricsRequired = Convert.ToBoolean(p["bIsMetricsRequired"] == DBNull.Value ? false : p["bIsMetricsRequired"]),
                                  IsTATApplicable = Convert.ToBoolean(p["bIsTATEnable"] == DBNull.Value ? false : p["bIsTATEnable"]),
                                  IsCombinedAccuracyNeeded = Convert.ToBoolean(p["bIsCombinedAccuracy"] == DBNull.Value ? false : p["bIsCombinedAccuracy"]),
                                  IsWorkFlowNeedforCorrection = Convert.ToBoolean(p["bIsWorkFlowNeedforCorrection"] == DBNull.Value ? false : p["bIsWorkFlowNeedforCorrection"]),
                                  createdBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? "0" : p["iCreatedBy"]).ToString(),
                                  createdDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? null : p["dsCreatedDate"]).ToString(),
                                  modifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? "0" : p["iModifiedBy"]).ToString(),
                                  modifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? null : p["dsModifiedDate"]).ToString(),
                                  IsEditAllowed = Convert.ToBoolean(p["bIsEditAllowed"] == DBNull.Value ? 0 : p["bIsEditAllowed"]),

                                  IsDeletMailEnableTriggerApplicable = Convert.ToBoolean(p["bIsDeletMailEnable"] == DBNull.Value ? false : p["bIsDeletMailEnable"]),
                                  DateFormat = Convert.ToString(p["szDateFormat"] == DBNull.Value ? string.Empty : p["szDateFormat"]),
                                  IntAllocCnt = Convert.ToInt32(p["iIntAllocCnt"] == DBNull.Value ? 0 : p["iIntAllocCnt"]),
                                  ExtAllocCnt = Convert.ToInt32(p["iExtAllocCnt"] == DBNull.Value ? 0 : p["iExtAllocCnt"]),
                                  BusiAllocCnt = Convert.ToInt32(p["iBusiAllocCnt"] == DBNull.Value ? 0 : p["iBusiAllocCnt"]),
                                  sSamplingMethodforInternal = Convert.ToString(p["szSamplingMethodInternal"] == DBNull.Value ? string.Empty : p["szSamplingMethodInternal"]),
                                  sSamplingMethodforBusiness = Convert.ToString(p["szSamplingMethodBusiness"] == DBNull.Value ? string.Empty : p["szSamplingMethodBusiness"]),
                                  StaticFields = Convert.ToString(p["szStaticFields"] == DBNull.Value ? string.Empty : p["szStaticFields"]),
                                  AHTApplicability = Convert.ToBoolean(p["blsAHTEnable"] == DBNull.Value ? false : p["blsAHTEnable"]),
                                  CTQComments = Convert.ToBoolean(p["blsCTQComments"] == DBNull.Value ? false : p["blsCTQComments"]),
                                  //Added for Rating Difference Mail Trigger
                                  IsRatingDifferenceMailApplicable = Convert.ToBoolean(p["bIsRatingDifferenceMailEnable"] == DBNull.Value ? false : p["bIsRatingDifferenceMailEnable"]),
                                  //Added for SLA changes
                                  IsSLABasedSubProcess = Convert.ToBoolean(p["IsSLABasedSubProcess"] == DBNull.Value ? false : p["IsSLABasedSubProcess"]),
                                  IsSamplingTypeCustommode = Convert.ToBoolean(p["bIsSamplingtypeCustomMode"] == DBNull.Value ? false : p["bIsSamplingtypeCustomMode"]),
                                  IsDataPurgingEnabled = Convert.ToBoolean(p["bIsDataPurgingEnabled"] == DBNull.Value ? false : p["bIsDataPurgingEnabled"]),
                                  IsTop5MailDataElementEnabled = Convert.ToBoolean(p["bIsTop5MailDataElement"] == DBNull.Value ? false : p["bIsTop5MailDataElement"]) 
                              }).ToList();
            return baseEntityList;

        }
    }
}
