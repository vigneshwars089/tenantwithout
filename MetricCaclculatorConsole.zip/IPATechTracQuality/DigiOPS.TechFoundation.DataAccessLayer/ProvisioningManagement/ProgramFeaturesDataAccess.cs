﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class ProgramFeaturesDataAccess
    {
        ProgramFeaturesDAO prodao = null;

        ProgramFeatureTransformer programtrans = new ProgramFeatureTransformer();

        public string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt)
        {
            prodao = new ProgramFeaturesDAO(programEnt.AppID, programEnt.TenantID);
            string createRecVal = string.Empty;
            createRecVal = prodao.SetProgramFeatures(programEnt);
            return createRecVal;
        }
        public List<ProgramFeatureSetUp> GetProgramFeatures(int programId,string AppID,int TenantID)
        {
            prodao = new ProgramFeaturesDAO(AppID, TenantID);
            List<ProgramFeatureSetUp> listprog = new List<ProgramFeatureSetUp>();
            DataTable dt = new DataTable();
            dt = prodao.GetProgramFeatures(programId);
            if (dt.Rows.Count <= 0)
                return listprog;
            else
            {
                listprog = programtrans.MapToProgramFeatureList(dt);
            }
            return listprog;
        }
    }
}
