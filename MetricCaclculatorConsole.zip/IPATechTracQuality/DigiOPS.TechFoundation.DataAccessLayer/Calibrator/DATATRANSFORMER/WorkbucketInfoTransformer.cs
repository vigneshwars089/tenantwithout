﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
using DigiOPS.TechFoundation.DataAccessLayer.Calibration;

namespace DigiOPS.TechFoundation.DataAccessLayer.Calibrator.DATATRANSFORMER
{
    public class WorkbucketInfoTransformer
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        public List<AuditTransactionListViewModal> MapToAuditTransactionList(DataSet ds)
        {
            //proxyLogger.Log.Info(" Transaction List to Entity List - Calling.");
            objloginfo.Message = ("Transaction List to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            List<AuditTransactionListViewModal> baseEntityList = new List<AuditTransactionListViewModal>();
            AuditTransactionListViewModalList transactionList = new AuditTransactionListViewModalList();

            int columncnt = ds.Tables[0].Columns.Count;
            bool flag = false;
            int i;
            AuditTransactionListViewModal transaction;
            string type = "";
            foreach (DataRow dr in (ds.Tables[0].Rows))
            {
                i = 0;
                transaction = new AuditTransactionListViewModal();
                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    type = (dc.DataType).FullName;

                    if (dc.ColumnName == "TotalRows")
                    {
                        if (!flag)
                        {
                            transaction.TotalRows = Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i]);
                            flag = true;
                        }
                    }
                    else
                    {
                        switch (type)
                        {
                            case "System.Int32":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.Int64":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt64(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.Int16":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt16(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            case "System.String":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
                                break;
                            case "System.Boolean":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? "No" : (dr[i].ToString() == "true" ? "Yes" : "No"))));
                                break;
                            case "System.Object":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
                                break;
                            case "System.DateTime":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTime.Parse(dr[i].ToString()).ToString())));
                                break;
                            case "System.smalldatetime":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTime.Parse(dr[i].ToString()).ToString())));
                                break;
                            case "System.DateTimeOffset":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTimeOffset.Parse(dr[i].ToString()).DateTime.ToString())));
                                break;
                            case "System.Bit":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToBoolean(dr[i] == DBNull.Value ? "No" : (dr[i].ToString() == "true" ? "Yes" : "No"))));
                                break;
                            case "System.Decimal":
                                transaction.AuditTransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToDecimal(dr[i] == DBNull.Value ? 0 : dr[i])));
                                break;
                            default:
                                //proxyLogger.Log.Info("Unable to map the datatype (" + type + ") to list in Quart.BusinessObjects.Mapper.TransactionCreationMapper.MapToAuditTransactionList.");
                                objloginfo.Message = ("Unable to map the datatype (" + type + ") to list in Quart.BusinessObjects.Mapper.TransactionCreationMapper.MapToAuditTransactionList.");
                                objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                                break;
                        }
                    }
                    i = i + 1;
                }
                transactionList.AuditTransactionListViewModals.Add(transaction);
            }
            baseEntityList = transactionList.AuditTransactionListViewModals.Cast<AuditTransactionListViewModal>().ToList();
            //proxyLogger.Log.Info(" Transaction List to Entity List - Called.");
            objloginfo.Message = ("Transaction List to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            return baseEntityList;
        }
    }
}
