﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
using DigiOPS.TechFoundation.DataAccessLayer.Calibration;
using DigiOPS.TechFoundation.DataAccessLayer.Calibrator.DATATRANSFORMER;



namespace DigiOPS.TechFoundation.DataAccessLayer.Calibrator
{
    public class WorkbucketDataAccess
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        WorkBucketDAO wadao = new WorkBucketDAO();
        List<AuditTransactionListViewModal> baseList = null;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        WorkbucketInfoTransformer wbit = new WorkbucketInfoTransformer();

        public List<AuditTransactionListViewModal> GetAuditList(AuditTransactionListViewModal objBase)
        {
            AuditTransactionListViewModal objAuditTrans = (AuditTransactionListViewModal)objBase;
            if ((objAuditTrans.ProcessedDate != null && objAuditTrans.ProcessingToDate != null) || objAuditTrans.Value != null)
            {
                ds = wadao.GetAuditTransactionList(objAuditTrans);
                if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
                {
                    if (ds.Tables[0].Rows.Count <= 0)
                        return baseList;
                    baseList = wbit.MapToAuditTransactionList(ds);
                }
            }
            //else
            //{
            //    dt = wadao.GetAuditTransElementConfigList(objAuditTrans);
            //    if (dt.Rows.Count <= 0)
            //        return baseList;
            //    baseList = mapAuditTransList.MapToDropDownList(dt);
            //}
            return baseList;
        }

    }
}
