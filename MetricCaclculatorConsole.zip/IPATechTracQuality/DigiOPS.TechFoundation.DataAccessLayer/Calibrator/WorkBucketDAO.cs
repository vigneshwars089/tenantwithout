﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
using System.Collections;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class WorkBucketDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public DataSet GetAuditTransactionList(AuditTransactionListViewModal objBase)
        {
            //proxyLogger.Log.Info("GetAuditTransactionList - Called.");
            objloginfo.Message = ("GetAuditTransactionList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                DataSet ds = new DataSet();
                DataTable resultdt = new DataTable();
                AuditTransactionListViewModal objList = new AuditTransactionListViewModal();
                objList = (AuditTransactionListViewModal)objBase;
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                SqlCommand command = null;
                string spname = string.Empty;
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"].ToString();
                //    XElement Parent = new XElement("root");
                //    XElement root = new XElement("xmlArguments");

                //    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                //        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT;

                //    sqlConnection.Open();
                    //change made for GCS CR II -Final Audit Update
                    if (objBase.AuditTypeId != 8)
                    {
                        spname = "USP_GET_AUDITTRANSACTIONLIST";
                    }
                    else
                    {
                        spname = "USP_GET_AUDITTRANSACTIONLIST_FinalAuditUpdate";
                    }
                    //End of Change
                    //command.CommandType = CommandType.StoredProcedure;
                    //command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);

                    root.Add(new XAttribute("iSubProcessId", Convert.ToString(objBase.SubProcessId)));
                    root.Add(new XAttribute("StartRowIndex", Convert.ToString(objBase.StartRowIndex)));
                    root.Add(new XAttribute("MaximumRows", Convert.ToString(objBase.MaximumRows)));
                    root.Add(new XAttribute("SortOrder", Convert.ToString(objBase.SortOrder)));
                    root.Add(new XAttribute("SortColumn", Convert.ToString(objBase.SortColumn)));

                    if (objBase.ElementName != null && objBase.ElementName.Length > 0)
                        root.Add(new XAttribute("ElementName", Convert.ToString(objBase.ElementName)));
                    if (objBase.Value != null & objBase.Value.Length > 0)
                        root.Add(new XAttribute("Value", Convert.ToString(objBase.Value)));

                    root.Add(new XAttribute("UserID", Convert.ToString(objBase.UserId)));
                    root.Add(new XAttribute("AuditType", Convert.ToString(objBase.AuditTypeId)));

                    Parent.Add(root);

                    if (objBase.ProcessedDate != null)
                        command.Parameters.Add("@processedDate", SqlDbType.VarChar).Value = objBase.ProcessedDate.Value.ToString("yyyy-MM-dd");
                    if (objBase.ProcessingToDate != null)
                        command.Parameters.Add("@processedToDate", SqlDbType.VarChar).Value = objBase.ProcessingToDate.Value.ToString("yyyy-MM-dd");

                    //command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);


                    Hashtable hs = new Hashtable();
                    if (objBase.ProcessedDate != null)
                    hs.Add("@processedDate", objBase.ProcessedDate.Value.ToString("yyyy-MM-dd"));
                    if (objBase.ProcessingToDate != null)
                    hs.Add("@processedToDate", objBase.ProcessingToDate.Value.ToString("yyyy-MM-dd"));
                    hs.Add("@ExcelData", Convert.ToString(Parent));
                    DBHelper db = new DBHelper();
                    ds = db.SelectDataSet(spname, hs); 

                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(ds);
                //}
                return ds;
            }
            catch (InvalidOperationException Ex)
            {
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            catch (SqlException Ex)
            {
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            catch (ArgumentException Ex)
            {
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            catch (FormatException Ex)
            {
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            catch (OverflowException Ex)
            {
                // proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            //catch (QuartException Ex)
            //{
            //    //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            //    objlog.GetLoggingHandler("Log4net").LogException(Ex);
            //    throw;
            //}
        }
    }
}
