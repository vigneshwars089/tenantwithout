﻿using System;
using System.Text;
using System.Collections.Generic;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Data;
using System.Xml;
using System.Collections;
using System.IO;
using System.Configuration;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using DigiOPS.TechFoundation.Sampling;

namespace DigiOPS.TechFoundation.ComponentUnitTest.sampling
{
    /// <summary>
    /// Summary description for SamplingUnitTest
    /// </summary>
    [TestClass]
    public class SamplingUnitTest
    {
        //public SamplingUnitTest()
        //{
        //    //
        //    // TODO: Add constructor logic here
        //    //
        //}

        //private TestContext testContextInstance;

        ///// <summary>
        /////Gets or sets the test context which provides
        /////information about and functionality for the current test run.
        /////</summary>
        //public TestContext TestContext
        //{
        //    get
        //    {
        //        return testContextInstance;
        //    }
        //    set
        //    {
        //        testContextInstance = value;
        //    }
        //}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion
        [TestMethod]
        public void RandomDailySub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 11007;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11008;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11009;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11010;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 11011;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11012;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11013;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(6, count);
        }
        [TestMethod]
        public void RandomDaily_Procr_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 11028;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11029;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11030;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11031;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 11032;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11033;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11034;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(5, count);
        }
        [TestMethod]
        public void RandomDaily_Procr_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 11035;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11036;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11037;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11038;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 11039;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 11040;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 11041;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("Processor", "Monthly", "Random", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(5, count);
        }
        [TestMethod]
        public void RandomMonthly_Sub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 2021;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2022;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2023;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2024;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 2025;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2026;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2027;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Monthly", "Random", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(6, count);
        }

        [TestMethod]
        public void stratifiedMonthly_Sub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 2028;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2029;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2030;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2031;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 2032;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2033;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2034;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Monthly", "Stratified", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(3, count);
        }
        [TestMethod]
        public void stratifiedDaily_Sub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 2035;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2036;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2037;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2038;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 2039;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2040;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2041;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Stratified", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(3, count);
        }
        //[TestMethod]
        ////from 70
        //public void stratifiedDaily_Processor_PositiveTest()
        //{
        //    SamplingFactory objSamplingFactory = new SamplingFactory();
        //    TransactionListDetails tld = new TransactionListDetails();
        //    List<TransactionLists> tldlst = new List<TransactionLists>();
        //    List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
        //    List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
        //    TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

        //    talR.Allocated = 0;
        //    talR.Percentage = 75.0;
        //    talR.ProcessedBy = 288220;
        //    tal.Add(talR);

        //    talR = new TransactionsAllocatedLists();
        //    //tld.Allocated = 0;
        //    //tld.Total = 8;
        //    talR.Allocated = 0;
        //    talR.Percentage = 50.0;
        //    talR.ProcessedBy = 188598;
        //    tal.Add(talR);

        //    //List<TransactionLists> tldlst = new List<TransactionLists>();
        //    TransactionLists objlist = new TransactionLists();
        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2070;
        //    objlist.ProcessedBy = 188598;
        //    objlist.DataValue = "14";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 51;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2071;
        //    objlist.DataValue = "20";
        //    objlist.ProcessedBy = 188598;
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);


        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2072;
        //    objlist.ProcessedBy = 188598;
        //    objlist.DataValue = "50";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 51;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2073;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "60";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);
        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2074;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "70";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2075;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "10";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);


        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2076;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "30";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);
        //    tld.TransactionLists = tldlst;
        //    tld.TransactionAllocatedLists = tal;
        //    tld.MinValue = 20;
        //    tld.MaxValue = 60;
        //    tld.IsStoreInDB = true;


        //    tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Stratified", tld);
        //    tldlst = tld.TransactionLists;
        //    int count = tldlst.Count;
        //    Assert.AreEqual(3, count);
        //}
        //[TestMethod]
        //public void stratifiedMonthly_Processor_PositiveTest()
        //{
        //    SamplingFactory objSamplingFactory = new SamplingFactory();
        //    TransactionListDetails tld = new TransactionListDetails();
        //    List<TransactionLists> tldlst = new List<TransactionLists>();
        //    List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
        //    List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
        //    TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

        //    talR.Allocated = 0;
        //    talR.Percentage = 75.0;
        //    talR.ProcessedBy = 288220;
        //    tal.Add(talR);

        //    talR = new TransactionsAllocatedLists();
        //    //tld.Allocated = 0;
        //    //tld.Total = 8;
        //    talR.Allocated = 0;
        //    talR.Percentage = 50.0;
        //    talR.ProcessedBy = 188598;
        //    tal.Add(talR);

        //    //List<TransactionLists> tldlst = new List<TransactionLists>();
        //    TransactionLists objlist = new TransactionLists();
        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2077;
        //    objlist.ProcessedBy = 188598;
        //    objlist.DataValue = "14";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 51;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2078;
        //    objlist.DataValue = "20";
        //    objlist.ProcessedBy = 188598;
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);


        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2079;
        //    objlist.ProcessedBy = 188598;
        //    objlist.DataValue = "50";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 51;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2080;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "60";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);
        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2081;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "70";
        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);

        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2082;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "10";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);


        //    objlist = new TransactionLists();
        //    objlist.RecordID = 2083;
        //    objlist.ProcessedBy = 288220;
        //    objlist.DataValue = "30";

        //    //Required only, if stratified sampling
        //    // objlist.DataValue = 50;
        //    tldlst.Add(objlist);
        //    tld.TransactionLists = tldlst;
        //    tld.TransactionAllocatedLists = tal;
        //    tld.MinValue = 20;
        //    tld.MaxValue = 60;
        //    tld.IsStoreInDB = true;


        //    tld = objSamplingFactory.GetSampingDetails("Processor", "Monthly", "Stratified", tld);
        //    tldlst = tld.TransactionLists;
        //    int count = tldlst.Count;
        //    Assert.AreEqual(3, count);
        //}
        //// till 83

        [TestMethod]
        public void StatisticalDaily_Sub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 200092;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200093;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 200094;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200095;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 200096;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200097;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 200098;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Statistical", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(6, count);
        }
        [TestMethod]
        public void StatisticalDaily_Procr_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 200099;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200100;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 200101;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200102;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 200103;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 200104;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 200105;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Statistical", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(5, count);
        }
        [TestMethod]
        public void StatisticalMonthly_Procr_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 288228;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288229;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 288230;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288231;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 288232;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288233;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 288234;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("Processor", "Monthly", "Statistical", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(5, count);
        }
        [TestMethod]
        public void StatisticalMonthly_Sub_PositiveTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 288235;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288236;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 288237;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288238;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 288239;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 288240;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 288241;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;


            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Monthly", "Statistical", tld);
            tldlst = tld.TransactionLists;
            int count = tldlst.Count;
            Assert.AreEqual(6, count);
        }
        //till 69

        [TestMethod]
        public void ActorDurationTypeWrongParameters_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 2084;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2085;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2086;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2087;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 2088;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2089;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2090;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("SubProcess1", "Dailis", "Random1", tld);
            tldlst = tld.TransactionLists;

            int count = tldlst.Count;
            Assert.AreEqual(0, count);

            Assert.AreEqual("Input's are not in the standard format", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void DBParametersNotSpecified_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 2091;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2092;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2093;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2094;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 2095;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 2096;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 2097;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void ObjTransListNotprovided_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            //  tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Transaction List Or Transaction Allocated List object is null", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void ObjTransAllocatedListNotprovided_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Transaction List Or Transaction Allocated List object is null", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void PercentageNotProvided_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            //talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            //   talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Percentage is not provided in the Transaction Allocated Lists", tld.ErrorMessage.ToString());
        }

        [TestMethod]
        public void ProcessedByNotProvidedTransaction_Lists_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 0;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = -1;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 0;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("ProcessedBy is not provided in the Transaction Lists", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void ProcessedByNotProvidedTransaction_Allocated_Lists_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = -1;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 188598;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 0;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = -1;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 0;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            //  tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("ProcessedBy is not provided in the Transaction Allocated Lists", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void RecordIdNotCorrect_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 1;
            objlist.ProcessedBy = 2;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            //objlist.RecordID = 802;
            objlist.ProcessedBy = 0;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 0;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Record ID is not provided in the Transaction Lists", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void ProcessorGivenInTransListAndAllocatedListWillNotTally_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 20089;
            objlist.ProcessedBy = 2;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 20090;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 20091;
            objlist.ProcessedBy = 0;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 20092;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 20093;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 20094;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 20095;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(3, count);
            //   Assert.AreEqual("{ProcessedBy is not provided in the Transaction Allocated Lists}", tld.ErrorMessage);
        }

        [TestMethod]
        public void DuplicateTransactionsEntered_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 1;
            objlist.ProcessedBy = 2;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 15;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 91;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Random", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Duplication Transactions Entered", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void DataValueNeededforStratified_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 1;
            objlist.ProcessedBy = 2;
            //objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;

            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "0";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 89;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "10";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Stratified", tld);
            tldlst = tld.TransactionLists;


            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Data Value is Needed in the Transaction Lists, if Type is Stratified", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void AllocatedNotProvided_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = -1;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 1;
            objlist.ProcessedBy = 2;
            //objlist.DataValue = "14";
            //Required only, if stratified sampling
            objlist.DataValue = "51";
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "56";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 78;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "89";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Stratified", tld);
            tldlst = tld.TransactionLists;

            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Allocated is not provided in the Transaction Allocated Lists", tld.ErrorMessage.ToString());
        }
        [TestMethod]
        public void MinMaxValuesNotProvided_NegativeTest()
        {
            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 75.0;
            talR.ProcessedBy = 2;
            tal.Add(talR);

            talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            //talR.Allocated = 0;
            talR.Percentage = 50.0;
            talR.ProcessedBy = 1;
            tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 1;
            objlist.ProcessedBy = 2;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "30";
            objlist.ProcessedBy = 2;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 0;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 1;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 78;
            objlist.ProcessedBy = 9;
            objlist.DataValue = "70";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 6;
            objlist.DataValue = "60";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 4;
            objlist.DataValue = "30";

            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            tld.TransactionLists = tldlst;
            //tld.TransactionLists = null;
            tld.TransactionAllocatedLists = tal;
            //tld.MinValue = 20;
            //tld.MaxValue = 60;
            tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Daily", "Stratified", tld);
            tldlst = tld.TransactionLists;

            int count = tldlst.Count;
            Assert.AreEqual(0, count);
            Assert.AreEqual("Min and Max Value is Needed, if Type is Stratified", tld.ErrorMessage.ToString());
        }
        }
    }

