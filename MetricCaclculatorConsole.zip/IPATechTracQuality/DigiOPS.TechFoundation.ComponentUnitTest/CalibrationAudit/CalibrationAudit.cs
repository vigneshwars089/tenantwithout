﻿using System;
using System.Text;
using System.Collections.Generic;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Data;
using System.Xml;
using System.Collections;
using System.IO;
using System.Configuration;
using DigiOPS.TechFoundation.Calibration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.ComponentUnitTest.CalibrationAudit
{
    /// <summary>
    /// Summary description for CalibrationAudit
    /// </summary>
    [TestClass]
    public class CalibrationAudit
    {
        //public CalibrationAudit()
        //{
        //    //
        //    // TODO: Add constructor logic here
        //    //
        //}

        //private TestContext testContextInstance;

        ///// <summary>
        /////Gets or sets the test context which provides
        /////information about and functionality for the current test run.
        /////</summary>
        //public TestContext TestContext
        //{
        //    get
        //    {
        //        return testContextInstance;
        //    }
        //    set
        //    {
        //        testContextInstance = value;
        //    }
        //}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void CalibrationValidation_PositivetTest() 
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "CONFIGURED";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 0;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 0;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Critical";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 1;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreEqual(0, output.QualityScore);
            //Assert.AreEqual("Internal Rating ID / External Rating ID / Criticality Type is not provided", output.ErrorMessage.ToString());

        }

        [TestMethod]
        public void CalibrationValidation_NegativeTestNull()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = null;

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 70;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 70;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Critical";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 0;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Calibration Type is Not Provided.", output.ErrorMessage.ToString());

            
        }


        [TestMethod]
        public void CalibrationValidation_NegativeTest()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "CONFIGURED";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 0;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 0;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Critical";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 1;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Internal Rating ID / External Rating ID / Criticality Type is not provided", output.ErrorMessage.ToString());


        }

        [TestMethod]
        public void CalibrationValidation_NegativeTestcalibrationtype()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "Test";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 70;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 70;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Critical";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 0;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Calibration Type is not in the Standard Format.", output.ErrorMessage.ToString());
        }

        [TestMethod]
        public void CalibrationValidation_NegativeTestCombinedAccuracy()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "CONFIGURED";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 70;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 70;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Critical";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 0;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            //ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Combined Accuracy List is Not Provided", output.ErrorMessage.ToString());
        }


        [TestMethod]
        public void CalibrationValidation_NegativeTestcriticalitytype()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "CONFIGURED";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 70;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 70;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Test";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 0;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(ad);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Criticality Type is not in the standard format", output.ErrorMessage.ToString());
        }

        [TestMethod]
        public void CalibrationValidation_NegativeTestNullentity()
        {
            CalibrationScoreInfo ad = new CalibrationScoreInfo();

            //ad._SubCategoryID = "1";
            ad._strAuditlogic = "WDPO";
            ad._strScoringLogic = "CHECKPOINT BASED";
            ad._IsCriticalApp = "False";
            ad._calibrationType = "CONFIGURED";

            List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
            ade.DOId = 458;
            ade.DOGroupID = 603;
            ade.ParentDOId = 457;
            ade.SelectedRatingId = 70;
            lstIn.Add(ade);
            ad.IntAuditedList = lstIn;


            List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
            adEx.DOId = 458;
            adEx.DOGroupID = 603;
            adEx.ParentDOId = 457;
            adEx.SelectedRatingId = 71;
            lstEx.Add(adEx);
            ad.ExtAuditedList = lstEx;

            List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
            CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
            adComb.DOGroupID = 603;
            adComb.InternalRatingId = 70;
            adComb.ExternalRatingId = 71;
            adComb.CombinedRatingId = 71;
            adComb.CriticalityType = "Test";
            adComb.DefectNA = false;
            //adComb.ActualWeightage = 1;
            adComb.CalculatedGroupWeightage = 0;
            //adComb.CalulatedWeightage = 1;
            adComb.GivenWeightage = 0;
            adComb.GroupWeightage = 0;
            //adComb.iLine = 0;
            adComb.MaxWeightage = 1;
            lstComb.Add(adComb);
            ad.CombinedAccuracyList = lstComb;

            ScoringOutput output = new ScoringOutput();
            CalibrationScoreInfo csi = new CalibrationScoreInfo();

            ICalibrationFactory cal = new CalibrationFactory();
            ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
            output = CalAg.CalibrationValidation(null);
            Assert.AreNotEqual(100, output.QualityScore);
            Assert.AreEqual("Parameters cannot be null", output.ErrorMessage.ToString());
        }
    }
}
