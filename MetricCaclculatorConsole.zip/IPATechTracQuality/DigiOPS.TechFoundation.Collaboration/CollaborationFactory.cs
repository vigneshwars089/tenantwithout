﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Collaboration
{
    public class CollaborationFactory: ICollaborationFactory
    {
        public ICollaboration GetCollaborationHandler(string collaborationType)
        {
            switch (collaborationType)
            {
                case S_CollaborationType.EMail:
                    return new MailCollaboration();

                default:
                    return null;
            }
        }

        public IContentTemplate GetTemplateHandler(string templateType)
        {
            switch (templateType)
            {
                case S_TemplateType.EMail:
                    return new MailContentTemplate();

                default:
                    return null;
            }
        }
        //// Summary:
        ////     The method will get the instance for provider class
        ////
        //// Parameters:
        ////   :
        ////
        //// Returns:
        ////     returns the instance of provider class
        //public IExcelProvider GetExcelHandler();
        ////
        //// Summary:
        ////     Based on the Mail Type the method will get the instance for provider class
        ////
        //// Parameters:
        ////   mailType:
        ////     Mail Type
        ////
        //// Returns:
        ////     returns the instance of provider class
        //public IMailProvider GetMailHandler(string mailType);
        ////
        //// Summary:
        ////     Based on the Mail Type the method will get the instance for provider class
        ////
        //// Parameters:
        ////   mailType:
        ////     Template mail Type
        ////
        //// Returns:
        ////     returns the instance of provider class
        //public ITemplateProvider GetTemplateHandler(string MailType);
    }
}
