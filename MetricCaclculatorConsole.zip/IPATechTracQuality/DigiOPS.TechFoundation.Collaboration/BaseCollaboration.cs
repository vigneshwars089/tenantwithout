﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Collaboration
{
   public class BaseCollaboration: ICollaboration
    {
       public virtual ResponseInfo ValidateMailObject(EMailInfo objEMailInfo)
       {          
           ResponseInfo objResponseInfo = new ResponseInfo { ResultStatus = false };
           if (string.IsNullOrEmpty(objEMailInfo.Sender.Trim()))
           {
               objResponseInfo.ErrorMessage.Append("Username is null or empty. ");
               return objResponseInfo;
           }
           if (string.IsNullOrEmpty(objEMailInfo.Recipient.Trim()))
           {
               objResponseInfo.ErrorMessage.Append("Password is null or empty. ");
               return objResponseInfo;
           }
          

           return new ResponseInfo { ResultStatus = true };
       }

       public virtual void send(CollaborationInfo objCollaborationInfo)
        {
            
        }
    }
}
