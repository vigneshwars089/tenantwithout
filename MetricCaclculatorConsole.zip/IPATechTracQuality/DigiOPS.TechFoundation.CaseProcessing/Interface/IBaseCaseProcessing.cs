﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public interface IBaseCaseProcessing
    {
        String CreateHTMLFile(string EMailFrom, string EMailTo, string EMailCC, string Subject, string BodyText, string Importance);

        List<ConversationInfo> GetConversationsByCaseId(Int64 ID, bool IsEncrypted, string EncryptionKey);
        List<ConversationInfo> GetConversationsByCaseIdWithoutAttachments(Int64 ID, bool IsEncrypted, string EncryptionKey);

        List<AttachmentInfo> GetAttachmentByConversationID(Int32 ID);
        List<AttachmentInfo> GetInlineAttachmentByConversationID(Int32 ID);
        bool SendMail(ConversationInfo objConversationInfo, MailBoxInfo objMailBoxInfo, bool IsEncrypted, string EncryptionKey);
        SignatureInfo GetSignature(string UserId);
        ConversationInfo GetConversationDetails(long ConversationId, bool IsEncrypted, String EncryptionKey);
        ConversationInfo ProcessConversationDetailsforSave(ConversationInfo objEmailConversationInfo, ConversationInfo objFollowupConversation, bool IsEncrypted, string EncryptionKey);
        List<ConversationInfo> ProcessConversationDetailsforDisplay(List<ConversationInfo> lstConversationInfo, bool IsEncrypted, string EncryptionKey);
        void InsertAttachments(List<AttachmentInfo> lstAttachments, long ConversationId, String UserId);
        bool DeleteDraft(long CaseId);
    }
}
