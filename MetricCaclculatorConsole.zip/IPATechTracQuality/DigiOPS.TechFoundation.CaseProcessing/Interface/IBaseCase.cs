﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public interface IBaseCase
    {
        List<CommentsInfo> GetComments(Int64 CaseId);
        List<AuditInfo> GetAuditLog(Int64 CaseId);
        List<CategoryInfo> GetCategory(Int64 EmailBoxid);
        List<StatusTransitionInfo> GetStatusTransition(int SubProcessId, int UserRoleId);
        CaseInfo GetCaseDetailsByCaseId(Int64 ID);
        int UpdateCaseDetails(CaseInfo objEmailCaseInfo, string ModifiedBy, DateTime ModifiedDate);
        int UpdateForwardToGMB(long CaseId, bool ForwardToGMB);
        List<Int64> GetAllChildCases(long ParentcaseId);
        MailBoxInfo GetEmailBoxDetails(Int32 EmailBoxId);
        bool UpdateOnReassign(long CaseId, String AssignedToId, String LoggedInUserId);
        bool UpdateDynamicFields();
        List<DynamicFieldsInfo> GetDynamicFieldsInfo(long CaseId);
        List<ControlValues> GetControlValuesForBinding(int FieldMasterID);
    }
}
