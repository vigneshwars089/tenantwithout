﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.CaseProcessing
{
    public abstract class BaseCaseProcessing : IBaseCaseProcessing
    {


        public virtual bool ProcessCase(EMailInfo objcaseInfo)
        {
            return false;
        }
        public virtual String CreateHTMLFile(string EMailFrom, string EMailTo, string EMailCC, string Subject, string BodyText, string Importance)
        {
            return "";
        }
        public virtual List<ConversationInfo> GetConversationsByCaseId(Int64 ID, bool IsEncrypted, string EncryptionKey)
        {
            return null;
        }
        public virtual int InsertEmailConversation(ConversationInfo objConversationInfo, long CaseId, String UserId)
        {
            return 0;
        }
        public virtual List<ConversationInfo> GetConversationsByCaseIdWithoutAttachments(Int64 ID, bool IsEncrypted, string EncryptionKey)
        {
            return null;
        }
        public virtual List<AttachmentInfo> GetAttachmentByConversationID(Int32 ID)
        {
            return null;
        }
        public virtual List<AttachmentInfo> GetInlineAttachmentByConversationID(Int32 ID)
        {
            return null;
        }
        public virtual bool SendMail(ConversationInfo objConversationInfo, MailBoxInfo objMailBoxInfo, bool IsEncrypted, string EncryptionKey)
        {
            return false;
        }
        public virtual SignatureInfo GetSignature(string UserId)
        {
            return null;
        }
        public virtual ConversationInfo GetConversationDetails(long ConversationId, bool IsEncrypted, String EncryptionKey)
        {
            return null;
        }
        public virtual ConversationInfo ProcessConversationDetailsforSave(ConversationInfo objEmailConversationInfo, ConversationInfo objFollowupConversation, bool IsEncrypted, string EncryptionKey)
        {
            return null;
        }
        public virtual List<ConversationInfo> ProcessConversationDetailsforDisplay(List<ConversationInfo> lstConversationInfo, bool IsEncrypted, string EncryptionKey)
        {
            return null;
        }
        public virtual void InsertAttachments(List<AttachmentInfo> lstAttachments, long ConversationId, String UserId)
        {

        }
        public virtual bool DeleteDraft(long CaseId)
        {
            return false;
        }
    }
}
