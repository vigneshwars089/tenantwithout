﻿using DigiOPS.TechFoundation.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using System.Web;
using System.Globalization;
using System.Collections;
using System.Configuration;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.Utilities;
using Microsoft.Exchange.WebServices.Data;
using System.Security;
using System.Runtime.InteropServices;
using DigiOPS.TechFoundation.CaseProcessing;
using DigiOPS.TechFoundation.Logging;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net;



namespace DigiOPS.TechFoundation.CaseProcessing
{
    public class EmailCaseProcessing : BaseCaseProcessing
    {
        public const string WorkQueuePage = "WorkQueue";
        public const string QCWorkQueuePage = "QCWorkQueue";
        public const string SearchPage = "Search";
        public const string FileSent = "File Sent";
        public const string FileReceived = "File Received";
        public const string Unauthorized = "The request failed. The remote server returned an error: (401) Unauthorized.";
        public const string NotFoundinStore = "The specified folder could not be found in the store.";
        CaseProcessingDAO casedao = new CaseProcessingDAO();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        /// <summary>
        /// To build the Email Construct with from,to,cc,subject,importance for the first conversation as it would not be available by default in message body
        /// </summary>
        /// <param name="EMailFrom"></param>
        /// <param name="EMailTo"></param>
        /// <param name="EMailCC"></param>
        /// <param name="Subject"></param>
        /// <param name="BodyText"></param>
        /// <param name="Importance"></param>       
        /// <returns></returns>
        public override String CreateHTMLFile(string EMailFrom, string EMailTo, string EMailCC, string Subject, string BodyText, string Importance)
        {

            ConversationInfo conver = new ConversationInfo();
            //Create a Email sender and receiver info with datetime
            StringBuilder EMailTransactionDetails = new StringBuilder();
            EMailTransactionDetails.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append("From: ");
            EMailTransactionDetails.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append(EMailFrom + "<br/>");
            EMailTransactionDetails.Append("<b>Sent: </b>" + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToShortTimeString() + "<br/>");

            EMailTransactionDetails.Append("<b>To: </b>" + HelperMethods.GetNamesWithoutDuplicates(EMailTo) + "<br/>");
            if (EMailCC.Length > 0)
            {
                EMailTransactionDetails.Append("<b>Cc: </b>" + HelperMethods.GetNamesWithoutDuplicates(EMailCC) + "<br/>");
            }

            EMailTransactionDetails.Append("<b>Subject: </b>" + Subject);
            bool Priority = (Importance.ToString() == "Low" || Importance.ToString() == "Normal" ? false : true);
            if (Priority)
                EMailTransactionDetails.Append("<br/><b>Importance: </b>" + Importance.ToString());
            EMailTransactionDetails.Append("</span>");
            EMailTransactionDetails.Append("</p></div><br/>");

            if (BodyText != null)
            {
                BodyText = EMailTransactionDetails.ToString() + BodyText.ToString();
            }
            else
            {
                BodyText = "";
            }
            return BodyText;

        }

        //TESTED
        public override List<ConversationInfo> GetConversationsByCaseId(Int64 ID, bool IsEncrypted, string EncryptionKey)
        {
            List<ConversationInfo> lstConversationInfo = new List<ConversationInfo>();
            lstConversationInfo = casedao.LoadConversationDetails(ID);  //SP to return details from conversation table

            if (lstConversationInfo.Count > 0)
            {
                foreach (ConversationInfo objConversationInfo in lstConversationInfo)
                {
                    DateTime CreatDate = DateTime.Parse(objConversationInfo.CreatedDate);
                    objConversationInfo.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);

                    //get file attachments
                    List<AttachmentInfo> lstAttachments = GetAttachmentByConversationID(objConversationInfo.Id);
                    objConversationInfo.lstAttachments = lstAttachments;
                    //get inline attachments
                    List<AttachmentInfo> lstInlineAttachments = GetInlineAttachmentByConversationID(objConversationInfo.Id);
                    objConversationInfo.lstInlineAttachments = lstInlineAttachments;
                }
            }
            return ProcessConversationDetailsforDisplay(lstConversationInfo, IsEncrypted, EncryptionKey);
        }
        /// <summary>
        /// Returns emailconversations without file and inline attachments
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="IsEncrypted"></param>
        /// <param name="cipherKey"></param>
        /// <returns></returns>
        public override List<ConversationInfo> GetConversationsByCaseIdWithoutAttachments(Int64 ID, bool IsEncrypted, string EncryptionKey)
        {
            List<ConversationInfo> lstConversationInfo = new List<ConversationInfo>();
            lstConversationInfo = casedao.LoadConversationDetails(ID);
            return ProcessConversationDetailsforDisplay(lstConversationInfo, IsEncrypted, EncryptionKey);
        }

        //gets file attachments for each conversation
        public override List<AttachmentInfo> GetAttachmentByConversationID(Int32 ID)
        {
            HelperMethods objHelperMethods = new HelperMethods();
            List<AttachmentInfo> lstAttachmentInfo = new List<AttachmentInfo>();
            lstAttachmentInfo = casedao.LoadAttachmentDetails(ID);
            foreach (AttachmentInfo objAttachmentInfo in lstAttachmentInfo)
            {
                objAttachmentInfo.FileName = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objAttachmentInfo.FileName.ToString().Replace(@"\", "").Replace("..", ""), true);
                objAttachmentInfo.AttachmentTypeId = Convert.ToInt32(System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode((objHelperMethods.GetAttachmentType(objAttachmentInfo.AttachmentType.ToString().Replace(@"\", "").Replace("..", ""))).ToString(), true));
                objAttachmentInfo.AttachmentType = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objAttachmentInfo.AttachmentType.ToString().Replace(@"\", "").Replace("..", ""), true);
                DateTime CreatDate = DateTime.Parse(objAttachmentInfo.CreatedDate);
                objAttachmentInfo.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);
                //DateTime CreatDate = DateTime.Parse(dr["CREATEDDATE"].ToString());
                //conv.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);

            }
            return lstAttachmentInfo;
        }

        //gets inline attachments for each conversation
        public override List<AttachmentInfo> GetInlineAttachmentByConversationID(Int32 ID)
        {
            HelperMethods objHelperMethods = new HelperMethods();
            List<AttachmentInfo> lstAttachmentInfo = new List<AttachmentInfo>();
            lstAttachmentInfo = casedao.LoadInlineAttachmentDetails(ID);
            foreach (AttachmentInfo objAttachmentInfo in lstAttachmentInfo)
            {
                objAttachmentInfo.FileName = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objAttachmentInfo.FileName.ToString().Replace(@"\", "").Replace("..", ""), true);
                objAttachmentInfo.AttachmentTypeId = Convert.ToInt32(System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode((objHelperMethods.GetAttachmentType(objAttachmentInfo.AttachmentType.ToString().Replace(@"\", "").Replace("..", ""))).ToString(), true));
                objAttachmentInfo.AttachmentType = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objAttachmentInfo.AttachmentType.ToString().Replace(@"\", "").Replace("..", ""), true);
                DateTime CreatDate = DateTime.Parse(objAttachmentInfo.CreatedDate.ToString());
                objAttachmentInfo.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);

            }
            return lstAttachmentInfo;
        }
        /// <summary>
        /// Method to send a email to the intended recipient from the mailbox
        /// </summary>
        /// <param name="objConversationInfo">The mail conversation to be sent </param>
        /// <param name="objMailBoxInfo">The emailbox from which email is to be sent </param>        
        /// <param name="isSuccess">Indicates the Send mail success/failure</param>        
        /// <returns></returns>
        public override bool SendMail(ConversationInfo objConversationInfo, MailBoxInfo objMailBoxInfo, bool IsEncrypted, string EncryptionKey)
        {
            System.Text.Encoding enc = System.Text.Encoding.UTF8;
            bool isSuccess = true;
            try
            {
                //Create an object to ExchangeService
                ExchangeService objService;

                if (objMailBoxInfo.ClientExVersion == "Exchange2013_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else if (objMailBoxInfo.ClientExVersion == "Exchange2007_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                }
                else if (objMailBoxInfo.ClientExVersion == "Exchange2010")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010);
                }
                else if (objMailBoxInfo.ClientExVersion == "Exchange2010_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                }
                else if (objMailBoxInfo.ClientExVersion == "Exchange2010_SP2")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                }
                else if (objMailBoxInfo.ClientExVersion == "Exchange2013")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013);
                }
                else
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                //Create an object to EMailBox from which we need to send emails
                Mailbox objCommonMailBox = new Mailbox(objMailBoxInfo.EMailId);
                //Create an object to Drafts folder
                FolderId objDraftsFolder = new FolderId(WellKnownFolderName.Drafts, objCommonMailBox);
                //Create an object to Sentitems folder
                FolderId objSentItemsFolder = new FolderId(WellKnownFolderName.SentItems, objCommonMailBox);
                if (IsEncrypted == true)
                {
                    if (objMailBoxInfo.Domain != null && objMailBoxInfo.Domain != "")
                        objService.Credentials = new WebCredentials(objMailBoxInfo.LoginEMailId, HelperMethods.DecryptString(objMailBoxInfo.Password.ToString(), IsEncrypted, EncryptionKey), objMailBoxInfo.Domain);
                    else
                        objService.Credentials = new WebCredentials(objMailBoxInfo.LoginEMailId, HelperMethods.DecryptString(objMailBoxInfo.Password.ToString(), IsEncrypted, EncryptionKey));
                }
                else
                {
                    if (objMailBoxInfo.Domain != null && objMailBoxInfo.Domain != "")
                        objService.Credentials = new WebCredentials(objMailBoxInfo.LoginEMailId, HelperMethods.DecryptValue(objMailBoxInfo.Password.ToString()), objMailBoxInfo.Domain);
                    else
                        objService.Credentials = new WebCredentials(objMailBoxInfo.LoginEMailId, HelperMethods.DecryptValue(objMailBoxInfo.Password.ToString()));

                }

                objService.Url = new Uri(objMailBoxInfo.ServiceExchangeUrl); //Assign Service URL
                objService.UseDefaultCredentials = false;
                //create an object for EmailMessage with Exchangeservice object
                EmailMessage objMessage = new EmailMessage(objService);
                objMessage.From = objConversationInfo.EmailFrom;
                //Add the recipients in the TO list
                if (objConversationInfo.EmailTo != string.Empty)
                {
                    string[] names = objConversationInfo.EmailTo.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            names[len] = names[len].Replace(';', ' ').Trim();
                            List<string> lstUserList = new List<string>();

                            if (len == 0)
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
                else
                {
                    objConversationInfo.ErrorMessage = new StringBuilder();
                    objConversationInfo.ErrorMessage.Append("To Address cannot be null or empty");
                }
                //Add the recipients in the CC list
                if (objConversationInfo.EmailCc != string.Empty)
                {
                    string[] names = objConversationInfo.EmailCc.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {

                            names[len] = names[len].Replace(';', ' ').Trim();

                            List<string> lstUserList = new List<string>();

                            if (len == 0)
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }

                if (objConversationInfo.IsHighImportance == true)
                {
                    objMessage.Importance = Importance.High;
                }
                else
                {
                    objMessage.Importance = Importance.Normal;
                }
                //Inline Attachments
                if (objConversationInfo.lstInlineAttachments.Count > 0)
                {
                    int maxno = 1;
                    for (int i = 0; i < objConversationInfo.lstInlineAttachments.Count; i++)
                    {
                        byte[] imgbyte = Convert.FromBase64String(objConversationInfo.lstInlineAttachments[i].ToString().Replace(" ", "+").ToString());
                        string Name = "";
                        if (maxno > 99)
                            Name = "image" + maxno + ".png";
                        else if (maxno >= 10 && maxno <= 99)
                            Name = "image0" + maxno + ".png";
                        else
                            Name = "image00" + maxno + ".png";
                        FileAttachment attachment = objMessage.Attachments.AddFileAttachment(Name, imgbyte);
                        attachment.IsInline = true;
                        attachment.ContentType = "PNG";
                        attachment.ContentId = Name;
                        maxno = maxno + 1;
                    }
                }

                objMessage.Subject = objConversationInfo.Subject;
                objMessage.Body = (objConversationInfo.Content); //EMail Body
                objMessage.Body.BodyType = BodyType.HTML;

                long totSize = 0;

                //Add Attachments to the EMail
                if (objConversationInfo.lstAttachments.Count > 0)
                {
                    foreach (AttachmentInfo at in objConversationInfo.lstAttachments)
                    {
                        if (at.FileName.Contains("cid:image") && at.FileName.Contains(".png"))
                        {
                            FileAttachment attachment = objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                            //if (!ExVersion2007orNot) 
                            attachment.IsInline = true;

                            attachment.ContentType = "PNG";
                            attachment.ContentId = at.FileName.Replace("cid:", "");
                        }
                        else
                            objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                    }
                }

                objMessage.Save(objDraftsFolder); //Save the message in drafts folder - to fix the attachment opening issue
                objMessage.SendAndSaveCopy(objSentItemsFolder); // Save the messgae in sentitems folder and send
                string plainbody = Regex.Replace((objConversationInfo.Content), @"<(.|\n)*?>", string.Empty);
                plainbody = plainbody.Replace("&nbsp;", "");
                isSuccess = true;
            }
            catch (Exception ex)
            {
                if (ex.Message == Unauthorized)
                {
                    casedao.LockEmail((int)EmailBoxType.LoginEmail, objMailBoxInfo.LoginEMailId);
                    objloginfo.Message = "Mail sent failure! Sub: " + objConversationInfo.Subject + ". Mailbox: " + objMailBoxInfo.LoginEMailId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == NotFoundinStore)
                {
                    casedao.LockEmail((int)EmailBoxType.EmailBox, objMailBoxInfo.LoginEMailId);
                    objloginfo.Message = "Mail sent failure! Sub: " + objConversationInfo.Subject + ". Mailbox: " + objMailBoxInfo.LoginEMailId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == "The message exceeds the maximum supported size.")
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);

                }
                else
                {
                    objloginfo.Message = "Mail sent failure! Sub: " + objConversationInfo.Subject + ". Mailbox: " + objMailBoxInfo.LoginEMailId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                isSuccess = false;
            }
            return isSuccess;
        }

        public override SignatureInfo GetSignature(string UserId)
        {
            SignatureInfo objSignatureInfo = new SignatureInfo();
            objSignatureInfo = casedao.GetSignature(UserId);
            return objSignatureInfo;
        }

        public override ConversationInfo GetConversationDetails(long ConversationId, bool IsEncrypted, String EncryptionKey)
        {
            CryptInfo cryptInfo = new CryptInfo();
            System.Text.Encoding enc = System.Text.Encoding.UTF8;
            SecurityFactory securityFactory = new SecurityFactory();
            ConversationInfo objConversationInfo = casedao.GetConversationDetails(ConversationId);
            //get file attachments
            List<AttachmentInfo> lstAttachments = GetAttachmentByConversationID(objConversationInfo.Id);
            objConversationInfo.lstAttachments = lstAttachments;
            //get inline attachments
            List<AttachmentInfo> lstInlineAttachments = GetInlineAttachmentByConversationID(objConversationInfo.Id);
            objConversationInfo.lstInlineAttachments = lstInlineAttachments;
            List<ConversationInfo> lstConversationInfo = new List<ConversationInfo>();
            lstConversationInfo.Add(objConversationInfo);
            lstConversationInfo = ProcessConversationDetailsforDisplay(lstConversationInfo, IsEncrypted, EncryptionKey);
            return lstConversationInfo[0];
        }

        /// <summary>
        ///Method to append the followup conversation, extract the inline images and return an entity with separated inline images and content with place holders

        /// </summary>       
        /// <param name="objEmailConversationInfo">EmailConversationInfo with inline images embedded in content</param>
        /// <param name="objFollowupConversation"></param>       
        /// <param name="IsEncrypted"></param>
        /// <param name="EncryptionKey"></param>
        /// <returns>EmailConversationInfo with content and inline images separated</returns>
        public override ConversationInfo ProcessConversationDetailsforSave(ConversationInfo objEmailConversationInfo, ConversationInfo objFollowupConversation, bool IsEncrypted, string EncryptionKey)
        {
            HelperMethods objHelperMethods = new HelperMethods();
            System.Text.Encoding enc = System.Text.Encoding.UTF8;
            try
            {
                if (objEmailConversationInfo.Content != null)
                {
                    int TotalMailAttachmentSize = 0;
                    bool isSuccess;
                    foreach (AttachmentInfo objAttachment in objEmailConversationInfo.lstAttachments)
                    {
                        TotalMailAttachmentSize += objAttachment.FileContent.Length;
                    }

                    if (DigiOPS.TechFoundation.Utilities.HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize))// Checking the total size of the existing screenshots and Attachments
                    {

                        bool imgSuccess = true;

                        string sourceText = (objEmailConversationInfo.Content);

                        if (objEmailConversationInfo.IsShowQuotedText == false)
                        {
                            string FollowupWithImages = "";
                            FollowupWithImages = (objFollowupConversation.Content);
                            sourceText = sourceText + FollowupWithImages;
                        }

                        var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                        string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                                    RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                    RegexOptions.Multiline);

                        List<string> imgSrcs = new List<string>();
                        int MaxNo = 1;
                        foreach (Match match in imgSrcMatches)
                        {
                            string srcvalue = match.Groups[1].Value;
                            try
                            {
                                if (srcvalue.Contains("data:image/png;base64"))
                                {
                                    imgSrcs.Add(srcvalue.Replace("data:image/png;base64,", ""));

                                    byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/png;base64,", "").Replace(' ', '+'));
                                    TotalMailAttachmentSize += imgArray.Length;
                                }
                                else if (srcvalue.Contains("data:image/jpeg;base64,"))
                                {
                                    imgSrcs.Add(srcvalue.Replace("data:image/jpeg;base64,", ""));

                                    byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/jpeg;base64,", "").Replace(' ', '+'));
                                    TotalMailAttachmentSize += imgArray.Length;
                                }
                                else
                                {
                                    byte[] imageArray;
                                    using (var webClient = new WebClient())
                                    {
                                        imageArray = webClient.DownloadData(srcvalue);
                                    }

                                    System.Threading.Thread.Sleep(2000);
                                    TotalMailAttachmentSize += imageArray.Length;
                                    string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                                    if (base64ImageRepresentation.Contains("data:image/png;base64,"))
                                        imgSrcs.Add(base64ImageRepresentation.Replace("data:image/png;base64,", ""));

                                    else if (base64ImageRepresentation.Contains("data:image/jpeg;base64,"))
                                        imgSrcs.Add(base64ImageRepresentation.Replace("data:image/jpeg;base64,", ""));
                                    else
                                        imgSrcs.Add(base64ImageRepresentation);
                                }
                                if (MaxNo > 99)
                                {
                                    sourceText = sourceText.Replace(srcvalue, "cid:image" + MaxNo + ".png");
                                }
                                else if (MaxNo >= 10 && MaxNo <= 99)
                                {
                                    sourceText = sourceText.Replace(srcvalue, "cid:image0" + MaxNo + ".png");
                                }
                                else
                                {
                                    sourceText = sourceText.Replace(srcvalue, "cid:image00" + MaxNo + ".png");
                                }

                                MaxNo = MaxNo + 1;
                            }
                            catch (Exception exnew)
                            {
                                imgSuccess = false;
                            }
                        }
                        if (imgSuccess)
                        {
                            bool success = false;
                            if (HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize)) // Checking the total size of the both New & existing screenshots and Attachments
                            {
                                string EncodeSubjectLine = HelperMethods.FollowupHtmlEncode(objEmailConversationInfo.Subject);
                                string plainbody = Regex.Replace(sourceText, @"<(.|\n)*?>", string.Empty);
                                plainbody = plainbody.Replace("&nbsp;", "");
                                objEmailConversationInfo.Content = sourceText;
                                if (imgSrcs.Count > 0)
                                {
                                    List<AttachmentInfo> InlineAttachments;
                                    List<AttachmentInfo> lstInline = new List<AttachmentInfo>();

                                    int aa = 1;

                                    foreach (string imgcontent in imgSrcs)
                                    {
                                        AttachmentInfo at = new AttachmentInfo();

                                        string Name = "";

                                        if (aa > 99)
                                            Name = "cid:image" + aa + ".png";
                                        else if (aa >= 10 && aa <= 99)
                                            Name = "cid:image0" + aa + ".png";
                                        else
                                            Name = "cid:image00" + aa + ".png";

                                        at.FileName = Name;
                                        at.AttachmentType = ".png";

                                        at.FileContent = DigiOPS.TechFoundation.Utilities.HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+")), IsEncrypted, EncryptionKey);

                                        at.AttachmentTypeId = 3;

                                        lstInline.Add(at);
                                        aa = aa + 1;

                                    }
                                    if (lstInline.Count > 0)
                                    {
                                        InlineAttachments = lstInline;

                                        //InsertAttachments(InlineAttachments, conversationId, UserId); //Upload followup file to DB
                                        objEmailConversationInfo.lstInlineAttachments = InlineAttachments;
                                    }

                                }
                                List<AttachmentInfo> externaltblattachments;
                                List<AttachmentInfo> lsttblattachments = new List<AttachmentInfo>();
                                if (objEmailConversationInfo.lstAttachments != null)
                                {
                                    foreach (AttachmentInfo at in objEmailConversationInfo.lstAttachments)
                                    {
                                        if (!(at.FileName.Contains("cid:image") && at.FileName.Contains(".png")))
                                        {
                                            AttachmentInfo objAttachmentInfo = new AttachmentInfo();

                                            objAttachmentInfo.FileName = at.FileName;
                                            objAttachmentInfo.ContentType = HelperMethods.ReturnExtension(at.FileName);
                                            objAttachmentInfo.FileContent = HelperMethods.EncryptAttachments(at.FileContent, IsEncrypted, EncryptionKey);
                                            objAttachmentInfo.AttachmentTypeId = 1;
                                            lsttblattachments.Add(objAttachmentInfo);
                                        }

                                    }
                                }
                                if (lsttblattachments.Count > 0)
                                {
                                    externaltblattachments = lsttblattachments;
                                    //InsertAttachments(externaltblattachments, conversationId, UserId); //Upload tableattachments to DB
                                    objEmailConversationInfo.lstAttachments = externaltblattachments;
                                }

                            }

                        }

                    }
                    else
                    {
                        objEmailConversationInfo.ErrorMessage = new StringBuilder("The Attachment size exceeds the allowed limit");
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return objEmailConversationInfo;
        }

        //TESTED
        /// <summary>
        /// Method to embed inline images into mail content before display
        /// </summary>
        /// <param name="lstConversationInfo"></param>
        /// <param name="IsEncrypted"></param>
        /// <param name="EncryptionKey"></param>
        /// <returns></returns>
        public override List<ConversationInfo> ProcessConversationDetailsforDisplay(List<ConversationInfo> lstConversationInfo, bool IsEncrypted, string EncryptionKey)
        {
            System.Text.Encoding enc = System.Text.Encoding.UTF8;
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            if (lstConversationInfo.Count > 0)
            {
                foreach (ConversationInfo objConversationInfo in lstConversationInfo)
                {
                    //DateTime CreatDate = DateTime.Parse(objConversationInfo.CreatedDate);
                    //objConversationInfo.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);


                    if (IsEncrypted == true)
                    {
                        for (int i = 0; i < objConversationInfo.lstAttachments.Count; i++)
                        {
                            string encryptedMailcontent = Convert.ToBase64String(objConversationInfo.lstAttachments[i].FileContent);//Convert.ToBase64String(objAttach.FileContent);                       
                            cryptInfo.CryptKey = EncryptionKey;
                            cryptInfo.ValueToCrypt = encryptedMailcontent;
                            string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            objConversationInfo.lstAttachments[i].FileContent = Convert.FromBase64String(decryptedValue);
                        }
                    }
                    //get inline attachments

                    string actualMailcontent = objConversationInfo.Content;

                    if (IsEncrypted == true)
                    {
                        //Decryption
                        cryptInfo.CryptKey = EncryptionKey;
                        cryptInfo.ValueToCrypt = actualMailcontent;
                        string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                        actualMailcontent = decryptedValue;

                        if (objConversationInfo.lstInlineAttachments != null && objConversationInfo.lstInlineAttachments.Count > 0)
                        {
                            for (int i = 0; i < objConversationInfo.lstInlineAttachments.Count; i++)
                            {
                                if (actualMailcontent.Contains(objConversationInfo.lstInlineAttachments[i].FileName.ToString()))
                                {
                                    if (IsEncrypted)
                                    {
                                        cryptInfo.CryptKey = EncryptionKey;
                                        cryptInfo.ValueToCrypt = Convert.ToBase64String(objConversationInfo.lstInlineAttachments[i].FileContent);
                                        string decryptedlstInline = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                                        actualMailcontent = actualMailcontent.Replace(objConversationInfo.lstInlineAttachments[i].FileName.ToString(), "data:image/png;base64," + decryptedlstInline);
                                    }
                                    else
                                    {
                                        actualMailcontent = actualMailcontent.Replace(objConversationInfo.lstInlineAttachments[i].FileName.ToString(), "data:image/png;base64," + Convert.ToBase64String(objConversationInfo.lstInlineAttachments[i].FileContent));
                                    }
                                }
                            }
                        }

                        objConversationInfo.Content = actualMailcontent;
                    }

                }
            }
            return lstConversationInfo;
        }
        public override int InsertEmailConversation(ConversationInfo objConversationInfo, long CaseId, String UserId)
        {
            int result = casedao.InsertEmailConversation(objConversationInfo, CaseId);
            return result;
        }

        public override void InsertAttachments(List<AttachmentInfo> lstAttachments, long ConversationId, String UserId)
        {
            casedao.InsertAttachments(lstAttachments, ConversationId, UserId);
        }

        public override bool DeleteDraft(long CaseId)
        {
            int result = casedao.DeleteDraft(CaseId);
            if (result == 0)
                return false;
            else
                return true;
        }

    }

}
