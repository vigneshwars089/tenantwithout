﻿using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public class EmailBaseCase : IBaseCase
    {
        CaseProcessingDAO casedao = null;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        public List<CommentsInfo> GetComments(Int64 CaseId)
        {
            casedao = new CaseProcessingDAO();
            List<CommentsInfo> lstCommentsInfo = new List<CommentsInfo>();
            lstCommentsInfo = casedao.GetComments(CaseId);
            foreach (CommentsInfo objCommentsInfo in lstCommentsInfo)
            {

                DateTime commentedDate = DateTime.ParseExact(objCommentsInfo.CommentedDate, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                objCommentsInfo.CommentedDate = commentedDate.ToString("dd/MM/yyyy HH:mm:ss");
                //lstCommentsInfo.Add(objCommentsInfo);
            }
            return lstCommentsInfo;

        }

        public List<AuditInfo> GetAuditLog(Int64 CaseId)
        {
            casedao = new CaseProcessingDAO();
            List<AuditInfo> lstAuditInfo = new List<AuditInfo>();
            lstAuditInfo = casedao.GetAuditLog(CaseId);
            foreach (AuditInfo objAuditInfo in lstAuditInfo)
            {
                if (objAuditInfo.FromDate.ToString() != "-")
                {
                    DateTime dateStarted = DateTime.ParseExact(objAuditInfo.FromDate.ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    objAuditInfo.FromDate = dateStarted.ToString("dd/MM/yyyy HH:mm:ss");
                }
                else
                {
                    objAuditInfo.FromDate = objAuditInfo.FromDate.ToString();
                }
                DateTime dateEnded = DateTime.ParseExact(objAuditInfo.ToDate.ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                objAuditInfo.ToDate = dateEnded.ToString("dd/MM/yyyy HH:mm:ss");
            }
            return lstAuditInfo;
        }

        public List<CategoryInfo> GetCategory(Int64 EmailBoxid)
        {
            casedao = new CaseProcessingDAO();
            List<CategoryInfo> lstCategoryInfo = new List<CategoryInfo>();
            lstCategoryInfo = casedao.GetCategory(EmailBoxid);
            return lstCategoryInfo;
        }

        public List<StatusTransitionInfo> GetStatusTransition(int SubProcessId, int UserRoleId)
        {
            casedao = new CaseProcessingDAO();
            List<StatusTransitionInfo> lstStatusTransitionInfo = new List<StatusTransitionInfo>();
            lstStatusTransitionInfo = casedao.GetStatusTransition(SubProcessId, UserRoleId);
            return lstStatusTransitionInfo;
        }

        public CaseInfo GetCaseDetailsByCaseId(Int64 ID)
        {
            casedao = new CaseProcessingDAO();
            CaseInfo objCaseInfo = new CaseInfo();

            if (ID != 0)
            {
                try
                {
                    objCaseInfo = casedao.LoadCaseDetails(ID); //SP to return details from EmailMaster
                    return objCaseInfo;
                }

                catch (Exception ex)
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                    throw;
                }
            }
            else
            {
                objCaseInfo.ErrorMessage = new StringBuilder();
                objCaseInfo.ErrorMessage.Append("ID cannot be null or empty");
                return objCaseInfo;
            }

        }

        public int UpdateCaseDetails(CaseInfo objEmailCaseInfo, string ModifiedBy, DateTime ModifiedDate)
        {
            int result = casedao.UpdateCaseDetails(objEmailCaseInfo, ModifiedBy, ModifiedDate);
            return result;
        }

        public int UpdateForwardToGMB(long CaseId, bool ForwardToGMB)
        {
            return casedao.UpdateForwardToGMB(CaseId, ForwardToGMB);
        }

        public List<Int64> GetAllChildCases(long ParentcaseId)
        {
            List<Int64> lstChildCases = new List<long>();
            lstChildCases = casedao.GetAllChildCaseIds(ParentcaseId);
            return lstChildCases;
        }

        public MailBoxInfo GetEmailBoxDetails(Int32 EmailBoxId)
        {
            casedao = new CaseProcessingDAO();
            MailBoxInfo objMailBoxInfo = new MailBoxInfo();
            objMailBoxInfo = casedao.GetEmailBoxDetails(EmailBoxId);
            return objMailBoxInfo;
        }

        public bool UpdateOnReassign(long CaseId, String AssignedToId, String LoggedInUserId)
        {
            int result = casedao.UpdateOnReassign(CaseId, AssignedToId, LoggedInUserId);
            if (result != 0)
                return true;
            else return false;

        }

        public bool UpdateDynamicFields()
        {
            return true;
        }

        public List<DynamicFieldsInfo> GetDynamicFieldsInfo(long CaseId)
        {
            List<DynamicFieldsInfo> lstDynamicFieldsInfo = new List<DynamicFieldsInfo>();
            lstDynamicFieldsInfo = casedao.GetDynamicFieldsInfo(CaseId);
            foreach (DynamicFieldsInfo objDynamicFieldsInfo in lstDynamicFieldsInfo)
                objDynamicFieldsInfo.lstControlValues = GetControlValuesForBinding(objDynamicFieldsInfo.FieldMasterID);
            return lstDynamicFieldsInfo;

        }

        public List<ControlValues> GetControlValuesForBinding(int FieldMasterID)
        {
            List<ControlValues> lstControlValues = new List<ControlValues>();

            lstControlValues = casedao.GetControlValuesForBinding(FieldMasterID);

            return lstControlValues;
        }

    }
}
