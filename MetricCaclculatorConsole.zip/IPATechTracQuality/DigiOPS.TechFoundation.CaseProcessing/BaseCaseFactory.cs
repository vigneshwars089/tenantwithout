﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public class BaseCaseFactory
    {
        public struct S_CaseType
        {
            public const string Email = "Email";
        }

        public IBaseCase GetCaseHandler(string CaseType)
        {
            switch (CaseType)
            {
                case S_CaseType.Email:
                    return new EmailBaseCase();
                default:
                    return null;
            }
        }
    }
}
