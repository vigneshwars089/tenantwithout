﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.Logging;


namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :BaseAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //8-May-2017    Venkata Lakshmi CH.     AllocationValidation            Added AllocationValidation method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public abstract class BaseAllocation : IAllocation
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseAllocation.cs
        // Namespace : DigiOps.TechFoundationAllocation
        // Class Name(s) :BaseAllocation
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/27/2017
        // Purpose : Allocation Component


        public virtual AllocatedDetails Allocate(AllocationDetails TLDA)
        {
            throw new NotImplementedException();
        }

        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseAllocation.cs
        // Namespace : DigiOps.TechFoundationAllocation
        // Class Name(s) :BaseAllocation
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/27/2017
        // Purpose : Allocation Component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //8-May-2017    Venkata Lakshmi CH.     AllocationValidation            Added AllocationValidation method  
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public AllocationDetails AllocationValidation(AllocationDetails objAllocationDetails)
        {
            // LoggingFactory objlog = new LoD:\188598\BPO_Tech_WD\Component - TFS\QuartComponent\DigiOPS.TechFoundation.Framework\DigiOPS.TechFoundation.Allocation\BaseAllocation.csggingFactory();
            // LogInfo objloginfo = new LogInfo();
            objAllocationDetails.ResultStatus = false;
            objAllocationDetails.ErrorMessage = new StringBuilder();

            int flag = 0;
            try
            {

                if (objAllocationDetails.RecordDetails != null)
                {
                    if (objAllocationDetails.RecordDetails.Count == 0)
                    {
                        objAllocationDetails.ErrorMessage.Append(ErrorMessgae.No_Record_Found);
                        //objloginfo.Message = ErrorMessgae.No_Record_Found + System.DateTime.Now;
                        //objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    }
                    else
                    {
                        objAllocationDetails.ResultStatus = true;
                    }

                }
                else
                    objAllocationDetails.ErrorMessage.Append(ErrorMessgae.No_Record_Found);


                if (objAllocationDetails.AllocateToUsers != null)
                {
                    if (objAllocationDetails.AllocateToUsers.Count == 0)
                    {
                        objAllocationDetails.ErrorMessage.Append(ErrorMessgae.No_User_Found);
                        //objloginfo.Message = ErrorMessgae.No_User_Found + System.DateTime.Now;
                        //objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    }
                    else
                    {
                        objAllocationDetails.ResultStatus = true;
                    }

                }
                else
                    objAllocationDetails.ErrorMessage.Append(ErrorMessgae.No_User_Found);

                #region old validation
                //else
                //{
                //    if (objAllocationDetails.AllocationType == Constants.LIVEAUDIT || objAllocationDetails.AllocationType == Constants.REALLOCATION || objAllocationDetails.AllocationType == Constants.SYSTEMATIC || objAllocationDetails.AllocationType == Constants.FIFO)
                //    {

                //        foreach (TransListDetailsToAllocate item in objAllocationDetails.TransListDetailsToAllocate)
                //        {
                //            if (item.TransID == "" || item.TransID == "0")
                //            {
                //                flag = 1;
                //            }
                //        }
                //        foreach (AuditorsListDetails item in objAllocationDetails.AuditorsListDetails)
                //        {
                //            if (item.UserID == null || item.UserID == 0)
                //            {
                //                flag = 2;
                //            }
                //        }

                //        if (objAllocationDetails.SubProcessId == 0)
                //        {
                //            flag = 3;
                //        }
                //        if (objAllocationDetails.AllocaterId == 0)
                //        {
                //            flag = 4;
                //        }
                //        if (objAllocationDetails.AllocationType == "" || objAllocationDetails.AllocationType == null)
                //        {
                //            flag = 5;
                //        }
                //        if (objAllocationDetails.AllocationType == Constants.REALLOCATION || objAllocationDetails.AllocationType == Constants.LIVEAUDIT)
                //        {
                //            if (objAllocationDetails.AuditorsListDetails.Count > 1)
                //            {
                //                flag = 6;
                //            }
                //        }
                //        if (objAllocationDetails.AllocationType == Constants.FIFO )
                //        {
                //            if (objAllocationDetails.TotalVolume == 0)
                //            {
                //                flag = 7;
                //            }
                //        }
                //        if (flag == 1)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("RecordID is not provided in the Transaction Lists");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag == 2)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("AuditorID is not provided in the AuditorsListDetails");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag == 3)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("SubProcessID is not provided in the Lists");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag == 4)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("CreatedBy is not provided in the Lists");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag == 5)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("Allocation Type is not provided in the Lists");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag == 6)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("Only one AuditorID should be provided in the Lists for TL-Invoked, Live Audit, ReAllocation");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else if (flag ==7)
                //        {
                //            objAllocationDetails.ErrorMessage.Append("TotalVolume Needed for FIFO Allocation");
                //            objAllocationDetails.ResultStatus = false;
                //        }
                //        else
                //        {
                //            objAllocationDetails.ResultStatus = true;
                //        }
                //  }
                //else
                //{
                //    objAllocationDetails.ErrorMessage.Append("Input's are not in the standard format");
                //    objAllocationDetails.ResultStatus = false;
                //}

                // }
                #endregion


            }
            catch (NullReferenceException ex)
            {

                objAllocationDetails.ErrorMessage.Append(ErrorMessgae.InPut_NotInCorrectFormat);
                //objloginfo.Message = ex.ToString() + System.DateTime.Now;
                //objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            }

            return objAllocationDetails;
        }

    }
}
