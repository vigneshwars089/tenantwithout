﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :TLInvokedAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :TLInvokedAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added TLInvokedAllocation to Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class TLInvokedAllocation: BaseAllocation
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :TLInvokedAllocation.cs
        // Namespace : DigiOps.TechFoundation.Allocation
        // Method Name(s) :DoAllocate
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/27/2017
        // Purpose : Added TLInvokedAllocation to Allocation Component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //7-May-2017    Venkata Lakshmi CH.              DoAllocate             Modified DoAllocate method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public override string DoAllocate(AllocationListDetails TLDA)
        {
            BaseAllocation objBase = new BaseAllocation();
            AllocationListDetails objALD = new AllocationListDetails();

            /// Call Validation method
            objALD = objBase.AllocationValidation(TLDA);

           if (objALD.ResultStatus)
           {
            string rtnVal;
            AllocationDataAccess AllocationDA = new AllocationDataAccess();

            rtnVal = AllocationDA.InsertAllocatedTrans(TLDA);
            objALD.ErrorMessage.Append(rtnVal.ToString());
           }
           return objALD.ErrorMessage.ToString();
            
        }
    }
}
