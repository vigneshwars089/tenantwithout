﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class EmailResponceInfo : BaseInfo
    {
       public EmailResponceInfo()
       {
           CaseCreationInputList = new List<CaseCreationInput>();
       }
       public string Result { get; set; }
      // public StringBuilder ErrorMessage { get; set; }
       public List<CaseCreationInput> CaseCreationInputList { get; set; }
       public string CreationType { get; set; }
       public string Action { get; set; }
    }

   public class CaseCreationInput : EmailResponceInfo
    {         
          public DateTime ReceivedDate { get; set; }
          //public string MailFolderId { get; set; }
          public string Subject { get; set; }
          public string Message { get; set; }
          public string Sender { get; set; }
          public string Toadd { get; set; }
          public string CCaddress { get; set; }
          public string BCCaddress{ get; set; }
          public bool Priority { get; set; }
          public string GUID { get; set; }
          public string ScreenShotfileName { get; set; }//attachment is screenshot
          public string FileAttachmentName { get; set; }//attachment is FileAttachment
          public string ItemAttachmentFileName { get; set; }//attachment is ItemAttachment
          public byte[] MailFileAttachmentContentBytes { get; set; }
    }
}
