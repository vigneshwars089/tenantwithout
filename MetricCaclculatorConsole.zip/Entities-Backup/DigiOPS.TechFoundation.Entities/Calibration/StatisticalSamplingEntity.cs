﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Statistical Sampling Configuratoin Entity Class
    /// </summary>
    [Serializable]
    public class StatisticalSamplingEntity: BaseTransportEntity
    {
        public int SubProcessId { get; set; }
        public string SubProcessName { get; set; }
        public int ProgramId { get; set; }
        public int ProcessId { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }       
        public int SystemUserId { get; set; }       
        public bool IsActive { get; set; }
        public string ProgramName { get; set; }
        public string ProcessName { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedByName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedByName { get; set; }

        public string ConfidenceLevel { get; set; }
        public Nullable<decimal> SelectedConfidenceValue { get; set; }
        public string MarginError { get; set; }
        public Nullable<decimal> SelectedMarginErrorValue { get; set; }
        public string TotalPopulationCount { get; set; }
        public Nullable<decimal> DegofVariance { get; set; }
        public Nullable<decimal> ZScore { get; set; }
        public Nullable<decimal> DefectRate { get; set; }
        public Nullable<int> SampledCount { get; set; }
        public string RevisedSampleCount { get; set; }
        public Nullable<decimal> SamplingPct { get; set; }
        public Nullable<decimal> RevisedPct { get; set; }
        public Nullable<int> iFinalizedSampleCount { get; set; }
     
        public bool IsOverridePct { get; set; }      
        public Nullable<decimal> OverridePct { get; set; }     
        public string ActionType { get; set; }
        public bool IsEditMode { get; set; }       

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }

        public DateTime? SampleFrom { get; set; }
        public DateTime? SampleTo { get; set; }

        public Nullable<int> ResidualSampleCount { get; set; }
        public Nullable<decimal> ResidualSamplePct { get; set; }
        public int AuditTypeId { get; set; }
        public string SamplingTrailMonth { get; set; }
        public bool bIsAllocationPending { get; set; }
        public int iPartalCount { get; set; }
    }

    /// <summary>
    /// Statistical Sampling view Model
    /// </summary>
    public class StatisticalSamplingViewModel
    {
        /// <summary>
        /// Constructor for Statistical Sampling
        /// </summary>
        public StatisticalSamplingViewModel()
        {
            StatsSamplingList = new List<StatisticalSamplingEntity>();
            StatsSample = new StatisticalSamplingEntity();
            ConfidenceLevelList = new List<TransDropDown>();          
            MarginofErrorList = new List<TransDropDown>();        
            
        }

        public List<StatisticalSamplingEntity> StatsSamplingList { get; set; }
        public StatisticalSamplingEntity StatsSample { get; set; }
        public List<TransDropDown> ConfidenceLevelList { get; set; }      
        public List<TransDropDown> MarginofErrorList { get; set; }
        public string CustomErrorMessage { get; set; }
      

    }

    /// <summary>
    /// Statistical Sampling Confidence Level configure Class
    /// </summary>
    [Serializable]
    public class ConfidenceLevel
    {

        public int ConfidenceLevelId { get; set; }
        public string ConfidenceLvlName { get; set; }
        public Nullable<decimal> ConfidenceZValue { get; set; }      

    }
    /// <summary>
    /// Margin of Error Class
    /// </summary>
    [Serializable]
    public class MarginofError
    {
        public int MarginofErrorId { get; set; }
        public string MarginErrorName { get; set; }
        public Nullable<decimal> MarginErrorvalue { get; set; }        
    }

    /// <summary>
    /// SLA Category Class
    /// </summary>
    [Serializable]
    public class SLACategory
    {
        public int SLACategoryId { get; set; }
        public string SLACategoryName { get; set; }    

    }
    /// <summary>
    /// SLA Target Class
    /// </summary>
    [Serializable]
    public class SLATarget
    {
        public int SLATargetId { get; set; }
        public string SLATargetName { get; set; }
        public string SLATargetType { get; set; }
        public Nullable<decimal> SLATargetValue { get; set; }       
    }
    /// <summary>
    /// SLA Ref Number
    /// </summary>
    [Serializable]
    public class SLARefNumber {
        public int SLARefernceID { get; set; }
        public string SLAReferenceName { get; set; }      


    }

}
