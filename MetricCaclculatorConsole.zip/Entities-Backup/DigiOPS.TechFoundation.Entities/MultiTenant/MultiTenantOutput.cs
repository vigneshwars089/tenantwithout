﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class MultiTenantOutput : BaseInfo
    {
        //From tblTenantDBDetails
        public string ServerName { get; set; }
        public string DataBaseName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int TenantDBID { get; set; }

        //From tblQuartTenantmaster 
        public int TenantID { get; set; }

        public string Output { get; set; }
    }
}
