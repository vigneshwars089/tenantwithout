﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;



namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// RatingGroupEntity class
    /// </summary>
    //[Serializable]
    public class RatingGroupEntity : BaseTransportEntity
    {
        public int RatingId { get; set; }

        public string RatingDesc { get; set; }

        public string RatingDisplayName { get; set; }

        public int SubProcessId { get; set; }

        public bool blnNotApplicable { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime dsModifiedDate { get; set; }

        public int selectedProgramId { get; set; }

        public string selectedProgramName { get; set; }

        public int selectedProcessId { get; set; }

        public string selectedProcessName { get; set; }

        public int selectedSubProcessId { get; set; }

        public string selectedSubProcessName { get; set; }

        public bool IsEditMode { get; set; }

        public bool IsChecked { get; set; }

        public string strRatingGrpIds { get; set; }

        public string strRatingGrpIdValues { get; set; }
        public string strRatingNAListss { get; set; }
        public string action { get; set; }

        public bool IsDropdownlist { get; set; }

        public int ValidNA { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }
    public class Transddrat : RatingGroupEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }

    /// <summary>
    /// RatingGroupViewModel class
    /// </summary>
    //public class RatingGroupViewModel : BaseTransportEntity
    //{
    //    /// <summary>
    //    /// Rating Group view model
    //    /// </summary>
    //    /// <returns></returns>
    //    public RatingGroupViewModel()
    //    {


    //        RatingGroupList = new List<RatingGroupEntity>();
    //        RatingGroup = new RatingGroupEntity();
    //        RatingList = new List<RatingEntity>();
    //    }

    //    public List<SelectListItem> ProgramList { get; set; }
    //    public List<SelectListItem> ProcessList { get; set; }
    //    public List<SelectListItem> SubprocessList { get; set; }


    //    public List<RatingEntity> RatingList { get; set; }

    //    public List<RatingGroupEntity> RatingGroupList { get; set; }
    //    public RatingGroupEntity RatingGroup { get; set; }

    //}


}
