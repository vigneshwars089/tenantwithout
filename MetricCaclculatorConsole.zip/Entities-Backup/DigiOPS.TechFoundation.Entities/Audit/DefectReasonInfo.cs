﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class DefectReasonInfo
    {
        public string DefectReasonName { get; set; }
        public string DefectReasonDescription { get; set; }

        public string DefectReasonLevelNo { get; set; }


        public string DefectReasonParentName { get; set; }


        public string DefectReasonLevelParentNo { get; set; }
    }
}
