﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DigiOPS.TechFoundation.Entities
{
    public struct S_AppID1
    {
        public const string QUART = "QUART";
        public const string AUDIT = "AUDIT";
        public const string LIVEWORKS = "LIVEWORKS";
        public const string PRODUCTION = "PRODUCTION";

    }

    [Serializable]
    public class UserManagementDetails : BaseInfo
    {
        public string CognizantId { get; set; }
        public string ClientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int RoleId { get; set; }
        public string Role { get; set; }
        public string Roles { get; set; }
        public string CognizantEmailId { get; set; }
        public int ShiftId { get; set; }
        public string ShiftTiming { get; set; }
        public int ProcessId { get; set; }
        public string ProcessIds { get; set; }
        public string ProcessName { get; set; }
        public int TeamId { get; set; }
        public int TLUserId { get; set; }



        public int SystemUserId { get; set; }
        public string CtsUserId { get; set; }
        public string ClientUserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int TotalCount { get; set; }
        public int ErrorCount { get; set; }
        public string UploadType { get; set; }
        public string ErrorLogPath { get; set; }
        public bool IsUserSearch { get; set; }
        public string eventAction { get; set; }

    }

    public class GenericParameter
    {
        public string ParameterName { set; get; }
        public DbType Type { get; set; }
        public int Size { get; set; }
        public object Value { get; set; }
        public ParameterDirection Direction { set; get; }
    }

    public static class TracWorkConstants
    {
        public const string DBParameter_Purpose = "@param_Purpose";
        public const string DBParameter_ClientId = "@param_ClientId";
        public const string DBParameter_ProcessId = "@param_ProcessId";
        public const string DBParameter_ProcessIds = "@param_ProcessIds";
        public const string DBParameter_AssociateId = "@param_AssociateId";
        public const string DBParameter_FirstName = "@param_FirstName";
        public const string DBParameter_LastName = "@param_LastName";
        public const string DBParameter_EmailId = "@param_EmailId";
        public const string DBParameter_RoleIds = "@param_RoleIds";
        public const string DBParameter_TeamId = "@param_TeamId";
        public const string DBParameter_Return = "@param_Return";
        public const string DBParameter_TLUserId = "@param_TLUserId";
        public const string DBParameter_LoginId = "@param_LoginId";
        public const string SP_SET_UserDetails = "USP_Set_UserDetails";

    }
    public class User : BaseTransportEntity
    {
        public int SystemUserId { get; set; }
        public string CtsUserId { get; set; }
        public string ClientUserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }
    public class BaseTransportEntity : BaseInfo
    {
        public string SessionId { get; set; }
        public int Id { get; set; }
        public int CurrentUserID { get; set; }
        public int CurrentUserRoleID { get; set; }
        public int _ProgramID { get; set; }
        public int _ProcessID { get; set; }
        public int _SubProcessID { get; set; }
        public string ViewName { get; set; }
        public string EntityName { get; set; }
        public string eventAction { get; set; }
        public string _ProcessedDate { get; set; }
        public string _ProcessedFromDate { get; set; }
        public string _ProcessedToDate { get; set; }
        public string _ReceivedDate { get; set; }
        public int iSubCategoryId { get; set; }
        public string ExtAuditTypeName { get; set; }
        public int _StartRowIndex { get; set; }
        public int _MaximumRows { get; set; }
        public string _SortOrder { get; set; }
        public string _SortColumn { get; set; }
        public int? _TotalRows { get; set; }
        public string ReturnValue { get; set; }
        public bool bIsEmpNeeded { get; set; }
        public bool bIsLineNeeded { get; set; }
        public bool bIsLineApplicable { get; set; }
        public bool IsPeerCheckerReq { get; set; }
        public bool bIsSLAActivityApplicable { get; set; }
        public bool IsReadonDDL { get; set; }
        public bool isBusiAutoAllocationSamplingRequired { get; set; }
        public bool isExternalAutoAllocationSamplingRequired { get; set; }
        public int _ElementCount { get; set; }
        public string NoofLineReuired { get; set; }


        public bool bIsExternalAudit { get; set; }
        public int ReportID { get; set; }
        public int RatingDifferenceCount { get; set; }

        /// <summary>
        /// AddUSer 
        /// </summary>

        public int SystemUserId { get; set; }
        public string CtsUserId { get; set; }
        public string ClientUserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int TotalCount { get; set; }
        public int ErrorCount { get; set; }
        public string UploadType { get; set; }
        public string ErrorLogPath { get; set; }
        public bool IsUserSearch { get; set; }


        //-userROlemapping

        public int iUserGroupId { get; set; }
        public string szUserGroupName { get; set; }
        public int iUserGroupMapId { get; set; }
        public int iUserGroupRoleMapId { get; set; }
        public int iSystemUserId { get; set; }
        public string szProgram { get; set; }
        public string szUserName { get; set; }
        public string szCtsUserId { get; set; }
        public int iRoleId { get; set; }
        public string UserList { get; set; }
        public string szRoles { get; set; }
        public int iCreatedBy { get; set; }
        //    public bool IsActive { get; set; }
        public int iModifiedBy { get; set; }
        public int SelectedProgramID { get; set; }
        public int ProgramID { get; set; }
        public string UsersSearchText { get; set; }
        //     public bool IsUserSearch { get; set; }
        public int SelectedUserGroupID { get; set; }
        public int SelectedUserID { get; set; }
        private bool selectedUserRoleID = false;

        public bool SelectedUserRoleID
        {
            get { return selectedUserRoleID; }
            set { value = selectedUserRoleID; }
        }
        public string[] Users { get; set; }
        public string[] Roles { get; set; }
        public int LevelID { get; set; }
        //     public int? StartRowIndex { get; set; }
        //     public int? MaximumRows { get; set; }
        //     public int? TotalRows { get; set; }
        //     public string SortOrder { get; set; }
        //      public string SortColumn { get; set; }

        //    public string CreatedBy { get; set; }
        //    public DateTime CreatedDate { get; set; }
        //    public string ModifiedBy { get; set; }
        //    public DateTime ModifiedDate { get; set; }

    }


    public class RolePermissionMapping : BaseTransportEntity
    {
        public int iUserGroupId { get; set; }
        public string szUserGroupName { get; set; }
        public int iUserGroupMapId { get; set; }
        public int iSystemUserId { get; set; }
        public string szUserName { get; set; }
        public string[] Roles { get; set; }
        public string[] Permissions { get; set; }
        public string PermissionIDs { get; set; }
        public string szCtsUserId { get; set; }
        public int RoleID { get; set; }
        public string szRoles { get; set; }
        public int iCreatedBy { get; set; }
        public int iPermissionMappingID { get; set; }
        public int iRolePermissionMappingId { get; set; }
        public TransDropDown[] PermissionList { get; set; }
        public int iPermissionId { get; set; }
        public string SubProcessName { get; set; }
        public string RoleName { get; set; }
        public string PermissionName { get; set; }
        public bool Active { get; set; }
        public int iUserGroupRoleMapId { get; set; }
        public string szPermissions { get; set; }
        public int iModifiedBy { get; set; }
        public int SelectedProgramID { get; set; }
        public int SelectedProcessID { get; set; }
        public int SelectedSubProcessID { get; set; }
        public int ProgramID { get; set; }
        public int ProcessID { get; set; }
        public int SubProcessID { get; set; }
        public int SelectedUserGroupID { get; set; }
        public int SelectedUserID { get; set; }

        private bool selectedUserRoleID = false;
        private bool selectedUserRolePermissionID = false;

        public bool SelectedUserRoleID
        {
            get { return selectedUserRoleID; }
            set { value = selectedUserRoleID; }
        }

        public bool SelectedUserRolePermissionID
        {
            get { return selectedUserRolePermissionID; }
            set { value = selectedUserRolePermissionID; }
        }
        public int LevelID { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    //public class TransDropDown : BaseTransportEntity
    //{
    //    public Boolean IsSelected { get; set; }
    //    public Boolean IsNA { get; set; }
    //    public string Text { get; set; }
    //    public string Value { get; set; }
    //    public string Score { get; set; }
    //    public string ForeignKey { get; set; }
    //    public string TempId { get; set; }
    //    public string criticality { get; set; }
    //}

    public class AddUser : BaseTransportEntity
    {
        public int SystemUserId { get; set; }
        public string CtsUserId { get; set; }
        public string ClientUserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int TotalCount { get; set; }
        public int ErrorCount { get; set; }
        public string UploadType { get; set; }
        public string ErrorLogPath { get; set; }
        public bool IsUserSearch { get; set; }

    }
    public class GroupUser : BaseTransportEntity
    {
        public int UserGroupMapID { get; set; }
        public int UserGroupID { get; set; }
        public string UserGroupName { get; set; }
        public int ProgramID { get; set; }
        public string ProgramName { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string SubprocessID { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsSaved { get; set; }
        public string SelectedProgramId { get; set; }
        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public DateTime dsCreatedDate { get; set; }
        public DateTime dsModifiedDate { get; set; }
    }
    public class GroupUserMapping : BaseTransportEntity
    {
        public int UserGroupMapID { get; set; }
        public int UserGroupID { get; set; }
        public string UserGroupName { get; set; }
        public int ProgramID { get; set; }
        public string ProgramName { get; set; }
        public int SysUserID { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string UserList { get; set; }
        public string SelectedUserList { get; set; }
        public string[] Users { get; set; }
        public TransDropDown[] SystemUsers { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsSaved { get; set; }
        public string SelectedProgramId { get; set; }
        public string SelectedUserID { get; set; }
        public string SelectedUserGroupID { get; set; }

        public string UsersSearchText { get; set; }
        public bool IsUserSearch { get; set; }

        public bool IsEditMode { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public DateTime dsCreatedDate { get; set; }
        public DateTime dsModifiedDate { get; set; }
    }
    public class UserRoleMapping : BaseTransportEntity
    {
        public int iUserGroupId { get; set; }
        public string szUserGroupName { get; set; }
        public int iUserGroupMapId { get; set; }
        public int iUserGroupRoleMapId { get; set; }
        public int iSystemUserId { get; set; }
        public string szProgram { get; set; }
        public string szUserName { get; set; }
        public string szCtsUserId { get; set; }
        public int iRoleId { get; set; }
        public string UserList { get; set; }
        public string szRoles { get; set; }
        public int iCreatedBy { get; set; }
        public bool IsActive { get; set; }
        public int iModifiedBy { get; set; }
        public int SelectedProgramID { get; set; }
        public int ProgramID { get; set; }
        public string UsersSearchText { get; set; }
        public bool IsUserSearch { get; set; }
        public int SelectedUserGroupID { get; set; }
        public int SelectedUserID { get; set; }
        private bool selectedUserRoleID = false;

        public bool SelectedUserRoleID
        {
            get { return selectedUserRoleID; }
            set { value = selectedUserRoleID; }
        }
        public string[] Users { get; set; }
        public string[] Roles { get; set; }
        public int LevelID { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

}


