﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// CodesEntity class
    /// </summary>
    [Serializable]
    public class CodesEntity : BaseInfo
    {
        public int CodeId { get; set; }
        public string CodeDesc { get; set; }
        public string DisplayName { get; set; }
        public string CodeValue { get; set; }
        public int SequenceNo { get; set; }
        public string CodeGroupId { get; set; }
        public string ParentGroupId { get; set; }
        public int Level { get; set; }
        public Boolean isActive { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public string ElementID { get; set; }
        public string ElementName { get; set; }
        public Boolean IsEditMode { get; set; }
        public string CodeNameValue { get; set; }
        public string eventAction { get; set; }
    }

    /// <summary>
    /// CodeGroupEntity
    /// </summary>
    [Serializable]
    public class CodeGroupEntity : BaseInfo
    {
        public string ElementID { get; set; }
        public string ElementName { get; set; }
        public string CodeGrpId { get; set; }
        public List<CodesEntity> CodeGroupList { get; set; }
    }
    /// <summary>
    /// CodesEntityViewModel class
    /// </summary>
    public class CodesEntityViewModel
    {
        /// <summary>
        /// CodesEntityViewModel constructor
        /// </summary>
        public CodesEntityViewModel()
        {
            DataList = new List<CodesEntity>();
            ListItem = new CodesEntity();
        }

        public List<CodesEntity> DataList { get; set; }
        public CodesEntity ListItem { get; set; }
        public string CustomErrorMessage { get; set; }
    }
}
