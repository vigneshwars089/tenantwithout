﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
namespace DigiOPS.TechFoundation.Entities
{
    public class DataElementInfo:BaseInfo
    {
        public int ProgramId { get; set; }
        public int ProcessId { get; set; }
        public int SubProcessId { get; set; }
        public string ViewName { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }

    public class Template:BaseInfo
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public string SubProcessId { get; set; }
        public string CurrentUserID { get; set; }
        public int ProgramID { get; set; }
        public byte[] FileContent { get; set; }
        public string RestrictedNames { get; set; }
        public int ECnt { get; set; }
        public string Errorpath { get; set; }
        //public string AppID { get; set; }

    }


    public class MemoryFile : HttpPostedFileBase
    {
        Stream stream;
        string contentType;
        string fileName;

        public MemoryFile(Stream stream, string contentType, string fileName)
        {
            this.stream = stream;
            this.contentType = contentType;
            this.fileName = fileName;
        }

        public override int ContentLength
        {
            get { return (int)stream.Length; }
        }

        public override string ContentType
        {
            get { return contentType; }
        }

        public override string FileName
        {
            get { return fileName; }
        }

        public override Stream InputStream
        {
            get { return stream; }
        }

        public override void SaveAs(string filename)
        {
            using (var file = File.Open(filename, FileMode.CreateNew))
                stream.CopyTo(file);
        }
    }
}
