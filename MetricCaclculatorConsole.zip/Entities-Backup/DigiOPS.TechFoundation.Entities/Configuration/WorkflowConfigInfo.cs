﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class WorkflowConfigInfo:BaseInfo
    {
        public int SubProcessId { get; set; }
    }
}
