function DrawDonutChart(result) {
              var r_data = result;
              nv.addGraph(function () {
                  var donutChart = nv.models.pieChart()
                        .x(function (d) { return d.Name })
                        .y(function (d) { return d.Count })
                         //.legendPosition("right")
                        .showLabels(true)
                        //.labelThreshold(.01)
                        .labelType(function (d, i) { return d.data.Count; })
                        //.labelType("value")
                        .padAngle(0)
                        .cornerRadius(0)
                        .color(["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"])
                        .donut(true)
                        .labelsOutside(false)
                        .donutRatio(0.5)
                        .width(450)
                        .height(450)
                        .showLegend(true)
                       .title("Work Items")
                        .id('test1');

                  donutChart.tooltip.contentGenerator(function (d) {
                      var html = "<B>" + d.data.Name + ":" + d.data.Count + "</B>";
                      return html;
                  })

                  d3.select("#chart svg")
                    .datum(r_data)
                    .transition().duration(600)
                    .call(donutChart);
                  donutChart.pie.dispatch.on("elementClick", function (e) {
                      var Statusid = e.data.Name;
                  });

                  $('#test1').css({ "font-family": "Segoe UI", "font-size": "14px" });//, "width": "500px" });

                  $('.nv-pie-title').css({ "font-size": "24px" });//, "width": "500px" });

                  return donutChart;
              });
  }


var chart2;
function DrawStackedbarchart(result)
{
              var chart;
              nv.addGraph(function ()
              {
                  chart = nv.models.multiBarHorizontalChart()
                      .x(function (d) { return d.label })
                      .y(function (d) { return d.value })
                      .color(["#1f77b4", "#2ca02c", "#d62728", "#bcbd22", "#e377c2", "#6D8E41", "#4E652E", "#2F3C1B", "#9dcb5d", "#17becf", "#1f77b4", "#2f59dd", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#7f7f7f"])
                      .margin({ left: 125 })
                      .showControls(true)
                      .stacked(true)

                  chart.yAxis.tickFormat(d3.format(', 2f'));//.2f'));

                  d3.select('#chart svg')
                      .datum(result)
                      .call(chart);

                  nv.utils.windowResize(chart.update);

                  chart.dispatch.on('stateChange', function (e) { nv.log('New State:', JSON.stringify(e)); });
                  chart.state.dispatch.on('change', function (state) {
                      nv.log('state', JSON.stringify(state));
                  });
                  return chart;
              });
      $('#test2').css({ "height": "540px", "width": "430px" });
  }
