﻿
using DigiOPS.TechFoundation.MetricCalculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetricCaclculatorConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal = new Calculator();           
             object result=   TestUtilization();
            Console.WriteLine(result);
        }

        private static object TestUtilization()
        {
            Program ps = new Program();
            MetricTransactionMappingInfo formulaMapinfo = new MetricTransactionMappingInfo();
            formulaMapinfo.MetricParamFieldsMappings = new List<MetricParamMappingInfo>();
            ProcessTransactionInfo transactionifno = new ProcessTransactionInfo();
            transactionifno.ProductiveHRs = 6;
            transactionifno.loggedInHrs = 2;
            transactionifno.HT = 2;
            transactionifno.AuxHRs = 2;
            transactionifno.TotalProductiveHRs = 40;
            transactionifno.Processedby = "test";
            transactionifno.ProcessedOn = "test";
            //formulaMapinfo.Formula = "x+y+z";
            MetricParamMappingInfo testobj = new MetricParamMappingInfo();
            testobj.Index = 1;
            testobj.MetricParameterName = "Actuals";
            testobj.MetricParamFields = new List<DigiOPS.TechFoundation.MetricCalculator.MetricParamFieldInfo>();
            testobj.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "TotalProductiveHRs", ParameterFieldValue = transactionifno.TotalProductiveHRs });

            MetricParamMappingInfo testobj1 = new MetricParamMappingInfo();
            testobj1.Index = 2;
            testobj1.MetricParameterName = ConstMathfunction.Divide;
            testobj1.MetricParamFields = new List<DigiOPS.TechFoundation.MetricCalculator.MetricParamFieldInfo>();
            testobj1.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = ConstMathfunction.Divide, ParameterFieldValue = 0 });

            MetricParamMappingInfo testobj2 = new MetricParamMappingInfo();
            testobj2.Index = 3;
            testobj2.MetricParameterName = "Targeted";
            testobj2.MetricParamFields = new List<DigiOPS.TechFoundation.MetricCalculator.MetricParamFieldInfo>();           
            testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "ProdcutiveHRs", ParameterFieldValue = transactionifno.ProductiveHRs });
           


            formulaMapinfo.MetricParamFieldsMappings.Add(testobj);
            formulaMapinfo.MetricParamFieldsMappings.Add(testobj1);
            formulaMapinfo.MetricParamFieldsMappings.Add(testobj2);
            IMetricfactory obj = new Metricfactory();
            object result = ps.Calculate(formulaMapinfo, transactionifno);
                //obj.GetMetrics(MetricTypes.Availability).Calculate(formulaMapinfo, transactionifno);
            return result;

        }
        public  object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
          Calculator cal = new Calculator();
            double nominator = 0.0;
            double denominator = 0;         
           
            formulaMapinfo.MetricName = "Utilization";
            formulaMapinfo.Formula = "Actuals/Targeted";

            if (formulaMapinfo != null && transactionifno!=null)
            {
                MetricParamMappingInfo TotalTasks_CompletionTime = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "Actuals");
                if (TotalTasks_CompletionTime.MetricParamFields.Count == 1)
                {
                    nominator = TotalTasks_CompletionTime.MetricParamFields[0].ParameterFieldValue;
                }

                MetricParamMappingInfo TaskCount_inQueue = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "Targeted");

                if (TaskCount_inQueue.MetricParamFields.Count == 1)
                {
                    denominator = TaskCount_inQueue.MetricParamFields[0].ParameterFieldValue;
                }


                return cal.Divide(nominator, denominator);
            }
            return 0.0;
        }
    }
}
