﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DigiOPS.TechFoundation.Sampling;
using DigiOPS.TechFoundation.Calibration;
using DigiOPS.TechFoundation.CalibrationAudit;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.WebAPI.Controllers
{
    public class SamplingController : ApiController
    {
        [HttpGet]
        public List<TransactionLists> GetSampingDetails(string Actor, string Duration, string Type, TransactionListDetails objTransListDetails)
        {
            try
            {
                SamplingFactory objSamplingFactory = new SamplingFactory();
                TransactionListDetails tld = new TransactionListDetails();
                List<TransactionLists> tldlst = new List<TransactionLists>();
                List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
                List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
                TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
               tal.Add(talR);
             talR = new TransactionsAllocatedLists();
               tal.Add(talR);
                      
               TransactionLists objlist = new TransactionLists();
                objlist = new TransactionLists();
                tldlst.Add(objlist);

                objlist = new TransactionLists();
               tldlst.Add(objlist);


                objlist = new TransactionLists();
                tldlst.Add(objlist);

                objlist = new TransactionLists();
                 tldlst.Add(objlist);
                objlist = new TransactionLists();
                tldlst.Add(objlist);

                objlist = new TransactionLists();
                tldlst.Add(objlist);


                objlist = new TransactionLists();
                 tldlst.Add(objlist);
                tld.TransactionLists = tldlst;
                tld.TransactionAllocatedLists = tal;
               
                 tld = objSamplingFactory.GetSampingDetails("SubProcess", "Daily", "Stratified", tld);
            tldlst = tld.TransactionLists; 
        return tldlst;
            }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
    }
}
