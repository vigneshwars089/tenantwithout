﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DigiOPS.TechFoundation.Calibration.Interface;
using DigiOPS.TechFoundation.Calibration;
using DigiOPS.TechFoundation.Entities;
using System.Data;
using System.Xml;
using System.IO;



//using System.Text;
//using System.Threading.Tasks;
////using Newtonsoft.Json;
//using DigiOPS.TechFoundation.Security;
//using DigiOPS.TechFoundation.DataTransfer;
//using DigiOPS.TechFoundation.Entities;
//using System.Data;
//using DigiOPS.TechFoundation.Calibration.MasterCalibrator;
//using DigiOPS.TechFoundation.Calibration.Interface;

namespace DigiOPS.WebAPI.Controllers
{
    public class CalibrationController : ApiController
    {

        /// <summary>
        /// API to get list of calibrators
        /// </summary>
        /// <param name="MCE"></param>
        /// <returns></returns>
        /// 
        [HttpGet]
        public List<MasterCalibratorEntity> GetController()//int SelectedSubProcessId
        {
            try
            {
                MasterCalibratorEntity MCE = new MasterCalibratorEntity();
               // MCE.SelectedSubProcessId = SelectedSubProcessId;
                MCE.SelectedSubProcessId = 43;
                //MasterCalibratorEntity lstMCE = new MasterCalibratorEntity();
                List<MasterCalibratorEntity> lstMCE = new List<MasterCalibratorEntity>();
              
                IMasterCalibratorAllocation MCT = new MasterCalibratorTransaction();
                lstMCE = MCT.MapCalibrators(MCE);
                return lstMCE;
            }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
 
        }
         /// <summary>
        /// API to Assign Record to the Calibrator
        /// </summary>
        /// <param name="MCE"></param>
        /// <returns></returns>
        [HttpGet]
        public string SubmitCalibrators()//MasterCalibratorEntity objMasterCalibrator
        {
            try
            {
              MasterCalibratorEntity MCE = new MasterCalibratorEntity();
              MCE.SelectedSubProcessId = 43;
              MCE.szCalibrators = "1354,324";
              MCE.RecordIds = "111460";
              MCE.SystemUserId = 936;
            
                ////List<MasterCalibratorEntity> BEL = new List<MasterCalibratorEntity>();
                IMasterCalibratorAllocation MCT = new MasterCalibratorTransaction();
                MCT.SubmitCalibrators(MCE);
                ////Console.WriteLine(MCE);

                //Console.WriteLine(MCE.createRecVal);
                //Console.ReadLine();
                return MCE.createRecVal;
            }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //public List<TransactionListViewModalList> GetTransactionList(SearchElementConfigViewModel objBase)
         [HttpGet]
        public List<TransactionListViewModalList> GetTransactionList()       
    {
            SearchElementConfigViewModel objBase = new SearchElementConfigViewModel();
            IMasterCalibratorAllocation mct = new MasterCalibratorTransaction();
            //SearchElementConfigViewModel search = new SearchElementConfigViewModel();

            XmlDocument doc = new XmlDocument();

            doc.LoadXml("<root><SearchElementConfigViewModel  >  <Id>0</Id>  <CurrentUserID>936</CurrentUserID>  <CurrentUserRoleID>11</CurrentUserRoleID>  <_ProgramID>0</_ProgramID>  <_ProcessID>0</_ProcessID>  <_SubProcessID>43</_SubProcessID>  <eventAction>GetSearchList</eventAction>  <_ProcessedFromDate>02/01/2017</_ProcessedFromDate>  <_ProcessedToDate>02/15/2017</_ProcessedToDate>  <iSubCategoryId>0</iSubCategoryId>  <_StartRowIndex>1</_StartRowIndex>  <_MaximumRows>10</_MaximumRows>  <_SortOrder>DESC</_SortOrder>  <_SortColumn>iRecordID</_SortColumn>  <_TotalRows>0</_TotalRows>  <bIsEmpNeeded>false</bIsEmpNeeded>  <bIsLineNeeded>false</bIsLineNeeded>  <iSubcategory>0</iSubcategory>  <bIsLineApplicable>false</bIsLineApplicable>  <IsPeerCheckerReq>false</IsPeerCheckerReq>  <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>  <IsReadonDDL>false</IsReadonDDL>  <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>  <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>  <_ElementCount>0</_ElementCount>  <bIsExternalAudit>false</bIsExternalAudit>  <bIsExternalAuditAuto>false</bIsExternalAuditAuto>  <ReportID>0</ReportID>  <RatingDifferenceCount>0</RatingDifferenceCount>  <ProcessedFromDate>02/01/2017</ProcessedFromDate>  <ProcessedToDate>02/15/2017</ProcessedToDate>  <RecordId>0</RecordId>  <SearchTransactionList>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>156</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>157</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>158</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>159</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>160</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>161</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>162</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>163</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>164</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>165</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>166</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>167</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>168</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>169</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>  </SearchTransactionList>  <NoofLines>0</NoofLines></SearchElementConfigViewModel></root>");
            StringWriter sw = new StringWriter();
            XmlTextWriter tx = new XmlTextWriter(sw);
            doc.WriteTo(tx);
            sw.ToString();
            DateTime ds = new DateTime();
            ds = Convert.ToDateTime("02/01/2017"); ;
            objBase.ProcessedFromDate = ds;
            objBase.ProcessedToDate = "02/15/2017";
            objBase._ReceivedDate = "";

            XmlDocument doc1 = new XmlDocument();

            doc.LoadXml("<root>  <xmlArguments iRecordId='0' iSubProcessId='43' StartRowIndex='1' MaximumRows='10' SortOrder='DESC' SortColumn='Record ID' SearchedBy='936' /></root>");
            StringWriter sw1 = new StringWriter();
            XmlTextWriter tx1 = new XmlTextWriter(sw1);
            doc.WriteTo(tx);
            sw1.ToString();
            List<TransactionListViewModalList> list = new List<TransactionListViewModalList>();
            list = mct.GetTrasnsactionList(objBase);
            return list;
        }
        //[HttpGet]
        //public List<AuditTransactionListViewModal> GetAuditTransactionList(AuditTransactionListViewModal objBase)
        //{
        //    List<AuditTransactionListViewModal> atl = new List<AuditTransactionListViewModal>();

        //    return atl;
        //}
     
    

    }
}
