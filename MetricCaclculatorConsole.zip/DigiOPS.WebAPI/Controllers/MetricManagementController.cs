﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.WebAPI.Controllers
{
    public class MetricManagementController : ApiController
    {
        [HttpPost]
        public ScoringOutput CalculateQualityScore(ScoringInfo objAuditDataEntity)//ScoringInfo objAuditDataEntity
        {
            try
            {
                ScoringInfo ad = new ScoringInfo();
               List<DetailsEntity> lstComb = new List<DetailsEntity>();
                DetailsEntity adComb = new DetailsEntity();
                lstComb.Add(adComb);
                adComb.AuditedList = lstComb;
                ScoringOutput so = new ScoringOutput();
                IScoringAlgorithmFactory isaf = new ScoringAlgorithmFactory();
                so = isaf.GetScoringHandler(ad).Validation(ad);
                  
                return so;
            }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

    }
}
