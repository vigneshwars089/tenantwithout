﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DigiOPS.TechFoundation.WebAPI.Models
{
    public class CaseHandleModel
    {

        public List<Cases> CasesList { get; set; }    
        [JsonProperty("CaseCreationDateTime")]
        public DateTime CaseCreationDateTime { get; set; }
        public List<Security> SecurityList { get; set; }


    }
     public class Cases{
          
         public string ID { get; set; }
         public string Value { get; set; }
         public bool IsList { get; set; }
         public string MultipleValues { get; set; }
         
         
    }
     public class Security
     {
          
         public string ID { get; set; }
         public string Value { get; set; }
          
        
     }

     public class CaseHandlingEntities : DbContext
     {
         public DbSet<CaseHandleModel> Objcasehandling { get; set; }
     } 
}