﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ExceptionHandling
{
    public class ProductionException : BaseException
    {
         public ProductionException()
        {

        }

        /// <summary>
        /// Custom Exception Constructor with message
        /// </summary>
        /// <param name="message">string</param>
        public ProductionException(string message) : base(message)
        {
            this.customMessage = message;
        }

        /// <summary>
        /// Custom Exception Constructor with message and inner exception
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="inner">Exception</param>
        public ProductionException(string message, Exception inner)
            : base(message, inner)
        {
            this.customMessage = message;
            this.innerException = inner;
        }
    }
}
