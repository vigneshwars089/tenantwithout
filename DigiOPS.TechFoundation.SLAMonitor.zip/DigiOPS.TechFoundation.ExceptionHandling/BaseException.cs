﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DigiOPS.TechFoundation.ExceptionHandling
{
    public abstract class BaseException : Exception
    {
        protected Exception innerException;
        /// <summary>
        /// Custom Message 
        /// </summary>
        protected string customMessage;
        /// <summary>
        /// Public accessor of customMessage
        /// </summary>
        public string CustomMessage
        {
            get { return this.customMessage; }
            set { this.customMessage = value; }
        }
        public BaseException()
        {

        }

        /// <summary>
        /// Custom Exception Constructor with message
        /// </summary>
        /// <param name="message">string</param>
        public BaseException(string message) : base(message)
        {
            this.customMessage = message;
        }

        /// <summary>
        /// Custom Exception Constructor with message and inner exception
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="inner">Exception</param>
        public BaseException(string message, Exception inner)
            : base(message, inner)
        {
            this.customMessage = message;
            this.innerException = inner;
        }
    }
}
