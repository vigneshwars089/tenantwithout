﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public sealed class DBHelper
    {
       // UserSession UserData = new UserSession();
        //UserErrorLog errorlog = new UserErrorLog();
        
        //public Database Db
        //{
        //    get { return DatabaseFactory.CreateDatabase("ConnStr"); }
        //}
        public Database Db = DatabaseFactory.CreateDatabase("ConnStr");

        public DBHelper(string connectionstring)
        {
            Db = DatabaseFactory.CreateDatabase(connectionstring);

        }

        public DBHelper()
        {
            Db = DatabaseFactory.CreateDatabase("ConnStr");

        }


        /// <summary>
        /// Converts hash table to object array
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private void AddParameter(ref DbCommand command, Hashtable values)
        {
            try
            {
                foreach (string key in values.Keys)
                {
                    object obj = DBNull.Value;
                    if (values[key].ToString() == "" || values[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = values[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), obj));
                }
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | AddParameter()");

            }

        }
        /// <summary>
        /// Converts hash table to object array, xmlvalues
        /// </summary>
        /// <param name="command"></param>
        /// <param name="values"></param>
        /// <param name="xmlValues"></param>
        private void AddParameter(ref DbCommand command, Hashtable values, Hashtable xmlValues)
        {
            try
            {
                foreach (string key in values.Keys)
                {
                    object obj = DBNull.Value;
                    if (values[key].ToString() == "" || values[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = values[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), obj));
                }
                foreach (string key in xmlValues.Keys)
                {
                    object obj = DBNull.Value;
                    if (xmlValues[key].ToString() == "" || xmlValues[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = xmlValues[key];

                    command.Parameters.Add(new SqlParameter(key, SqlDbType.Xml)
                    {
                        Value = new SqlXml(new XmlTextReader(obj.ToString(), XmlNodeType.Document, null))
                    });
                }
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | AddParameter()");

            }

        }
        /// <summary>
        /// Converts hash table to object array, xmlvalues and outputvalues
        /// </summary>
        /// <param name="command"></param>
        /// <param name="values"></param>
        /// <param name="xmlValues"></param>
        /// <param name="outputValues"></param>
        private void AddParameter(ref DbCommand command, Hashtable values, Hashtable xmlValues,Hashtable outputValues)
        {
            try
            {
                foreach (string key in values.Keys)
                {
                    object obj = DBNull.Value;
                    if (values[key].ToString() == "" || values[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = values[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), obj));
                }
                foreach (string key in xmlValues.Keys)
                {
                    object obj = DBNull.Value;
                    if (xmlValues[key].ToString() == "" || xmlValues[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = xmlValues[key];

                    command.Parameters.Add(new SqlParameter(key, SqlDbType.Xml)
                    {
                        Value = new SqlXml(new XmlTextReader(obj.ToString(), XmlNodeType.Document, null))
                    });
                }
                foreach (string key in outputValues.Keys)
                {
                    object obj = DBNull.Value;
                    if (outputValues[key].ToString() == "" || outputValues[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = outputValues[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), ParameterDirection.Output));
                }
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | AddParameter()");

            }

        }
        /// <summary>
        /// Returns multiple records from database with output values
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="values"></param>
        /// <param name="xmlValues"></param>
        /// <param name="outputValues"></param>
        /// <returns></returns>
        public DataSet SelectDataSet(string spName, Hashtable values, Hashtable xmlValues,Hashtable outputValues)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    DataSet ds = new DataSet();
                    DbCommand command = this.Db.GetStoredProcCommand(spName);
                    command.CommandTimeout = 0;
                    AddParameter(ref command, values, xmlValues,outputValues);
                    ds = this.Db.ExecuteDataSet(command);
                    return ds;
                }
                catch (Exception ex)
                {
                    // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataSet()");
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public DataSet SelectDataSet(string spName, Hashtable values,Hashtable xmlValues)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    DataSet ds = new DataSet();
                    DbCommand command = this.Db.GetStoredProcCommand(spName);
                    command.CommandTimeout = 0;
                    AddParameter(ref command, values,xmlValues);
                    ds = this.Db.ExecuteDataSet(command);
                    return ds;
                }
                catch (Exception ex)
                {
                    // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataSet()");
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        /// <summary>
        /// Returns multiple records from database
        /// </summary>
        /// <param name="SPName"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public DataSet SelectDataSet(string spName, Hashtable values)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    DataSet ds = new DataSet();
                    DbCommand command = this.Db.GetStoredProcCommand(spName);
                    command.CommandTimeout = 0;
                    AddParameter(ref command, values);
                    ds = this.Db.ExecuteDataSet(command);
                    return ds;
                }
                catch (Exception ex)
                {
                   // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataSet()");
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        /// <summary>
        /// Returns multiple records from database no parameter passed
        /// </summary>
        /// <param name="SPName"></param>
        /// <returns></returns>
        public DataSet SelectDataSet(string spName)
        {
            using (DbConnection connection = Db.CreateConnection())
            {

                connection.Open();
                try
                {
                    DataSet ds = new DataSet();
                    DbCommand command = this.Db.GetStoredProcCommand(spName);
                    ds = this.Db.ExecuteDataSet(command);
                    return ds;
                }
                catch (Exception ex)
                {
                   // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataSet()");
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        public DataSet SelectDataSet_Inbox(string spName, Hashtable values)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    DataSet ds = new DataSet();
                    DbCommand command = this.Db.GetStoredProcCommand(spName);
                    command.CommandTimeout = 0;
                    AddParameter(ref command, values);
                    command.Parameters.Add(new SqlParameter("@RecordCount", ParameterDirection.Output));
                    ds = this.Db.ExecuteDataSet(command);
                    return ds;
                }
                catch (Exception ex)
                {
                   // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataSet_Inbox()");
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        /// <summary>
        /// Returns single record
        /// </summary>
        /// <param name="SPName"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public IDataReader SelectDataReader(string spName, Hashtable values)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);
                AddParameter(ref command, values);

                return this.Db.ExecuteReader(command);
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataReader()");
                throw ex;
            }
            finally
            {
            }
        }

        public IDataReader SelectDataReader(string spName)
        {
            try
            {

                DbCommand command = this.Db.GetStoredProcCommand(spName);

                return this.Db.ExecuteReader(command);
            }
            catch (Exception ex)
            {
               // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataReader()");
                throw ex;
            }
            finally
            {
            }
        }



        // Return datatable using data reader
        public DataTable SelectDataTable(string spName)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);
                command.CommandTimeout = 0;
                IDataReader dr = this.Db.ExecuteReader(command);
                DataTable dt = new DataTable();
                dt.Load(dr);
                dr.Close();

                return dt;
            }
            catch (Exception ex)
            {
               // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataTable()");
                throw ex;
            }
            finally
            {
            }
        }


        public DataTable SelectDataTable(string spName, Hashtable values)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);
                command.CommandTimeout = 0;
                AddParameter(ref command, values);

                IDataReader dr = this.Db.ExecuteReader(command);
                DataTable dt = new DataTable();
                dt.Load(dr);
                dr.Close();

                return dt;
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataTable()");

                throw ex;
            }
            finally
            {
            }
        }


        //----------------------------------
        /// <summary>
        /// Returns single value
        /// </summary>
        /// <param name="SPName"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public object SelectSingleValue(string spName, Hashtable values)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);

                AddParameter(ref command, values);
                return this.Db.ExecuteScalar(command);
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectSingleValue()");
                throw ex;
            }
            finally
            {
            }
        }

        /// <summary>
        /// Executes insert,update,delete procedures
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string spName, Hashtable values)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            DbCommand command = this.Db.GetStoredProcCommand(spName);
                            AddParameter(ref command, values);
                            int i = this.Db.ExecuteNonQuery(command, transaction);
                            transaction.Commit();
                            return i;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            //errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | ExecuteNonQuery()");
                            throw ex;
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        /// <summary>
        /// Returns single value under transaction
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="values"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public object ExecuteScalarWithTransaction(string spName, Hashtable values, DbTransaction transaction)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);
                AddParameter(ref command, values);
                return this.Db.ExecuteScalar(command, transaction);
            }
            catch (Exception ex)
            {
               // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | ExecuteScalarWithTransaction()");
                throw ex;
            }
            finally
            {
            }
        }
        public int InsertData(string spName, Hashtable values)
        {
            return ExecuteNonQuery(spName, values);
        }
        public int UpdateData(string spName, Hashtable values)
        {
            return ExecuteNonQuery(spName, values);
        }
        public int DeleteData(string spName, Hashtable values)
        {
            return ExecuteNonQuery(spName, values);
        }

        #region funcation to return the string values
        public string GetImageFolderPath(string spName, Hashtable values)
        {
            //execute procedure and return document path
            using (DbConnection connection = Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            DbCommand command = this.Db.GetStoredProcCommand(spName);
                            AddParameter(ref command, values);
                            return Convert.ToString(this.Db.ExecuteScalar(command));

                        }
                        catch (Exception ex)
                        {
                           // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | GetImageFolderPath()");
                            throw ex;
                        }

                    }

                }
                finally
                {
                    connection.Close();
                }

            }
        }

        /// <summary>
        ///  Get Data Table using xml input
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="inputXML"></param>
        /// <returns></returns>
        public DataTable ProcessXMLAndSelectDataTable(string spName, Hashtable xmlValues)
        {
            try
            {
                DbCommand command = this.Db.GetStoredProcCommand(spName);               
                AddParameter(ref command, null, xmlValues);
                command.CommandTimeout = 0;
                IDataReader dr = this.Db.ExecuteReader(command);
                DataTable dt = new DataTable();
                dt.Load(dr);
                dr.Close();
                return dt;
            }
            catch (Exception ex)
            {
                // errorlog.HandleError(ex, UserData.UserId, " | DBHelper.cs | SelectDataTable()");
                throw ex;
            }
            finally
            {
            }
        }
        #endregion
    }
}
