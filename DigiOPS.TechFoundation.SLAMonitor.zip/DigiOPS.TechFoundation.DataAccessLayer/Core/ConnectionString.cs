﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class ConnectionString
    {
       TenantDAL tenant = null;
       private string dbConnectionString = string.Empty;

       public string GetConnectionString(string AppId, int TenantId)
       {
            tenant = new TenantDAL();
           DataTable dt = new DataTable();
           dt=tenant.GetConnectionStringDetails(AppId, TenantId);
              string ConnectionString =string.Empty;
              if (dt.Rows.Count > 0)
              {
                  if(dt.Rows[0]["ConnectionString"].ToString()!=null)
                       ConnectionString = dt.Rows[0]["ConnectionString"].ToString();
                  else
                      ConnectionString = "Data Source=" + dt.Rows[0]["szServerName"] + "; Initial Catalog=" + dt.Rows[0]["szDatabaseName"] + ";  User Id=" + dt.Rows[0]["szUserId"] + "; Password=" + dt.Rows[0]["szPassword"] + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;";
              }
           return ConnectionString;
       }

       public string GetConnectionString( string TenantName)
       {
           
           if(!string.IsNullOrEmpty(TenantName) && TenantName!=null)              
           dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
           return dbConnectionString;
       }
    }
}
