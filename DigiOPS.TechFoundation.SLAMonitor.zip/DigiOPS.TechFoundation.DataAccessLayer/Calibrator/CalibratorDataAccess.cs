﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Xml.Serialization;
using DigiOPS.TechFoundation.DataAccessLayer.Calibrator.DATATRANSFORMER;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class CalibratorDataAccess
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        List<TransactionListViewModalList> baseList = null;
        List<MasterCalibratorEntity> MapList = null;
        string createRecVal = string.Empty;
        MasterCalibratorAllocationDAO mcdao = null;
        CalibratorInfoTransformer calibinfo = new CalibratorInfoTransformer();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        public CalibratorDataAccess()
        {
            objloginfo.Message = ("CalibratorDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
        public CalibratorDataAccess(string TenantName, string AppId)
        {
            mcdao = new MasterCalibratorAllocationDAO(TenantName, AppId);           
        }
        public List<MasterCalibratorEntity> MaptoCalibrator(MasterCalibratorEntity objbasetrans)
        {
            ds = mcdao.GetCalibratorsColl(objbasetrans);
            if (ds.Tables.Count != 0)
            {
                if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
                {
                    if (ds.Tables[0].Rows.Count <= 0)
                        return MapList;
                    else
                        MapList = calibinfo.MapToCheckBoxList(ds);
                }
            }
            return MapList;
        }
        public string SubmitCalibrators(MasterCalibratorEntity objMasterCalibrator)
        {
            createRecVal = mcdao.CalibratorMapping(objMasterCalibrator);
            return createRecVal;
        }
        public List<TransactionListViewModalList> GetTransactionList(SearchElementConfigViewModel objBase)
        {
            StringBuilder sb = new StringBuilder();

            SearchElementConfigViewModel objSearchElement = new SearchElementConfigViewModel();
            List<SearchElementConfigViewModel> objSearchList = new List<SearchElementConfigViewModel>();

            BaseTransportEntity bs = new BaseTransportEntity();

            objSearchElement = (SearchElementConfigViewModel)objBase;
            objSearchList.Add(objSearchElement);

            sb.Append("<root>");

            foreach (SearchElementConfigViewModel item in objSearchList)
            {
                sb.Append(item.ToXml());
            }
            sb.Append("</root>");
            ds = mcdao.GetSearchTransactionList(objBase, sb.ToString());
            if (ds.Tables.Count != 0)
            {
                if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
                {
                    if (ds.Tables[0].Rows.Count <= 0)
                        return baseList;
                    else
                        baseList = calibinfo.MapToSearchTransactionList(ds);

                    //baseList = tcmap.MapToSearchTransactionList(ds);
                }

            }
            return baseList;
        }


    }
}
