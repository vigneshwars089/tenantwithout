﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class AllocationRepository : IAllocationRepository
    {
        public virtual string InsertAllocatedTrans(AllocationListDetails TLDA)
        {
            return "";
        }

        public virtual string SerializeToString(object value)
        {
            return "";
        }
    }
}
