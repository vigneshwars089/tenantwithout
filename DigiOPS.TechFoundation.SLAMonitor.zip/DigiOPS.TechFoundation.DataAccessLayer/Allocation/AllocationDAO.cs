﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AllocationDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public AllocationDAO()
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public AllocationDAO(string TenantName,string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public string InsertAllocationDetails(string TransListXml, string AuditorListXml, int CreatedBy, int SubProcessId, string AllocationType)
        {
            string result = string.Empty;
            objloginfo.Message = ("SamplingDAO - GetTransListForAutoAlloc - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            try
            {
                DBHelper DBHAllocation = new DBHelper();
                Hashtable hsAllocation = new Hashtable();
                hsAllocation.Add("@TransListXml", TransListXml);
                hsAllocation.Add("@AuditorListXml", AuditorListXml);
                hsAllocation.Add("@CreatedBy", CreatedBy);
                hsAllocation.Add("@SubProcessID", SubProcessId);
                if (AllocationType == "ReAllocation")
                {
                    result = (DBHAllocation.SelectSingleValue("USP_SET_COMP_REALLOCATION", hsAllocation)).ToString();

                }
                else
                {
                    result = (DBHAllocation.SelectSingleValue("USP_GET_ALLOCATION", hsAllocation)).ToString();
                }

            }

            catch (SqlException ex)
            {
                result = "Duplication Transactions Entered";



            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                result = ex.ToString();
            }
            catch (NullReferenceException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex);
                result = ex.ToString();

            }
            return result;
        }
    }
}
