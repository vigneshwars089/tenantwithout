﻿using System;
//using Quart.BusinessEntity;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
//using Quart.Utility;
using System.Xml.Linq;
using System.Collections;
using System.IO;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Sub Process DAO
    /// </summary>
    public class SubProcessDAO : ManualHierarchyConfigurationRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
       // UserInfo objUserInfo = new UserInfo();
        //private string dbConnectionString = string.Empty;
        //private Logger proxyLogger = new Logger();

        /// <summary>
        /// Constructor for SubProcess DAO
        /// </summary>
        public SubProcessDAO(string appId, int TenantId)
        {
            //dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId); 
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
        }

        public SubProcessDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        /// <summary>
        /// this method used for creating, updating and deleting the subprocess details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess">SubProcessEntity</param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public override string SetSubProcessRecord(SubProcessEntity objSubprocess)
        {
            objloginfo.Message = ("SubProcessDAO - SetSubProcessRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("SubProcessDAO - SetSubProcessRecord - Called.");
            string resultValue = "-1";
            string spName = string.Empty;
            spName = "USP_SET_SUBPROCESSMASTER";

            try
            {
                //string resultValue = "-1";
                XElement Parent = new XElement("root");
                XElement root = null;
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_SUBPROCESSMASTER", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    root = new XElement("xmlArguments",
                        new XAttribute("iSubProcessId", objSubprocess.SubProcessId)
                        );


                  
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.SubProcessName)))
                        root.Add(new XAttribute("szSubProcessName", Convert.ToString(objSubprocess.SubProcessName)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.DisplayName)))
                        root.Add(new XAttribute("szDisplayName", Convert.ToString(objSubprocess.DisplayName)));
                    if(!string.IsNullOrEmpty(Convert.ToString(objSubprocess.SelectedProcessId)))
                        root.Add(new XAttribute("iProcessId", Convert.ToString(objSubprocess.SelectedProcessId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.SelectedProgramId)))
                        root.Add(new XAttribute("siProgramId", Convert.ToString(objSubprocess.SelectedProgramId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.SelectedUserGroupId)))
                        root.Add(new XAttribute("iUserGroupId", Convert.ToString(objSubprocess.SelectedUserGroupId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.dSamplingPct)))
                        root.Add(new XAttribute("dSamplingPct", Convert.ToString(objSubprocess.dSamplingPct))); 
                    //Added for SLA Cahnge
                     if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.iSLALevelID)))
                         root.Add(new XAttribute("iSLALevelID", Convert.ToString(objSubprocess.iSLALevelID)));  
                    command.Parameters.Add("@dsEffectiveFrom", SqlDbType.SmallDateTime).Value = objSubprocess.EffectiveFrom.ToShortDateString();
                    command.Parameters.Add("@dsEffectiveTo", SqlDbType.SmallDateTime).Value = objSubprocess.EffectiveTo.ToShortDateString();                   
                    
                     
                    if (objSubprocess.Action != "DELETE")
                    {
                        if (objSubprocess.EffectiveFrom.Date <= DateTime.Now)
                        {
                            objSubprocess.IsActive = true;
                        }
                        else
                        {
                            objSubprocess.IsActive = false;
                        }
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.IsActive)))
                        root.Add(new XAttribute("bIsActive", objSubprocess.IsActive));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.CreatedBy)))
                        root.Add(new XAttribute("iCreatedBy", Convert.ToString(objSubprocess.CreatedBy)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.ModifiedBy)))
                        root.Add(new XAttribute("iModifiedBy", Convert.ToString(objSubprocess.ModifiedBy)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objSubprocess.Action)))
                        root.Add(new XAttribute("sOpertaionName", Convert.ToString(objSubprocess.Action)));                
                    command.Parameters.Add("@dsCreatedDate", SqlDbType.SmallDateTime).Value = objSubprocess.CreatedDate;                   
                    command.Parameters.Add("@dsModifiedDate", SqlDbType.SmallDateTime).Value = objSubprocess.ModifiedDate;
                    Parent.Add(root);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);                   
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();

                    //Hashtable hs = new Hashtable();                 
                    //hs.Add("@dsEffectiveFrom", objSubprocess.EffectiveFrom.ToShortDateString());
                    //hs.Add("@dsEffectiveTo", objSubprocess.EffectiveTo.ToShortDateString());                   
                    //hs.Add("@dsCreatedDate", objSubprocess.CreatedDate);
                    //hs.Add("@dsModifiedDate", objSubprocess.ModifiedDate);
                    //hs.Add("@ExcelData", Convert.ToString(Parent));
                    //hs.Add("@iReturnValue", 0);
                    //DBHelper db = new DBHelper();
                    //object message=db.ExecuteNonQuery(spName,hs);
                    //resultValue = message.ToString();
                }

               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw;
            //}
            return resultValue;
        }
        /// <summary>
        /// to get subprocess list
        /// </summary>
        /// <param name="objsubpro"></param>
        /// <returns></returns>
        public override DataTable GetSubProcessList(ManualHierarchyInfo objsubpro)
        {
            objloginfo.Message = ("ProcessDAO - GetProcessEntityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("SubProcessDAO - GetSubProcessList - Called.");
            DataTable _dt = new DataTable();

            try
            {
               
                string spName = string.Empty;
                spName = "usp_Get_Program_Process_SubProcessList";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("usp_Get_Program_Process_SubProcessList", sqlConnection);
                    command.Parameters.Add("@ProgramID", SqlDbType.Int).Value = objsubpro.ProgramId;
                    command.Parameters.Add("@ProcessID", SqlDbType.Int).Value = objsubpro.ProcessId;
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objsubpro.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objsubpro.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objsubpro.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objsubpro.SortColumn;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                    //Hashtable hs = new Hashtable();
                    //hs.Add("@ProgramID", objsubpro.ProgramId);
                    //hs.Add("@ProcessID", objsubpro.ProcessId);
                    //hs.Add("@StartRowIndex", objsubpro.StartRowIndex);
                    //hs.Add("@MaximumRows", objsubpro.MaximumRows);
                    //hs.Add("@SortOrder", objsubpro.SortOrder);
                    //hs.Add("@SortColumn", objsubpro.SortColumn);
                    //DBHelper db = new DBHelper();
                    //_dt = db.SelectDataTable(spName, hs);
                }
               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);        
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);        
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);        
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw;
            //}
            return _dt;
        }

        /// <summary>
        /// Method to Get Entity List Collection
        /// </summary>
        /// <param name="objsub">SubProcessEntity</param>
        /// <returns>DataSet</returns>
        public override DataSet GetEntityListcollection(ManualHierarchyInfo objsub)
        {
            objloginfo.Message = ("ProcessDAO - GetProcessEntityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("SubProcessDAO - GetEntityListcollection - Called.");
            DataSet _ds = new DataSet();
            try
            {
                
                string spName = string.Empty;
                spName = "usp_Get_Program_Related_List";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("usp_Get_Program_Related_List", sqlConnection);
                    //Hashtable hs = new Hashtable();
                    //hs.Add("@ID", objsub.ProgramId);
                    //DBHelper db = new DBHelper();
                    //_ds = db.SelectDataSet(spName, hs);
                    command.Parameters.Add("@ID", SqlDbType.Int).Value = objsub.ProgramId;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);     
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);     
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);     
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw;
            //}
            return _ds;
        }

    }
}
