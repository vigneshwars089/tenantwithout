﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
//using Quart.BusinessEntity;
//using Quart.Utility;
using System.Xml.Linq;
using System.Collections;
using System.IO;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Program Data Access Class
    /// </summary>
    public class ProgramDAO : ManualHierarchyConfigurationRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        //UserInfo objUserInfo = new UserInfo();

        //private Logger proxyLogger = new Logger();
        /// <summary>
        /// database connection string
        /// </summary>
        public ProgramDAO(string appId, int TenantId)
        {
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId); 
            //dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }
        public ProgramDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        /// <summary>
        /// Program Data Access
        /// </summary>
        /// <param name="_Obj"></param>
        /// <returns></returns>
        #region Program Data Access

        public DataTable GetProgramRecordList(BaseTransportEntity _Obj)
        {
            objloginfo.Message = ("ProgramDAO - GetProgramRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable _dt = new DataTable();
            //proxyLogger.Log.Info("ProgramDAO - GetProgramRecordList - Called.");
            try
            {
                string spName = string.Empty;
                spName = "USP_GET_PROGRAMMASTER";
                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //   SqlCommand command = new SqlCommand(Constants.SP_GET_PROGRAMMASTER, sqlConnection);
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}

                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            return _dt;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        /// <summary>
        /// TO GET PROGRAM ROLE MAP RECORD LIST
        /// </summary>
        /// <param name="_Obj"></param>
        /// <returns></returns>
        public DataTable GetProgramRoleMapRecordList(ProgramEntity _Obj)
        {
            objloginfo.Message = ("ProgramDAO - GetProgramRoleMapRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable _dt = new DataTable();
            //proxyLogger.Log.Info("ProgramDAO - GetProgramRoleMapRecordList - Called.");
            try
            {
                string spName = string.Empty;
                spName = "USP_GET_PROGRAM_ROLEMAPPING_LIST";

                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //    SqlCommand command = new SqlCommand("USP_GET_PROGRAM_ROLEMAPPING_LIST", sqlConnection);
                //    command.CommandType = CommandType.StoredProcedure;
                //    command.Parameters.Add("@ProgramID", SqlDbType.Int).Value = _Obj.programId;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                Hashtable hs = new Hashtable();
                hs.Add("@ProgramID", _Obj.programId);
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            return _dt;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        /// <summary>
        /// TO GET ACCOUNT RECORD LIST
        /// </summary>
        /// <param name="_Obj"></param>
        /// <returns></returns>
        public DataTable GetAccountRecordList(BaseTransportEntity _Obj)
        {
            objloginfo.Message = ("ProgramDAO - GetAccountRecordList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable _dt = new DataTable();
            // proxyLogger.Log.Info("ProgramDAO - GetAccountRecordList - Called.");
            try
            {
                AccountEntity _Account = new AccountEntity();
                _Account = (AccountEntity)_Obj;
                string spName = string.Empty;
                spName = "USP_GET_ACCOUNTMASTER";

                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    sqlConnection.Open();
                //    SqlCommand command = new SqlCommand(Constants.SP_GET_ACCOUNTMASTER, sqlConnection);
                //    command.Parameters.Add(Constants.PAR_iVerticalId, SqlDbType.Int).Value = (_Account.verticalId == 0) ? 0 : _Account.verticalId;
                //    command.CommandType = CommandType.StoredProcedure;
                //    SqlDataAdapter adp = new SqlDataAdapter(command);
                //    adp.Fill(_dt);
                //}
                Hashtable hs = new Hashtable();
                hs.Add("@iVerticalId", (_Account.verticalId == 0) ? 0 : _Account.verticalId);
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            return _dt;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        /// <summary>
        /// Method to Get CUD Program Record
        /// </summary>
        /// <param name="programEnt">BaseTransportEntity</param>
        /// <returns>string</returns>
        public override string CUDProgramRecord(ProgramEntity _Program)
        {
            objloginfo.Message = ("ProgramDAO - CUDProgramRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("ProgramDAO - CUDProgramRecord - Called.");
            string resultValue = "-1";
            XElement Parent = new XElement("root");
            XElement root = new XElement("xmlArguments");
            try
            {
                //ProgramEntity _Program = new ProgramEntity();
                //_Program = (ProgramEntity)programEnt;
                string spName = string.Empty;
                spName = "USP_SET_PROGRAMMASTER";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_PROGRAMMASTER, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                root.Add(new XAttribute("siProgramId", Convert.ToString(_Program.programId) ?? "0"));
                if (!string.IsNullOrEmpty(Convert.ToString(_Program.programName)))
                    root.Add(new XAttribute("szProgramName", Convert.ToString(_Program.programName)));
                root.Add(new XAttribute("iAccountId", Convert.ToString(_Program.selectedAccountId) ?? "0"));
                root.Add(new XAttribute("iZoneId", Convert.ToString(_Program.selectedZoneId) ?? "0"));

                if (!string.IsNullOrEmpty(Convert.ToString(_Program.effectiveFrom)))
                    root.Add(new XAttribute("dsEffectiveFrom", Convert.ToString(_Program.effectiveFrom.ToShortDateString())));
                if (!string.IsNullOrEmpty(Convert.ToString(_Program.effectiveTo)))
                    root.Add(new XAttribute("dsEffectiveTo", Convert.ToString(_Program.effectiveTo.ToShortDateString())));


                if (_Program.eventAction != "DELETE")
                {
                    if (_Program.effectiveFrom.Date <= DateTime.Now)
                    {
                        _Program.isActive = true;
                    }
                    else
                    {
                        _Program.isActive = false;
                    }
                }

                root.Add(new XAttribute("bIsActive", (_Program.isActive) ? _Program.isActive : false));

                if (!string.IsNullOrEmpty(Convert.ToString(_Program.createdBy)))
                    root.Add(new XAttribute("iCreatedBy", Convert.ToString(_Program.createdBy)));

                if (!string.IsNullOrEmpty(Convert.ToString(_Program.modifiedBy)))
                    root.Add(new XAttribute("iModifiedBy", Convert.ToString(_Program.modifiedBy) ?? "0"));

                if (!string.IsNullOrEmpty(Convert.ToString(_Program.eventAction)))
                    root.Add(new XAttribute("szOpertaionName", Convert.ToString(_Program.eventAction)));
                if (!string.IsNullOrEmpty(Convert.ToString(_Program.TenantdbID)))
                    root.Add(new XAttribute("siTenantId", Convert.ToString(_Program.TenantdbID) ?? "0"));
                Parent.Add(root);
                //Hashtable hs = new Hashtable();
                //hs.Add("@ExcelData", Convert.ToString(Parent));
                //hs.Add("@iReturnValue", 0);

                //DBHelper db = new DBHelper();
                //object message = db.ExecuteNonQuery(spName, hs);
                //resultValue = message.ToString();

                command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                outprm.Direction = ParameterDirection.Output;
                command.Parameters.Add(outprm);

                command.ExecuteNonQuery();
                resultValue = outprm.Value.ToString();
                }


            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            return resultValue;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        /// <summary>
        /// TO SET PROGRAM ROLE MAPPED DATA
        /// </summary>
        /// <param name="programEnt"></param>
        /// <returns></returns>
        public string SetProgramRoleMapData(ProgramEntity programEnt)
        {
            objloginfo.Message = ("SetProgramRoleMapData - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = "-1";
            // proxyLogger.Log.Info("SetProgramRoleMapData - Called.");
            try
            {

                //using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                //{
                //sqlConnection.Open();
                string spName = string.Empty;
                spName = "USP_SET_PROGRAMROLEMAP";

                //SqlCommand command = new SqlCommand(spName, sqlConnection);
                //command.CommandType = CommandType.StoredProcedure;
                Hashtable hs = new Hashtable();
                hs.Add("@RecordXML", programEnt.programRoleMaplist);
                hs.Add("@ProgramId", programEnt.programId);
                hs.Add("@CreatedBy", (programEnt.CurrentUserID == null) ? 0 : Convert.ToInt32(programEnt.CurrentUserID));
                hs.Add("@iReturnValue", 0);
                DBHelper db = new DBHelper();
                object message = db.ExecuteNonQuery(spName, hs);
                resultValue = message.ToString();
                //command.Parameters.Add("@RecordXML", SqlDbType.Xml).Value = programEnt.programRoleMaplist;
                //command.Parameters.Add("@ProgramId", SqlDbType.Int).Value = programEnt.programId;
                //command.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = (programEnt.CurrentUserID == null) ? 0 : Convert.ToInt32(programEnt.CurrentUserID);
                //command.Parameters.Add("@iReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                //outprm.Direction = ParameterDirection.Output;
                //command.Parameters.Add(outprm);

                //command.ExecuteNonQuery();
                //resultValue = outprm.Value.ToString();
                //}


            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }

            return resultValue;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
        #endregion

        /// <summary>
        /// Entity List collection
        /// </summary>
        /// <param name="_obj"></param>
        /// <returns></returns>

        public override DataSet GetEntityListcollectionProgram(ManualHierarchyInfo _obj)
        {
            objloginfo.Message = ("ProgramDAO - GetEntityListcollection - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("ProgramDAO - GetEntityListcollection - Called.");
            DataSet _ds = new DataSet();
            try
            {
                string spName = string.Empty;
                spName = "USP_GET_PROGRAMCOLLECTION";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_GET_PROG_COL, sqlConnection);
                //Hashtable hs = new Hashtable();
                //hs.Add("@StartRowIndex", _obj.StartRowIndex);
                //hs.Add("@MaximumRows", _obj.MaximumRows);
                //hs.Add("@SortOrder", _obj.SortOrder);
                //hs.Add("@SortColumn", _obj.SortColumn);
                //DBHelper db = new DBHelper();
                //_ds = db.SelectDataSet(spName, hs);
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = _obj.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = _obj.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = _obj.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = _obj.SortColumn;

                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }

            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }

            return _ds;
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }
    }
}
