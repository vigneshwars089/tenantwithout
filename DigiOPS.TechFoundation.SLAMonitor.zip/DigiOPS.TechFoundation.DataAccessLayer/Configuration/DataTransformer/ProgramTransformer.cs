﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Data;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class ProgramTransformer
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        internal List<ProgramEntity> MapToProgramList(DataTable dt)
        {
            objloginfo.Message = ("MapToProgramList to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToProgramList to Entity List - Calling.");
            List<ProgramEntity> baseEntityList = new List<ProgramEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new ProgramEntity
                              {
                                  programId = Convert.ToInt16(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  programName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  selectedVerticalId = Convert.ToInt32(p["iVerticalId"] == DBNull.Value ? 0 : p["iVerticalId"]),
                                  selectedVerticalName = Convert.ToString(p["szVerticalName"] == DBNull.Value ? string.Empty : p["szVerticalName"]),
                                  selectedZoneId = Convert.ToInt32(p["iZoneId"] == DBNull.Value ? 0 : p["iZoneId"]),
                                  selectedZoneName = Convert.ToString(p["szZoneName"] == DBNull.Value ? string.Empty : p["szZoneName"]),
                                  selectedAccountId = Convert.ToInt32(p["iAccountId"] == DBNull.Value ? 0 : p["iAccountId"]),
                                  selectedAccountName = Convert.ToString(p["szAccountName"] == DBNull.Value ? string.Empty : p["szAccountName"]),
                                  isActive = Convert.ToBoolean(p["bIsActive"]),
                                  effectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? string.Empty : p["dsEffectiveFrom"]),
                                  effectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? string.Empty : p["dsEffectiveTo"]),
                                  createdBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  createdDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  modifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  modifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  _TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"])
                              }).ToList();

            objloginfo.Message = ("MapToProgramList to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToProgramList to Entity List - Called.");
            return baseEntityList;
        }

        internal List<ProgramEntity> MapToDropDownList(DataTable dt)
        {
            List<ProgramEntity> EntityList = new List<ProgramEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprogram
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<ProgramEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprogram
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<ProgramEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprogram
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<ProgramEntity>().ToList();

            }

            return EntityList;
        }
    }
}
