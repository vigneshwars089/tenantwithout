﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class WorkFlowDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        
        public WorkFlowDAO()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public WorkFlowDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public int OpenToExternalTransaction(string TransId, string CreatedBy, int AuditTypeID, int StatusID, int StatusIDStatusData, int PrevStatusID)
        {
            Hashtable hs = new Hashtable();
            objloginfo.Message = ("WorkFlowDAO - OpenToExternalTransaction - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                hs.Add("@szRecordId", TransId);
                hs.Add("@szCreatedBy", CreatedBy);
                hs.Add("@iAuditTypeId", AuditTypeID);
                hs.Add("@iStatusId ", StatusID);
                hs.Add("@iStatusId_StatusData", StatusIDStatusData);
                hs.Add("@iPrevStatusId_StatusData", PrevStatusID);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_SET_OpenToExternalAudit", hs));
        
        }
    }
}
