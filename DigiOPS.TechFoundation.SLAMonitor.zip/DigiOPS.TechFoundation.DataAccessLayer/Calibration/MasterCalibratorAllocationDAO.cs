﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Logging;
using System.Collections;
using System.Xml;
using System.IO;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Manual and ReAllocation DB logic.
    /// </summary>
    public class MasterCalibratorAllocationDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        // Logger proxyLogger = new Logger();
        //private string dbConnectionString = string.Empty;
        /// <summary>
        /// Connection string
        /// </summary>
        public MasterCalibratorAllocationDAO()
        {
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            // dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public MasterCalibratorAllocationDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        #region Master Calibrator Allocation Data Access
        /// <summary>
        /// Method to Get Mail Recipients list Collection
        /// </summary>
        /// <param name="mail">MailTriggerEntity</param>
        /// <returns>DataSet</returns>
        public DataSet GetCalibratorsColl(MasterCalibratorEntity MC)
        {
            try
            {
                DataSet _ds = new DataSet();
                string spname = string.Empty;
                Hashtable hs = new Hashtable();

                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //    SqlConnection.Open();
                spname = "USP_GET_Calibrators";
                hs.Add("@iSubprocessId", MC.SelectedSubProcessId);
                //command.Parameters.Add("@iSubprocessId", SqlDbType.Int).Value = (MC == null) ? 0 : MC.SelectedSubProcessId;
                // command.CommandType = CommandType.StoredProcedure;
                // SqlDataAdapter adp = new SqlDataAdapter(command);
                // adp.Fill(_ds);
                DBHelper db = new DBHelper();
                _ds = db.SelectDataSet(spname, hs);
                //}
                return _ds;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }

        /// <summary>
        /// Method to map calibrators to records 
        /// </summary>
        /// <param name="objMasterCalibrator">MasterCalibratorEntity</param>
        /// <returns>string</returns>
        public string CalibratorMapping(MasterCalibratorEntity objMasterCalibrator)
        {
            //proxyLogger.Log.Info("CalibratorMapping - Called.");
            objloginfo.Message = ("CalibratorMapping - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                string resultValue = "-1";
                DataTable dt = new DataTable();
                string spname = string.Empty;
                Hashtable hs = new Hashtable();
                //using (SqlConnection con = new SqlConnection(dbConnectionString))
                //{
                //    con.Open();
                //    SqlCommand cmd = new SqlCommand("USP_ADD_CALIBRATORRECORDSMAPPING", con);
                //    cmd.CommandType = CommandType.StoredProcedure;
                spname = "USP_ADD_CALIBRATORRECORDSMAPPING";
                //    cmd.CommandType = CommandType.StoredProcedure;
                //    cmd.Parameters.AddWithValue("@iSubprocessId", objMasterCalibrator.SelectedSubProcessId);
                //    cmd.Parameters.AddWithValue("@szCalibrators", objMasterCalibrator.szCalibrators);
                //    cmd.Parameters.AddWithValue("@RecordIds", objMasterCalibrator.RecordIds);
                //    cmd.Parameters.AddWithValue("@iCreatedBy", objMasterCalibrator.SystemUserId);
                //    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                //      cmd.ExecuteNonQuery();
                //    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                //}
                hs.Add("@iSubprocessId", objMasterCalibrator.SelectedSubProcessId);
                hs.Add("@szCalibrators", objMasterCalibrator.szCalibrators);
                hs.Add("@RecordIds", objMasterCalibrator.RecordIds);
                hs.Add("@iCreatedBy", objMasterCalibrator.SystemUserId);
                DBHelper db = new DBHelper();
                objMasterCalibrator.createRecVal = Convert.ToString(db.SelectSingleValue(spname, hs));
                return objMasterCalibrator.createRecVal;
                // return resultValue;
            }
            catch (InvalidOperationException Ex)
            {
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(Ex);
                throw;
            }
            catch (SqlException ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ArgumentException ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw;
            //}
        }



        #endregion

        /// <summary>
        /// Method to Get SearchTransaction List
        /// </summary>
        /// <param name="objBase">BaseTransportEntity</param>
        /// <param name="sb">string</param>
        /// <returns>DataSet</returns>
        public DataSet GetSearchTransactionList(BaseTransportEntity objBase, string sb)
        {
            //objlog.Log.Info("GetTransactionList - Called.");
            objloginfo.Message = ("GetTransactionList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                DataSet ds = new DataSet();
                DataTable resultdt = new DataTable();
                SearchElementConfigViewModel objList = new SearchElementConfigViewModel();
                objList = (SearchElementConfigViewModel)objBase;
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                string spname = string.Empty;
                //using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                //{
                //SqlConnection.Open();
                //SqlCommand command = null;
                //string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                //if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                //    QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT;



                if (objList.CurrentUserRoleID == 6 || objList.CurrentUserRoleID == 9)
                {
                    spname = "USP_SEARCHTRANSACTION_HIGUser";//new SqlCommand("USP_SEARCHTRANSACTION_HIGUser", SqlConnection);
                }
                else if (objBase.ViewName != Constants.VIEW_SEARCH_LIST)
                {
                    spname = "USP_SEARCHTRANSACTION";//new SqlCommand("USP_SEARCHTRANSACTION", SqlConnection);
                }
                else
                {
                    spname = "USP_VIEW_SEARCHTRANSACTION";//new SqlCommand("USP_VIEW_SEARCHTRANSACTION", SqlConnection);
                }
                //command.CommandType = CommandType.StoredProcedure;
                //command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);

                if (!string.IsNullOrEmpty(Convert.ToString(objBase.Id)))
                    root.Add(new XAttribute("iRecordId", Convert.ToString(objBase.Id)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase._SubProcessID)))
                    root.Add(new XAttribute("iSubProcessId", Convert.ToString(objBase._SubProcessID)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase._StartRowIndex)))
                    root.Add(new XAttribute("StartRowIndex", Convert.ToString(objBase._StartRowIndex)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase._MaximumRows)))
                    root.Add(new XAttribute("MaximumRows", Convert.ToString(objBase._MaximumRows)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase._SortOrder)))
                    root.Add(new XAttribute("SortOrder", Convert.ToString(objBase._SortOrder)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase._SortColumn)))
                    root.Add(new XAttribute("SortColumn", Convert.ToString(objBase._SortColumn)));
                if (!string.IsNullOrEmpty(Convert.ToString(objList.ReferenceValue)))
                    root.Add(new XAttribute("Reference", Convert.ToString(objList.ReferenceValue)));

                // command.Parameters.Add("@RecordXML", SqlDbType.Xml).Value = sb;
                //command.Parameters.Add("@dsProcessedDate", SqlDbType.VarChar).Value = objBase._ProcessedDate;
                //command.Parameters.Add("@dsProcessedFromDate", SqlDbType.VarChar).Value = objBase._ProcessedFromDate;
                //command.Parameters.Add("@dsProcessedToDate", SqlDbType.VarChar).Value = objBase._ProcessedToDate;
                //command.Parameters.Add("@ddReceivedDate", SqlDbType.VarChar).Value = objBase._ReceivedDate;
                if (objBase.IsReadonDDL == true && !string.IsNullOrEmpty(Convert.ToString(objList.ReasonValue)))
                {
                    root.Add(new XAttribute("ReasonID", Convert.ToString(objList.ReasonValue)));
                }
                else
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(objList.ReasonValue)))
                        root.Add(new XAttribute("Reason", Convert.ToString(objList.ReasonValue)));
                }
                if (!string.IsNullOrEmpty(Convert.ToString(objList.SelectedUser)))
                    root.Add(new XAttribute("Associate", Convert.ToString(objList.SelectedUser)));
                if (!string.IsNullOrEmpty(Convert.ToString(objList.SelectedCurrentStatus)))
                    root.Add(new XAttribute("CurrentStatus", Convert.ToString(objList.SelectedCurrentStatus)));
                if (!string.IsNullOrEmpty(Convert.ToString(objList.SelectedPeerChecker)))
                    root.Add(new XAttribute("PeerChecker", Convert.ToString(objList.SelectedPeerChecker)));
                if (!string.IsNullOrEmpty(Convert.ToString(objList.SelectedSLAActivity)))
                    root.Add(new XAttribute("SLAActivity", Convert.ToString(objList.SelectedSLAActivity)));
                if (!string.IsNullOrEmpty(Convert.ToString(objList.CurrentUserID)))
                    root.Add(new XAttribute("SearchedBy", Convert.ToString(objList.CurrentUserID)));
                if (!string.IsNullOrEmpty(Convert.ToString(objBase.NoofLineReuired)))
                    root.Add(new XAttribute("Lines", Convert.ToString(objBase.NoofLineReuired)));

                if (objList.CurrentUserRoleID == 6 || objList.CurrentUserRoleID == 9)
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(objList.CurrentUserRoleID)))
                        root.Add(new XAttribute("CurrentUserRoleID", Convert.ToString(objList.CurrentUserRoleID)));
                }

                Parent.Add(root);
                //command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);

                //SqlDataAdapter adp = new SqlDataAdapter(command);
                //adp.Fill(ds);

                SearchElementConfigViewModel search = new SearchElementConfigViewModel();

                XmlDocument doc = new XmlDocument();

                doc.LoadXml("<root><SearchElementConfigViewModel  >  <Id>0</Id>  <CurrentUserID>936</CurrentUserID>  <CurrentUserRoleID>11</CurrentUserRoleID>  <_ProgramID>0</_ProgramID>  <_ProcessID>0</_ProcessID>  <_SubProcessID>43</_SubProcessID>  <eventAction>GetSearchList</eventAction>  <_ProcessedFromDate>02/01/2017</_ProcessedFromDate>  <_ProcessedToDate>02/15/2017</_ProcessedToDate>  <iSubCategoryId>0</iSubCategoryId>  <_StartRowIndex>1</_StartRowIndex>  <_MaximumRows>10</_MaximumRows>  <_SortOrder>DESC</_SortOrder>  <_SortColumn>iRecordID</_SortColumn>  <_TotalRows>0</_TotalRows>  <bIsEmpNeeded>false</bIsEmpNeeded>  <bIsLineNeeded>false</bIsLineNeeded>  <iSubcategory>0</iSubcategory>  <bIsLineApplicable>false</bIsLineApplicable>  <IsPeerCheckerReq>false</IsPeerCheckerReq>  <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>  <IsReadonDDL>false</IsReadonDDL>  <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>  <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>  <_ElementCount>0</_ElementCount>  <bIsExternalAudit>false</bIsExternalAudit>  <bIsExternalAuditAuto>false</bIsExternalAuditAuto>  <ReportID>0</ReportID>  <RatingDifferenceCount>0</RatingDifferenceCount>  <ProcessedFromDate>02/01/2017</ProcessedFromDate>  <ProcessedToDate>02/15/2017</ProcessedToDate>  <RecordId>0</RecordId>  <SearchTransactionList>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>156</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>157</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>158</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>159</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>160</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>161</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>162</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>163</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>164</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>165</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>166</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>167</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>168</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>169</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>  </SearchTransactionList>  <NoofLines>0</NoofLines></SearchElementConfigViewModel></root>");
                StringWriter sw = new StringWriter();
                XmlTextWriter tx = new XmlTextWriter(sw);
                doc.WriteTo(tx);
                sb = sw.ToString();

                search._ProcessedFromDate = "02/01/2017";
                search._ProcessedToDate = "02/15/2017";
                search._ReceivedDate = "";

                XmlDocument doc1 = new XmlDocument();

                doc.LoadXml("<root>  <xmlArguments iRecordId='0' iSubProcessId='43' StartRowIndex='1' MaximumRows='10' SortOrder='DESC' SortColumn='Record ID' SearchedBy='936' /></root>");
                StringWriter sw1 = new StringWriter();
                XmlTextWriter tx1 = new XmlTextWriter(sw1);
                doc.WriteTo(tx1);
                string sb1 = sw1.ToString();


                //string a= Parent.ToString();
                Hashtable hs = new Hashtable();
                hs.Add("@RecordXML", sb);
                hs.Add("@dsProcessedFromDate", search._ProcessedFromDate);
                hs.Add("@dsProcessedToDate", search._ProcessedToDate);
                hs.Add("@ddReceivedDate", search._ReceivedDate);
                // hs.Add("@ExcelData", Convert.ToString(Parent));
                hs.Add("@ExcelData", sb1);

                DBHelper db = new DBHelper();
                ds = db.SelectDataSet(spname, hs);


                //}
                return ds;
            }
            catch (SqlException ex)
            {
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw ex;
            //}
        }


    }
}
