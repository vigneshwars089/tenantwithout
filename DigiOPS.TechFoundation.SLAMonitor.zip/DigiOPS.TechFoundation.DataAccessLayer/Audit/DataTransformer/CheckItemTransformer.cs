﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data;
using System.Configuration;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class CheckItemTransformer
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        string TenantName = ConfigurationManager.AppSettings["TenantName"].ToString();
        string AppID = ConfigurationManager.AppSettings["AppId"].ToString();

        internal List<CheckItemEntity> MapCriticality(DataTable dt)
        {
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Calling.");
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {
                                  CriticalityType = Convert.ToString(p["szCriticalityType"] == DBNull.Value ? string.Empty : p["szCriticalityType"])
                              }).ToList();
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToDefectOpportunityConfig(DataTable dt)
        {
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Calling.");
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {
                                  DOId = Convert.ToInt32(p["iDOId"] == DBNull.Value ? 0 : p["iDOId"]),
                                  DODesc = Convert.ToString(p["szDODesc"] == DBNull.Value ? string.Empty : p["szDODesc"]),
                                  DisplayName = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),
                                  RatingName = Convert.ToString(p["RatingName"] == DBNull.Value ? string.Empty : p["RatingName"]),
                                  AuditingLogic = Convert.ToString(p["AuditingLogic"] == DBNull.Value ? string.Empty : p["AuditingLogic"]),
                                  IsCritical = Convert.ToBoolean(p["bIsCritical"] == DBNull.Value ? string.Empty : p["bIsCritical"]),
                                  DOGroupID = Convert.ToInt32(p["iDOGroupID"] == DBNull.Value ? 0 : p["iDOGroupID"]),
                                  CTQGroupName = Convert.ToString(p["szDOGroupName"] == DBNull.Value ? string.Empty : p["szDOGroupName"]),
                                  RatingGroupID = Convert.ToInt32(p["iRatingGroupId"] == DBNull.Value ? 0 : p["iRatingGroupId"]),
                                  IsHeading = p["bIsHeading"] != DBNull.Value ? Convert.ToBoolean(p["bIsHeading"]) : false,
                                  Level = Convert.ToInt32(p["iLevel"] == DBNull.Value ? 0 : p["iLevel"]),
                                  ParentDOId = Convert.ToInt32(p["iParentDOId"] == DBNull.Value ? 0 : p["iParentDOId"]),
                                  SubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  IsActive = Convert.ToBoolean(p["bIsActive"] != DBNull.Value ? p["bIsActive"] : false),
                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  CategoryID_DOId = Convert.ToInt32(p["CategoryID"] == DBNull.Value ? 0 : p["CategoryID"]),
                                  CategoryName = Convert.ToString(p["CategoryName"] == DBNull.Value ? string.Empty : p["CategoryName"]),
                                  HeadingID_DOId = Convert.ToInt32(p["HeadingID"] == DBNull.Value ? 0 : p["HeadingID"]),
                                  HeadingName = Convert.ToString(p["HeadingName"] == DBNull.Value ? string.Empty : p["HeadingName"]),
                                  CriticalName = (Convert.ToBoolean(p["bIsCritical"] == DBNull.Value ? false : p["bIsCritical"]) == true) ? "Critical" : "Non-Critical",
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  CanRatingEnable = Convert.ToInt32(p["CanRatingEnable"] == DBNull.Value ? 0 : p["CanRatingEnable"]),
                                  CriticalityType = Convert.ToString(p["szCriticalityType"] == DBNull.Value ? string.Empty : p["szCriticalityType"])
                              }).ToList();
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToDropDownList(DataTable dt)
        {
            List<CheckItemEntity> EntityList = new List<CheckItemEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TransDropDownlst
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<CheckItemEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TransDropDownlst
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<CheckItemEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new TransDropDownlst
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<CheckItemEntity>().ToList();

            }

            return EntityList;
        }
        internal List<CheckItemEntity> MapToDOGroupMapConfig(DataTable dt)
        {
            objloginfo.Message = ("MapToDOGroupMapConfig to Entity List - Calling.");
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDOGroupMapConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {

                                  DOId = Convert.ToInt32(p["iDOId"] == DBNull.Value ? 0 : p["iDOId"]),
                                  DODesc = Convert.ToString(p["szDODesc"] == DBNull.Value ? string.Empty : p["szDODesc"]),
                                  DisplayName = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),

                                  DOGroupID = Convert.ToInt32(p["iDOGroupID"] == DBNull.Value ? 0 : p["iDOGroupID"])


                              }).ToList();
            objloginfo.Message = (" MapToDOGroupMapConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDOGroupMapConfig to Entity List - Called.");

            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToRatingGroupMapConfig(DataTable dt)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("MapToRatingGroupMapConfig to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToRatingGroupMapConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {
                                  DisplayName = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),
                                  RatingID = Convert.ToInt32(p["iRatingId"] == DBNull.Value ? string.Empty : p["iRatingId"]),
                              }).ToList();
            objloginfo.Message = ("MapToRatingGroupMapConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToRatingGroupMapConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToDORatingWeightageMapConfig(DataTable dt)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("MapToDORatingWeightageMapConfig to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDORatingWeightageMapConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {

                                  DOHeadingName = Convert.ToString(p["DOName"] == DBNull.Value ? string.Empty : p["DOName"]),
                                  RatingName = Convert.ToString(p["RatingName"] == DBNull.Value ? string.Empty : p["RatingName"]),
                                  Weightage = float.Parse((p["fWeightage"] == DBNull.Value ? "-1" : p["fWeightage"]).ToString()),
                                  CTQGroupName = Convert.ToString(p["szDOGroupName"] == DBNull.Value ? string.Empty : p["szDOGroupName"]),
                                  DOGroupID = Convert.ToInt32(p["iDOGroupID"] == DBNull.Value ? string.Empty : p["iDOGroupID"]),
                                  RatingGroupMapId = Convert.ToInt32(p["iRatingGroupMapId"] == DBNull.Value ? string.Empty : p["iRatingGroupMapId"]),
                                  RatingID = Convert.ToInt32(p["iRatingId"] == DBNull.Value ? string.Empty : p["iRatingId"]),
                                  CheckpointID_DOId = Convert.ToInt32(p["CheckpointID"] == DBNull.Value ? string.Empty : p["CheckpointID"]),
                                  HeadingID_DOId = Convert.ToInt32(p["HeadingID"] == DBNull.Value ? string.Empty : p["HeadingID"]),
                                  DOGroupMapId = Convert.ToInt32(p["iDOGroupMapId"] == DBNull.Value ? string.Empty : p["iDOGroupMapId"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  IsNotApplicable = Convert.ToBoolean(p["bIsNotApplicable"] != DBNull.Value ? p["bIsNotApplicable"] : false)
                              }).ToList();

            objloginfo.Message = ("MapToDORatingWeightageMapConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDORatingWeightageMapConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToSearchRelatedDefectOpportunity(DataTable dt)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {
                                  CheckpointID_DOId = Convert.ToInt32(p["iDOid_CheckpointID"] == DBNull.Value ? 0 : p["iDOid_CheckpointID"]),
                                  DOId = Convert.ToInt32(p["ROWID"] == DBNull.Value ? 0 : p["ROWID"]),
                                  DisplayName = Convert.ToString(p["szgridtext"] == DBNull.Value ? string.Empty : p["szgridtext"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"])

                              }).ToList();
            objloginfo.Message = ("MapToDefectOpportunityConfig to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info(" MapToDefectOpportunityConfig to Entity List - Called.");
            return baseEntityList;
        }
        internal List<CheckItemEntity> MapToRatingType(DataTable dt)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("MapToRatingType to Entity List - Calling.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info(" MapToRatingType to Entity List - Calling.");
            List<CheckItemEntity> baseEntityList = new List<CheckItemEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new CheckItemEntity
                              {
                                  IsNotApplicable = Convert.ToBoolean(p["bIsNotApplicable"] == DBNull.Value ? false : p["bIsNotApplicable"])

                              }).ToList();
            objloginfo.Message = ("MapToRatingType to Entity List - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info(" MapToRatingType to Entity List - Called.");
            return baseEntityList;
        }


        internal List<AuditConfigEntity> MapToAuditConfig(DataTable dt)
        {
            List<AuditConfigEntity> baseEntityList = new List<AuditConfigEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new AuditConfigEntity
                              {
                                  AuditConfigId = Convert.ToInt32(p["iAuditConfigId"] == DBNull.Value ? 0 : p["iAuditConfigId"]),
                                  AuditingLogicType = Convert.ToString(p["szAuditingLogicType"] == DBNull.Value ? string.Empty : p["szAuditingLogicType"]),
                                  ScoringLogicType = Convert.ToString(p["szScoringLogicType"] == DBNull.Value ? string.Empty : p["szScoringLogicType"]),
                                  IsEmpNeeded = Convert.ToBoolean(p["bIsEmpNeeded"] == DBNull.Value ? string.Empty : p["bIsEmpNeeded"]),
                                  SubDefectLevel = Convert.ToByte(p["bySubDefectLevel"] == DBNull.Value ? string.Empty : p["bySubDefectLevel"]),
                                  SamplingType = Convert.ToString(p["szSamplingType"] == DBNull.Value ? string.Empty : p["szSamplingType"]),
                                  WorkflowConfigId = Convert.ToInt32(p["iWorkflowConfigId"] == DBNull.Value ? string.Empty : p["iWorkflowConfigId"]),
                                  SubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? string.Empty : p["iSubProcessId"]),
                                  IsActive = Convert.ToBoolean(p["bIsActive"] == DBNull.Value ? string.Empty : p["bIsActive"]),
                                  CreatedBy = Convert.ToInt32(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  ModifiedBy = Convert.ToInt32(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  CopySubDefectLevel = Convert.ToByte(p["iCopySubdefectLevel"] == DBNull.Value ? string.Empty : p["iCopySubdefectLevel"])



                              }).ToList();

            return baseEntityList;
        }
     
    }
}
