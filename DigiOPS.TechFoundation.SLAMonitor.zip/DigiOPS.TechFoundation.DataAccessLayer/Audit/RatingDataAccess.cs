﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class RatingDataAccess
    {
        RatingDAO ratingdao = new RatingDAO();
        RatingInfoTransformer ratingda = new RatingInfoTransformer();

        public List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp)
        {


            DataTable dt = new DataTable();
            List<RatingGroupEntity> baseList = null;
            //result = objrating.GetRatingEntityList(objratingentity).ToString();
            dt = ratingdao.GetRatingGroupEntityList(objratinggrp);
            if (!objratinggrp.IsDropdownlist)
                baseList = ratingda.MapToRatingGroupList(dt);
            else
                baseList = ratingda.MapToDropDownList(dt);

            return baseList;

        }

        public List<RatingEntity> GetRatingList(RatingEntity objratingentity)
        {
            List<RatingEntity> ratinglist = new List<RatingEntity>();
            DataTable dt = new DataTable();
            dt = ratingdao.GetRatingListForGroup(objratingentity);
            if (dt.Rows.Count <= 0)
                return ratinglist;
            else
            {
                ratinglist = ratingda.MapToRatingListForGroup(dt);
                return ratinglist;
            }

        }
        public List<RatingEntity> GetAuditRating(RatingEntity objratingentity)
        {

            AuditRatingInfo ratinginfo = new AuditRatingInfo();
            DataTable dt = new DataTable();
            List<RatingEntity> ratlist = null;
            dt = ratingdao.GetRatingEntityList(objratingentity);
            ratlist = ratingda.MapToRatingList(dt);
            return ratlist;

        }
        public string SetAuditRatingGroup(RatingGroupEntity objratgrp)
        {
            string result = string.Empty;
            result = ratingdao.SetRatingGroupRecord(objratgrp);
            return result;

        }
        public string SetAuditRating(RatingEntity objrating)
        {
            string result = string.Empty;
            result = ratingdao.SetRatingRecord(objrating);
            return result;

        }
        public string SetRatings(AuditRatingInfo AuditRatingInfo)
        {
            string result = string.Empty;
            result = ratingdao.SetRatings(AuditRatingInfo);
            return result;

        }

    }
}
