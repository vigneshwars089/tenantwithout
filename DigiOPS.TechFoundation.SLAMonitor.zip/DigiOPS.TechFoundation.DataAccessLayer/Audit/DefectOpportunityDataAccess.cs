﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class DefectOpportunityDataAccess
    {
        DefectOpportunityDAO doDAO = new DefectOpportunityDAO();
        CheckItemTransformer checkitemda = new CheckItemTransformer();

        public string AddAuditCheckItems(AuditCheckItemsInfo objDo)
        {

            string createRecVal = string.Empty;
            // DefectOpportunityEntity objDo = (DefectOpportunityEntity)objBase;
            //if (objDo.Level != 10)
            //{
            createRecVal = doDAO.SetDefectOpportunity(objDo);

            //}
            return createRecVal;

        }

        public string CopyDefOpp(CheckItemEntity objDo)
        {
            string createRecVal = string.Empty;

            //if (objDo.Level == 10)
            //{
            createRecVal = doDAO.CopyDefectOpportunity(objDo);

            //}
            return createRecVal;

        }

        public List<CheckItemEntity> GetDefectOppList(CheckItemEntity objdo)
        {
            DataTable dt = new DataTable();
            List<CheckItemEntity> baseList = null;
            dt = doDAO.GetDefectOpportunityList(objdo);
            if (dt.Rows.Count <= 0)
                return baseList;
            //DefectOpportunityEntity objdo = (DefectOpportunityEntity)objBase;
            if (objdo.Level == 0)
            {
                baseList = checkitemda.MapCriticality(dt);
                return baseList;
            }
            else
            {
                if (objdo.Level < 6)
                {
                    if (!objdo.isDropdowndetails)
                        baseList = checkitemda.MapToDefectOpportunityConfig(dt);
                    else
                        baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 6)
                {
                    if (!objdo.isDropdowndetails)
                        baseList = checkitemda.MapToDOGroupMapConfig(dt);
                    else
                        baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 7)
                {
                    if (!objdo.isDropdowndetails)
                        baseList = checkitemda.MapToRatingGroupMapConfig(dt);
                    else
                        baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 8)
                {
                    if (!objdo.isDropdowndetails)
                        baseList = checkitemda.MapToDORatingWeightageMapConfig(dt);
                    else
                        baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 9)
                {

                    baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 10)
                {

                    baseList = checkitemda.MapToSearchRelatedDefectOpportunity(dt);
                }
                else if (objdo.Level == 11)
                {

                    baseList = checkitemda.MapToRatingType(dt);
                }
                else if (objdo.Level == 12)
                {

                    baseList = checkitemda.MapToDropDownList(dt);
                }
                else if (objdo.Level == 13)
                {

                    if (!objdo.isDropdowndetails)
                        baseList = checkitemda.MapToDefectOpportunityConfig(dt);
                    else
                        baseList = checkitemda.MapToDropDownList(dt);
                }
                return baseList;
            }
        }

        public List<AuditConfigEntity> GetAuditCheckItems(AuditConfigEntity objaudconfig)
        {

            DataTable dt = new DataTable();
            List<AuditConfigEntity> baseList = null;

            dt = doDAO.GetAuditEntityRecordByEntity(objaudconfig);
            if (dt.Rows.Count <= 0)
                return baseList;
            else
            {
                baseList = checkitemda.MapToAuditConfig(dt);
                return baseList;
            }

        }
    }
}
