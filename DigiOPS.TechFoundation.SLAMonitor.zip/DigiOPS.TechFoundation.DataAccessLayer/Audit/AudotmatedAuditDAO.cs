﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AudotmatedAuditDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        string TenantName = ConfigurationManager.AppSettings["TenantName"].ToString();
        string AppID = ConfigurationManager.AppSettings["AppId"].ToString();

        public AudotmatedAuditDAO()
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }

        public DataSet GetDataElement(int recordid)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataSet ds = new DataSet();
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditQCStatus - Called.");
            //try
            //{

            //    DataSet ds = new DataSet();
            //    DataTable _dt = new DataTable();
            //    string spName = string.Empty;
            //    spName = "USP_GET_TransElementBasedOnSource";
            //    Hashtable hs = new Hashtable();
            //    hs.Add("@iRecordId", recordid);

            DBHelper db = new DBHelper();
            //    ds = db.SelectDataSet(spName, hs);
            //    return ds;


            try
            {

                //DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_TransElementBasedOnSource", SqlConnection);
                    command.Parameters.Add("@iSubProcessId", recordid);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(ds);
                }

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppID);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            return ds;
        }

        public DataTable GetAutoAuditFindingData(int recordid)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditQCStatus - Called.");
            try
            {


                DataTable _dt = new DataTable();
                string spName = string.Empty;
                spName = "USP_GET_AuditComaprisonData";
                Hashtable hs = new Hashtable();
                hs.Add("@iRecordId", recordid);
                //hs.Add("@szOpertaionName", _Obj.eventAction);
                //hs.Add("@iReturnValue", 0);

                List<Hashtable> lstHash = new List<Hashtable>();

                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppID);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
        }

        public string SetAutoAuditedElement(int recordid, int elementid, string elementocr, string elementlos, bool matchstatus, int createdby, int modifiedby, int statusid, string SubDefects, string comments)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("AuditDetailsDAO - SetAutoAuditedElement - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();
            string spName = string.Empty;
            try
            {
                if (SubDefects == null)
                    SubDefects = string.Empty;
                if (comments == null)
                    comments = string.Empty;

                spName = "USP_SET_AuditComaprisonData";
                hs.Add("@iRecordId", recordid);
                hs.Add("@iElementId", elementid);
                hs.Add("@szElementOCRData", elementlos);
                hs.Add("@szElementLOSData", elementocr);
                hs.Add("@bMatchStatus", matchstatus);
                hs.Add("@iCreatedBy", createdby);
                hs.Add("@iModifiedBy", modifiedby);
                hs.Add("@iStatusId", statusid);
                hs.Add("@szsubdefects", SubDefects);
                hs.Add("@szComments", comments);



                //DBHelper db = new DBHelper();
                //_dt = db.SelectDataTable(spName, hs);
                //return _dt;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppID);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            return new DBHelper().SelectSingleValue(spName, hs).ToString();
            // return Convert.ToInt32(new DBHelper().SelectSingleValue(spName, hs));
        }

        public int SetAutoAuditedElementtotblARD(int recordid, int elementid, string elementocr, string elementlos, bool matchstatus, int createdby, int modifiedby, int statusid, string QCNotes)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("AuditDetailsDAO - SetAutoAuditedElement - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();
            string spName = string.Empty;
            try
            {
                spName = "USP_SET_AuditComaprisonDatainARD";
                hs.Add("@iRecordId", recordid);
                // hs.Add("@iElementId", elementid);
                //hs.Add("@szElementOCRData", elementocr);
                //hs.Add("@szElementLOSData", elementlos);
                //hs.Add("@bMatchStatus", matchstatus);
                hs.Add("@szcreatedBy", createdby.ToString());
                hs.Add("@szModifiedBy", modifiedby.ToString());
                hs.Add("@iStatId", statusid);
                if (QCNotes == " " || QCNotes == "NULL" || QCNotes == null)
                    QCNotes = "NULL";
                hs.Add("@szQCNotes", QCNotes);


                //DBHelper db = new DBHelper();
                //_dt = db.SelectDataTable(spName, hs);
                //return _dt;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppID);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(spName, hs));
        }

        public DataTable GetToAutomateAuditLOSData(int subprocessid)
        {
            objloginfo.AppID = AppID;
            objloginfo.TenantName = TenantName;
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("AuditDetailsDAO - GetAuditQCStatus - Called.");
            try
            {

                DataTable _dt = new DataTable();
                string spName = string.Empty;
                spName = "USP_GET_ToAutomateAuditLOSData";
                Hashtable hs = new Hashtable();
                hs.Add("@iSubProcessId", subprocessid);
                List<Hashtable> lstHash = new List<Hashtable>();
                DBHelper db = new DBHelper();
                _dt = db.SelectDataTable(spName, hs);
                return _dt;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppID);
                // proxyLogger.Log.Error(ex.Message); // proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
        }
    }
}
