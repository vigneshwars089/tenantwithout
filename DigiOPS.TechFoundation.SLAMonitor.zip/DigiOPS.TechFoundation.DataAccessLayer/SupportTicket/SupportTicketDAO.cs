﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class SupportTicketDAO
    {
        private string dbConnectionString = string.Empty;
        LogInfo objLogInfo = new LogInfo();
        ILoggingFactory objLogging = new LoggingFactory();

        public SupportTicketDAO()
        {
            //dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"].ToString();
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public SupportTicketDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public string SetSupportTicket(SupportTicketEntity Ticket)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - SetSupportTicket - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            //proxyLogger.Log.Info("SupportTicketDetailsDAO - SetSupportTicket - Called.");
            try
            {
                string strAction = Ticket.Action;
                string resultValue = "-1";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_SupportTicket, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iIssueId", SqlDbType.Int).Value = (Ticket == null) ? 0 : Ticket.IssueId;
                    command.Parameters.Add("@szUserName", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.UserName;
                    command.Parameters.Add("@szEmailId", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.EmailId;
                    command.Parameters.Add("@szQuartLoginId", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.QuartLoginId;
                    command.Parameters.Add("@szIssueSummary", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.IssueSummary;
                    command.Parameters.Add("@szIssueDesc", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.IssueDesc;
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }
                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
           
        }

        /// <summary>
        /// TO SET SUPPORT TICKET TRAIL 
        /// </summary>
        /// <param name="Ticket"></param>
        /// <returns></returns>
        public string SetSupportTicketTrail(SupportTicketEntity Ticket)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - SetSupportTicketTrail - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            //proxyLogger.Log.Info("SupportTicketDetailsDAO - SetSupportTicketTrail - Called.");
            try
            {

                string resultValue = "-1";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();


                    SqlCommand command = new SqlCommand("USP_SET_SupportTicketTrail", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iIssueId", SqlDbType.Int).Value = (Ticket == null) ? 0 : Ticket.IssueId;
                    command.Parameters.Add("@szIssueModule", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.SelectedIssueModule;
                    command.Parameters.Add("@szIssueType", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.SelectedIssueType;
                    command.Parameters.Add("@szPriorityType", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.SelectedPriorityType;
                    command.Parameters.Add("@szIssueStatus", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.SelectedStatus;
                    command.Parameters.Add("@fWorkEffort", SqlDbType.Float).Value = (Ticket == null) ? 0 : Convert.ToSingle(Ticket.WorkEffort);
                    command.Parameters.Add("@szComments", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.Comments;
                    command.Parameters.Add("@iModifiedBy", SqlDbType.VarChar).Value = (Ticket == null) ? string.Empty : Ticket.ModifiedBy;

                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }
                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            
        }

        public DataTable GetSupportTicketEntityList(SupportTicketEntity objProgramIssuesEntity)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - GetSupportTicketEntityList - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            //proxyLogger.Log.Info("SupportTicketDetailsDAO - GetSupportTicketEntityList - Called.");

            try
            {
                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_SupportTicketDataList", sqlConnection);
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objProgramIssuesEntity.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objProgramIssuesEntity.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objProgramIssuesEntity.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objProgramIssuesEntity.SortColumn;
                    command.Parameters.Add("@FilePath", SqlDbType.VarChar).Value = objProgramIssuesEntity.FileName;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                return _dt;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            
        }
        /// <summary>
        /// TO SET SUPPORT TICKET MAILING DETAILS
        /// </summary>
        /// <param name="_Obj"></param>
        /// <returns></returns>
        public string SetSupportTicketMailingDetails(BaseTransportEntity _Obj)
        {
            string resultValue = "-1";
            objLogInfo.Message = "SupportTicketDetailsDAO - SetSupportTicketMailingDetails - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
           // proxyLogger.Log.Info("SupportTicketDetailsDAO - SetSupportTicketMailingDetails - Called.");
            try
            {
                SupportTicketSendMailEntity MailData = new SupportTicketSendMailEntity();
                MailData = (SupportTicketSendMailEntity)_Obj;

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_SUPPORTMAILTRACKER", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iIssueId", SqlDbType.Int).Value = (MailData.IssueId == null) ? 0 : MailData.IssueId;
                    command.Parameters.Add("@szSentTo", SqlDbType.VarChar).Value = (MailData.szSentTo == null) ? null : MailData.szSentTo;
                    command.Parameters.Add("@szSentCC", SqlDbType.VarChar).Value = (MailData.szSentCC == null) ? null : MailData.szSentCC;
                    command.Parameters.Add("@szSentFrom", SqlDbType.VarChar).Value = (MailData.szSentFrom == null) ? null : MailData.szSentFrom;
                    command.Parameters.Add("@szSentSubj", SqlDbType.VarChar).Value = (MailData.szSentSubj == null) ? null : MailData.szSentSubj;
                    command.Parameters.Add("@bMailSent", SqlDbType.Bit).Value = (MailData.bMailSent == null) ? false : MailData.bMailSent;
                    command.Parameters.Add("@UserId", SqlDbType.VarChar).Value = (MailData.UserID == null) ? null : MailData.UserID;
                    command.Parameters.Add("@FileName", SqlDbType.VarChar).Value = (MailData.FileName == null) ? null : MailData.FileName;
                    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }

                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
           
        }

        public DataTable GetSupportTicketEntityTrailList(SupportTicketTrailEntity objTicketTrailEntity)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - GetSupportTicketEntityTrailList - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            //proxyLogger.Log.Info("SupportTicketDetailsDAO - GetSupportTicketEntityTrailList - Called.");

            try
            {
                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_SupportTicketTrailList", sqlConnection);
                    command.Parameters.Add("@IssueId", SqlDbType.Int).Value = objTicketTrailEntity.IssueId;

                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                return _dt;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            
        }

        public DataTable GetSupportTicketById(SupportTicketEntity objTicket)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - GetSupportTicketById - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
           // proxyLogger.Log.Info("SupportTicketDetailsDAO - GetSupportTicketById - Called.");

            try
            {
                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_SupportTicketById", sqlConnection);
                    command.Parameters.Add("@IssueId", SqlDbType.Int).Value = objTicket.IssueId;

                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                return _dt;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
           
        }


        public DataTable GetSupportTicketStatus(SupportTicketEntity objTicket)
        {
            objLogInfo.Message = "SupportTicketDetailsDAO - GetSupportTicketStatus - Called.";
            objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            //proxyLogger.Log.Info("SupportTicketDetailsDAO - GetSupportTicketStatus - Called.");

            try
            {
                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();

                    SqlCommand command = new SqlCommand("USP_GET_SupportTicketStaus", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                return _dt;
            }
            catch (ArgumentException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            
        }

    }
}
