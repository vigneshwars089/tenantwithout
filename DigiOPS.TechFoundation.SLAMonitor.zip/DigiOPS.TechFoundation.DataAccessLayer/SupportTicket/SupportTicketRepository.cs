﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class SupportTicketRepository : ISupportTicketRepository
    {
        public virtual string SetSupportTicket(Entities.SupportTicketEntity Ticket)
        {
            throw new NotImplementedException();
        }

        public virtual string SetSupportTicketTrail(Entities.SupportTicketEntity Ticket)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataTable GetSupportTicketEntityList(Entities.SupportTicketEntity objProgramIssuesEntity)
        {
            throw new NotImplementedException();
        }

        public virtual string SetSupportTicketMailingDetails(Entities.BaseTransportEntity _Obj)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataTable GetSupportTicketEntityTrailList(Entities.SupportTicketTrailEntity objTicketTrailEntity)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataTable GetSupportTicketStatus(Entities.SupportTicketEntity objTicket)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataTable GetSupportTicketById(Entities.SupportTicketEntity objTicket)
        {
            throw new NotImplementedException();
        }
    }
}
