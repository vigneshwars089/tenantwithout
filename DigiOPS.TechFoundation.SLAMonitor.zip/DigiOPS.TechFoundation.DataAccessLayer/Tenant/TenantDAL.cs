﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.DataAccessLayer
// Class Name(s) :MultiTenantDAL
// Author : Sujitha
// Creation Date : 9/5/2017
// Purpose : MultiTenant Data Access Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////

using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class TenantDAL : ITenantRepository
    {
        private string dbConnectionString = string.Empty;
        private string CommondbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public TenantDAL()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            CommondbConnectionString = ConfigurationManager.ConnectionStrings["CommonDBConnStr"].ConnectionString;
        }
        public TenantDAL(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public DataTable GetConnectionStringDetails(string AppId, int TenantId)
        {
            objloginfo.Message = ("MultiTenantDAL - GetTenantDBDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            try
            {

                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_GET_TenantDBDetails", sqlConnection);
                    command.Parameters.Add("@iTenantId", TenantId);
                    command.Parameters.Add("@szAppId", AppId);
                    // command.Parameters.Add(AppId.ToString());
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    // da.Fill(ds);
                    adp.Fill(_dt);
                    sqlConnection.Close();

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }


        }

        public string GetConnectionStringDetails(string AppId, string TenantName)
        {
            objloginfo.Message = ("MultiTenantDAL - GetTenantDBDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = "-1";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(CommondbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_GET_TenantConnectionDetails", sqlConnection);
                    command.Parameters.Add("@TenantName", TenantName);
                    command.Parameters.Add("@AppId", AppId);
                    // command.Parameters.Add(AppId.ToString());
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    resultValue = command.ExecuteScalar().ToString();
                    //SqlDataAdapter adp = new SqlDataAdapter(command);
                    //// da.Fill(ds);
                    //adp.Fill(_dt);
                    sqlConnection.Close();

                }
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }

            return resultValue;
        }

        public int SaveTenantDetails(TenantInfo objMultiTenancyInfo)
        {
            objloginfo.Message = ("MultiTenantDAL - SaveTenantDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();
            int resultValue = 0;
            try
            {
               //OLD Insertion Format
                //foreach (var a in objMultiTenancyInfo.TenantDetails)
                //{
                //   //Input for QuarTenantMaster
                //    hs.Add("@szInstanceName", a.InstanceName);                
                //    hs.Add("@szLicenceKey", a.LicenseKey);
                //    hs.Add("@szSameURL", a.SameURL);
                //    hs.Add("@szURL", a.URL);
                //    hs.Add("@dsEffectiveFrom", a.EffectiveFrom);
                //    hs.Add("@dsEffectiveTo", a.EffectiveTo);
                //    hs.Add("@iVertical", a.Vertical);
                //    hs.Add("@iAccountId", a.AccountId);
                //    hs.Add("@iTenantDbId", a.TenantDBID);
                //    hs.Add("@szServerName", objMultiTenancyInfo.DatabaseDetails.ServerName);//Input for TenantDBDetails
                //    hs.Add("@szDatabaseName", objMultiTenancyInfo.DatabaseDetails.DataBaseName);
                //    hs.Add("@szUserId", objMultiTenancyInfo.DatabaseDetails.UserName);
                //    hs.Add("@szPassword", objMultiTenancyInfo.DatabaseDetails.Password);
                //    hs.Add("@szTenantName", objMultiTenancyInfo.TenantName);
                //    hs.Add("@iTenantUserId", a.TenantUserID);//sending same values for 2 entities hence renamed
                //    hs.Add("@szAppId", objMultiTenancyInfo.AppID);
                //    hs.Add("@iTenantId", objMultiTenancyInfo.TenantID);//sending same values for 2 entities
                //    hs.Add("@sOpertaionName", objMultiTenancyInfo.OperationName);
                //}

                using (SqlConnection sqlConnection = new SqlConnection(CommondbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_SET_TenantDetails", sqlConnection);
                    foreach (var a in objMultiTenancyInfo.TenantDetails)
                    {                 
                    command.Parameters.Add("@szInstanceName", a.InstanceName);
                    command.Parameters.Add("@szLicenceKey", a.LicenseKey);
                    command.Parameters.Add("@szSameURL", a.SameURL);
                    command.Parameters.Add("@szURL", a.URL);
                    command.Parameters.Add("@dsEffectiveFrom", a.EffectiveFrom);
                    command.Parameters.Add("@dsEffectiveTo", a.EffectiveTo);                   
                    command.Parameters.Add("@iTenantDbId", a.TenantDBID);
                    command.Parameters.Add("@szServerName", objMultiTenancyInfo.DatabaseDetails.ServerName);//Input for TenantDBDetails
                    command.Parameters.Add("@szDatabaseName", objMultiTenancyInfo.DatabaseDetails.DataBaseName);
                    command.Parameters.Add("@szUserId", objMultiTenancyInfo.DatabaseDetails.UserName);
                    command.Parameters.Add("@szPassword", objMultiTenancyInfo.DatabaseDetails.Password);
                    command.Parameters.Add("@szTenantName", objMultiTenancyInfo.TenantName);
                    command.Parameters.Add("@iTenantUserId", a.TenantUserID);//sending same values for 2 entities hence renamed
                    command.Parameters.Add("@szAppId", objMultiTenancyInfo.AppID);
                    command.Parameters.Add("@iTenantId", objMultiTenancyInfo.TenantID);//sending same values for 2 entities
                    command.Parameters.Add("@sOpertaionName", objMultiTenancyInfo.OperationName);
                     string ConnectionString = "Data Source=" + objMultiTenancyInfo.DatabaseDetails.ServerName + "; Initial Catalog=" + objMultiTenancyInfo.DatabaseDetails.DataBaseName + ";  User Id=" + objMultiTenancyInfo.DatabaseDetails.UserName +"; Password=" + objMultiTenancyInfo.DatabaseDetails.Password + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;";
                     command.Parameters.Add("@szConnectionString", ConnectionString);                   
                     command.Parameters.Add("@IsActive", a.IsActive);
                    }
                    // command.Parameters.Add(AppId.ToString());
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    resultValue = Convert.ToInt32(command.ExecuteScalar());
                    //SqlDataAdapter adp = new SqlDataAdapter(command);
                    //// da.Fill(ds);
                    //adp.Fill(_dt);
                    sqlConnection.Close();

                }


                ////Insertion Format changed on 28/Aug/2017
                //foreach (var a in objMultiTenancyInfo.TenantDetails)
                //{
                //    //Input for QuarTenantMaster
                //    hs.Add("@szInstanceName", a.InstanceName);
                //    hs.Add("@szLicenceKey", a.LicenseKey);
                //    hs.Add("@szSameURL", a.SameURL);
                //    hs.Add("@szURL", a.URL);
                //    hs.Add("@dsEffectiveFrom", a.EffectiveFrom);
                //    hs.Add("@dsEffectiveTo", a.EffectiveTo);                   
                //    hs.Add("@iTenantDbId", a.TenantDBID);
                //    hs.Add("@szServerName", objMultiTenancyInfo.DatabaseDetails.ServerName);//Input for TenantDBDetails
                //    hs.Add("@szDatabaseName", objMultiTenancyInfo.DatabaseDetails.DataBaseName);
                //    hs.Add("@szUserId", objMultiTenancyInfo.DatabaseDetails.UserName);
                //    hs.Add("@szPassword", objMultiTenancyInfo.DatabaseDetails.Password);
                //    hs.Add("@szTenantName", objMultiTenancyInfo.TenantName);
                //    hs.Add("@iTenantUserId", a.TenantUserID);//sending same values for 2 entities hence renamed
                //    hs.Add("@szAppId", objMultiTenancyInfo.AppID);
                //    hs.Add("@iTenantId", objMultiTenancyInfo.TenantID);//sending same values for 2 entities
                //    hs.Add("@sOpertaionName", objMultiTenancyInfo.OperationName);
                //     string ConnectionString = "Data Source=" + objMultiTenancyInfo.DatabaseDetails.ServerName + "; Initial Catalog=" + objMultiTenancyInfo.DatabaseDetails.DataBaseName + ";  User Id=" + objMultiTenancyInfo.DatabaseDetails.UserName +"; Password=" + objMultiTenancyInfo.DatabaseDetails.Password + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;";
                //     hs.Add("@szConnectionString", ConnectionString);                   
                //     hs.Add("@IsActive", a.IsActive);
                //}
              
              
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            return resultValue;
                //Convert.ToInt32(new DBHelper().SelectSingleValue("USP_SET_TenantDetails", hs));
        }

      
    }
}
