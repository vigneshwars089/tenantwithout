﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{

    public class BaseEfficiencyCalculator : IEfficiencyCalculator
    {
       // string sqlConnectionString = ConfigurationManager.AppSettings["EfficiencyCalculator"];

        public List<string> GetRoles(string ApplicationName)
        {
            Hashtable hs = new Hashtable();
            hs.Add("@ApplicationName", ApplicationName);     
            DataSet ds= new DBHelper().SelectDataSet(EMTConstant.S_EfficiencyCalculatorScripts.GetRoles);
            return ds.Tables[0].AsEnumerable().Select(r => r.Field<string>("RoleName")).ToList();
                     
        }

        public List<string> GetActivity(string ApplicationName)
        {
            Hashtable hs = new Hashtable();
            DataSet ds = new DataSet();
            List<string> activities = new List<string>();
            try
            {
                hs.Add("@ApplicationName", ApplicationName);
                ds = new DBHelper().SelectDataSet(EMTConstant.S_EfficiencyCalculatorScripts.GetActivity, hs);
                activities = ds.Tables[0].AsEnumerable().Select(r => r.Field<string>("ActivityName")).ToList();
            }
            catch(Exception ex)
            {
            }

            return activities;
            
          
        }
        
     
    }
}
