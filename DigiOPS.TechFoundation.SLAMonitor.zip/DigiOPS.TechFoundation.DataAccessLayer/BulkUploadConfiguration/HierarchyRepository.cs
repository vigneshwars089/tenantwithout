﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class HierarchyRepository : IHierarchyRepository
    {

        public virtual System.Data.DataSet InsertHierarchyDetails(string strTableName, string strXML)
        {
            throw new NotImplementedException();
        }
    }
}
