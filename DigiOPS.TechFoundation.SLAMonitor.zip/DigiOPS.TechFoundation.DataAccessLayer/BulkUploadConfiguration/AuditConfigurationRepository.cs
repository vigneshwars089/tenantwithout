﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class AuditConfigurationRepository : IBulkUploadConfigurationRepository
    {

        public virtual System.Data.DataSet GetExcelTemplate()
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet InsertAuditConfigDetails(System.Data.DataSet ds)
        {
            throw new NotImplementedException();
        }

        public virtual string defectopportunity(System.Data.DataTable result1)
        {
            throw new NotImplementedException();
        }

        public virtual string subdefectopportunity(System.Data.DataTable result1)
        {
            throw new NotImplementedException();
        }

        public virtual string Ratingtype(System.Data.DataTable result1)
        {
            throw new NotImplementedException();
        }

        public virtual string Ratinggroup(System.Data.DataTable result1)
        {
            throw new NotImplementedException();
        }

        public virtual string CombinedAccuracy(System.Data.DataTable result1)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet DefectSubDefectValidation()
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet RatingTypeValidation()
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet CombinedAccuracyValidation()
        {
            throw new NotImplementedException();
        }
    }
}
