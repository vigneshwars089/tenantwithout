﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class HierarchyDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        public HierarchyDAO()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;           
        }
        public HierarchyDAO(string appId, int tenantId)
        {

            //dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            ConnectionString conn = new ConnectionString();
            dbConnectionString = conn.GetConnectionString(appId, tenantId);
        }
        public HierarchyDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :AllocationDAO.cs
        // Namespace : DigiOps.TechFoundation.DataAccessLayer
        // Method Name(s) :InsertAllocationDetails
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/6/2017
        // Purpose : InsertAllocationDetails method added for Allocation Component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name                          Method Name                                        Description
        // ----------   --------                      --------------------------             --------------------------------------------------
        // 6-May-2017    Venkata Lakshmi CH.              InsertAllocationDetails               Modified InsertAllocationDetails method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public DataTable InsertHierarchyDetails(string strTableName, string strXML)
       {
             string error = "";
           string result = string.Empty;
           objloginfo.Message = ("HierarchyDAO - InsertHierarchyDetails - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           DataTable ds = new DataTable();
            
            SqlConnection connection = null;
           try
           {

               connection = new SqlConnection(dbConnectionString);
               connection.Open();
            
               using (SqlCommand command = connection.CreateCommand())
               {

                   switch (strTableName)
                   {
                       case "Process":

                          
                           command.CommandText = "USP_SET_PROCESSMASTER_Test";
                         break;
                       case "SubProcess":
                           command.CommandText = "USP_SET_SUBPROCESSMASTER_Test";
                           break;
                   }
                   command.Parameters.Add("@strXml", strXML);
                   command.CommandType = CommandType.StoredProcedure;
                   using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                   {
                       adapter.Fill(ds);
                   }
               }
               if (true)
               {
                   
               }
              // result = ds.Tables[0].Rows[0][0].ToString();              
               //ds.Tables[0].Rows[0].Table.TableName = strTableName;
               return ds;                           
               

           }
           catch (SqlException ex)
           {
               result = "Duplication Transactions Entered";



           }
           catch (InvalidOperationException ex)
           {
               objlog.GetLoggingHandler("Log4net").LogException(ex);
               result = ex.ToString();
           }
           catch (NullReferenceException ex)
           {

               objlog.GetLoggingHandler("Log4net").LogException(ex);
               result = ex.ToString();

           }
           return ds;
           //x = x+ 1;
       }

        
    }
    }

