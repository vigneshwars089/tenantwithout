﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class EMTConfigurationConstant
    {
        public struct S_ConfigurationrDBScripts
        {
            public const string CREATE_USERS = "USP_CREATE_USERS";
            public const string UPDATE_USERS = "USP_UPDATE_USERS";
            public const string RSA = "RSA";
            public const string Base64 = "Base64";
        }
    }
}
