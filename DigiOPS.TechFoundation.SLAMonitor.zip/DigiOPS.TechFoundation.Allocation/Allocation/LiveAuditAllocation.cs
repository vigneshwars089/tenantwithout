﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :LiveAuditAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :LiveAuditAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added ReAllocation to Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class LiveAuditAllocation : BaseAllocation
    {
        public override AllocatedDetails Allocate(AllocationDetails allocationDetails)
        {
            allocationDetails = AllocationValidation(allocationDetails);
            AllocatedDetails allocatedDetails = new AllocatedDetails();
            if (allocationDetails.ResultStatus)
            {

                allocatedDetails.CreatedBy = allocationDetails.CreatedBy;
                allocatedDetails.CreatedOn = allocationDetails.CreatedOn;
                if (allocationDetails.AllocateToUsers.Count > 1)
                {
                    allocatedDetails.ErrorMessage.Append("User" + ErrorMessgae.Not_More_thanOne);
                }
                else
                {
                    var user = allocationDetails.AllocateToUsers[0].UserID;
                    foreach (var allocationDetailsList in allocationDetails.RecordDetails)
                    {
                        var AllocatedDetailsList = new AllocatedDetail();
                        AllocatedDetailsList.UserID = user;
                        AllocatedDetailsList.TransID = allocationDetailsList.TransID;

                        allocatedDetails.AllocatedDetailsList.Add(AllocatedDetailsList);
                    }
                }
            }
            return allocatedDetails;
            //foreach (var user in allocationDetails.AllocateToUsers)
            //{
            //    foreach (var allocatedRecords in allocationDetails.RecordDetails)
            //    {
            //        var AllocatedDetail = new AllocatedDetails();
            //        AllocatedDetail.UserID = Convert.ToString(user.UserID);
            //        AllocatedDetail.TransID = allocatedRecords.TransID;
            //        LstAllocatedDetails.Add(AllocatedDetail);
            //    }
            //}

        }
    }
}
