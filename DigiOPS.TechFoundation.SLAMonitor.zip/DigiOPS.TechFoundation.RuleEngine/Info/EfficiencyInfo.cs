﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.RuleEngine
{
    public class EfficiencyInfo
    {
        
            public string RoleName { get; set; }
            public string ActivityName { get; set; }
            /// <summary>
            /// Default regularWorkingHrs of Cognizant Employee is 8
            /// </summary>
            private decimal regularWeekdayWorkingHrs = 8;
            public decimal RegularWeekdayWorkingHrs
            {
                get
                {
                    if (regularWeekdayWorkingHrs <= 0)
                    {
                        regularWeekdayWorkingHrs = 8;
                    }
                    return regularWeekdayWorkingHrs;
                }
                set { regularWeekdayWorkingHrs = value; }
            }
            /// <summary>
            ///  4 weeks of a month * 5 days * 7.85 hrs/day 
            /// </summary>
            public decimal MonthlyWorkingHrs
            {
                get
                {
                    return RegularWeekdayWorkingHrs * 4 * 5;
                }

            }


            public decimal TimeSpentOnActivityinaWeek { get; set; }

            public decimal TimeSpentOnActivityinaMonth
            {
                get
                {
                    return TimeSpentOnActivityinaWeek * 4;
                }
            }

            public int EfficienyRate { get; set; }
            public decimal TimeSavedOnActivityinaMonth
            {
                get
                {
                    return TimeSpentOnActivityinaMonth * EfficienyRate / 100;
                }
            }
            private int headCount = 1;

            public int HeadCount
            {
                get
                {
                    if (headCount <= 0)
                    {
                        headCount = 1;
                    }

                    return headCount;
                }
                set { headCount = value; }
            }

            public decimal TotalHrsSaved
            {
                get
                {
                    return TimeSavedOnActivityinaMonth * headCount;
                }

            }
            public decimal FTESaved
            {
                get
                {
                    return TotalHrsSaved / MonthlyWorkingHrs;
                }
            }

            public decimal FTECostSaved
            {
                get
                {
                    return 1600 * FTESaved;
                }
            }
            public string Comments { get; set; }
            /// <summary>
            /// 1 * 10 $ * 8 hrs  * 5 days * 4 weeks
            /// </summary>
            public decimal OneFTECostPerMonth
            {
                get
                {
                    return 1 * 10 * 8 * 5 * 4;
                }
            }
        }
    }


