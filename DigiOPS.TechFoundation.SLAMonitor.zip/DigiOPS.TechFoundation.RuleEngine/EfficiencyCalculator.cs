﻿using DigiOPS.TechFoundation.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.RuleEngine
{
   public class EfficiencyCalculator
    {
       IEfficiencyCalculator objCalculator = new BaseEfficiencyCalculator();

       public List<string> ListRoles(){
           return objCalculator.GetRoles("");  
    }
       public List<string> ListAcitvities()
       {
           return objCalculator.GetActivity("");
       }


       public List<double> WorkingHoursperMonth()
       {
           List<double> objin = new List<double>();
           for (double i = 7.50; i <= 8.5; i = i +.25)
           { objin.Add(i); }
           return objin;
       }


       public List<int> EfficiencyPercentage()
       {
           List<int> objin = new List<int>();
           for (int i = 1; i <= 20; i = i * 5)
           { objin.Add(i); }
           return objin;
       }
          

    }
}
