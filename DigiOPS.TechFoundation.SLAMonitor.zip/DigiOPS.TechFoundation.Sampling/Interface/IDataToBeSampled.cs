﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
   public interface IDataToBeSampled
    {
       TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransListDetails);
       // object GetDataToBeSampled(List<object> AssociateList);
      // object GetFieldsToBeSampled(List<object> Field);
       
    }
}
