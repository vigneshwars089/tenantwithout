﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    public interface IDataToBeSampledFactory
    {
        IDataToBeSampled GetFilterHandler(string Actor, string Duration, string Type);
    }
}
