﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.Sampling
{
    public interface IBaseSampling //: ISamplingFactory
    {
        //string SetSamplingPercentage(string AudittypeID, string SubprocessID, string SystemUserID, string SamplingPct, string SamplingType, string CreatedBy);
        string SetSamplingPercentage(SamplingEntity SE);
        List<SamplingEntity> GetSamplingPctDetails(SamplingEntity objSamplingEntity);
        //List<string> SamplingMethods(TransactionListViewModalList objTransactionListViewModalList);



    }
}
