﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    public class DataToBeSampledByActor : BaseDataTobeSampled
    {
        public object GetDataTobeSampled(TransactionListDetails DatatobeSampled)
        {
            throw new NotImplementedException();
        }

        //public TransactionListDetails DoSamplebyActor(TransactionListDetails objTranDet)
        //{

        //    return objTranDet;
        //}
    }
}
