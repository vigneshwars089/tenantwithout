﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    public class DataToBeSampledByDuration : BaseDataTobeSampled
    {
        public TransactionLists GetDataTobeSampled(string Duratation ,int totalcount, int Alreadyallocated , int samplingPerentage )

        {
            TransactionLists list = new TransactionLists();

            if(Duratation=="Daily")
            {
                
            }
            return list;


        }
    }
}
