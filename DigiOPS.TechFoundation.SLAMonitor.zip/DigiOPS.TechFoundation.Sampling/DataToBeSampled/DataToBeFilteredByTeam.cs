﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredByTeam.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredByTeam
    // Author : Venkata Lakshmi CH.
    // Creation Date : 5/2/2017
    // Purpose : This class will be used to perform Sampling for Team.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class DataToBeFilteredByTeam : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredByScore.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/2/2017
        // Purpose : This method will be used to perform Sampling for Team.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransactionListDetails)
        {
                TransactionListDetails objListDetails = new TransactionListDetails();
            TransactionListResponse objResponse = new TransactionListResponse();

            //Getting the SamplingPercentage
            List<TransactionsAllocatedLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;


            //Getting the Transaction List
            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists.ToList();
            objListDetails.TransactionLists = objTransactionLists.ToList();
            objListDetails.TransactionAllocatedLists = objTransactionAllocatedLists;
            IDataToBeSampled objSampling = null;
          
            objSampling = new DataToBeFilteredBySubProcessDaily();
            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);

           

            return objResponse;

        }
    }
}
