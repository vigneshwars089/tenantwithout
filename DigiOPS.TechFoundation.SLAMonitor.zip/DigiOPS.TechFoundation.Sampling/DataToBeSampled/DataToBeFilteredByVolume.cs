﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredByVolume.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredByVolume
    // Author : Venkata Lakshmi CH.
    // Creation Date : 5/4/2017
    // Purpose : This class will be used to perform Sampling for Volume.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class DataToBeFilteredByVolume : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredByVolume.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/4/2017
        // Purpose : This method will be used to perform Sampling for Team.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransactionListDetails)
        {
            TransactionListResponse objResponse = new TransactionListResponse();

            //Getting the SamplingPercentage
            List<TransactionsAllocatedLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;


            //Passing for Response
            List<TransactionsPendingLists> objTransactionsPendingLists = new List<TransactionsPendingLists>();

            double SampPercentage = objTransactionAllocatedLists.FirstOrDefault().Percentage;
            int Volume = objTransactionListDetails.ToBeSampledByVolume;

            ///* GEt Total Transactions for the given Month*/
            //int Total = (from p in objTransactionListDetails.TransactionLists

            //             select p
            //               ).Count();

            ///* Calculating the Percentage*/
            //double Percentage = SampPercentage;

            ///* Calculating the pending transactions*/
            //int pending = Convert.ToInt16(Percentage);
            //pending = ((pending <= Allocated) ? 0 : pending - Allocated);

            TransactionsPendingLists objPendinglist = new TransactionsPendingLists();
            objPendinglist.TobeSampled = Volume;
            //objPendinglist.Percentage = SampPercentage;
            objTransactionsPendingLists.Add(objPendinglist);

            objResponse.TransactionPendingLists = objTransactionsPendingLists;
            objResponse.TransactionLists = objTransactionListDetails.TransactionLists;
            return objResponse;



        }

    }
}
