﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseSamplingStage.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :BaseSamplingStage
    // Author : P Sadhesh Kumar.
    // Creation Date : 5/4/2017
    // Purpose : This class will declare two virtual methods which will be implemented by MultiStageSampling and SingleStage Sampling 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////


    public class BaseSamplingStage : IBaseSamplingStage
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseSamplingStage.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // method Name(s) :GetSampingDetails
        // Author : P Sadhesh Kumar.
        // Creation Date : 5/4/2017
        // Purpose : This method will have declaration part which will be implemented by SingleStage Sampling 
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public virtual TransactionListDetails GetSampingDetails(string Actor, string Duration, string Type, TransactionListDetails objTransListDetails)
        {
            throw new NotImplementedException();
        }

        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseSamplingStage.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // method Name(s) :GetSampingDetails
        // Author : P Sadhesh Kumar.
        // Creation Date : 5/4/2017
        // Purpose : This method will have declaration part which will be implemented by MultiStage Sampling  
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public virtual TransactionListDetails GetSampingDetails(MultiStageSamplingInfo objmultistageinfo, TransactionListDetails objTransListDetails)
        {
            throw new NotImplementedException();
        }
    }
}
