﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Sampling
{
    public class MultiStageSamplingInfo
    {
        public MultiStageSamplingInfo()
        {
            Multistageinfo = new List<SamplingInfo>();

        }
        public List<SamplingInfo> Multistageinfo { get; set; }
    }

    public class SamplingInfo : MultiStageSamplingInfo
    {

        public int Level { get; set; }
        public string Actor { get; set; }
        public string Duration { get; set; }
        public string Type { get; set; }

    }
}
