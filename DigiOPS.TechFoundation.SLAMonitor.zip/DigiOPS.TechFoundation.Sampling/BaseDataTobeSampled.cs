﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{

    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseDataTobeSampled.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // class Name(s) :BaseDataTobeSampled
    // Author : P Sadhesh Kumar.
    // Creation Date : 4/17/2017
    // Purpose : This class will have declaration part which will be implemented by All the DataToBeFiltered classes to filter the TransactionList. 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class BaseDataTobeSampled : IDataToBeSampled

    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseDataTobeSampled.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // method Name(s) :GetDataTobeSampled
        // Author : P Sadhesh Kumar.
        // Creation Date : 4/17/2017
        // Purpose : This method will have declaration part which will be implemented by All the DataToBeFiltered classes to filter the TransactionList. 
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public virtual TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails ObjDatatobeSampled)
        {
            throw new NotImplementedException();
        }
    }
}
