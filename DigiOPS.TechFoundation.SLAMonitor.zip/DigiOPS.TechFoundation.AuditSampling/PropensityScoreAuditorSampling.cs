﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.AuditSampling
{
    public class PropensityScoreAuditorSampling : BaseAuditSampling
    {
        SamplingDAO SDAOPropensityScoreAuditor = new SamplingDAO();
        public override TransactionListDetails SamplingLogic(TransactionListDetails objTransactionListDetails)
        {
            string Message = objTransactionListDetails.SamplingTechnique + " Auditor Sampling";
            // Message = (SDAOPropensityScoreAuditor.GetTransListForAutoAlloc(objTransactionListDetails)).ToString();
            return objTransactionListDetails;
        }

    }
}
