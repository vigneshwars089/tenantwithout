﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Calibration
{

    public struct S_calibrationType
    {

        public const string Configure = "CONFIGURED";
        public const string Runtime = "RUNTIME";
       
    }

    public class CalibrationFactory : ICalibrationFactory
    {
       public ICalibrationAlgorithm GetCalibratorHandler(string calibrationType)
       {
           switch (calibrationType)
           {
               case S_calibrationType.Configure:
                   return new ConfiguredCalibrationAlgorithm();
               case S_calibrationType.Runtime:
                   return new RuntimeCalibrationAlgorithm();
               default:
                   return null;
           }
       
       }
    }
}
