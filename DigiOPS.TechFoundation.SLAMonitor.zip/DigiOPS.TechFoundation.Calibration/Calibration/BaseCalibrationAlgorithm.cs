﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
    public class BaseCalibrationAlgorithm : ICalibrationAlgorithm
    {

        public virtual ScoringOutput GetCalibartionScore(ScoringInfo objAuditDataEntity)
        {
            return null;
        }
    }
}
