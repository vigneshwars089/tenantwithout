﻿using DigiOPS.TechFoundation.Audit;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomateAudit_Scheduler_Testing
{
    public class Program
    {
        AudotmatedAuditDataAccess objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess();

        public static void Main(string[] args)
        {
            string loannumberlocal = string.Empty;
            double qualityscore = 0.0;
            AutomatedAudit objaudi = new AutomatedAudit();
            List<ServiceOutput> objserviceoutlist = new List<ServiceOutput>();
            List<List<ServiceOutput>> objserviceoutput = new List<List<ServiceOutput>>();
            List<List<DataelementAutomatedAuditEntity>> objoutp = new List<List<DataelementAutomatedAuditEntity>>();
            DataelementAutomatedAuditEntity objDataElmntEnt = new DataelementAutomatedAuditEntity();
            List<DataelementAutomatedAuditEntity> LoanNolist = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> ExpctdList = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> ActualList = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> LOSList = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> OCRList = new List<DataelementAutomatedAuditEntity>();
            DataelementAutomatedAuditEntity inp = new DataelementAutomatedAuditEntity();
            int result = 0;
            int subprcoessid = 162;
            inp.RecordId = subprcoessid;
            inp.TenantName = "ConnStr";
            inp.AppID = "Quart";
            objoutp = objaudi.GetDataElementBasedonSource(inp);
            if (objoutp != null)
            {
                LoanNolist = objoutp[2];
                LOSList = objoutp[1];
                OCRList = objoutp[0];
                for (int l = 0; l < LoanNolist.Count; l++)
                {
                    objserviceoutlist = new List<ServiceOutput>();
                    ExpctdList = new List<DataelementAutomatedAuditEntity>();
                    ActualList = new List<DataelementAutomatedAuditEntity>();
                    loannumberlocal = LoanNolist[l].ValueOfLoanNumber;
                    for (int i = 0; i < LOSList.Count; i++)
                    {
                        objDataElmntEnt = new DataelementAutomatedAuditEntity();
                        if (loannumberlocal == LOSList[i].ValueOfLoanNumber)
                        {
                            objDataElmntEnt = LOSList[i];
                            ActualList.Add(objDataElmntEnt);
                        }
                    }
                    for (int j = 0; j < OCRList.Count; j++)
                    {
                        objDataElmntEnt = new DataelementAutomatedAuditEntity();
                        if (loannumberlocal == OCRList[j].ValueOfLoanNumber)
                        {
                            objDataElmntEnt = OCRList[j];
                            ExpctdList.Add(objDataElmntEnt);
                        }

                    }

                    objserviceoutlist = objaudi.AuditDataElements(ActualList, ExpctdList);
                    objserviceoutput.Add(objserviceoutlist);

                    //for (int j = 0,k=0; j < objoutp.Count() && k<25; k++,j++)
                    //{
                    //    loannumberlocal = LoanNolist[l].ValueOfLoanNumber;
                    //    if(loannumberlocal==objDataElmntEnt
                    ////    objDataElmntEnt = objoutp[j];
                    //    if (objDataElmntEnt.TransactionSource.ToUpper() == "OCR")
                    //        ActualList.Add(objDataElmntEnt);
                    //    else if (objDataElmntEnt.TransactionSource.ToUpper() == "LOS")
                    //        ExpctdList.Add(objDataElmntEnt);


                    //    if (ExpctdList != null && ActualList != null)
                    //        objserviceoutput = objaudi.AuditDataElements(ExpctdList, ActualList);
                    //}
                }
            }
            List<ServiceOutput> objlistop = new List<ServiceOutput>();
            List<ServiceOutput> objlistopinsert = new List<ServiceOutput>();
            ServiceOutput objsop = new ServiceOutput();
            ServiceOutput objsop1 = new ServiceOutput();
            for (int j = 0; j < objserviceoutput.Count; j++)
            {
                int count = 0;
                objlistop = objserviceoutput[j];
                if (objlistop.Count > 0)
                {
                    for (int i = 0; i < objlistop.Count; i++)
                    {
                        objsop = new ServiceOutput();
                        objsop = objlistop[i];
                        if (objsop.ResultStatus == true)
                            count++;

                    }
                    objsop.CountOfMatch = count;
                    objsop1 = objsop;
                    if (count == objlistop.Count)
                    {
                        objsop = new ServiceOutput();
                        objsop.AuditStatusId = 19;
                        objsop.CreatedBy = 572814;
                        objsop.ModifiedBy = 572814;
                        objsop.RecordID = objsop1.RecordID;
                        objsop.ElementId = objsop1.ElementId;
                    }
                    else
                    {
                        objsop = new ServiceOutput();
                        objsop.AuditStatusId = 21;
                        objsop.CreatedBy = 572814;
                        objsop.ModifiedBy = 572814;
                        objsop.RecordID = objsop1.RecordID;
                        objsop.ElementId = objsop1.ElementId;
                    }
                    for (int l = 0; l < objlistop.Count; l++)
                    {
                        objsop1 = new ServiceOutput();
                        objsop1 = objlistop[l];
                        objsop1.CreatedBy = 572814;
                        objsop1.ModifiedBy = 572814;
                        objlistopinsert.Add(objsop1);
                    }

                    // foreach(var a  in objserviceoutput[0])
                    result = objaudi.InsertintoAuditFindingData(objlistopinsert);
                    result = objaudi.InsertintoAuditFindingDataStatus(objsop);
                }
            }
            // qualityscore=ps.ScoreCalculation(objlistopinsert);
            Console.WriteLine(result);
            Console.Read();

        }

    

    }
}

