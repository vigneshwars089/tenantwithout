﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
  public  class Common
    {

        #region PRIVATE METHODS
        /// <summary>
        /// Method to Encrpt a string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>        
        public string EncryptValue(string value)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(value);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        /// <summary>
        /// Method to Decrypt a string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string DecryptValue(string value)
        {
            byte[] b = Convert.FromBase64String(value.ToString());
            string decryptedvalue = System.Text.ASCIIEncoding.ASCII.GetString(b);
            return decryptedvalue;
        }
        /// <summary>
        /// Method to convert a string to bytes
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }
        /// <summary>
        /// Method to convert bytes to string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string GetString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }

        #endregion
    }
}
