﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public struct S_eMailType
    {

        public const string GMail = "GMAIL";
        public const string OutBox365 = "OUTBOX365";
        public const string OutLook = "OUTLOOK";

    }

    public class EmailReadingFactory : IEmailReadingFactory
    {

        public IEmailReading eMailReadingHandler(EMailInfo eInfo)
        {
            if (eInfo == null)
            {
                return new BaseMailReading();
            }
            else if (eInfo.eMailType == "" || String.IsNullOrEmpty(eInfo.eMailType))
            {
                return new BaseMailReading();
            }
            else if (eInfo.eMailType.ToUpper().Trim() != "GMAIL" && eInfo.eMailType.ToUpper().Trim() != "OUTBOX365" && eInfo.eMailType.ToUpper().Trim() != "OUTLOOK")
            {
                return new BaseMailReading();
            }
            else
            {
                switch (eInfo.eMailType.ToUpper())
                {
                    case S_eMailType.GMail:
                        return new GMailReading();
                    case S_eMailType.OutBox365:
                        return new OutBox365MailReading();
                    case S_eMailType.OutLook:
                        return new OutLookMailReading();
                    default:
                        return null;
                }

            }
        }
    }
}
