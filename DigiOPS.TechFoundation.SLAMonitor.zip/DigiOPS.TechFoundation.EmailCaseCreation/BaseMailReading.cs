﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Text.RegularExpressions;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public class BaseMailReading : IEmailReading
    {

        public virtual void readMail(DigiOPS.TechFoundation.Entities.EMailInfo emailInfo)
        {
            
        }


         public string Validation(EMailInfo emailInfo)
        {
          //  StringBuilder str = new StringBuilder();
            List<EmailInput> elist = new List<EmailInput>();
            emailInfo.ErrorMessage=new StringBuilder();
            EmailInput input = new EmailInput();
            //input.EMailId = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            //Regex r = new Regex(input.EMailId);
            //Regex r = new Regex("^/w+([-+.']/w+)*@/w+([-.]/w+)*/./w+([-.]/w+)*$");

           // r = input.EMailId.ToString();

          
            if (emailInfo == null)
            {
                emailInfo.ErrorMessage.Append("Email info Cannot be null");

            }
            else if ((emailInfo.eMailType == "") || (emailInfo.eMailType == null))
           {
               emailInfo.ErrorMessage.Append("Email Type Cannot be null");

            }
            else if((emailInfo.eMailType.ToUpper().Trim() != "GMAIL") || (emailInfo.eMailType.ToUpper().Trim() != "OUTBOX365") || (emailInfo.eMailType.ToUpper().Trim() != "OUTLOOK"))
            {
                 emailInfo.ErrorMessage.Append("Email Type Should be GMAIL or OUTBOX365 or OUTLOOK");

            }
            else if((emailInfo.CreationType == "")||(emailInfo.CreationType ==null))
            {
                emailInfo.ErrorMessage.Append("Email Creation Type cannot be null");
            }
            //var emlist in emailInfo.EmailInputList
            foreach( var emlist in emailInfo.EmailInputList)
             {
                input.EMailId = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
                Regex r = new Regex(input.EMailId);

             if(input.intmailfolderid=="")
            {
                emailInfo.ErrorMessage.Append("Please provide the mailFolderId");
            }
            else if (input.strpath == "")
            {
                emailInfo.ErrorMessage.Append("Please provide the valid strpath");
            }
            else if (input.strname == "")
            {
                emailInfo.ErrorMessage.Append("Please provide the valid strname");
            }
            else if((input.EMailId=="")||(!(r.IsMatch(input.EMailId))))
            {

                emailInfo.ErrorMessage.Append("Please provide Valid LoginId");
            }
            else if(input.TimeZone=="")
            {
                emailInfo.ErrorMessage.Append("Please provide valid TimeZone");
            }
            else if(input.ClientExVersion=="")
            {
                emailInfo.ErrorMessage.Append("Please provide Valid ClientExVersion");
            }
            else if(input.password=="")
            {
                emailInfo.ErrorMessage.Append("Please provide Valid Password");
            }
            }
            return emailInfo.ErrorMessage.ToString();
        }
    }
}
