﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
   public class OutBox365MailReading : BaseMailReading
    {
       public override void readMail(EMailInfo emailInfo)
       {

       }
    }
}
