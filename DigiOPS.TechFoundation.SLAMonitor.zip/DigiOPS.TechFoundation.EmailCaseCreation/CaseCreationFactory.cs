﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public class CaseCreationFactory : ICaseCreationFactory 
    {
        public struct S_CaseCreationType
        {

            public const string EMT = "EMT";
            public const string TrackWork = "TRACKWORK";

        }

        public IEmailReadingFactory CaseCreationHandler(EMailInfo eInfo)
        {
            switch (eInfo.CreationType.ToUpper())
                {
                    case S_CaseCreationType.EMT:
                        return new EmailReadingFactory();
                    case S_CaseCreationType.TrackWork:
                        return null;
                    default:
                        return null;
                }            
        }
    }
}
