﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class EMailInfo : BaseInfo
    {
        public EMailInfo()
        {
            //EmailInputList = new List<EmailInput>();
            //CaseCreationInputList = new List<CaseCreationInput>();
            EmbImageList = new List<EmbImg>();
            AttachmentList = new List<AttachmentFile>();
        }

        //public List<EmailInput> EmailInputList { get; set; }
        //public List<CaseCreationInput> CaseCreationInputList { get; set; }
        public List<EmbImg> EmbImageList { get; set; }
        public List<AttachmentFile> AttachmentList { get; set; }

        //output
        public string EMailBoxId { get; set; }
        public string eMailType { get; set; }
        public string toadd { get; set; }
        public string ccaddress { get; set; }
        public bool Priority { get; set; }
        //public string CaseIdKeyword { get; set; }
        public string spSubject { get; set; }
        public string spMessage { get; set; }
        public string spSender { get; set; }

        public string strpath { get; set; }
        public string strname { get; set; }
        public string EMailId { get; set; }
        public string LoginEMailId { get; set; }
        public string password { get; set; }
        public bool isVIP { get; set; }

        //public string bccaddress { get; set; }
        public string caseID { get; set; }

    }

    public class EmbImg : EMailInfo
    {
        public string strimages { get; set; }
    }
    public class AttachmentFile : EMailInfo
    {
        //public int AttachmentId { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public Byte[] FileContent { get; set; }
        public int AttachmentTypeId { get; set; }
        public string AttachmentType { get; set; }
        public DateTime CreatedDate { get; set; }
    }
    //public class CaseCreationInput : EMailInfo
    //{
    //    public string CaseIdKeyword { get; set; }
    //    public int currentStatus { get; set; }
    //    public string sCaseID { get; set; }
    //    public string caseID { get; set; }
    //    public DateTime spDate { get; set; }
    //    public string spMailFolderId { get; set; }
    //    public string spStatusId { get; set; }
    //    public string spSubject { get; set; }
    //    public string spMessage { get; set; }
    //    public string spSender { get; set; }
    //    public string toadd { get; set; }
    //    public string ccaddress { get; set; }
    //    public string bccaddress { get; set; }
    //    public bool Priority { get; set; }
    //    public string subcaseid { get; set; }
    //}

    //public class EmailInput : EMailInfo
    //{
    //    //public string intmailfolderid { get; set; }
    //    public string strpath { get; set; }
    //    public string strname { get; set; }
    //    //public string strMailHeader { get; set; }
    //    public string EMailId { get; set; }
    //    public string LoginEMailId { get; set; }
    //    public string TimeZone { get; set; }
    //    public string ClientExVersion { get; set; }
    //    public string password { get; set; }
    //}

}
