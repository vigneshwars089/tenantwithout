﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class MoveMailsInfo : BaseInfo
    {
       public MoveMailsInfo()
       {
           EmailInputList = new List<MoveMailsInput>();
       }
       public List<MoveMailsInput> EmailInputList { get; set; }
    }

   public class MoveMailsInput : MainBoxInfo
   {
       public List<GUIDList> GUIDList { get; set; }
       public string DestinationFolder { get; set; }
   }

   public class GUIDList
   {
       public string GUID { get; set; }
   }
}
