﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class CaseInfo : BaseInfo
    {
        public CaseInfo()
        {
            Attachments = new List<AttachmentInfo>();
            Comments = new List<CommentsInfo>();
            Traversal = new List<TraversalInfo>();

        }
        public string CaseID { get; set; }


        public EMailDetails EmailInformation { get; set; }

        public List<AttachmentInfo> Attachments { get; set; }
        public List<CommentsInfo> Comments { get; set; }
        public List<TraversalInfo> Traversal { get; set; }
    }
    public class AttachmentInfo : CaseInfo
    {
        public int AttachmentId { get; set; }
        public string FileName { get; set; }
        public Byte[] FileContent { get; set; }
        public int AttachmentTypeId { get; set; }
        public string AttachmentType { get; set; }
        public DateTime CreatedDate { get; set; }
    }
    public class CommentsInfo : CaseInfo
    {
        public string Comments { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedDate { get; set; }
    }
    public class TraversalInfo : CaseInfo
    {
        public string FromStatus { get; set; }
        public string ToStatus { get; set; }
        public string UserName { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
    public class EMailDetails : CaseInfo
    {
        public string EMailRecivedDate { get; set; }
        public string EMailFrom { get; set; }
       // public string EMailTo { get; set; }
        public string EMailCc { get; set; }
        //public string EMailBcc { get; set; }
        //public string ClassifiactionDescription { get; set; }
        //public bool IsActive { get; set; }
        public string Subject { get; set; }
        //public string EMailboxname { get; set; }
        //public string EMailboxAddress { get; set; }
        public bool IsUrgent { get; set; }
        public string EMailBody { get; set; }
        //public string Country { get; set; }
        //public string CountryId { get; set; }
        //public string StatusID { get; set; }
        //public string StatusDescription { get; set; }
        //public string AssignedToID { get; set; }
        //public string AssignedTo { get; set; }
        //public string QcUserID { get; set; }
        //public string QcAssignTo { get; set; }
        public bool IsManual { get; set; }
        //public string AttachmentLocation { get; set; }
        public string EMailType { get; set; }
        //public bool IsQcRequired { get; set; }
        //public bool IsMailTriggerRequired { get; set; }
        //public string EMailBoxID { get; set; }
        //public string CategoryId { get; set; }
        //public string SubprocessName { get; set; }
    }

}
