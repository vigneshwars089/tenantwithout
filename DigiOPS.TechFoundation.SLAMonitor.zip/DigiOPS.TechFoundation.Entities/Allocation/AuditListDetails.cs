﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{

    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :AllocationListDetails.cs
    // Namespace : DigiOps.TechFoundation.Entities
    // Class Name(s) :AllocationListDetails
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : AllocationListDetails Entity added for Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    // xx-xxx-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class AllocationListDetails : BaseInfo
    {
        public int AllocaterId { set; get; }
        public int SubProcessId { set; get; }
        public List<TransListDetailsToAllocate> TransListDetailsToAllocate { get; set; }
        public List<AuditorsListDetails> AuditorsListDetails { get; set; }
        /// <summary>
        ///  Added the following properties on 5/7/2017 by Venkata Lakshmi Ch.
        /// </summary>
        public bool ResultStatus { get; set; }
        public StringBuilder ErrorMessage { get; set; }
        public string AllocationType { set; get; }
        public int TotalVolume { set; get; }
        public string ReAllocateType { set; get; }
        public int CreatedBy { set; get; }

    }

    public class TransListDetailsToAllocate
    {
        public string TransID { set; get; }
    }

    public class AuditorsListDetails
    {
        public int UserID { set; get; }
    }
}
