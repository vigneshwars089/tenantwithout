﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Class for Encryption and Decryption
    /// </summary>
    public class EncodeDecode
    {
        /// <summary>
        /// Constructor for Encryption Decryption
        /// </summary>
        private EncodeDecode() { }

        /// <summary>
        /// Method to Encode the Key value pair
        /// </summary>
        /// <param name="value">string</param>
        /// <param name="key">string</param>
        /// <returns>string</returns>
        public static string StringEncode(string value, string EncryptionKey)
        {
            byte[] inputByteArray;

            try
            {
                using (Aes aesCrypt = Aes.Create())
                {
                    inputByteArray = Encoding.UTF8.GetBytes(value);

                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    aesCrypt.Key = pdb.GetBytes(32);
                    aesCrypt.IV = pdb.GetBytes(16);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, aesCrypt.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(inputByteArray, 0, inputByteArray.Length);
                            cs.FlushFinalBlock();
                        }
                        value = Convert.ToBase64String(ms.ToArray());
                    }
                }

            }
            catch (FormatException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (ArgumentException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (NotSupportedException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (CryptographicException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            //catch (QuartException ex)
            //{
            //    throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            //}
            finally
            {
                inputByteArray = null;
            }
            return value;
        }

        /// <summary>
        /// Method to Decode the Given Key value pair 
        /// </summary>
        /// <param name="val">string</param>
        /// <param name="key">string</param>
        /// <returns></returns>
        public static string StringDecode(string value, string EncryptionKey)
        {
            byte[] inputByteArray;

            try
            {
                using (Aes aesCrypt = Aes.Create())
                {
                    inputByteArray = Convert.FromBase64String(value);
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    aesCrypt.Key = pdb.GetBytes(32);
                    aesCrypt.IV = pdb.GetBytes(16);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, aesCrypt.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(inputByteArray, 0, inputByteArray.Length);
                            cs.FlushFinalBlock();
                        }
                        value = Encoding.UTF8.GetString(ms.ToArray());
                    }
                }

            }
            catch (FormatException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (ArgumentException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (NotSupportedException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            catch (CryptographicException ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }
            //catch (QuartException ex)
            //{
            //    throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            //}
            finally
            {
                inputByteArray = null;
            }
            return value;
        }


        //private string ciphertext = System.Configuration.ConfigurationManager.AppSettings["CIPHERPASSWORD"];
        /// <summary>
        /// Method to Encode the Querystring parameters
        /// </summary>
        /// <param name="value">string</param>
        /// <param name="ciphertext">string</param>
        /// <returns>string</returns>
        public static string QueryStringEncode(string value, string ciphertext)
        {
            return StringEncode(value, ciphertext);
        }

        /// <summary>
        /// Method to Decode the  Querystring Parameters
        /// </summary>
        /// <param name="value">string</param>
        /// <param name="ciphertext">string</param>
        /// <returns>string</returns>
        public static string QueryStringDecode(string value, string ciphertext)
        {
            return StringDecode(value, ciphertext);
        }

        /// <summary>
        /// Method to Decode the Login String
        /// </summary>
        /// <param name="val">string</param>
        /// <param name="key">string</param>
        /// <returns>string</returns>
        public static string LoginStringDecode(string val, string EncryptionKey)
        {
            string dataValue = "";

            try
            {
                using (Aes aesCrypt = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    aesCrypt.Key = pdb.GetBytes(32);
                    aesCrypt.IV = pdb.GetBytes(16);
                    dataValue = Encoding.UTF8.GetString(Convert.FromBase64String(val));
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Invalid TamperProofString" + ex.Message);
            }

            return dataValue;

        }

    }
}
