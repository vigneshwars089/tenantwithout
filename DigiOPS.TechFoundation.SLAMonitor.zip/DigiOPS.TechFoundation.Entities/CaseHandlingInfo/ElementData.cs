﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class ElementData
    {
         public string ElementId { get; set; }       
        public string ElementValue { get; set; }
        public string ElementItemValue { get; set; }
        public bool IsList { get; set; }
        
    }

    /// <summary>
    /// ElementDatas class
    /// </summary>
    public class ElementDatas
    {
        public string CreationType { get; set; } 
        public string USERID { get; set; }
        public int subprocessid  { get; set; }
        public string Processeddate { get; set; }
        public string ReceivedDate { get; set; }
        public string Comments { get; set; }
        public List<ElementData> Items { get; set; }
       // public string CreationType { get; set; }
    }
    public class InputDatas
    {
 
    }
    
}
