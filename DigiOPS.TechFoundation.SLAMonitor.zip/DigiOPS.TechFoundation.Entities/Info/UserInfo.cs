﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{

    public struct S_AppID
    {
        public const string EMT = "EMT";
        public const string AUDIT = "Quart";
        public const string PRODUCTION = "PRODUCTION";

    }
    [Serializable]
    public class UserInfo : BaseInfo
    {

        public string UserID { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public string EmailID { set; get; }
        public string EncryptPassword { set; get; }
        public string EncryptConfirmPassword { set; get; }
        public string TimeZone { set; get; }
        public bool IsActive { set; get; }
        public string UserManagingType { set; get; }
        // public string LoginType { set; get; }
        public int RoleId { set; get; }
        public string UTCTime { set; get; }
        public string CountryId { set; get; }
        public List<string> EncryptPasswordList { get; set; }
        public string CreationType { get; set; }
        public string CtsUserId { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public int UserGroupMapID { get; set; }
        public int UserGroupID { get; set; }
        public string UserGroupName { get; set; }
        public string UserList { get; set; }
        public string szRoles { get; set; }
        public int SystemUserId { get; set; }
        public string ClientUserId { get; set; }
        public string eventAction { get; set; }
        public string UsersSearchText { get; set; }
        public int ProgramID { set; get; }
        public int iUserGroupRoleMapId { set; get; }
        public int SubProcessID { set; get; }
        public int RoleID { set; get; }
        public string PermissionIDs { get; set; }
        public bool IsUserSearch { get; set; }
        public int SelectedUserID { get; set; }
        public int ProcessId { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }



}
