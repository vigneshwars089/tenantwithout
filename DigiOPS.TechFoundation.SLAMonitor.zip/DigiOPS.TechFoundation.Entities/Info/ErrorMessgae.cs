﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class ErrorMessgae
    {

        public const string No_Record_Found = "No Records Found";
        public const string No_User_Found = "No Users Found";
        public const string InPut_NotInCorrectFormat = "Input Not In Correct Format";
        public const string Not_More_thanOne = "Id Cannot be more than One";
    }
}
