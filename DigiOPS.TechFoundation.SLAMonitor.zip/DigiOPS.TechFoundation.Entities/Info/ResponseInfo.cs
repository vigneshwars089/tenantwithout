﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{


    public class ResponseInfo
    {
        public bool ResultStatus { set; get; }
        public StringBuilder ErrorMessage { set; get; }
        public DateTime CreatedOn { set; get; }
        public string CreatedBy { set; get; }
        public string AppID { set; get; }
        public string TenantName { get; set; }
        public int TenantID { get; set; }
        public string Message { get; set; }
    } 


}
