﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Program Feature Setup class
    /// </summary>
    [Serializable]
    public class ProgramFeatureSetUp : BaseInfo
    {
        public bool AHTApplicability { get; set; }
        public string AuditLogicId { get; set; }
        public string AuditLogicName { get; set; }
        public string AuditTypes { get; set; }
        public int BusiAllocCnt { get; set; }
        public string createdBy { get; set; }
        public string createdDate { get; set; }
        public bool CTQComments { get; set; }
        public string DateFormat { get; set; }
        public bool EntitySavedStatus { get; set; }
        public string ErrorMessage { get; set; }
        public string eventAction { get; set; }
        public int ExtAllocCnt { get; set; }
        public int IntAllocCnt { get; set; }
        public bool IsCombinedAccuracyNeeded { get; set; }
        public bool IsCriticalityApplicable { get; set; }
        public bool IsDataEntryByAuditorEnable { get; set; }
        public bool IsDataPurgingEnabled { get; set; }
        public bool IsDaylimitforcorrectionApplicable { get; set; }
        public bool IsDefaultRating { get; set; }
        public bool IsDeletMailEnableTriggerApplicable { get; set; }
        public bool IsEditAllowed { get; set; }
        public bool IsEditMode { get; set; }
        public bool IsEmployeeApplicable { get; set; }
        public bool IsExternalSamplingFrozen { get; set; }
        public bool IsFatalErrorApplicable { get; set; }
        public bool IsFeedbackMailTriggerApplicable { get; set; }
        public bool IsLinesApplicable { get; set; }
        public bool IsMetricsRequired { get; set; }
        public bool IsPeerToPeerAuditInfoEnable { get; set; }
        public bool IsRatingDifferenceMailApplicable { get; set; }
        public bool IsReworkRemainderMailTgrApplicable { get; set; }
        public bool IsSamplingFrozen { get; set; }
        public bool IsSamplingTypeCustommode { get; set; }
        public bool IsSLAAccuracyEnabled { get; set; }
        public bool IsSLAActivityApplicable { get; set; }
        public bool IsSLABasedSubProcess { get; set; }
        public bool IsStaticConditionsEnabled { get; set; }
        public bool IsStratifiedSampling { get; set; }
        public bool IsSubProcessValidationEnabled { get; set; }
        public bool IsSupervisorAuditApplicable { get; set; }
        public bool IsTATApplicable { get; set; }
        public bool IsTop5MailDataElementEnabled { get; set; }
        public bool IsTotalVolumeApplicable { get; set; }
        public bool IsWorkFlowNeedforCorrection { get; set; }
        public bool Leveld { get; set; }
        public string MailBoxName { get; set; }
        public int MailFrequency { get; set; }
        public int MaxCorrectionCnt { get; set; }
        public int MaxCorrectionDaysCnt { get; set; }
        public int MaxNoOfRemainder { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedDate { get; set; }
        public int NoOfElement { get; set; }
        public int ProgramFeatureSetUpId { get; set; }
        public short ProgramId { get; set; }
        public string ProgramName { get; set; }
        public string SamplingPctCalculation { get; set; }
        public string ScoringLogicId { get; set; }
        public string ScoringLogicName { get; set; }
        public string SelectedAuditLogicId { get; set; }
        public short SelectedProgramId { get; set; }
        public string SelectedScoringLogicId { get; set; }
        public string SelectedSystemEffectId { get; set; }
        public string sSamplingMethodforBusiness { get; set; }
        public string sSamplingMethodforInternal { get; set; }
        public string StaticFields { get; set; }
        public string SystemEffectId { get; set; }
        public string SystemEffectName { get; set; }
        public string szCombinedAccuracyType { get; set; }
        public bool IsSelfAudit { get; set; }
        public bool IsAutoAudit { get; set; }
    }
    /// <summary>
    /// ProgramFeatureSetUpViewModel
    /// </summary>
    public class ProgramFeatureSetUpViewModel
    {
        /// <summary>
        /// to set up program features view model constructor
        /// </summary>
        public ProgramFeatureSetUpViewModel()
        {
            ProgramFeatureSetUpList = new List<ProgramFeatureSetUp>();
            ProgramFeatureSetup = new ProgramFeatureSetUp();
            DDLProgram = new DropDownEntity();
            RDNFeatures = new RadioButtonEntity();
        }
        public List<ProgramFeatureSetUp> ProgramFeatureSetUpList { get; set; }
        public ProgramFeatureSetUp ProgramFeatureSetup { get; set; }
        public DropDownEntity DDLProgram { get; set; }
        public RadioButtonEntity RDNFeatures { get; set; }
        public string CustomErrorMessage { get; set; }
    }
}
