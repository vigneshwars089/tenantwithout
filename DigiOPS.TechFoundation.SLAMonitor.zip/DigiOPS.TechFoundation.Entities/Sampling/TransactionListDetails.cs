﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{

        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :TransactionListDetails.cs
        // Namespace : DigiOps.TechFoundation.Entities
        // Class Name(s) :TransactionListDetails
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/13/2017
        // Purpose : TransactionList Details to Hold all the details which user need to send it to sampling component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class TransactionListDetails
    {
        public List<TransactionLists> TransactionLists { get; set; }
        public List<TransactionsAllocatedLists> TransactionAllocatedLists { get; set; }
        public int MinValue { get; set; }
        public int MaxValue { get; set; }
        public bool TobeStoredDB { get; set; }
        public bool ResultStatus { get; set; }
        public StringBuilder ErrorMessage { get; set; }
        public List<string> FieldValue { get; set; }
        public string FormulaToSample { get; set; }
        public int ToBeSampledByVolume { get; set; }
        public double ThresholdValue { get; set; }
    }

    public class TransactionListResponse
    {
        public List<TransactionLists> TransactionLists { get; set; }
        public List<TransactionsPendingLists> TransactionPendingLists { get; set; }

    }
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :TransactionListDetails.cs
    // Namespace : DigiOps.TechFoundation.Entities
    // Class Name(s) :TransactionLists
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/13/2017
    // Purpose : To hold the transaction details inside TransactionListDetails
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////


    public class TransactionLists
    {
        public int RecordID { get; set; }
        public int ProcessedBy { get; set; }
        public DateTime ProcessedDate { get; set; }
        public string DataValue { get; set; }
        public string Priority { get; set; }
        public int? TotalRecordrows { get; set; }
    }

    public class TransactionsAllocatedLists
    {
        public int ProcessedBy { get; set; }
        public DateTime ProcessedDate { get; set; }
        public int Total { get; set; }
        public int Sampled { get; set; }
        public double Percentage { get; set; }


    }
    public class TransactionsPendingLists
    {
        public int ProcessedBy { get; set; }
        public DateTime ProcessedDate { get; set; }
        public int Total { get; set; }
        public int Allocated { get; set; }
        public double Percentage { get; set; }
        public int TobeSampled { get; set; }

    }
}

