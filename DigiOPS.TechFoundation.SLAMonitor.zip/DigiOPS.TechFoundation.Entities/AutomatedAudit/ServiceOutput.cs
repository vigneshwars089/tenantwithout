﻿//using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class ServiceOutput : BaseInfo
    {
        public int ElementId{get;set;}
        public int RecordID { get; set; }
        public string ExpectedValue { get; set; }
        public string ActualValue { get; set; }
        public Boolean IsOverride { get; set; }
        public string OCRConfidencetiality { get; set; }//Description
        public string Comments { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int AuditStatusId { get; set; }
        public string Description { get; set; }
        public string QCNotes { get; set; }
        public int CountOfMatch { get; set; }      
        public string SubDefects { get; set; }
        public int AuditId { get; set; }
        public int PageNo { get; set; }
        public int TotalPages { get; set; }
        public string Coordinates { get; set; }
        public string ImageAttributes { get; set; }
        public string FileName { get; set; }
        public int CurrentPageNo { get; set; }
        public string PagePath { get; set; }
        
    }
}
