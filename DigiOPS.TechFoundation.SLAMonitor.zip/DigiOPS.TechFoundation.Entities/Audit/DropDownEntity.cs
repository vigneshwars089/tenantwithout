﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Drop down entity
    /// </summary>
    public class DropDownEntity
    {
        /// <summary>
        /// Drop down constructor
        /// </summary>
        public DropDownEntity()
        {
            ProgramList = new List<TransDropDown>();
            ProcessList = new List<TransDropDown>();
            SubProcessList = new List<TransDropDown>();
            UserGroupList = new List<TransDropDown>();
            CategoryList = new List<TransDropDown>();
            CriticalTypeList = new List<TransDropDown>();
            HeadingList = new List<TransDropDown>();
            RatingGroupList = new List<TransDropDown>();
            CheckpointList = new List<TransDropDown>();
            CTQGroupList = new List<TransDropDown>();
            SubDefectList = new List<TransDropDown>();
            DefectOppGroupList = new List<TransDropDown>();
            AccountList = new List<TransDropDown>();
            VerticalList = new List<TransDropDown>();
            ZoneList = new List<TransDropDown>();
            DataTypeList = new List<TransDropDown>();
            DataElementTypeList = new List<TransDropDown>();
            DirectAuditTypeList = new List<TransDropDown>();
            RoleList = new List<TransDropDown>();
            CoreStatusDdlList = new List<TransDropDown>();
            UserList = new List<TransDropDown>();
            ReportList = new List<TransDropDown>();
            SupportIssueModuleList = new List<TransDropDown>();
            SupportIssueTypeList = new List<TransDropDown>();
            SupportIssuePriporityList = new List<TransDropDown>();
            SupportIssueStatusList = new List<TransDropDown>();
            AuditingLogicList = new List<TransDropDown>();
            SLACriticalityList = new List<TransDropDown>(); //Added for SLA - Criticality 
            SLAEntityList = new List<TransDropDown>(); //Added for to show SLA data in SubProcess
        }
        public List<TransDropDown> ProgramList { get; set; }
        public List<TransDropDown> ProcessList { get; set; }
        public List<TransDropDown> SubProcessList { get; set; }
        public List<TransDropDown> UserGroupList { get; set; }
        public List<TransDropDown> AccountList { get; set; }
        public List<TransDropDown> VerticalList { get; set; }
        public List<TransDropDown> ZoneList { get; set; }
        public List<TransDropDown> DataTypeList { get; set; }
        public List<TransDropDown> DataElementTypeList { get; set; }
        public List<TransDropDown> DirectAuditTypeList { get; set; }

        public List<TransDropDown> CategoryList { get; set; }
        public List<TransDropDown> HeadingList { get; set; }
        public List<TransDropDown> CriticalTypeList { get; set; }
        public List<TransDropDown> RatingGroupList { get; set; }
        public List<TransDropDown> CheckpointList { get; set; }
        public List<TransDropDown> CTQGroupList { get; set; }
        public List<TransDropDown> SubDefectList { get; set; }
        public List<TransDropDown> DefectOppGroupList { get; set; }
        public List<TransDropDown> RoleList { get; set; }
        public List<TransDropDown> UserList { get; set; }
        public List<TransDropDown> ReportList { get; set; }
        public List<TransDropDown> AuditingLogicList { get; set; }

        public List<TransDropDown> SupportIssueModuleList { get; set; }
        public List<TransDropDown> SupportIssueTypeList { get; set; }
        public List<TransDropDown> SupportIssuePriporityList { get; set; }
        public List<TransDropDown> SupportIssueStatusList { get; set; }
        public List<TransDropDown> CoreStatusDdlList { get; set; }
        public List<TransDropDown> SLACriticalityList { get; set; } //Added for SLA - Criticality 
        public List<TransDropDown> SLAEntityList { get; set; } //Added for to show SLA data in SubProcess
    }

    /// <summary>
    /// Tansaction Drop down entity
    /// </summary>
    public class TransDropDown :BaseTransportEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }

    /// <summary>
    /// Report Dropdown entity
    /// </summary>
    public class ReportDropDown : BaseTransportEntity
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public string ReportFieldID { get; set; }
    }
}
