﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.Entities
{
    public class AuditRatingInfo : BaseInfo
    {
        public int SubProcessId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime dsModifiedDate { get; set; }
        public string RatingGroupName { get; set; }
        public int RatingGroupID { get; set; }
        public string Action { get; set; }
        public List<RatingInfo> RatingInfoList { get; set; }
        public bool IsEditMode { get; set; }
        public XElement xmlRatingCheckItem { get; set; }
        public int RatingId { get; set; }
        public string RatingDesc { get; set; }
        public string RatingDisplayName { get; set; }
        public bool blnNotApplicable { get; set; }
        public string Ratingids { get; set; }
        public bool IsActive { get; set; }
    }

    public class RatingInfo
    {
        public int RatingId { get; set; }
        public string RatingDesc { get; set; }
        public string RatingDisplayName { get; set; }

        public bool blnNotApplicable { get; set; }

        public bool IsEditMode { get; set; }
        public bool IsChecked { get; set; }
        public string action { get; set; }
        public bool IsActive { get; set; }
        public bool IsDropdownlist { get; set; }
        public int ValidNA { get; set; }
        public int CanRatingEnable { get; set; }



    }
    public class AuditRatingGroupInfo
    {
        public string RatingGroupName { get; set; }
        public int RatingGroupID { get; set; }



    }

}
