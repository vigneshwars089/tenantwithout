﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Xml.Linq;


namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// AuditDetails Entity Classs
    /// </summary>
    [Serializable]
    public class AuditDetailsEntity : BaseTransportEntity
    {
        /// <summary>this entity define RatingType and subdefect level dropdowns</summary> 
        public AuditDetailsEntity()
        {
            RatingType = new List<TransDropDown>();
            SubDefectlevel1 = new List<TransDropDown>();
            SubDefectlevel2 = new List<TransDropDown>();
        }
        public string ViewName { get; set; }
        public int DOId { get; set; }
        public string DisplayName { get; set; }
        public Boolean IsCritical { get; set; }
        public string szSubDefectDesc { get; set; }
        public string MailSubdefectLevel { get; set; }
        public int iLevel { get; set; }
        private string criticalityType = "";
        public string CriticalityType
        {
            get { return criticalityType; }
            set { criticalityType = value; }
        }
        public Boolean HasSubDefects { get; set; }
        public float MaxWeightage { get; set; }
        public int DOGroupID { get; set; }
        public string DOType { get; set; }
        public int Level { get; set; }
        public int ParentDOId { get; set; }
        public List<TransDropDown> RatingType { get; set; }
        public List<TransDropDown> ExtRatingType { get; set; }
        public List<TransDropDown> CombinedRatingType { get; set; }
        public List<TransDropDown> SubDefectlevel1 { get; set; }
        public List<TransDropDown> ExtSubDefectlevel1 { get; set; }

        public List<TransDropDown> SubDefectlevel5 { get; set; }
        public List<TransDropDown> SubDefectlevel4 { get; set; }
        public List<TransDropDown> SubDefectlevel3 { get; set; }
        public List<TransDropDown> SubDefectlevel2 { get; set; }
        public List<SubDefectDetailsEntity> SubDefectList { get; set; }
        public int SelectedRatingId { get; set; }
        public string SelectedRatingName { get; set; }
        public int SelectedSubDefect1Id { get; set; }
        public int SelectedSubDefect2Id { get; set; }
        public int SelectedSubDefect3Id { get; set; }
        public int SelectedSubDefect4Id { get; set; }
        public int SelectedSubDefect5Id { get; set; }
        public int DefaultSubDefect1Id { get; set; }
        public int DefaultSubDefect2Id { get; set; }
        public int DefaultSubDefect3Id { get; set; }
        public int DefaultSubDefect4Id { get; set; }
        public int DefaultSubDefect5Id { get; set; }
        public string szSubDefectlevelType { get; set; }

        public string SelectedSubDefect1Ids { get; set; }
        public string SelectedSubDefect2Ids { get; set; }
        public string SelectedSubDefect3Ids { get; set; }
        public string SelectedSubDefect4Ids { get; set; }
        public string SelectedSubDefect5Ids { get; set; }
        public int CopyLevel3 { get; set; }
        public int CopyLevel4 { get; set; }
        public int CopyLevel5 { get; set; }

        public Boolean DefectNA { get; set; }
        public float ActualWeightage { get; set; }
        public float GivenWeightage { get; set; }
        public float CalulatedWeightage { get; set; }
        public int CorrectEmployee { get; set; }
        public int ErrorField { get; set; }
        public string CTQComments { get; set; }
        public bool isAudited { get; set; }
        public bool isDeleted { get; set; }
        public string SupervisorAudit { get; set; }

        public int iAuditId { get; set; }
        public int iAuditFindingId { get; set; }
        public int iAuditorId { get; set; }
        public string AuditingLogicType { get; set; }
        public string ScoringLogicType { get; set; }
        public Boolean IsEmpNeeded { get; set; }
        public Boolean IsLineNeeded { get; set; }
        public int iLine { get; set; }
        public int iSubCategoryAudit { get; set; }
        public int iPageCntDataAudit { get; set; }
        public object szComments { get; set; }

        public string szDOType { get; set; }
        public string szDODesc { get; set; }

        /*Added for combined accuracy list*/
        public int InternalRatingId { get; set; }
        public int ExternalRatingId { get; set; }
        public int CombinedRatingId { get; set; }
        public int RatingId { get; set; }
        public float Weightage { get; set; }

        /* Added by sathish */
        public float GroupWeightage { get; set; }
        public float CalculatedGroupWeightage { get; set; }
        public bool isGroup { get; set; }
        public bool isbtnDisable { get; set; }
        public string szAuditingLogic { get; set; }
        //Added for Rating Difference Email Trigger
        //public string QCintSelectedRatingName { get; set; }
        //public string QCextSelectedRatingName { get; set; }
        ////End Of Change


        ////Added for GCS-CR 2- Phase 2
        //public int ExtSelectedRatingId { get; set; }
        //public int ExtSelectedSubDefect1Id { get; set; }
        //public int ExtSelectedSubDefect2Id { get; set; }
        //public string ExtCTQComments { get; set; }
        //public List<SubDefectDetailsEntity> ExtSubDefectList { get; set; }
    }
    /// <summary>
    /// TransactionDetailsEntity class
    /// </summary>
    [Serializable]
    public class TransactionDetailsEntity : AuditDetailsEntity
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TransactionDetailsEntity()
        {
            SubDefectList2 = new List<TransDropDown>();
        }
        public string ReworkComments { get; set; }
        public int RecordId { get; set; }
        public string Program { get; set; }
        public string Process { get; set; }
        public string SubProcess { get; set; }
        public string ProcessedBy { get; set; }
        public string ProcessedDate { get; set; }
        public string Reference { get; set; }
        public int CoverageID { get; set; }
        public int AuditId { get; set; }
        public string AuditedDate { get; set; }
        public string AuditorId { get; set; }
        public int AuditTypeId { get; set; }
        public string AuditTypeName { get; set; }
        public int AuditWorkFlowId { get; set; }
        public int AuditStatusId { get; set; }
        public string AuditStatus { get; set; }
        public string AuditLogicType { get; set; }
        public string ScoringLogicType { get; set; }
        public int SubDefectLevel { get; set; }
        public int CopySubdefectLevel { get; set; }
        public Boolean IsEmployeeApp { get; set; }
        public int TotCorrectEmployee { get; set; }
        public Boolean IsLineApp { get; set; }
        public int bIsLineApp { get; set; }
        public Boolean IsCriticalApp { get; set; }
        public Boolean IsTATApp { get; set; }
        public int TotLines { get; set; }
        public int iSubCategory { get; set; }
        public int iPageCntData { get; set; }
        public int AuditFindingId { get; set; }
        [DisplayFormat(DataFormatString = "{0:0.00}")]
        public double QualityScore { get; set; }
        public string QLName { get; set; }
        public string ScoreCorrectedDate { get; set; }
        public double PrevQualityScore { get; set; }
        public double PrevFieldQualityScore { get; set; }
        public double FieldQualityScore { get; set; }
        public string AuditFeedback { get; set; }
        public string AuditNotes { get; set; }
        public string TATFeedback { get; set; }
        public string TATFeedbackComments { get; set; }
        public string SelectedTATFeedback { get; set; }
        public string SelectedFatalStatus { get; set; }
        public int SelectedSubDefect2Id { get; set; }
        public List<TransDropDown> SubDefectList2 { get; set; }
        public List<TransDropDown> SubDefectList3 { get; set; }
        public List<TransDropDown> SubDefectList4 { get; set; }
        public List<TransDropDown> SubDefectList5 { get; set; }
        public List<TransDropDown> FatalStatusList { get; set; }
        public List<TransDropDown> TATFeedbackList { get; set; }
        public List<DynamicElementEntity> DynamicElementList { get; set; }
        public List<AuditDetailsEntity> ButtonDisableList { get; set; }

        public List<AuditNotesEntity> AuditNotesList { get; set; }

        public string ApproverComments { get; set; }
        public string RecommendationComments { get; set; }
        public string UploadFilePath { get; set; }
        public string ApprovalStatus { get; set; }
        public string ApprovedBy { get; set; }
        public string ApprovedDate { get; set; }
        public string RecommendationType { get; set; }
        public string CustomErrorMessage { get; set; }

        //Added for Rating Difference Email Trigger
        public int iAuditTypeID { get; set; }
        public int iDefectCount { get; set; }
        public int iRecordId { get; set; }
        public int iMailTypeId { get; set; }
        public string iAuditedBy { get; set; }
        public string PrimaryAuditedDate { get; set; }
        public string PrimaryAuditor { get; set; }
        public string InternalAuditorName { get; set; }
        public Boolean IsCTQComments { get; set; }
        public string ExternalAuditorName { get; set; }
        public string InternalAuditedDate { get; set; }
        public string ExternalAuditedDate { get; set; }
        public double InternalQualityScore { get; set; }
        public double ExternalQualityScore { get; set; }
        public string AuditType { get; set; }
        public int CombinedAuditId { get; set; }
        public double CombinedQualityScore { get; set; }
        // public double PerAgreement { get; set; }
    }

    /// <summary>
    ///  Added for Rating Difference Email Trigger
    /// </summary>
    //[Serializable]
    //public class TransactionExternalDetailsEntity : BaseTransportEntity
    //{
    //    public TransactionExternalDetailsEntity()
    //    {
    //        SubDefectList2 = new List<TransDropDown>();
    //    }
    //    public int RecordId { get; set; }
    //    public string Program { get; set; }
    //    public string Process { get; set; }
    //    public string SubProcess { get; set; }
    //    public string ExtProcessedBy { get; set; }
    //    public string ExtAuditedDate { get; set; }
    //    public string ExtProcessedDate { get; set; }
    //    public int ExtAuditId { get; set; }
    //    public int ExtAuditTypeId { get; set; }
    //    public int AuditTypeId { get; set; }
    //    public string AuditTypeName { get; set; }
    //    public string AuditLogicType { get; set; }
    //    public string ScoringLogicType { get; set; }
    //    public Boolean IsLineApp { get; set; }
    //    public int bIsLineApp { get; set; }
    //    public Boolean IsTATApp { get; set; }
    //    public int TotLines { get; set; }
    //    public int AuditFindingId { get; set; }
    //    [DisplayFormat(DataFormatString = "{0:0.00}")]
    //    public double QualityScore { get; set; }
    //    public string QLName { get; set; }
    //    public string ScoreCorrectedDate { get; set; }
    //    public double ExtQualityScore { get; set; }
    //    public string ExtAuditFeedback { get; set; }
    //    public string AuditNotes { get; set; }
    //    public List<TransDropDown> SubDefectList2 { get; set; }
    //    public List<TransDropDown> FatalStatusList { get; set; }
    //    public List<TransDropDown> TATFeedbackList { get; set; }
    //    public List<DynamicElementEntity> DynamicElementList { get; set; }

    //    public List<AuditNotesEntity> AuditNotesList { get; set; }
    //    public int iDefectCount { get; set; }
    //    public string iProgramName { get; set; }
    //    public string SecondaryAuditedDate { get; set; }
    //    public string SecondaryAuditor { get; set; }
    //}
    //End of change

    /// <summary>
    ///  //Added by Sahana for Delete Transaction mail Trigger
    /// </summary>
    //[Serializable]
    //public class TransactionRecordDetailsEntity : BaseTransportEntity
    //{
    //    /// <summary>
    //    /// Constructor 
    //    /// </summary>
    //    public TransactionRecordDetailsEntity()
    //    {
    //        //CCRecipient = new List<SendMailCCRecipient>();
    //        //TORecipient = new List<SendMailToRecipient>();
    //    }

    //    // public List<SendMailCCRecipient> CCRecipient { get; set; }
    //    // public List<SendMailToRecipient> TORecipient { get; set; }
    //    public int RecordId { get; set; }
    //    public byte byTransactionTypeId { get; set; }
    //    public string TransactionType { get; set; }
    //    public int StatusId { get; set; }
    //    public string CoreTransStatusReason { get; set; }
    //    public string Comment { get; set; }
    //    public string ProcessedBy { get; set; }
    //    public string ProcessedDate { get; set; }
    //    public string ReceivedDate { get; set; }
    //    public int SubProcessId { get; set; }
    //    public string ModifiedBy { get; set; }
    //    public string ProcessName { get; set; }
    //    public string SubProcessName { get; set; }
    //    public string TransStatus { get; set; }
    //    public int iProcessedBy { get; set; }
    //    public string CreatedBy { get; set; }
    //    public string DeletedBy { get; set; }
    //    public string ModifiedDate { get; set; }
    //    public string DeleteReason { get; set; }
    //    public string ProgramName { get; set; }
    //    public string ReasonText { get; set; }
    //    public string Reason { get; set; }
    //    public string Status { get; set; }
    //    public Boolean IsLineApp { get; set; }
    //    public int TotLines { get; set; }
    //    public List<DynamicElementEntity> DynamicElementList { get; set; }

    //}

    /// <summary>
    /// DynamicElementEntity class
    /// </summary>
    [Serializable]
    public class DynamicElementEntity
    {
        public int RecordId { get; set; }
        public int iElementId { get; set; }
        public string szElementName { get; set; }
        public string sznElementData { get; set; }
        public int iDataTypeId { get; set; }
        public Boolean bIsUnique { get; set; }
    }
    /// <summary>
    /// AuditNotesEntity class
    /// </summary>
    [Serializable]
    public class AuditNotesEntity : AuditDetailsEntity
    {
        public int AuditId { get; set; }
        public int NoteId { get; set; }
        public string szNotes { get; set; }
        public string NotesCreateBy { get; set; }
        public DateTime NotesCreatedDate { get; set; }
    }
    /// <summary>
    /// AuditDOEntity class
    /// </summary>
    [Serializable]
    public class AuditDOEntity : BaseTransportEntity
    {
        public List<AuditDetailsEntity> AuditedList { get; set; }
        public List<AuditGroupDataEntity> AuditedGroupList { get; set; }

        public int iAuditId { get; set; }
        public int iAuditFindingId { get; set; }
        public double QualityScore { get; set; }
        public double FieldQualityScore { get; set; }
        public string AuditFeedback { get; set; }
        public string AuditNotes { get; set; }
        public string TATFeedback { get; set; }
        public string TATFeedbackComments { get; set; }
        public string ApproverComments { get; set; }
        public string RecommendationComments { get; set; }
        public string UploadFilePath { get; set; }
        public string ApprovalStatus { get; set; }
        public int CoverageID { get; set; }
        public Boolean IsEditMode { get; set; }
        public string SupervisorAudit { get; set; }

        public XElement xmlAuditDO { get; set; }
        public XElement xmlAuditGroupDO { get; set; }
        public XElement xmlAuditSubDO { get; set; }

        /*CheckPoint Based*/
        public int TotalOpp { get; set; }
        public int TotalAppOpp { get; set; }
        public int TotalNotAppOpp { get; set; }
        public int TotalAppDefects { get; set; }
        public int TotalAppNoDefects { get; set; }

        public double TotalOpp_W { get; set; }
        public double TotalAppOpp_W { get; set; }
        public double TotalNotAppOpp_W { get; set; }
        public double TotalAppDefects_W { get; set; }
        public double TotalAppNoDefects_W { get; set; }

        /*Heading Based*/
        public int TotalHeadings { get; set; }
        public int TotalAppHeadings { get; set; }
        public int TotalNotAppHeadings { get; set; }
        public int TotalAppHeadingsDefects { get; set; }
        public int TotalAppHeadingsNoDefects { get; set; }

        public double TotalHeadings_W { get; set; }
        public double TotalAppHeadings_W { get; set; }
        public double TotalNotAppHeadings_W { get; set; }
        public double TotalAppHeadingsDefects_W { get; set; }
        public double TotalAppHeadingsNoDefects_W { get; set; }

        public string FatalStatus { get; set; }
        public string CriticalityType { get; set; }
        public bool isPicked { get; set; }
        public bool isAudited { get; set; }
        public bool isDeleted { get; set; }
        public string CallName { get; set; }

        //Added for Rating Difference Email Trigger
        public int iAuditTypeID { get; set; }
        public int iRecordID { get; set; }
        public int iRoleID { get; set; }
        public string CombinedQualityScore { get; set; }
    }

    /// <summary>
    /// SendMailEntity class
    /// </summary>
    //[Serializable]
    //public class SendMailEntity : BaseTransportEntity
    //{
    //    /// <summary>
    //    /// Constructor
    //    /// </summary>
    //    public SendMailEntity()
    //    {
    //        AuditDetailsList = new List<AuditDetailsEntity>();
    //        CCRecipient = new List<SendMailCCRecipient>();
    //        TORecipient = new List<SendMailToRecipient>();
    //        TransDetails = new TransactionDetailsEntity();
    //        MailCriteria = new List<SendMailCriteria>();
    //        //Added for Rating Difference Email Trigger
    //        TransExternalDetails = new TransactionExternalDetailsEntity();
    //        DefectCount = new DefectCountEntity();
    //        //End of Change
    //    }

    //    public List<AuditDetailsEntity> AuditDetailsList { get; set; }
    //    public List<SendMailCCRecipient> CCRecipient { get; set; }
    //    public List<SendMailToRecipient> TORecipient { get; set; }
    //    public List<SendMailCriteria> MailCriteria { get; set; }
    //    public TransactionDetailsEntity TransDetails { get; set; }
    //    public TransactionRecordDetailsEntity TransRecordDetails { get; set; }
    //    public string Recipient { get; set; }
    //    public string Sender { get; set; }
    //    public string iProcessorID { get; set; }
    //    public string szProcessorName { get; set; }
    //    public string szEmail { get; set; }
    //    public Boolean bQsLtHundred { get; set; }
    //    public Boolean bQsEqHundred { get; set; }
    //    public Boolean bQsCorrected { get; set; }
    //    public int iAuditId { get; set; }
    //    public int iAuditMailTackerId { get; set; }
    //    public string szSentTo { get; set; }
    //    public string szSentCC { get; set; }
    //    public string szSentFrom { get; set; }
    //    public string szSentSubj { get; set; }
    //    public string szMailTypeName { get; set; }
    //    public Boolean bMailSent { get; set; }
    //    public int iMailTypeId { get; set; }
    //    public int iRecordId { get; set; }

    //    // Added for Rating Difference Email Trigger
    //    public TransactionExternalDetailsEntity TransExternalDetails { get; set; }
    //    public DefectCountEntity DefectCount { get; set; }
    //    public List<AuditDetailsEntity> QCRatingDetails { get; set; }
    //    public string iAuditedBy { get; set; }
    //    // End of Change

    //}

    /// <summary>
    /// Added for mail Trigger Component
    /// </summary>
    //[Serializable]
    //public class MailComponentEntity : BaseTransportEntity
    //{
    //    /// <summary>
    //    /// Constructor
    //    /// </summary>
    //    public MailComponentEntity()
    //    {
    //        CCRecipient = new List<SendMailCCRecipient>();
    //        TORecipient = new List<SendMailToRecipient>();
    //        EmbededObjectsEntityList = new List<EmbededObjectsEntity>();
    //        ReplaceMailContentEntityList = new List<ReplaceMailContentEntity>();
    //    }

    //    /// <summary>
    //    /// Mail tracker unique id
    //    /// </summary>
    //    public int iMailTrackerId { get; set; }

    //    /// <summary>
    //    /// Flag to identify the mail sent/ not sent
    //    /// </summary>
    //    public Boolean bMailSent { get; set; }

    //    /// <summary>
    //    /// Folder path of mail template
    //    /// </summary>
    //    public string szPath { get; set; }

    //    /// <summary>
    //    /// Port to send mails
    //    /// </summary>
    //    public string szPort { get; set; }

    //    /// <summary>
    //    /// Host to send mails
    //    /// </summary>
    //    public string szHost { get; set; }
    //    /// <summary>
    //    /// Recipient to send mails
    //    /// </summary>
    //    public string Recipient { get; set; }
    //    /// <summary>
    //    /// Sender to send mails
    //    /// </summary>
    //    public string Sender { get; set; }
    //    /// <summary>
    //    /// List of senders to send mails
    //    /// </summary>
    //    public string szSentTo { get; set; }
    //    /// <summary>
    //    /// List of senders to send mails
    //    /// </summary>
    //    public string szSentCC { get; set; }
    //    /// <summary>
    //    /// From mail address
    //    /// </summary>
    //    public string szSentFrom { get; set; }
    //    /// <summary>
    //    /// Subject of mail
    //    /// </summary>
    //    public string szSentSubj { get; set; }
    //    /// <summary>
    //    /// Mail name
    //    /// </summary>
    //    public string szMailName { get; set; }
    //    /// <summary>
    //    /// Mail body content
    //    /// </summary>
    //    public string szMailBody { get; set; }
    //    /// <summary>
    //    /// Mail body template - file name
    //    /// </summary>
    //    public string szMailBodyFileName { get; set; }
    //    /// <summary>
    //    /// Type of mail name
    //    /// </summary>
    //    public string szMailTypeName { get; set; }
    //    /// <summary>
    //    /// Type of mail priority
    //    /// </summary>
    //    public string szMailPriority { get; set; }
    //    /// <summary>
    //    /// Mail template type
    //    /// </summary>
    //    public string szMailTemplateType { get; set; }

    //    /// <summary>
    //    /// Flag to set , if body contains any image to be embed
    //    /// </summary>
    //    public Boolean IsBodyWithEmbededObjects { get; set; }
    //    /// <summary>
    //    /// Flag to set , if body should replace text with give replace content
    //    /// </summary>
    //    public Boolean IsBodyWithReplaceChar { get; set; }
    //    /// <summary>
    //    /// Flag to indicate, going to send the mail body as Plain Text
    //    /// </summary>
    //    public Boolean IsBodyPlainText { get; set; }

    //    /// <summary>
    //    /// CC recipient List
    //    /// </summary>
    //    public List<SendMailCCRecipient> CCRecipient { get; set; }
    //    /// <summary>
    //    /// To recipient List
    //    /// </summary>
    //    public List<SendMailToRecipient> TORecipient { get; set; }
    //    /// <summary>
    //    /// If IsBodyWithEmbededObjects is set as true, then consumer should pass Embeded Objects as EntityList
    //    /// </summary>
    //    public List<EmbededObjectsEntity> EmbededObjectsEntityList { get; set; }
    //    /// <summary>
    //    /// If IsBodyWithReplaceChar is set as true, then consumer should pass replace mailcontent as EntityList
    //    /// </summary>
    //    public List<ReplaceMailContentEntity> ReplaceMailContentEntityList { get; set; }
    //}

    /// <summary>
    /// Added for mail Trigger Component - By setting this values, User can embeded image in mail content
    /// </summary>
    //[Serializable]
    //public class EmbededObjectsEntity : BaseTransportEntity
    //{
    //    public string szPATH { get; set; }
    //    public string szName { get; set; }
    //}

    ///// <summary>
    ///// Added for mail Trigger Component - The mail content will be replaced by values
    ///// </summary>
    //[Serializable]
    //public class ReplaceMailContentEntity : BaseTransportEntity
    //{
    //    public string szReplaceName { get; set; }
    //    public string szReplaceValue { get; set; }
    //}

    ///// <summary>
    ///// DefectCountEntity
    ///// </summary>
    //[Serializable]
    //public class DefectCountEntity : BaseTransportEntity
    //{
    //    public string iDefectCount { get; set; }
    //}

    ///// <summary>
    ///// SendMailCCRecipient
    ///// </summary>
    //[Serializable]
    //public class SendMailCCRecipient : BaseTransportEntity
    //{
    //    public string szEmailRecipient { get; set; }
    //}

    ///// <summary>
    ///// SendMailToRecipient class
    ///// </summary>
    //[Serializable]
    //public class SendMailToRecipient : BaseTransportEntity
    //{
    //    public string szEmailToRecipient { get; set; }
    //}

    ///// <summary>
    ///// SendMailCriteria class
    ///// </summary>
    //[Serializable]
    //public class SendMailCriteria : BaseTransportEntity
    //{
    //    public int iMailCritId { get; set; }
    //    public string szMailCriteria { get; set; }
    //}

    /// <summary>
    /// CategoryDetailsEntity class
    /// </summary>
    public class CategoryDetailsEntity
    {
        public int CateGoryId { get; set; }
        public string CategoryDisplayName { get; set; }
        public List<HeadingDetailsEntity> HeadingList { get; set; }
    }

    /// <summary>
    /// HeadingDetailsEntity
    /// </summary>
    public class HeadingDetailsEntity
    {

        public int HeadId { get; set; }
        public string HeadDisplayName { get; set; }
        public int HeadParentDOId { get; set; }


        public List<CheckpointDetailsEntity> DefectOpportunityList { get; set; }
    }
    /// <summary>
    /// CheckpointDetailsEntity clas
    /// </summary>
    public class CheckpointDetailsEntity
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CheckpointDetailsEntity()
        {
            RatingTypeList = new List<TransDropDown>();
            SubDefectList1 = new List<TransDropDown>();
        }
        public int CheckpointId { get; set; }
        public string CheckpointDisplayName { get; set; }
        public string CheckpointDisplayNameDesc { get; set; }
        public Boolean IsCritical { get; set; }
        public string CriticalType { get; set; }
        public Boolean HasSubDefects { get; set; }
        public int DOGroupID { get; set; }
        public float DOGrpMaxWeightage { get; set; }
        public int CheckpointParentDOId { get; set; }
        public int selectedRatingTypeId { get; set; }
        public int SelectedSubDefect1Id { get; set; }
        public int SelectedSubDefect2Id { get; set; }
        public int SelectedSubDefect3Id { get; set; }
        public int SelectedSubDefect4Id { get; set; }
        public int SelectedSubDefect5Id { get; set; }
        public int DefaultSubDefect1Id { get; set; }
        public int DefaultSubDefect2Id { get; set; }
        public int DefaultSubDefect3Id { get; set; }
        public int DefaultSubDefect4Id { get; set; }
        public int DefaultSubDefect5Id { get; set; }
        public int CorrectEmployee { get; set; }
        public int ErrorField { get; set; }
        public string CTQComments { get; set; }
        public List<TransDropDown> RatingTypeList { get; set; }
        public List<TransDropDown> ExtRatingTypeList { get; set; }
        public List<TransDropDown> CombinedRatingTypeList { get; set; }
        public List<TransDropDown> SubDefectList1 { get; set; }
        public List<TransDropDown> ExtSubDefectList1 { get; set; }
        public float DOGroupWeightage { get; set; }
        public bool isDOGroup { get; set; }
        public int ExtSelectedSubDefect1Id { get; set; }
        public int ExtSelectedSubDefect2Id { get; set; }
        public string ExtCTQComments { get; set; }
        public string CTQCommentsCombined { get; set; }
        public string SelectedSubDefect1Ids { get; set; }
        public string SelectedSubDefect2Ids { get; set; }
        public string SelectedSubDefect3Ids { get; set; }
        public string SelectedSubDefect4Ids { get; set; }
        public string SelectedSubDefect5Ids { get; set; }
        public string szAuditingLogic { get; set; }
        
    }
    /// <summary>
    /// AuditDetailsEntityViewModel class
    /// </summary>
    public class AuditDetailsEntityViewModel
    {
        /// <summary>This Entiity Model is having the details of Category,Audit,Auditdetails 
        /// QC and Transaction details of the particular Record</summary> 
        public AuditDetailsEntityViewModel()
        {
            CategoryList = new List<CategoryDetailsEntity>();
            OpportunityList = new List<AuditDetailsEntity>();
            AuditNotesList = new List<AuditNotesEntity>();
            DDLAuditDetial = new DropDownEntity();
            SupAuditList = new List<TransDropDown>();
            TransDetails = new TransactionDetailsEntity();
            AuditDetialQC = new AuditDetailsEntityQCViewModel();
            serviceoutputlist = new List<ServiceOutput>();

        }
        public List<ServiceOutput> serviceoutputlist { get; set; }
        public List<CategoryDetailsEntity> CategoryList { get; set; }
        public List<AuditDetailsEntity> OpportunityList { get; set; }
        public List<AuditNotesEntity> AuditNotesList { get; set; }
        public TransactionDetailsEntity TransDetails { get; set; }
        public DropDownEntity DDLAuditDetial { get; set; }
        public List<TransDropDown> SupAuditList { get; set; }
        public string CustomErrorMessage { get; set; }
        public List<String> ErrorReason { get; set; }
        public string szSubDefectlevelType { get; set; }
        public string ConfigErrorMessage { get; set; }
        public string URLtoRedirect { get; set; }
        public string AuditViewType { get; set; }
        public string SelectedSupAuditList { get; set; }
        public bool IsFatalErrorApplicable { get; set; }
        public bool IsCriticalityApplicable { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsDisable { get; set; }
        public bool isAudited { get; set; }
        public AuditDetailsEntityQCViewModel AuditDetialQC { get; set; }

    }
    //public class ServiceOutput
    //{
    //    public int ElementId { get; set; }
    //    public int RecordID { get; set; }
    //    public string ExpectedValue { get; set; }
    //    public string ActualValue { get; set; }
    //    public Boolean Result { get; set; }
    //    //  public string OCRConfidencetiality { get; set; }
    //    public string Comments { get; set; }
    //    //public int CreatedBy { get; set; }
    //    //public int ModifiedBy { get; set; }
    //    public int AuditStatusId { get; set; }

    //}
    /// <summary>
    /// AuditDetailsEntityQCViewModel class
    /// </summary>
    [Serializable]
    public class AuditDetailsEntityQCViewModel : BaseTransportEntity
    {
        /// <summary>This Entiity Model is havign the details 
        /// of Category,Audit and Transaction details of the particular Record</summary> 
        public AuditDetailsEntityQCViewModel()
        {
            CategoryList = new List<CategoryDetailsEntity>();
            OpportunityList = new List<AuditDetailsEntity>();
            AuditNotesList = new List<AuditNotesEntity>();
            DDLAuditDetial = new DropDownEntity();
            TransDetails = new TransactionDetailsEntity();


        }
        public List<CategoryDetailsEntity> CategoryList { get; set; }
        public List<AuditDetailsEntity> OpportunityList { get; set; }
        public List<AuditNotesEntity> AuditNotesList { get; set; }
        public TransactionDetailsEntity TransDetails { get; set; }
        public DropDownEntity DDLAuditDetial { get; set; }
        public string szSubDefectlevelType { get; set; }
        public string CustomErrorMessage { get; set; }
        public string ConfigErrorMessage { get; set; }
        public string URLtoRedirect { get; set; }
        public string AuditViewType { get; set; }
        public string SelectedSupAuditList { get; set; }
        public bool IsFatalErrorApplicable { get; set; }
        public bool IsCriticalityApplicable { get; set; }


    }
    /// <summary>
    /// SubDefectDetailsEntity class
    /// </summary>
    [Serializable]
    public class SubDefectDetailsEntity : BaseTransportEntity
    {
        public int SubDOId { get; set; }
        public int DOId { get; set; }
        public int Level { get; set; }
        public int CopyLevel { get; set; }
        public string DisplayName { get; set; }
        public int ParentSubDOId { get; set; }
        public int AuditFindingId { get; set; }
        public string ParentSubDOIds { get; set; }
    }
    public class Transddlist : SubDefectDetailsEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }
    /// <summary>
    /// AuditDataEntity class
    /// </summary>
    [Serializable]
    public class AuditDataEntity : BaseTransportEntity
    {
        public AuditDataEntity() //Included by 572814 for Metric Management
        {
            AuditedList = new List<AuditDetailsEntity>();
            AuditedGroupList = new List<AuditGroupDataEntity>();
            ExtAuditedList = new List<AuditDetailsEntity>();
            CombinedAccuracyList = new List<AuditDetailsEntity>();
        }

        public List<AuditDetailsEntity> AuditedList { get; set; }
        public List<AuditGroupDataEntity> AuditedGroupList { get; set; }
        public List<AuditDetailsEntity> ExtAuditedList { get; set; }
        public List<AuditDetailsEntity> CombinedAccuracyList { get; set; }

        public string _strAuditlogic { get; set; }
        public string _strScoringLogic { get; set; }
        public string _AuditFindingId { get; set; }
        public string _IsEmpApp { get; set; }
        public string _FatalStatus { get; set; }
        public string IsFieldScoreApplicable { get; set; }
        public string _SubCategoryID { get; set; }
        public string _IsCriticalApp { get; set; }

        public string calibrationType { get; set; }
    }

    /// <summary>
    /// AuditGroupDataEntity class
    /// </summary>
    [Serializable]
    public class AuditGroupDataEntity : BaseTransportEntity
    {
        public int AuditId { get; set; }
        public int HeadingDOId { get; set; }
        public int CheckpointDOId { get; set; }
        public int GroupID { get; set; }
        public int NoofApplicable { get; set; }
        public int NoofError { get; set; }
        public double GroupWeightage { get; set; }
        public double CalculatedGroupWeightage { get; set; }
        public double SumGroupWeightage { get; set; }
        public double SumCalculatedGroupWeightage { get; set; }

        public int AuditFindingId { get; set; }
    }

}
