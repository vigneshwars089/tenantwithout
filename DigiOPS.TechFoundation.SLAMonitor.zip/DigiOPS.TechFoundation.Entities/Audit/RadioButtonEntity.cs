﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Quart.BusinessEntity;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// RadioButton Entit
    /// </summary>
    public class RadioButtonEntity
    {
        public List<TransDropDown> AuditTypeList { get; set; }
        public List<TransDropDown> YesNoTypeList { get; set; }

        /// <summary>
        /// RadioButton constructor
        /// </summary>
        public RadioButtonEntity()
        {
            AuditTypeList = new List<TransDropDown>();
            YesNoTypeList = new List<TransDropDown>();
        }
    }
}
