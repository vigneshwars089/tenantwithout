﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Hierarchy
{
    public class ProgramConfiguration : IProgramConfiguration
    {
        ProgramDAO pdao = new ProgramDAO();
        public string AddUpdateProgram(BaseTransportEntity programEnt)
        {
            string createRecVal = string.Empty;
            createRecVal = pdao.CUDProgramRecord(programEnt);
            return createRecVal;
        }
    }
}
