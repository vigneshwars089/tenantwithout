﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Hierarchy
{
    public interface IProgramConfiguration
    {
        string AddUpdateProgram(BaseTransportEntity programEnt);
        List<TransDropDown> GetAccountList(int VerId);
        List<List<BaseTransportEntity>> GetProgramList(string sortOrder = null, string sortColumn = null, int? startRowIndex = null, int? maximumRows = null);
        string DeleteProgram(int ProgId, string sortOrder = null, string sortColumn = null, int? startRowIndex = null);
    }
}
