﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Collaboration
{
    public class BaseContentTemplate : IContentTemplate
    {
        public virtual string GetTemplate(EMailInfo objInfo)
                    {
                        return string.Empty;
                    }
    }
}
