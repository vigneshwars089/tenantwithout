﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.Logging
// Class Name(s) :EntLibLogHelper
// Author : Sujitha
// Creation Date : 13/2/2017
// Purpose : EntLibLogHelper Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//13-Feb-2017    Sujitha     EntLibLogHelper            Added EntLibLogHelper Methods 
//////////////////////////////////////////////////////////////////////////////////////////////////////
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using Microsoft.Practices.EnterpriseLibrary.Logging.Formatters;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Logging
{
    internal class EntLibLogHelper
    {
        string SourceName = typeof(BaseCustomLogger).Name.ToString();

        const string logName = "BaseCustomLogger";

        #region internal  GetLogWriter
        /// <summary>
        /// set messages with a category ofError" or "Debug" to get distributed
        /// to all TraceListeners in traceListeners.
        /// </summary>
        /// <param name="logFileListener">Array of TraceListeners</param>
        /// <returns>IDictionary with logSource</returns>
        internal   LogWriter GetLogWriter(List<TraceListener> logListener)
        {


            // Assigning a non-existant LogSource
            // for Logging Application Block
            // Specials Sources that were doesn't cared.
            // Used to say "don't log".
            LogSource nonExistantLogSource = new LogSource("Empty");


            // Let's glue it all together.
            // No filters at this time.
            // I won't log a couple of the Special
            // Sources: All Events and Events not
            // using "Error" or "Debug" categories.
            return  LogWriter(new ILogFilter[0], // ICollection<ILogFilter> filters

                               GetTraceSource(AddToLogSource(logListener)),        // IDictionary<string, LogSource> traceSources

                               nonExistantLogSource,    // LogSource allEventsTraceSource

                               nonExistantLogSource,    // LogSource notProcessedTraceSource

                               AddToLogSource(logListener),    // LogSource errorsTraceSource

                               EntLibLogger.ErrorCategory,        // string defaultCategory

                               false,                // bool tracingEnabled

                               true);                // bool logWarningsWhenNoCategoriesMatch


        }

        private LogWriter LogWriter(ILogFilter[] logFilter, IDictionary<string, LogSource> dictionary, LogSource nonExistantLogSource1, LogSource nonExistantLogSource2, LogSource logSource, string p1, bool p2, bool p3)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region internal  GetTraceSource
        /// <summary>
        /// set messages with a category ofError" or "Debug" to get distributed
        /// to all TraceListeners in traceListeners.
        /// </summary>
        /// <param name="logFileListener">Array of TraceListeners</param>
        /// <returns>IDictionary with logSource</returns>
        internal  IDictionary<string, LogSource> GetTraceSource(LogSource lsource)
        {

            // set messages with a category of
            // "Error" or "Debug" to get distributed
            // to all TraceListeners in traceListeners.
            IDictionary<string, LogSource> traceSources = new Dictionary<string, LogSource>();

            traceSources.Add("Error", lsource);
            traceSources.Add("Debug", lsource);

            return traceSources;
        }

        #endregion

        #region internal GetTextFormat
        /// <summary>
        /// The formatter is responsible for the look 
        /// of the message.
        /// </summary>
        /// <returns></returns>
        internal  TextFormatter GetTextFormat()
        {
            // Notice the tokens:
            // {timestamp}, {newline}, {message}, {category}
            TextFormatter formatter = new TextFormatter
                (
                "Message: {message}{newline}" +
                "Category: {category}{newline}");
            return formatter;
        }
        #endregion

        #region Listeners
        #region internal FlatFileTraceListener GetFileTraceListener
        /// <summary>
        /// Log messages to a log file.
        /// </summary>
        /// <param name="formatter"></param>
        /// <returns></returns>
        internal  FlatFileTraceListener GetFileTraceListener(TextFormatter formatter)
        {
            // Log messages to a log file.
            // Use the formatter passed
            // as well as the header and footer
            // specified.
            string FlatfileName = GetLogFilename() + "Error_" + DateTime.Now.ToShortDateString().Replace('/', '_') + ".log";
            FlatFileTraceListener logFileListener =
                new FlatFileTraceListener(FlatfileName,
                                           "----------",
                                           "----------",
                                           formatter);
            return logFileListener;
        }
        #endregion

        #region internal FormattedEventLogTraceListener GetEventLogTraceListener
        /// <summary>
        /// Log messages to a log file.
        /// </summary>
        /// <param name="formatter"></param>
        /// <returns></returns>
        internal  FormattedEventLogTraceListener GetEventLogTraceListener(TextFormatter formatter)
        {
            // Log messages to a log file.
            // Use the formatter passed
            // as well as the header and footer
            // specified.


            FormattedEventLogTraceListener eventlogListener =
                new FormattedEventLogTraceListener(new EventLog(logName, Environment.MachineName, SourceName),
                                                          formatter);
            return eventlogListener;
        }
        #endregion

        #region internal EmailTraceListener GetEmailTraceListener
        /// <summary>
        /// Log messages to a log file.
        /// </summary>
        /// <param name="formatter"></param>
        /// <returns></returns>
        internal  EmailTraceListener GetEmailTraceListener(TextFormatter formatter)
        {
            // Log messages to a log file.
            // Use the formatter passed
            // as well as the header and footer
            // specified.


            EmailTraceListener mailListener =
                new EmailTraceListener("Test@xxxxx.com", "Test@xxxxxxx.com", "Admin", "<<ApplicationName>>", "smtp.xxxxxx.com", 25, formatter);
            return mailListener;
        }
        #endregion
        #endregion

        #region  LogSource AddToLogSource
        /// <summary>
        /// Add collection of TraceListeners to LogSource.
        /// </summary>
        /// <param name="ListenerArray">Array of listenerS</param>
        /// <returns>LogSource </returns>
        internal  LogSource AddToLogSource(List<TraceListener> ListenerArray)
        {
            // collection of TraceListeners.
            LogSource mainLogSource =
                new LogSource("TestLogSource", SourceLevels.All);
            foreach (var objTraceListener in ListenerArray)
                mainLogSource.Listeners.Add(objTraceListener);

            return mainLogSource;
        }
        #endregion

        #region  string GetLogFilename
        /// <summary>
        /// gets the log file (flat file) name
        /// from AppSettings in the web.config.
        /// </summary>
        /// <returns></returns>
        internal  string GetLogFilename()
        {
            string file;
            return file = System.Configuration.ConfigurationManager.AppSettings["logFilename"].ToString();


        }
        #endregion

    }
}
