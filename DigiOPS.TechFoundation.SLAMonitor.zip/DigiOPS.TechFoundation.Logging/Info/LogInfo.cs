﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.Logging
// Class Name(s) :LogInfo
// Author : Sujitha
// Creation Date : 13/2/2017
// Purpose : Logger Entities 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//13-Feb-2017    Sujitha     LogInfo            Added Logger Entities 
//////////////////////////////////////////////////////////////////////////////////////////////////////
using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Logging
{

   public class LogInfo : BaseInfo
    {
       public string Message { set; get; } 
    }

    public struct S_LoggerTypes
    {
        public const string Log4net = "Log4net";
    
    }

    public struct LogListenerType
    {
        public const string File ="File";
        public const string Email = "Email";
       public const string EventViewer = "EventViewer";
       public const string All = "All";
    }
}
