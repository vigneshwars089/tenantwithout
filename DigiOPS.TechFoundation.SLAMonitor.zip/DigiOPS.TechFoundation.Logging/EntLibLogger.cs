﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.Logging
// Class Name(s) :EntLibLogger
// Author : Sujitha
// Creation Date : 13/2/2017
// Purpose : EntLibLogger Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//13-Feb-2017    Sujitha     EntLibLogger            Added EntLibLogger Methods 
//////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
//using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging.Formatters;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using System.Diagnostics;

namespace DigiOPS.TechFoundation.Logging
{
    public class EntLibLogger : BaseCustomLogger
    {
        /// <summary>
        /// 
        /// </summary>
         LogWriter _writer;
        
        public static string ErrorCategory = "Error";
         List<TraceListener> logFileListener;
        /// <summary>
        /// Writes an Error to the log.
        /// </summary>
        /// <param name="ex"></param>
         public override void LogException(Exception ex)
        {
          //  Dictionary<string, string> additionalInfo = new Dictionary<string, string>();
            LogException(ex);
        }
         /// <summary>
        /// Writes a message to the log using the specified category
        /// </summary>
        /// <param name="message">meesage to be logged</param>
        /// <param name="category">category for logging the given message</param>
        public  void LogException(Exception ex, string category, string loglistenertype)
        {
            Dictionary<string, string> additionalInfo = new Dictionary<string, string>();
            /// Writes a message to the log using the specified
            /// category.
            LogEntry entry = new LogEntry();
            entry.Categories.Add(category);
            entry.Message = (SerializeToText(ex, ref additionalInfo)).ToString();
            logFileListener = new List<TraceListener>();
            EntLibLogHelper objEntLibLogHelper=new EntLibLogHelper();

            switch (loglistenertype)
            { 
                case LogListenerType.File:
                  
                    logFileListener.Add(objEntLibLogHelper.GetFileTraceListener(objEntLibLogHelper.GetTextFormat()));
                    break;
                case LogListenerType.EventViewer:
                    {
                        logFileListener.Add(objEntLibLogHelper.GetEventLogTraceListener(objEntLibLogHelper.GetTextFormat()));
                        entry.Severity = System.Diagnostics.TraceEventType.Error;
                        break;
                    }
                case LogListenerType.Email:
                    logFileListener.Add(objEntLibLogHelper.GetEmailTraceListener(objEntLibLogHelper.GetTextFormat()));
                    break;
                case LogListenerType.All:
                    {
                        logFileListener.Add(objEntLibLogHelper.GetFileTraceListener(objEntLibLogHelper.GetTextFormat()));
                        logFileListener.Add(objEntLibLogHelper.GetEventLogTraceListener(objEntLibLogHelper.GetTextFormat()));
                        break;
                    }
                default:
                    logFileListener.Add(objEntLibLogHelper.GetEventLogTraceListener(objEntLibLogHelper.GetTextFormat()));
                    break;
            }

            _writer = objEntLibLogHelper.GetLogWriter(logFileListener);
            _writer.Write(entry);
        }
    }


   
}


