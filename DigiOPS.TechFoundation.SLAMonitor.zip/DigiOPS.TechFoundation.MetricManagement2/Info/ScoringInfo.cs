﻿

using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :ScoringInfo.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :ScoringInfo
    // Author : Sujitha
    // Creation Date : 17/4/2017
    // Purpose : Scoring Info
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
      [Serializable]
        public class ScoringInfo :BaseInfo
        {
          public ScoringInfo() //Included by 572814 for Metric Management
            {
                AuditedList = new List<DetailsEntity>();              
              
            }

            public List<DetailsEntity> AuditedList { get; set; }
     
            public string _strAuditlogic { get; set; }
            public string _strScoringLogic { get; set; }   
            public string _IsCriticalApp { get; set; }
            public bool _IsLineApp { get; set; }
            public string _SubCategoryID { get; set; }
            public int _LineFieldlevel { get; set; }
            public int _ErrorFieldlevel  { get; set; }
            public int _iPageCount { get; set; }
            public int _iLine { get; set; }
            public double _CoverageScore { get; set; }
        }



      public class DetailsEntity : ScoringInfo
        {           
             
            public float GivenWeightage { get; set; } // Weitage provided on selecting the rating 1- yes 0 -No 
            public Boolean DefectNA { get; set; }  // Should be considerd for score calculation 
            public float MaxWeightage { get; set; } // Maximum configured for CTQ -1 yes
            public int DOGroupID { get; set; } // Grouping CTQ with Heading 
            public int ParentDOId { get; set; }       //If its is CTQ , Parent id - Heading Id ,if it Heading ParentId - Category Id    
            private string criticalityType = "";
            public string CriticalityType   // Critical , Non-Critical , Fatal 
            {
                get { return criticalityType; }
                set { criticalityType = value; }
            }           
            public float GroupWeightage { get; set; } // Group Based defined for more heading 
            public int SelectedRatingId { get; set; }
            public string SelectedRatingName { get; set; }
            public float CalculatedGroupWeightage { get; set; } // Weigtage provided for groups 
            public int ErrorField { get; set; }
        }

    }

