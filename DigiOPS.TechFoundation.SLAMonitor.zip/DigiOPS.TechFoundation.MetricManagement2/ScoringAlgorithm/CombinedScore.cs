﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :CombinedScore.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :CombinedScore
    // Author : 
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     GenerateQualityScore            Generate QualityScore  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class CombinedScore : BaseScoringAlgorithm
    {
        public override ScoringOutput GenerateQualityScore(List<ScoringInfo> objAuditDataEntity)
        {
            List<ScoringInfo> objMultiEntity = objAuditDataEntity;

            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringOutput objScoringValidation = new ScoringOutput();
            objScoringValidation.ErrorMessage = new StringBuilder();
            double _totAppOpp = 0;
            double QualityScore = 0;

            //Validate all levels
            foreach (ScoringInfo objinfo in objMultiEntity)
            {
                if (objinfo._strScoringLogic == "WDPO")
                {
                    objScoringValidation.ResultStatus = false;
                    objScoringValidation.ErrorMessage.Append("Multi Scoring Not Applicable For WDPO");
                }
                else if (objinfo._strAuditlogic != "CHECKPOINT BASED")
                {
                    objScoringValidation.ResultStatus = false;
                    objScoringValidation.ErrorMessage.Append("Multi Scoring Applicable only For CHECKPOINT BASED");
                }
                else
                {
                    objScoringValidation = Validation(objinfo);
                    if (objScoringValidation.ResultStatus == false)
                    {
                        break;
                    }

                }
            }

            if (objScoringValidation.ResultStatus)
            {
                foreach (ScoringInfo objinfo in objMultiEntity)
                {

                    _totAppOpp = _totAppOpp + objinfo.AuditedList.FirstOrDefault().GroupWeightage;
                    ScoringOutput objoutput = new ScoringOutput();
                    IScoringAlgorithmFactory objScoralog = new ScoringAlgorithmFactory();

                    if (objinfo._strAuditlogic == "DPU")
                    {
                        objoutput = objScoralog.GetScoringHandler(objinfo).CalculateQualityScore(objinfo);
                        QualityScore = QualityScore + ((objoutput.QualityScore == 0) ? 0 : objinfo.AuditedList.FirstOrDefault().GroupWeightage);
                    }
                    else if (objinfo._strAuditlogic == "DPO")
                    {
                        var TotalDefectsGroupWeightages = (from c in objinfo.AuditedList.Where(m => m.GivenWeightage != -1)//.Select(x => x.GroupWeightage).Sum();

                                                           group c by new { c.DOGroupID, c.GroupWeightage } into g
                                                           select g.Key.GroupWeightage).Sum();


                        var TotalDefectsAPPandNonAPP = from c in objinfo.AuditedList.Where(m => m.GivenWeightage != -1)
                                                       group c by new { c.DOGroupID, c.GroupWeightage } into g
                                                       select new
                                                       {

                                                           GroupID = g.Key.DOGroupID,

                                                           NoofApplicable = g.Count(),
                                                           NoofError = g.Count(oi => oi.GivenWeightage == 0),
                                                           GivenWeightage = g.Key.GroupWeightage

                                                       };

                        var SumGroupScore = from c in TotalDefectsAPPandNonAPP


                                            group c by new { c.GroupID } into g
                                            select (new
                                            {

                                                GroupID = g.Key.GroupID,

                                                TotalCalculatedScore = g.Sum(oi => (float)(((float)((oi.NoofApplicable - oi.NoofError)) / (float)(oi.NoofApplicable)) * (float)(oi.GivenWeightage)))


                                            });

                        var TotalDefectsCalculatedGroupWeightages = SumGroupScore.Select(p => p.TotalCalculatedScore).Sum();

                        QualityScore = QualityScore + TotalDefectsCalculatedGroupWeightages;
                    }
                }

                QualityScore = QualityScore / Convert.ToDouble(_totAppOpp);
                QualityScore = Math.Round(QualityScore, 4) * 100;
                objScoringOutput.QualityScore = QualityScore;
            }
            else
            {
                objScoringOutput = objScoringValidation;
            }
            return objScoringOutput;
        }
    }
}
