﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DPUCheckItem.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :DPUCheckItem
    // Author : Sujitha
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     GenerateQualityScore            Generate QualityScore  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class DPUCheckItem : DPUScoreAlgorithm
    {

        public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();    
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._totAppDefects = objAuditDataEntity.AuditedList
                                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1).Count();
            scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();

            
            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            else
            {
               
                    scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;

        }

        public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo _AuditData)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();   
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._totAppDefects = _AuditData.AuditedList
                                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Count();
            scoringAlgorithmInfo._CriticalityChecked = _AuditData.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();

            int _totErrorField = 0;
            double _ErrorFieldScore = 0.0;
            double _ErrorFieldQualityScore = 0.0;
            if (_AuditData._IsLineApp)
            {
                _totErrorField = _AuditData.AuditedList.Sum(m => m.ErrorField);
                if (_AuditData._SubCategoryID == "2")//billtype
                {


                    _ErrorFieldScore = _AuditData._ErrorFieldlevel + (_AuditData._LineFieldlevel * _AuditData._iLine);//noofline for billtype
                    _ErrorFieldQualityScore = 1 - (_totErrorField / _ErrorFieldScore);
                }
                else if (_AuditData._SubCategoryID == "1")//demandtype
                {
                    //pagecount-iPageCntDataAudit
                    _ErrorFieldQualityScore = ((Convert.ToDouble(_AuditData._iPageCount) - _totErrorField) / (_AuditData.AuditedList[0]._iPageCount));

                }
                if (_ErrorFieldQualityScore < 0)
                    _ErrorFieldQualityScore = 0;
                _ErrorFieldQualityScore = Math.Round(_ErrorFieldQualityScore, 4) * 100;
                objScoringOutput.FieldQualityScore = _ErrorFieldQualityScore;

            }

            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
               
            }
            else
            {
                    scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;
            
        }
    }
}
