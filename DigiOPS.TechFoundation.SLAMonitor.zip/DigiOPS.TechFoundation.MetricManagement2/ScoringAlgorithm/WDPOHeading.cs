﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :WDPOHeading.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :WDPOHeading
    // Author : Sujitha
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     GenerateQualityScore            Generate QualityScore  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
   public class WDPOHeading: WDPOScoreAlgorithm
    {

       public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
       {
           ScoringOutput objScoringOutput = new ScoringOutput();
           ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

           scoringAlgorithmInfo._QualityScore = 0.0;
           scoringAlgorithmInfo._CriticalityChecked = 0;
           scoringAlgorithmInfo._totAppDefects = 0;
           scoringAlgorithmInfo._totHeadings = 0;
           scoringAlgorithmInfo._totAppHeadings = 0;
           scoringAlgorithmInfo._totAppHeadingsDefects = 0;
           scoringAlgorithmInfo._totHeadings_W = 0.0;
           scoringAlgorithmInfo._totAppHeadings_W = 0.0;
           scoringAlgorithmInfo._totAppHeadingsWDPO_W = 0.0;
           scoringAlgorithmInfo._totHeadingsWDPO_W = 0.0;
           scoringAlgorithmInfo._totErrorField = 0;
           scoringAlgorithmInfo._ErrorFieldScore = 0.0;
           scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

           scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                  .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();


           var _Headings = objAuditDataEntity.AuditedList.GroupBy(m => m.ParentDOId).ToArray();

           foreach (var _Heading in _Headings)
           {
               double _Heading_W = _Heading
                                   .Select(m => m.MaxWeightage)
                                   .FirstOrDefault();

               double HeadingsDefects_W = _Heading
                                       .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                       .Select(x => x.GivenWeightage)
                                        .FirstOrDefault();

               int _AppHeading = _Heading
                                   .Where(x => x.GivenWeightage != -1)
                                   .GroupBy(x => x.DOGroupID)
                                   .Count();

               int _AppHeadingDefects = _Heading
                                          .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                          .GroupBy(x => x.DOGroupID)
                                          .Count();

               int _AppHeadingsNoDefects = 0;


              
                       _AppHeadingsNoDefects = (_AppHeading == 0) ? 0 : 1;
                       if (_AppHeading < 1)
                       {
                           _Heading_W = 0;
                       }
                       if (_AppHeadingDefects == 1)
                       {
                           HeadingsDefects_W = _Heading
                                                   .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                                   .Select(x => x.GivenWeightage)
                                                   .Min();
                       }



                       scoringAlgorithmInfo._totHeadings_W = scoringAlgorithmInfo._totHeadings_W + _Heading_W;

                       scoringAlgorithmInfo._totAppHeadings = scoringAlgorithmInfo._totAppHeadings + _AppHeading;
                       scoringAlgorithmInfo._totAppHeadings_W = scoringAlgorithmInfo._totAppHeadings_W + (_AppHeading * _Heading_W);

                       scoringAlgorithmInfo._totAppHeadingsDefects = scoringAlgorithmInfo._totAppHeadingsDefects + _AppHeadingDefects;

                      
                   if (_AppHeadingDefects == 1)
                   {
                       scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                       scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + HeadingsDefects_W;
                   }
                   else
                   {
                       scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                       scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + _Heading_W;

                   }
              
           }
           int _totErrorField = 0;
           double _ErrorFieldScore = 0.0;
           double _ErrorFieldQualityScore = 0.0;
           if (objAuditDataEntity._IsLineApp)
           {
               _totErrorField = objAuditDataEntity.AuditedList.Sum(m => m.ErrorField);
               if (objAuditDataEntity._SubCategoryID == "2")//billtype
               {


                   _ErrorFieldScore = objAuditDataEntity._ErrorFieldlevel + (objAuditDataEntity._LineFieldlevel * objAuditDataEntity._iLine);//noofline for billtype
                   _ErrorFieldQualityScore = 1 - (_totErrorField / _ErrorFieldScore);
               }
               else if (objAuditDataEntity._SubCategoryID == "1")//demandtype
               {
                   //pagecount-iPageCntDataAudit
                   _ErrorFieldQualityScore = ((Convert.ToDouble(objAuditDataEntity._iPageCount) - _totErrorField) / (objAuditDataEntity.AuditedList[0]._iPageCount));

               }
               if (_ErrorFieldQualityScore < 0)
                   _ErrorFieldQualityScore = 0;
               _ErrorFieldQualityScore = Math.Round(_ErrorFieldQualityScore, 4) * 100;
               objScoringOutput.FieldQualityScore = _ErrorFieldQualityScore;

           }

           if (scoringAlgorithmInfo._CriticalityChecked > 0)
           {
               scoringAlgorithmInfo._QualityScore = 0.0;
               scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           else
           {
               scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 1 : (scoringAlgorithmInfo._totAppHeadingsWDPO_W) / (scoringAlgorithmInfo._totHeadingsWDPO_W);
               scoringAlgorithmInfo._QualityScore = Math.Round(scoringAlgorithmInfo._QualityScore, 4) * 100;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           objScoringOutput.ResultStatus = true;
           return objScoringOutput;
                              
       }

       public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo _AuditData)
       {
           ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppHeadingsDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._totAppHeadingsWDPO_W = 0.0;
            scoringAlgorithmInfo._totHeadingsWDPO_W = 0.0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;



            scoringAlgorithmInfo._CriticalityChecked = _AuditData.AuditedList
                                           .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
                              

           var _Headings = _AuditData.AuditedList.GroupBy(m => m.ParentDOId).ToArray();

           foreach (var _Heading in _Headings)
           {
               double _Heading_W = _Heading
                                   .Select(m => m.MaxWeightage)
                                   .FirstOrDefault();

               double HeadingsDefects_W = _Heading
                                       .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                       .Select(x => x.GivenWeightage)
                                        .FirstOrDefault();

               int _AppHeading = _Heading
                                   .Where(x => x.GivenWeightage != -1)
                                   .GroupBy(x => x.DOGroupID)
                                   .Count();

               int _AppHeadingDefects = _Heading
                                          .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                          .GroupBy(x => x.DOGroupID)
                                          .Count();

               int _AppHeadingsNoDefects = 0;

               _AppHeadingsNoDefects = (_AppHeading == 0) ? 0 : 1;
               if (_AppHeading < 1)
               {
                   _Heading_W = 0;
               }
               if (_AppHeadingDefects == 1)
               {
                   HeadingsDefects_W = _Heading
                                           .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                           .Select(x => x.GivenWeightage)
                                           .Min();
               }


               scoringAlgorithmInfo._totAppHeadingsDefects = scoringAlgorithmInfo._totAppHeadingsDefects + _AppHeadingDefects;


              
                   if (_AppHeadingDefects == 1)
                   {
                       scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                       scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + HeadingsDefects_W;
                   }
                   else
                   {
                       scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                       scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + _Heading_W;
                   }
               
           }

           int _totErrorField = 0;
           double _ErrorFieldScore = 0.0;
           double _ErrorFieldQualityScore = 0.0;
           if (_AuditData._IsLineApp)
           {
               _totErrorField = _AuditData.AuditedList.Sum(m => m.ErrorField);
               if (_AuditData._SubCategoryID == "2")//billtype
               {


                   _ErrorFieldScore = _AuditData._ErrorFieldlevel + (_AuditData._LineFieldlevel * _AuditData._iLine);//noofline for billtype
                   _ErrorFieldQualityScore = 1 - (_totErrorField / _ErrorFieldScore);
               }
               else if (_AuditData._SubCategoryID == "1")//demandtype
               {
                   //pagecount-iPageCntDataAudit
                   _ErrorFieldQualityScore = ((Convert.ToDouble(_AuditData._iPageCount) - _totErrorField) / (_AuditData.AuditedList[0]._iPageCount));

               }
               if (_ErrorFieldQualityScore < 0)
                   _ErrorFieldQualityScore = 0;
               _ErrorFieldQualityScore = Math.Round(_ErrorFieldQualityScore, 4) * 100;
               objScoringOutput.FieldQualityScore = _ErrorFieldQualityScore;

           }
           if (scoringAlgorithmInfo._CriticalityChecked > 0)
                   {
                       scoringAlgorithmInfo._QualityScore = 0.0;
                       scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                       objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                   }
                   else
                   {
                       scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 1 : (scoringAlgorithmInfo._totAppHeadingsWDPO_W) / (scoringAlgorithmInfo._totHeadingsWDPO_W);
                       scoringAlgorithmInfo._QualityScore = Math.Round(scoringAlgorithmInfo._QualityScore, 4) * 100;
                       objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                   }
           objScoringOutput.ResultStatus = true;
           return objScoringOutput;
                  
           }             
       
   }
}
