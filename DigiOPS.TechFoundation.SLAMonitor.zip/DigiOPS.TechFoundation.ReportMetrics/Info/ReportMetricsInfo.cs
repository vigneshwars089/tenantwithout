﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ReportMetrics
{
   public class ReportMetricsInfo : BaseInfo
    {
       ReportMetricsInfo()
       {
           objMetricFormula = new List<MetricFormula>();
           objMetricResult = new List<MetricResult>();
           objInputSoruce = new List<InputSoruce>();
           objTransactionList = new List<TransactionList>();
       }
       public List<MetricFormula> objMetricFormula { get; set; }
       public List<MetricResult> objMetricResult { get; set; }
       public List<InputSoruce> objInputSoruce { get; set; }
       public List<TransactionList> objTransactionList { get; set; }
     
    }
   public class MetricFormula
   {
       public string Formula1 { get; set; }
   }
   public class MetricResult
   {
       public string Result1 { get; set; }
   }
   public class InputSoruce
   {
       public string Soruce1 { get; set; }
   }
   public struct MathOperators
   {
       public const string Addition = "+";
       public const string Subtraction = "-";
       public const string Multiplication = "*";
       public const string Division = "/"; 
       public const string Percentage = "%";
       
   }
   public class TransactionList
   {
       public string Transaction1 { get; set; }
   }
}
