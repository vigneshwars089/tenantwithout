﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ReportMetrics
{
    public class AHTCalculator : BaseMetricCalculator
    {
        public override ReportMetricsInfo AddMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }

        public override ReportMetricsInfo GetMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }

        public override ReportMetricsInfo ApplyMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }

    }
}
