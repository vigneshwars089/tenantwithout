﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ReportMetrics
{
    public class BaseMetricCalculator : IReportMetrics
    {

        public virtual ReportMetricsInfo AddMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }

        public virtual ReportMetricsInfo GetMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }

        public virtual ReportMetricsInfo ApplyMetrics(ReportMetricsInfo objRMT)
        {
            throw new NotImplementedException();
        }
    }
}
