﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ReportMetrics
{
    public interface IReportMetrics
    {
        ReportMetricsInfo AddMetrics(ReportMetricsInfo objRMT);
        ReportMetricsInfo GetMetrics(ReportMetricsInfo objRMT);
        ReportMetricsInfo ApplyMetrics(ReportMetricsInfo objRMT);

    }
}
