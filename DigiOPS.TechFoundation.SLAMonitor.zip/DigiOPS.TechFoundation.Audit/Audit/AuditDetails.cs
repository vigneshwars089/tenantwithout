﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;
//using System.Web.UI;

////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :AuditDetails.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :AuditDetails
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This method is used to get audit details.
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////

namespace DigiOPS.TechFoundation.Audit
{
    public class AuditDetails:IAuditDetails
    {

        AuditDetailsDataAccess addao = new AuditDetailsDataAccess();
        
        //public AuditDetails(BaseInfo objBaseinfo)
        //{
        //    addao = new AuditDetailsDataAccess(objBaseinfo.TenantName, objBaseinfo.AppID);
        //}

        public  List<List<AuditDetailsEntity>> GetAuditDetails(AuditDetailsEntity objauddet)
        {
            //addao = new AuditDetailsDataAccess(objauddet.TenantName, objauddet.AppID);
           return addao.GetAuditDetails(objauddet);
        }
        public List<SubDefectDetailsEntity> GetRCList(SubDefectDetailsEntity objsubdo)
        {
           // addao = new AuditDetailsDataAccess(objsubdo.TenantName, objsubdo.AppID);
            return addao.GetRCList(objsubdo);
        }

        public  AuditDOEntity GetAuditDeleteStatus(AuditDOEntity objauditdo)
        {
           // addao = new AuditDetailsDataAccess(objauditdo.TenantName, objauditdo.AppID);
            return addao.GetAuditDeleteStatus(objauditdo);
        }

        public bool IsAttachmentRequired(AuditDOEntity objauditdo)
        {
            //addao = new AuditDetailsDataAccess(objauditdo.TenantName, objauditdo.AppID);
            return addao.IsAttachmentRequired(objauditdo);
        }
        public  AuditDOEntity GetQCStatus(AuditDOEntity objauditdo)
        {
            //addao = new AuditDetailsDataAccess(objauditdo.TenantName, objauditdo.AppID);
            return addao.GetQCStatus(objauditdo);

       }

        public  string SetAuditDetails(AuditDOEntity objAuditDetailsEntity)
        {
           // addao = new AuditDetailsDataAccess(objAuditDetailsEntity.TenantName, objAuditDetailsEntity.AppID);
            return addao.SetAuditDetails(objAuditDetailsEntity);
        }

   
       
    }
}
