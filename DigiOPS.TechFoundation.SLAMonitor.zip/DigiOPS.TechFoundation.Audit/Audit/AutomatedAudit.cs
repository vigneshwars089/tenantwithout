﻿//using DigiOPS.TechFoundation.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Audit
{
    public class AutomatedAudit : IAutomatedAudit
    {
        //ConfigurationFactory obj = new ConfigurationFactory();
        AudotmatedAuditDataAccess objAudotmatedAuditdataaccess = null;
        //public AutomatedAudit(BaseInfo objBaseinfo)
        //{
        //    objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objBaseinfo.TenantName, objBaseinfo.AppID);
        //}
        //public List<DataElementEntity> GetTransactionFromAllSource(DataElementInfo objdataeleinfo)
        // {
        //   List<DataElementEntity> objdataeleentlist = new List<DataElementEntity>();
        //    List<List<DataElementEntity>> objlist = new List<List<DataElementEntity>>();
        //  //  DataElementInfo objdelmntinfo = new DataElementInfo();
        //    objlist = obj.GetConfigurationHandler("Manual", "DataElementConfiguration").GetDataElements(objdataeleinfo);
        //    objdataeleentlist = objlist[0];
        //    return objdataeleentlist;
        // }

        public List<ServiceOutput> AuditDataElements(List<DataelementAutomatedAuditEntity> ExpectedParamlist, List<DataelementAutomatedAuditEntity> ActualParamlist)
        {
            //  List<List<ServiceOutput>> objlistlistop = new List<List<ServiceOutput>>();
            List<ServiceOutput> objlistop = new List<ServiceOutput>();
            ServiceOutput objoutput = new ServiceOutput();
            DataelementAutomatedAuditEntity ActualParam = new DataelementAutomatedAuditEntity();
            DataelementAutomatedAuditEntity ExpectedParam = new DataelementAutomatedAuditEntity();
            string exp = string.Empty;
            string actual = string.Empty;
            if (ExpectedParamlist != null && ActualParamlist != null)
            {
                if (ExpectedParamlist.Count == ActualParamlist.Count)
                {
                    for (int j = 0; j < ActualParamlist.Count(); j++)
                    {
                        ActualParam = ActualParamlist[j];
                        ExpectedParam = ExpectedParamlist[j];
                        int c = ExpectedParam.GetType().GetProperties().Count();

                        var propsOfExpected = ExpectedParam.GetType().GetProperties();

                        if (ActualParam.ElementId == ExpectedParam.ElementId)
                        {
                            object ex = ExpectedParam.ElementData;//propsOfExpected[0].GetValue(ExpectedParam, null);

                            object ac = ActualParam.ElementData;//propsOfExpected[0].GetValue(ActualParam, null);
                            if (ex != null && ac != null)
                            {
                                exp = ex.ToString();
                                actual = ac.ToString();
                            }
                            objoutput = new ServiceOutput();
                            objoutput.ElementId = ActualParam.ElementId;//propsOfExpected[0].Name;
                            objoutput.RecordID = ActualParam.RecordId;
                            if (ex == null || ac == null)
                            {
                                if (ex == null && ac == null)
                                    objoutput.Comments = "Both Input's are null";
                                else if (ex == null)
                                    objoutput.Comments = "Expected Field is null";
                                else
                                    objoutput.Comments = "Actual Field is null";
                                objoutput.ResultStatus = false;
                                objlistop.Add(objoutput);
                            }
                            else if (exp == actual)
                            {

                                objoutput.ActualValue = actual;
                                objoutput.ExpectedValue = exp;
                                objoutput.ResultStatus = true;
                                objlistop.Add(objoutput);
                            }
                            else
                            {

                                objoutput.ActualValue = actual;
                                objoutput.ExpectedValue = exp;
                                objoutput.ResultStatus = false;
                                objlistop.Add(objoutput);
                            }
                        }


                    }
                }//objlistlistop.Add(objlistop);
            }
            return objlistop;
        }

        public List<List<DataelementAutomatedAuditEntity>> GetDataElementBasedonSource(DataelementAutomatedAuditEntity objdata)
        {
            List<List<DataelementAutomatedAuditEntity>> objdataeleentlist = new List<List<DataelementAutomatedAuditEntity>>();
            objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objdata.TenantName, objdata.AppID);
            objdataeleentlist = objAudotmatedAuditdataaccess.GetDataElement(objdata.RecordId);
            return objdataeleentlist;
        }

        //public List<DataelementAutomatedAuditEntity> AutoAuditFindingData(DataelementAutomatedAuditEntity objdata)
        //{
        //    List<DataelementAutomatedAuditEntity> objdataeleentlist = new List<DataelementAutomatedAuditEntity>();
        //    objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objdata.TenantName, objdata.AppID);
        //    objdataeleentlist = objAudotmatedAuditdataaccess.GetAutoAuditFindingData(objdata.RecordId);            
        //    return objdataeleentlist;
        //}

        public int InsertintoAuditFindingData(List<ServiceOutput> objservoutlist)
        {
            int result = 0;
            //  foreach (var a in objservoutlist)
            objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objservoutlist[0].TenantName, objservoutlist[0].AppID);
            result = objAudotmatedAuditdataaccess.SetAutoAuditedElement(objservoutlist);
            return result;
        }

        public int InsertintoAuditFindingDataStatus(ServiceOutput objservoutlist)
        {
            int result = 0;
            //  foreach (var a in objservoutlist)
            objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objservoutlist.TenantName, objservoutlist.AppID);
            result = objAudotmatedAuditdataaccess.SetAutoAuditedElementStatus(objservoutlist);
            return result;
        }

        public List<ServiceOutput> RubberBandingFeature(DataelementAutomatedAuditEntity objdata)
        {
            List<ServiceOutput> result = new List<ServiceOutput>();
            try
            {
                objAudotmatedAuditdataaccess = new AudotmatedAuditDataAccess(objdata.TenantName, objdata.AppID);
                result = objAudotmatedAuditdataaccess.GetToAutomateAuditImageData(objdata.RecordId);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }



    }
}
