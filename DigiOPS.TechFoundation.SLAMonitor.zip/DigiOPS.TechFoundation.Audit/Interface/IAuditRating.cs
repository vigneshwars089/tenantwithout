﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Audit
{
    public interface IAuditRating
    {
        string SetAuditRating(RatingEntity objrating);
        List<RatingEntity> GetAuditRating(RatingEntity objratingentity);

        string SetAuditRatingGroup(RatingGroupEntity objratinggrp);
        List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp);
        List<RatingEntity> GetRatingList(RatingEntity objratingentity);
    
    }
}
