﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.Audit
{
    public interface IAuditDetails
    {
        List<List<AuditDetailsEntity>> GetAuditDetails(AuditDetailsEntity objauddet);
        List<SubDefectDetailsEntity> GetRCList(SubDefectDetailsEntity objsubdo);
        AuditDOEntity GetAuditDeleteStatus(AuditDOEntity objauditdo);
        bool IsAttachmentRequired(AuditDOEntity objauditdo);
        AuditDOEntity GetQCStatus(AuditDOEntity objauditdo);
        string SetAuditDetails(AuditDOEntity objauditdo);
    }
}
