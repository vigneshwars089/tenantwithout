﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :ManualAuditRating.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :ManualAuditRating
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to configure AuditRating .
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public class ManualAuditRating : BaseAuditCheckItem
    {
        RatingDataAccess ratingdao = new RatingDataAccess();  
        string result = string.Empty;
      
        public override string SetAuditRating(RatingEntity objrating)
        {
          //  ratingdao = new RatingDataAccess(objrating.TenantName, objrating.AppID);
            return ratingdao.SetAuditRating(objrating);

        }
        public override string SetAuditRatingandGroup(AuditRatingInfo AuditRatingInfo)
        {
           // ratingdao = new RatingDataAccess(AuditRatingInfo.TenantName, AuditRatingInfo.AppID);
            return ratingdao.SetRatings(AuditRatingInfo);

        }
        public override string SetAuditRatingGroup(RatingGroupEntity objratgrp)
        {
           // ratingdao = new RatingDataAccess(objratgrp.TenantName, objratgrp.AppID);
            return ratingdao.SetAuditRatingGroup(objratgrp);

        }

        public override List<RatingEntity> GetAuditRating(RatingEntity objratingentity)
        {
           // ratingdao = new RatingDataAccess(objratingentity.TenantName, objratingentity.AppID);
            return ratingdao.GetAuditRating(objratingentity);

        }

        public override List<RatingGroupEntity> GetAuditRatingGroup(RatingGroupEntity objratinggrp)
        {
           // ratingdao = new RatingDataAccess(objratinggrp.TenantName, objratinggrp.AppID);
            return ratingdao.GetAuditRatingGroup(objratinggrp);

        }

        public override List<RatingEntity> GetRatingList(RatingEntity objratingentity)
        {
           // ratingdao = new RatingDataAccess(objratingentity.TenantName, objratingentity.AppID);
            return ratingdao.GetRatingList(objratingentity);

        }


    }
}
