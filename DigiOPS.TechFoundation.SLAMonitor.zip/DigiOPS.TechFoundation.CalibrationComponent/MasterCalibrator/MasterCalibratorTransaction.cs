﻿using DigiOPS.TechFoundation.Calibration.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Xml.Serialization;

namespace DigiOPS.TechFoundation.Calibration
{
 
    public class MasterCalibratorTransaction : IMasterCalibratorAllocation
    { 
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        List<TransactionListViewModalList> baseList = null;
        List<MasterCalibratorEntity> MapList = null;
        string createRecVal = string.Empty;
       // WorkBucketDAO wdao = new WorkBucketDAO();
        MasterCalibratorAllocationDAO mcdao = new MasterCalibratorAllocationDAO();
        DataSet ds = new DataSet();
        DataTable dt=new DataTable();
        //public List<TransactionListViewModalList> GetTransactionList(SearchElementConfigViewModel objBase)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    SearchElementConfigViewModel objSearchElement = new SearchElementConfigViewModel();
        //    List<SearchElementConfigViewModel> objSearchList = new List<SearchElementConfigViewModel>();

        //    BaseTransportEntity bs = new BaseTransportEntity();

        //    objSearchElement = (SearchElementConfigViewModel)objBase;
        //    objSearchList.Add(objSearchElement);

        //    sb.Append("<root>");

        //    foreach (SearchElementConfigViewModel item in objSearchList)
        //    {
        //        sb.Append(item.ToXml());
        //    }
        //    sb.Append("</root>");
        //    ds = mcdao.GetSearchTransactionList(objBase, sb.ToString());
        //    if (ds.Tables.Count != 0)
        //    {
        //        if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
        //        {
        //            if (ds.Tables[0].Rows.Count <= 0)
        //                return baseList;
        //            else
        //                baseList = MapToSearchTransactionList(ds);
                    
        //            //baseList = tcmap.MapToSearchTransactionList(ds);
        //        }

        //    }
        //    return baseList;
        //}
        //public List<TransactionListViewModalList> MapToSearchTransactionList(DataSet ds)
        //{

        //    proxyLogger.Log.Info(" Transaction List to Entity List - Calling.");
        //    objloginfo.Message = ("Transaction List to Entity List - Calling.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    string ciphertext;//= System.Configuration.ConfigurationManager.AppSettings["CIPHERPASSWORD"];
        //    List<TransactionListViewModalList> baseEntityList = new List<TransactionListViewModalList>();
        //    TransactionListViewModalList transactionList = new TransactionListViewModalList();

        //    int columncnt = ds.Tables[0].Columns.Count;
        //    bool flag = false;
        //    int i;
        //    TransactionListViewModal transaction = new TransactionListViewModal();
        //    string type = "";
        //    foreach (DataRow dr in (ds.Tables[0].Rows))
        //    {
        //        i = 0;
        //        foreach (DataColumn dc in ds.Tables[0].Columns)
        //        {
        //            type = (dc.DataType).FullName;

        //            if (dc.ColumnName == "TotalRows")
        //            {
        //                if (!flag)
        //                {
        //                    transaction.TotalRows = Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i]);
        //                    flag = true;
        //                }
        //            }
        //            else
        //            {
        //                switch (type)
        //                {
        //                    case "System.Int32":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt32(dr[i] == DBNull.Value ? 0 : dr[i])));
        //                        break;
        //                    case "System.Int64":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt64(dr[i] == DBNull.Value ? 0 : dr[i])));
        //                        break;
        //                    case "System.Int16":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToInt16(dr[i] == DBNull.Value ? 0 : dr[i])));
        //                        break;
        //                    case "System.String":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
        //                        break;
        //                    case "System.Object":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToString(dr[i] == DBNull.Value ? string.Empty : dr[i])));
        //                        break;
        //                    case "System.DateTime":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToDateTime(dr[i] == DBNull.Value ? null : dr[i].ToString())));
        //                        break;
        //                    case "System.smalldatetime":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToDateTime(dr[i] == DBNull.Value ? null : dr[i].ToString())));
        //                        break;
        //                    case "System.DateTimeOffset":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, (dr[i] == DBNull.Value ? string.Empty : DateTimeOffset.Parse(dr[i].ToString()).DateTime.ToString())));
        //                        break;
        //                    case "System.Bit":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToBoolean(dr[i] == DBNull.Value ? false : dr[i])));
        //                        break;
        //                    case "System.Decimal":
        //                        transaction.TransactionList.Add(new TransactionList(dc.ColumnName, Convert.ToDecimal(dr[i] == DBNull.Value ? 0 : dr[i])));
        //                        break;
        //                    default:
        //                        proxyLogger.Log.Info("Unable to map the datatype (" + type + ") to list in Quart.BusinessObjects.Mapper.TransactionCreationMapper.MapToSearchTransactionList.");
        //                        objloginfo.Message = ("Unable to map the datatype (" + type + ") to list in Quart.BusinessObjects.Mapper.TransactionCreationMapper.MapToSearchTransactionList.");
        //                        objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //                        break;
        //                }
        //            }
        //            i = i + 1;
        //        }
        //        transactionList.TransactionLists.Add(transaction);
        //    }
        //    baseEntityList = transactionList.TransactionLists.ToList();
        //    TransactionListViewModalList list = new TransactionListViewModalList();
        //    List<TransactionListViewModal> model = new List<TransactionListViewModal>();
        //    model.Add(transaction);
        //    list.TransactionLists = model;
        //    baseEntityList.Add(list);
        //    proxyLogger.Log.Info(" Transaction List to Entity List - Called.");
        //    objloginfo.Message = ("Transaction List to Entity List - Calling.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    return baseEntityList;
        //}

       // public List<MasterCalibratorEntity> MapCalibrators(MasterCalibratorEntity objbasetrans)
       //{
       //     ds = mcdao.GetCalibratorsColl(objbasetrans);
       //     if (ds.Tables.Count != 0)
       //     {
       //         if (ds.Tables.Count > 0)//(ds.Tables[0] != null)
       //         {
       //             if (ds.Tables[0].Rows.Count <= 0)
       //                 return MapList;
       //             else
       //                 MapList = MapToCheckBoxList(ds);
       //          }
       //     }
       //     return MapList;
       // }

        public List<MasterCalibratorEntity> MapCalibrators(MasterCalibratorEntity objbasetrans)
        {
            CalibratorDataAccess cd = new CalibratorDataAccess();
            MapList = cd.MaptoCalibrator(objbasetrans);

            return MapList;
        }
        public string SubmitCalibrators(MasterCalibratorEntity objMasterCalibrator)
        {
            CalibratorDataAccess cd = new CalibratorDataAccess();
           // objMasterCalibrator = cd.SubmitCalibrators(objMasterCalibrator);
            createRecVal = cd.SubmitCalibrators(objMasterCalibrator);
            //return objMasterCalibrator;
            return createRecVal;
        }
       // public List<TransactionListViewModalList> GetTransactionList(SearchElementConfigViewModel objBase)
       // {
       //     CalibratorDataAccess cd = new CalibratorDataAccess();
       //     baseList = cd.GetTransactionList(objBase);
       //     return baseList;
       //}

       // public List<MasterCalibratorEntity> MapToCheckBoxList(DataSet ds)
       // {
       //     DataTable dt = ds.Tables[0];
       //     List<MasterCalibratorEntity> EntityList = new List<MasterCalibratorEntity>();
       //     EntityList = (from p in dt.AsEnumerable()
       //                   select new MasterCalibratorEntity//DigiOPS.TechFoundation.Entities.Calibration.CheckBoxList as 
       //                   {
       //                       Value = Convert.ToString(p["iSystemUserId"] == DBNull.Value ? string.Empty : p["iSystemUserId"]),
       //                       Text = Convert.ToString(p["Calibrator"] == DBNull.Value ? string.Empty : p["Calibrator"]),
       //                       //IsSelected = Convert.ToBoolean(p[2] == DBNull.Value ? string.Empty : p[2])
       //                   }).Cast<MasterCalibratorEntity>().ToList();

       //     return EntityList;
       // }

       // public MasterCalibratorEntity SubmitCalibrators(MasterCalibratorEntity objMasterCalibrator)
       // {
       //     createRecVal = mcdao.CalibratorMapping(objMasterCalibrator);
       //     return objMasterCalibrator;
       // }
      //public List<TransactionListViewModalList> GetTrasnsactionList(SearchElementConfigViewModel objBase)
        //{
        //    throw new NotImplementedException();
        //}

        public List<TransactionListViewModalList> GetTrasnsactionList(SearchElementConfigViewModel objBase)
        {
            CalibratorDataAccess cd = new CalibratorDataAccess();
             baseList = cd.GetTransactionList(objBase);
              return baseList;
        }
    }
}
