﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Calibration.Interface
{
   public interface IMasterCalibratorAllocation
    {
       List<TransactionListViewModalList> GetTrasnsactionList(SearchElementConfigViewModel objBase);

       List<MasterCalibratorEntity> MapCalibrators(MasterCalibratorEntity objbasetrans);

       string SubmitCalibrators(MasterCalibratorEntity objMasterCalibrator);
   }
}
