﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public interface IBaseCaseProcessing
    {
        CaseInfo LoadCase(EMailInfo objcaseInfo);
         bool ProcessCase(EMailInfo objcaseInfo);
    }
}
