﻿using DigiOPS.TechFoundation.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using System.Web;
using System.Globalization;
using System.Collections;
using System.Configuration;
using DigiOPS.TechFoundation.Security;
using Microsoft.Exchange.WebServices.Data;
using System.Security;
using System.Runtime.InteropServices;
using DigiOPS.TechFoundation.CaseProcessing;
using DigiOPS.TechFoundation.Logging;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public class EmailCaseProcessing : BaseCaseProcessing
    {
        public const string WorkQueuePage = "WorkQueue";
        public const string QCWorkQueuePage = "QCWorkQueue";
        public const string SearchPage = "Search";
        public const string FileSent = "File Sent";
        public const string FileReceived = "File Received";
        public const string Unauthorized = "The request failed. The remote server returned an error: (401) Unauthorized.";
        public const string NotFoundinStore = "The specified folder could not be found in the store.";
        CaseProcessingDAO casedao = null;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public enum EmailBoxType
        {
            LoginEmail=1,
            EmailBox=2
        }

        public override CaseInfo LoadCase(EMailInfo objcaseInfo)
        {
            casedao = new CaseProcessingDAO(objcaseInfo.TenantName, objcaseInfo.AppID);
            CaseInfo objCI = new CaseInfo();
            EMailDetails objEI = new EMailDetails();
            List<AttachmentInfo> lstAtt=new List<AttachmentInfo>();
            List<CommentsInfo> lstComments = new List<CommentsInfo>();
            List<TraversalInfo> lstTraversal=new List<TraversalInfo>();
            string ID = objcaseInfo.caseID;

            if (!String.IsNullOrEmpty(ID)&& (ID !="0"))
            {
                try
                {

                    DataSet ds = casedao.LoadCase(ID);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        objCI.CaseID = ds.Tables[0].Rows[0]["CASEID"].ToString();
                        objEI.EMailRecivedDate = ds.Tables[0].Rows[0]["EMAILRECEIVEDDATE"].ToString();
                        objEI.EMailFrom = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                        //objEI.EMailTo = ds.Tables[0].Rows[0]["EMailTo"].ToString();
                        objEI.EMailCc = ds.Tables[0].Rows[0]["EMailCc"].ToString();
                        //objEI.EMailBcc = ds.Tables[0].Rows[0]["EMailBcc"].ToString();
                        objEI.Subject = ds.Tables[0].Rows[0]["Subject"].ToString();
                        objEI.IsUrgent = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsUrgent"].ToString());
                        objEI.EMailBody = ds.Tables[0].Rows[0]["EMailBody"].ToString();
                        objEI.IsManual = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsManual"].ToString());
                        objEI.EMailType = ds.Tables[0].Rows[0]["EMailType"].ToString();
                        objCI.EmailInformation = objEI;

                    }

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            AttachmentInfo objAtt = new AttachmentInfo();
                            objAtt.AttachmentId = Convert.ToInt32(dr["ATTACHMENTID"]);
                            objAtt.FileName = dr["FileName"].ToString();
                            objAtt.FileContent = (byte[])dr["Content"];
                            objAtt.AttachmentType = dr["ATTACHMENTTYPE"].ToString();
                            objAtt.CreatedDate = DateTime.Parse(dr["CREATEDDATE"].ToString());
                            lstAtt.Add(objAtt);
                        }
                        objCI.Attachments = lstAtt;
                    }

                    if (ds.Tables[2].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                        {
                            TraversalInfo objTraversal = new TraversalInfo();


                            //tdToDate.InnerHtml = value.Tables[0].Rows[i]["EndTime"].ToString();
                            //DateTime dateEnded = Convert.ToDateTime(value.Tables[0].Rows[i]["EndTime"].ToString());


                            objTraversal.FromStatus = ds.Tables[2].Rows[i]["FromStatus"].ToString();
                            objTraversal.ToStatus = ds.Tables[2].Rows[i]["ToStatus"].ToString();
                            objTraversal.UserName = ds.Tables[2].Rows[i]["UserName"].ToString();
                            DateTime? dateStarted = null;
                            if (ds.Tables[2].Rows[i]["StartTime"].ToString() != "-")
                            {
                                dateStarted = DateTime.ParseExact(ds.Tables[2].Rows[i]["StartTime"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                            }
                            objTraversal.StartTime = dateStarted;
                            objTraversal.EndTime = DateTime.ParseExact(ds.Tables[2].Rows[i]["EndTime"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                            lstTraversal.Add(objTraversal);
                        }
                        objCI.Traversal = lstTraversal;
                    }

                    if (ds.Tables[3].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[3].Rows.Count; i++)
                        {
                            CommentsInfo objComments = new CommentsInfo();
                            objComments.Comments = ds.Tables[3].Rows[i]["COMMENTS"].ToString();
                            objComments.UserName = ds.Tables[3].Rows[i]["USERNAME"].ToString();
                            objComments.CreatedDate = DateTime.ParseExact(ds.Tables[3].Rows[i]["CREATEDDATE"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                            lstComments.Add(objComments);
                        }
                        objCI.Comments = lstComments;
                    }
                    return objCI;
                }

                catch(Exception ex)
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                    throw;
                }
            }
            else
            {
                objCI.ErrorMessage = new StringBuilder();
                objCI.ErrorMessage.Append("ID cannot be null or empty");
                return objCI;
            }

        }

        public override bool ProcessCase(EMailInfo objcaseInfo)
        {
            casedao = new CaseProcessingDAO(objcaseInfo.TenantName, objcaseInfo.AppID);
            //string cipher = System.Configuration.ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            //IList FollowAttachment = null;
            //CryptInfo cryptInfo = new CryptInfo();
            //SecurityFactory securityFactory = new SecurityFactory();
            //securestring sec_strpassword = new securestring();
            //EmailInput input = new EmailInput();
            //string encryptedValue;
            bool isSuccess;
            try
            {
                //Create an object to ExchangeService
                ExchangeService objService;

                if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2013_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2007_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                }
                else if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2010")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010);
                }
                else if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2010_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                }
                else if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2010_SP2")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                }
                else if (System.Configuration.ConfigurationManager.AppSettings.Get("ClientExVersion") == "Exchange2013")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013);
                }
                else
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                //Create an object to EMailBox which we need to send emails
                Mailbox objCommonMailBox = new Mailbox(objcaseInfo.EMailBoxId);
                //Create an object to Drafte folder
                FolderId objDraftsFolder = new FolderId(WellKnownFolderName.Drafts, objCommonMailBox);
                //Create an object to Sentitems folder
                FolderId objSentItemsFolder = new FolderId(WellKnownFolderName.SentItems, objCommonMailBox);


                if (System.Configuration.ConfigurationManager.AppSettings.Get("Domian").ToString() != "")
                    objService.Credentials = new WebCredentials(objcaseInfo.LoginEMailId, objcaseInfo.password.ToString(), System.Configuration.ConfigurationManager.AppSettings.Get("Domian").ToString());
                else
                    objService.Credentials = new WebCredentials(objcaseInfo.LoginEMailId, objcaseInfo.password.ToString());

                objService.Url = new Uri(objcaseInfo.strpath); //Assign Service URL
                objService.UseDefaultCredentials = false;
                //create an object for EmailMessage with Exchangeservice object
                EmailMessage objMessage = new EmailMessage(objService);
                //DataTable dtVIP = GetVIPUsers();

                objMessage.From = objcaseInfo.EMailBoxId;
                //Add the recipients in the TO list

                if (objcaseInfo.toadd != string.Empty)
                {
                    string[] names = objcaseInfo.toadd.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            names[len] = names[len].Replace(';', ' ').Trim();
                            List<string> lstUserList = new List<string>();

                            if (len == 0)
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
                else
                {
                    objcaseInfo.ErrorMessage = new StringBuilder();
                    objcaseInfo.ErrorMessage.Append("To Address cannot be null or empty");
                }
                //Add the recipients in the CC list
                if (objcaseInfo.ccaddress != string.Empty)
                {
                    string[] names = objcaseInfo.ccaddress.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {

                            names[len] = names[len].Replace(';', ' ').Trim();

                            List<string> lstUserList = new List<string>();

                            if (len == 0)
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
             

                if (objcaseInfo.Priority == true)
                {
                    objMessage.Importance = Importance.High;
                }
                else
                {
                    objMessage.Importance = Importance.Normal;
                }
                //Inline Attachments
                if (objcaseInfo.EmbImageList.Count > 0)
                {
                    int maxno = casedao.GetMaxNoScreenshotCaseId(Convert.ToInt64(objcaseInfo.caseID));
                    for (int i = 0; i < objcaseInfo.EmbImageList.Count; i++)
                    {
                        byte[] imgbyte = Convert.FromBase64String(objcaseInfo.EmbImageList[i].ToString().Replace(" ", "+").ToString());
                        string Name = "";
                        if (maxno > 99)
                            Name = "image" + maxno + ".png";
                        else if (maxno >= 10 && maxno <= 99)
                            Name = "image0" + maxno + ".png";
                        else
                            Name = "image00" + maxno + ".png";
                        FileAttachment attachment = objMessage.Attachments.AddFileAttachment(Name, imgbyte);
                        //if (!ExVersion2007orNot)
                        attachment.IsInline = true;
                        attachment.ContentType = "PNG";
                        attachment.ContentId = Name;
                        //Body = Body.Replace("data:image/png;base64," + EmbedImgs[i].ToString(), "cid:Screenshot" + maxno + ".png");
                        maxno = maxno + 1;
                    }
                }

                objMessage.Subject = objcaseInfo.spSubject;
                objMessage.Body = objcaseInfo.spMessage; //EMail Body
                objMessage.Body.BodyType = BodyType.HTML;

                long totSize = 0;

                //Add Attachments to the EMail
                if (objcaseInfo.AttachmentList.Count>0)
                {
                    foreach (AttachmentFile at in objcaseInfo.AttachmentList)
                    {
                        if (at.FileName.Contains("cid:image") && at.FileName.Contains(".png"))
                        {
                            FileAttachment attachment = objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                            //if (!ExVersion2007orNot) 
                            attachment.IsInline = true;

                            attachment.ContentType = "PNG";
                            attachment.ContentId = at.FileName.Replace("cid:", "");
                        }
                        else
                            objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                    }
                }

                objMessage.Save(objDraftsFolder); //Save the message in drafts folder - to fix the attachment opening issue
                objMessage.SendAndSaveCopy(objSentItemsFolder); // Save the messgae in sentitems folder and send
                string plainbody = Regex.Replace(objcaseInfo.spMessage, @"<(.|\n)*?>", string.Empty);
                plainbody = plainbody.Replace("&nbsp;", "");
                isSuccess = true;
                if (isSuccess)
                {

                    casedao.InsertEMailDetails(Convert.ToInt64(objcaseInfo.caseID), objcaseInfo.toadd, objcaseInfo.ccaddress, objcaseInfo.spSubject, objcaseInfo.spMessage,
                        Convert.ToInt32(objcaseInfo.eMailType), Convert.ToDateTime(DateTime.UtcNow), isSuccess, plainbody, Convert.ToInt32(objcaseInfo.Priority), objcaseInfo.isVIP);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == Unauthorized)
                {
                    casedao.LockEmail((int)EmailBoxType.LoginEmail, objcaseInfo.LoginEMailId);
                    objloginfo.Message = "Mail sent failure! Sub: " + objcaseInfo.spSubject + ". Mailbox: " + objcaseInfo.EMailBoxId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == NotFoundinStore)
                {
                    casedao.LockEmail((int)EmailBoxType.EmailBox, objcaseInfo.LoginEMailId);
                    objloginfo.Message = "Mail sent failure! Sub: " + objcaseInfo.spSubject + ". Mailbox: " + objcaseInfo.EMailBoxId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == "The message exceeds the maximum supported size.")
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                  
                }
                else
                {
                    objloginfo.Message = "Mail sent failure! Sub: " + objcaseInfo.spSubject + ". Mailbox: " + objcaseInfo.EMailBoxId + " Locked.";
                    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                    
                    //uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                isSuccess = false;
            }
            
            //Create an object to ExchangeService
            return isSuccess;
        }

        private string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

      

      

      
        
    }
    
}
