﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.CaseProcessing
{
    public abstract class BaseCaseProcessing : IBaseCaseProcessing
    {
        public virtual CaseInfo LoadCase(EMailInfo objcaseInfo)
        {
            return null;
        }

        public virtual bool ProcessCase(EMailInfo objcaseInfo)
        {
            return false;
        }
    }
}
