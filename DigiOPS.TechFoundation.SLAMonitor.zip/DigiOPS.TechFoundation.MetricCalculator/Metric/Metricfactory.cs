﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
   public class Metricfactory:IMetricfactory
    {
       public IMetric GetMetrics(string MetricType)
        {
            IMetric met = null;
            switch (MetricType)
            { case "Utilization":
                     met = new BaseUtilizationMetric();
                    break;
            case "Availability":
                    met = new AvailabilityMetric();
                    break;
            }
            return met;
        }
    }
}
