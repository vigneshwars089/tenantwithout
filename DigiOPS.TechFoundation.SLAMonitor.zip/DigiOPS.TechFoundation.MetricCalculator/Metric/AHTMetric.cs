﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class AHTMetric : BaseMetric
    {
        
        public AHTMetric(string strformula) : base()
        {
            base.formula = "AHT";
            metricName = MetricTypes.Average_Handling_Time;
            ///
            formula = "TotalTasks_CompletionTime/TaskCount_inQueue";
            metricParameters.Add("TotalTasks_CompletionTime");
            metricParameters.Add(ConstMathfunction.Divide);
            metricParameters.Add("TaskCount_inQueue");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
            bool isExist = DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters = metricParameters;

            if (isExist)
            {
                MetricParamMappingInfo TotalTasks_CompletionTime = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "TotalTasks_CompletionTime");
                if (TotalTasks_CompletionTime.MetricParamFields.Count == 1)
                {
                    nominator = TotalTasks_CompletionTime.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = TotalTasks_CompletionTime.MetricParamFields[0].ParameterFieldValue;

                }
                MetricParamMappingInfo TaskCount_inQueue = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "TaskCount_inQueue");

                if (TaskCount_inQueue.MetricParamFields.Count == 1)
                {
                    denominator = TaskCount_inQueue.MetricParamFields[0].ParameterFieldValue;
                }

                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                return outputmethod(operand, nominator, denominator);
            }
            return 0.0;
        }
    }
}

