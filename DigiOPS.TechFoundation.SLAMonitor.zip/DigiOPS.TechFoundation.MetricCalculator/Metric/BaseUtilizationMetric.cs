﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
   public class BaseUtilizationMetric : BaseMetric
   {
      
        public BaseUtilizationMetric() : base()
        {
            metricName = MetricTypes.Utilization;
            formula = "Actuals/Targeted";
            metricParameters.Add("Actuals");
            metricParameters.Add(ConstMathfunction.Divide);
            metricParameters.Add("Targeted");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
           bool isExist= DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters= metricParameters;
            
  if (isExist)
            {
                MetricParamMappingInfo Actuals = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "Actuals");
                if (Actuals.MetricParamFields.Count == 1)
                {
                    nominator = Actuals.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = Actuals.MetricParamFields[0].ParameterFieldValue;
                   
                }
                MetricParamMappingInfo Targeted = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "Targeted");

                if (Targeted.MetricParamFields.Count == 1)
                {
                    denominator = Targeted.MetricParamFields[0].ParameterFieldValue;
                }
                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                return outputmethod(operand, nominator, denominator);
         
            }

            

            return 0.0;
        }
    }
}
