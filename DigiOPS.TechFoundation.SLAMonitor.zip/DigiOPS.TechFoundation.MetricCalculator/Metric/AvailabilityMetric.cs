﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class AvailabilityMetric : BaseMetric
    {
        

        public AvailabilityMetric() : base()
        {
            metricName = MetricTypes.Availability;

            formula = "SumofActualProductiveHrs/StdWorkingHrs";
            metricParameters.Add("SumofActualProductiveHrs");
            metricParameters.Add(ConstMathfunction.Divide);
            metricParameters.Add("StdWorkingHrs");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
            AvailabilityMetric availmetric = new AvailabilityMetric();
            bool isExist = DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters = metricParameters;

            if (isExist)
            {
                MetricParamMappingInfo SumofActualProductiveHrs = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "SumofActualProductiveHrs");
                if (SumofActualProductiveHrs.MetricParamFields.Count == 1)
                {
                    nominator = SumofActualProductiveHrs.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = SumofActualProductiveHrs.MetricParamFields[0].ParameterFieldValue;

                }
                MetricParamMappingInfo StdWorkingHrs = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "StdWorkingHrs");

                if (StdWorkingHrs.MetricParamFields.Count == 1)
                {
                    denominator = StdWorkingHrs.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    denominator = availmetric.ReplaceFormula(StdWorkingHrs, StdWorkingHrs.ParamfieldFormula);
                }
                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                return outputmethod(operand,nominator,denominator);

            }



            return 0.0;
        }

      

    }
}
