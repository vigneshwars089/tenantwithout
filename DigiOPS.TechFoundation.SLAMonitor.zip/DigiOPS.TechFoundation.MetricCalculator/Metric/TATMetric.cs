﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator.Metric
{
    public class TATMetric :BaseMetric
    {
        public TATMetric() : base()
        {
            metricName = MetricTypes.Turn_Around_Time;
            formula = "CaseCompletionTime-CaseIntakeTime";
            metricParameters.Add("CaseCompletionTime");
            metricParameters.Add(ConstMathfunction.Minus);
            metricParameters.Add("CaseIntakeTime");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
            bool isExist = DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters = metricParameters;

            if (isExist)
            {
                MetricParamMappingInfo CaseCompletionTime = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "CaseCompletionTime");
                if (CaseCompletionTime.MetricParamFields.Count == 1)
                {
                    nominator = CaseCompletionTime.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = CaseCompletionTime.MetricParamFields[0].ParameterFieldValue;

                }
                MetricParamMappingInfo CaseIntakeTime = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "CaseIntakeTime");

                if (CaseIntakeTime.MetricParamFields.Count == 1)
                {
                    denominator = CaseIntakeTime.MetricParamFields[0].ParameterFieldValue;
                }

                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                return outputmethod(operand, nominator, denominator);
            }



            return 0.0;
        }

    }
}
