﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator.Metric
{
    public class ProductivityMetric : BaseMetric
    {
       

        public ProductivityMetric() : base()
        {
            metricName = MetricTypes.Accuracy;
            formula = "CountofCaseCompleted-SumofProductiveHrs";
            metricParameters.Add("CountofCaseCompleted");
            metricParameters.Add(ConstMathfunction.Minus);
            metricParameters.Add("SumofProductiveHrs");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
            bool isExist = DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters = metricParameters;

            if (isExist)
            {
                MetricParamMappingInfo CountofCaseCompleted = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "CountofCaseCompleted");
                if (CountofCaseCompleted.MetricParamFields.Count == 1)
                {
                    nominator = CountofCaseCompleted.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = CountofCaseCompleted.MetricParamFields[0].ParameterFieldValue;

                }
                MetricParamMappingInfo SumofProductiveHrs = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "SumofProductiveHrs");

                if (SumofProductiveHrs.MetricParamFields.Count == 1)
                {
                    denominator = SumofProductiveHrs.MetricParamFields[0].ParameterFieldValue;
                }

                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                return outputmethod(operand, nominator, denominator);
            }



            return 0.0;
        }

    }
}
