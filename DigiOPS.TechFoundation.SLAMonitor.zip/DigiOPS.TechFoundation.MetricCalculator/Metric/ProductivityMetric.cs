﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator.Metric
{
    public class AccuracyMetric :BaseMetric
    {
        public AccuracyMetric() : base()
        {
            metricName = MetricTypes.Turn_Around_Time;
            formula = "Defects-SampledCaseInventory";
            metricParameters.Add("Defects");
            metricParameters.Add(ConstMathfunction.Divide);
            metricParameters.Add("SampledCaseInventory");
        }

        public override object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
            bool isExist = DoMetricFieldExistsNTransaction(formulaMapinfo, transactionifno);
            double nominator = 0.0;
            double denominator = 0;

            formulaMapinfo.Formula = formula;
            formulaMapinfo.MetricName = metricName;
            formulaMapinfo.MetricParameters = metricParameters;

            if (isExist)
            {
                MetricParamMappingInfo Defects = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "Defects");
                if (Defects.MetricParamFields.Count == 1)
                {
                    nominator = Defects.MetricParamFields[0].ParameterFieldValue;
                }
                else
                {
                    nominator = Defects.MetricParamFields[0].ParameterFieldValue;

                }
                MetricParamMappingInfo SampledCaseInventory = formulaMapinfo.MetricParamFieldsMappings.Find(x => x.MetricParameterName == "SampledCaseInventory");

                if (SampledCaseInventory.MetricParamFields.Count == 1)
                {
                    denominator = SampledCaseInventory.MetricParamFields[0].ParameterFieldValue;
                }
                string operand = formulaMapinfo._innerList[1].MetricParameterName;

                double output= outputmethod(operand, nominator, denominator);
                output = outputmethod("*", output, 100);
                return outputmethod("-", 100, output);

            }



            return 0.0;
        }

    }
}
