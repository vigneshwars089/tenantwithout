﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
   public abstract class BaseMetric :IMetric
    {
       public Calculator calc = null;
        public  BaseMetric( )
        {
             calc = new Calculator();
        }

        internal string formula;
        public string Formula
        {
            get { return formula; }
            private set { }
        }


        internal string metricName;
        public  string MetricName
        {
            get { return metricName; }
            private set { }
        }

        internal List<String> metricParameters = new List<string>();
        public List<String> MetricParameters
        {
            get { return metricParameters; }
            private set { }
        }

      

        public ArrayList ConstMathFunctionArr = new ArrayList() { ConstMathfunction.Clear, ConstMathfunction.Divide, ConstMathfunction.Plus, ConstMathfunction.Minus };

        public abstract object Calculate(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno);

        internal object ExecuteFormula(MetricTransactionMappingInfo formulaMapinfo)
        {
           // var keys = formulaMapinfo.MetricParamFieldsMapping.Where(x => someValues.Contains(x.Value)).Select(x => x.Key);

           // if (formulaMapinfo.MetricParamFieldsMappings.ContainsKey(ConstMathfunction.OpenCurve))
          //  {
          //      formulaMapinfo.MetricParamFieldsMappings.Select().Where(x=>x.Key== ConstMathfunction.OpenCurve)

          //  }
           // formulaMapinfo.ConstrustFormulaFields
            return null;
        }

        internal bool DoMetricFieldExistsNTransaction(MetricTransactionMappingInfo formulaMapinfo, ProcessTransactionInfo transactionifno)
        {
         List< System.Reflection.PropertyInfo> propinfo = transactionifno.GetType().GetProperties(BindingFlags.FlattenHierarchy
                | BindingFlags.Public
                | BindingFlags.Instance).ToList();

            //foreach (MetricParamMappingInfo field in formulaMapinfo.MetricParamFieldsMappings)
            //{
            //    foreach (string fieldname in field.MetricParameterName)
            //    {
            //        PropertyInfo prop = propinfo.Find(x => x.Name == fieldname);

            //        if (prop == null)
            //        {
            //            return false;
            //        }
            //        else
            //        {
            //            var value = field.ParameterField[fieldname];
            //        }
            //    }
            //}

            return true;
        }

        public double ReplaceFormula(MetricParamMappingInfo objprocesstrsnts, string Formula)
        {
            double actualshifttime = 0.0;
            BodmasCalculator bodmascalc = new BodmasCalculator();
            string BodmasFormula = Formula;
            char[] formulachars = Formula.ToCharArray();
            char[] operands = new char[formulachars.Count()];
            int i = 0;
            foreach (char a in formulachars)
            {
                if(!Char.IsWhiteSpace(a) && a!=null)
                {
                if (Char.IsLetter(a))
                {
                    operands[i] = a;
                    i++;
                }
                }
            }
            for (int j = 0; j < i; j++)
            {
                BodmasFormula = BodmasFormula.Replace(operands[j].ToString(), objprocesstrsnts.MetricParamFields[j].ParameterFieldValue.ToString());
            }
            //if (objprocesstrsnts.HT != null || objprocesstrsnts.loggedInHrs != null || objprocesstrsnts.ProductiveHRs != null)
            //{               
            //    string replacestring1 = Formula.Replace("x", objprocesstrsnts.HT.ToString());
            //    string replacestring2 = replacestring1.Replace("y", objprocesstrsnts.loggedInHrs.ToString());
            //    string replacestring3 = replacestring2.Replace("z", objprocesstrsnts.ProductiveHRs.ToString());

            //    actualshifttime = bodmascalc.Bodmascalculation(replacestring3);
            //}
            actualshifttime = bodmascalc.Bodmascalculation(BodmasFormula);
            return actualshifttime;
        }

        public double outputmethod(string operand, double input1, double input2)
        {
            double output = 0.0;
            switch (operand)
            {
                case "+":
                    output = Convert.ToDouble(calc.Add(input1, input2));
                    break;
                case "-":
                    output = Convert.ToDouble(calc.Subtract(input1, input2));
                    break;
                case "*":
                    output = Convert.ToDouble(calc.Multiply(input1, input2));
                    break;
                case "/":
                    output = Convert.ToDouble(calc.Divide(input1, input2));
                    break;
                default:
                    return 0.0;

            }
            return output;
        }
    }
}
