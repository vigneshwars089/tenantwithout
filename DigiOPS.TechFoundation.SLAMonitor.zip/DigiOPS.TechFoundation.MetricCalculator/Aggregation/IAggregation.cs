﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public interface IAggregation
    {
        object Calculate(MetricDurationRangeInfo rangeInfo, List<ProcessTransactionInfo> transactionifno);
    }
}
