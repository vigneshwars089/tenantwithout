﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class ConditionBasedAggregation : BaseAggregation
    {
        public override object Calculate(MetricDurationRangeInfo rangeInfo, List<ProcessTransactionInfo> transactionifno)
        {
            return null;
        }
    }
}
