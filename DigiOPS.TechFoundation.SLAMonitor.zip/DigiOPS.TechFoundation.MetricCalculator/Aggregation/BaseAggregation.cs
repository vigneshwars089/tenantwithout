﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class BaseAggregation : IAggregation
    {
        Calculator calc = null;
        public BaseAggregation()
        {
             calc = new Calculator();
        }

        public virtual object Calculate(MetricDurationRangeInfo rangeInfo, List<ProcessTransactionInfo> transactionifno)
        {
            throw new NotImplementedException();
        }

        public double outputmethod(string operand, List<object> input1)
        {
            double output = 0.0;
            switch (operand)
            {
               
                case "Summation":
                    output =Convert.ToDouble(calc.Sum(input1));
                    break;
                case "Average":
                    output = Convert.ToDouble(calc.Average(input1));
                    break;
                case "Min":
                    output = Convert.ToDouble(calc.Min(input1));
                    break;
                case "Max":
                    output = Convert.ToDouble(calc.Max(input1));
                    break;

                default:
                    return 0.0;

            }
            return output;
        }
    }
}
