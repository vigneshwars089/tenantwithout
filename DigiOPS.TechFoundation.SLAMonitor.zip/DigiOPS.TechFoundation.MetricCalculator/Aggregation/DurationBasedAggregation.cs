﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class DurationBasedAggregation : BaseAggregation
    {        
        public override object Calculate(MetricDurationRangeInfo rangeInfo, List<ProcessTransactionInfo> transactionifno)
        {
            object output = null;
            if (rangeInfo != null)
            {
                string ProcessInput = rangeInfo.RangeFieldName;
                List<object> inputs = new List<object>();
                string datetobechcecked = string.Empty;
                string ragefield = rangeInfo.RangeFieldName;               
            
                foreach (var a in transactionifno)
                {
                    if(a.ProcessedOn != null)
                    datetobechcecked = a.ProcessedOn;
                }
                DateTime dateToCheck = Convert.ToDateTime(datetobechcecked.ToString());
                if (dateToCheck >= rangeInfo.DurationRange["startdate"] && dateToCheck < rangeInfo.DurationRange["enddate"])
                {
                    //for (int i = 0; i < rangeInfo.RangeFieldValue.Count; i++)
                    //{
                    //    inputs.Add(rangeInfo.RangeFieldValue[i]);
                    //}
                    foreach (var a in transactionifno)
                    {
                        Type objectType = a.GetType();
                        PropertyInfo property = objectType.GetProperty(ragefield);
                        switch (property.Name.ToString())
                        {
                            case "AuxHRs":
                                inputs.Add(a.AuxHRs);
                                break;
                            case "HT":
                                inputs.Add(a.AuxHRs);
                                break;
                            case "ProductiveHRs":
                                inputs.Add(a.ProductiveHRs);
                                break;
                            case "IdleHRs":
                                inputs.Add(a.IdleHRs);
                                break;
                            case "TotalProductiveHRs":
                                inputs.Add(a.TotalProductiveHRs);
                                break;
                            case "loggedInHrs":
                                inputs.Add(a.loggedInHrs);
                                break;

                        }
                    }
                }
                output = outputmethod(rangeInfo.AggregationName, inputs);
                  
            }
            return output;
        }
    }
}
