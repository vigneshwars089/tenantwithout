﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class ProcessTransactionInfo
    {
        public string Processedby { get;  set; }

        public string ProcessedOn { get; set; }

        public int HT { get; set; }

        public int ProductiveHRs { get; set; }
        public int AuxHRs { get; set; }
        public int IdleHRs { get; set; }
        public int TotalProductiveHRs { get; set; }

        public int loggedInHrs { get;  set; }
    }
}
