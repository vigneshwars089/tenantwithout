﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class MetricTransactionMappingInfo: BaseInfo
    {
        public MetricTransactionMappingInfo()
        {
            MetricParameters = new List<string>();       
            _innerList = new List<MetricParamMappingInfo>();
            MetricParamFieldsMappings = new List<MetricParamMappingInfo>();

        }
        public string Formula { get;  set; }

        public string MetricName { get; set; }

        public List<string> MetricParameters { get; set; }
       
      
        internal List<MetricParamMappingInfo> _innerList = new List<MetricParamMappingInfo>();

        public List<MetricParamMappingInfo> MetricParamFieldsMappings

        {
            get { return _innerList; }
            set { _innerList = value; }
        }


    }

    public class MetricParamMappingInfo
    {
        public int Index { get;  set; }

        public string MetricParameterName { get; set; }
        public string ParamfieldFormula { get; set; }

        private List<MetricParamFieldInfo> _innerList = new List<MetricParamFieldInfo>();

        public List<MetricParamFieldInfo> MetricParamFields

        {
            get { return _innerList; }
            set { _innerList = value; }
        }

    }

    public class MetricParamFieldInfo
    {
        public int Index { get; set; }

        public string ParameterFieldName { get; set; }

        public double ParameterFieldValue { get; set; }

   
    }
   


    
}
