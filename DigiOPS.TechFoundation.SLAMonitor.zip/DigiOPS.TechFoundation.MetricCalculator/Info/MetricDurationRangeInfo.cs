﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
   public class MetricDurationRangeInfo : BaseInfo
    {
       public MetricDurationRangeInfo()
       {
           DurationRange = new Dictionary<string, DateTime>();
           AggregationFieldValue = new List<double>();
       }
        /// <summary>
        /// Name of the Range Field -like Idle hrs, Productive hrs
        /// </summary>
        public string RangeFieldName { get; set; }
        public double RangeFieldValue { get; set; }
       /// <summary>
       /// Name of the Aggregation to be looped through in the Process transaction info
       /// </summary>
        public string AggregationName { get; set; }
        public List<double> AggregationFieldValue { get; set; }   

       /// <summary>
       /// Duration range like start date and end date
       /// </summary>
        public Dictionary<string, DateTime> DurationRange { get; set; }


        /// <summary>
        /// Says whether daily,weekly,monthly or yearly
        /// </summary>
        //  public  int DurationRange { get; set; }
      
      

    }
}
