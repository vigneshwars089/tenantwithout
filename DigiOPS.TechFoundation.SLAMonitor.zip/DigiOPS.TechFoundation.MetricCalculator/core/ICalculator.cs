﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public interface ICalculator
    {
       object Add(object A, object B);
        object Subtract(object A, object B);
        object Multiply(object A, object B);
        object Divide(object A, object B);


        object Sum(List<object> A);

        object Sum(object A, string durationRange);
        object Difference(object A, object B);
        object Product(object A, object B);
        object Average(List<object> A);

        object Average(object A,string durationRange);

        object Min(List<object> A);

        object Min(object A, string durationRange);

        object Max(List<object> A);

        object Max(object A, string durationRange);

    }

   
}
