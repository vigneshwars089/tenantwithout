﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public sealed class Calculator : ICalculator
    {

        Double dblAcc;
        Double dblSec;
        bool blnClear, blnFrstOpen;

        public object Add(object A, object B)
        {

            Type datatype = getDataType(A, B);
            double result = Convert.ToDouble(A) + Convert.ToDouble(B);
            return Convert.ChangeType(result, datatype);
            //return null;
        }

        public object Subtract(object A, object B)
        {
            double result = Convert.ToDouble(A) - Convert.ToDouble(B);
            return result;
        }

        public object Multiply(object A, object B)
        {
            double result = Convert.ToDouble(A) * Convert.ToDouble(B);
            return result;
        }

        public object Divide(object A, object B)
        {
            double result = Convert.ToDouble(A) / Convert.ToDouble(B);
            return result;
        }

        public object Sum(List<object> A)
        {
            double result = 0.0;
            for (int i = 0; i < A.Count;i++ )
                result += Convert.ToDouble(A[i]);
            return result;
        }

        public object Difference(object A, object B)
        {
            throw new NotImplementedException();
        }

        public object Product(object A, object B)
        {
            throw new NotImplementedException();
        }

        public object Average(List<object> A)
        {
            Calculator calc = new Calculator();
            double result = 0.0;
            int count = 0;
            for (int i = 0; i < A.Count; i++)
            {
                result += Convert.ToDouble(A[i]);
                count++;
            }
            return calc.Divide(result,count);
        }
        public object Min(List<object> A)
        {
            double result = 0.0;
            double temp = 0.0;
            if (A != null)
            {
                result = Convert.ToDouble(A[0]);
                for (int i = 1; i < A.Count; i++)
                {
                    temp = Convert.ToDouble(A[i]);
                    if (result > temp)
                        result = temp;
                }
            }
            return result;
        }

        public object Max(List<object> A)
        {
            double result = 0.0;
            double temp = 0.0;
            if (A != null)
            {
                result = Convert.ToDouble(A[0]);
                for (int i = 1; i < A.Count; i++)
                {
                    temp = Convert.ToDouble(A[i]);
                    if (result < temp)
                        result = temp;
                }
            }
            return result;
        }

        public object Average(object A, string durationRange)
        {
            return null;
        }

        public object Min(object A, object B)
        {
            throw new NotImplementedException();
        }

        public object Max(object A, object B)
        {
            throw new NotImplementedException();
        }

        public object Sum(object A, string durationRange)
        {
            throw new NotImplementedException();
        }

        public object Min(object A, string durationRange)
        {
            throw new NotImplementedException();
        }

        public object Max(object A, string durationRange)
        {
            throw new NotImplementedException();
        }


        private Type getDataType(object A, object B)
        {
            Type result = null;
            try
            {
                if (A.GetType() == typeof(System.String) || B.GetType() == typeof(System.String))
                    return result;//error

                if (A.GetType() == B.GetType())
                    return result = A.GetType();
                else if (A.ToString().Contains(ConstMathfunction.Dot) || B.ToString().Contains(ConstMathfunction.Dot))
                    return result = typeof(System.Double);
            }
            catch
            {
                return result;
            }
            return result;
        }


        public Dictionary<string,DateTime> getDuration(int durationRange)
        {
            Dictionary<string, DateTime> dateduration = new Dictionary<string, DateTime>();
            dateduration.Add("enddate", DateTime.Today);

            switch (durationRange)
            {
                case DurationRange.Daily:
                    dateduration.Add("startdate", DateTime.Today.AddDays(-DurationRange.Daily));
                    return dateduration;
                case DurationRange.Weekly:
                    dateduration.Add("startdate", DateTime.Today.AddDays(-DurationRange.Weekly));
                    return dateduration;
                case DurationRange.Monthly:
                    dateduration.Add("startdate", DateTime.Today.AddDays(-DurationRange.Monthly));
                    return dateduration;
                case DurationRange.Quarterly:
                    dateduration.Add("startdate", DateTime.Today.AddDays(-DurationRange.Quarterly));
                    return dateduration;
            }
            return dateduration;
        }
    }
}
