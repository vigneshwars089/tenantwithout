﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class Globals //Global Variables
    {
        public static Stack<char> operatorStack = new Stack<char>(); //Operator char stack
        public static Stack<double> operandStack = new Stack<double>(); //Operand double stack
        public static Queue<string> Expression = new Queue<string>(); //Post Expression string queue. I have used a queue to be able to print it in the correct order and traverse it in the correct order (left to right)
    }
}
