﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class BodmasCalculator
    {
        public double Bodmascalculation(string a)
        {

            int i = new int();
            int b = new int();
            double j = new double();
            double result = new double();
            string temp = string.Empty;
            BodmasCalculator P = new BodmasCalculator();
            int flag = new int();
            while (i < a.Length)
            {
                switch (a[i])
                {
                    case '(':
                        Globals.operatorStack.Push(a[i]);
                        break;
                    case '^':
                        if (Globals.operatorStack.Count == 0) //if stack is empty, it should be pushed
                        {
                            Globals.operatorStack.Push(a[i]);
                        }
                        else
                        {
                            if (P.Precedence(a[i]) > P.Precedence(Globals.operatorStack.Peek()))
                            {
                                Globals.operatorStack.Push(a[i]);
                            }
                            else
                            {
                                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
                                Globals.operatorStack.Push(a[i]);
                            }
                        }
                        break;
                    case '*':
                        if (Globals.operatorStack.Count == 0)
                        {
                            Globals.operatorStack.Push(a[i]);
                        }
                        else
                        {
                            if (P.Precedence(a[i]) > P.Precedence(Globals.operatorStack.Peek()))
                            {
                                Globals.operatorStack.Push(a[i]);
                            }
                            else
                            {
                                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
                                Globals.operatorStack.Push(a[i]);
                            }
                        }
                        break;
                    case '/':
                        if (Globals.operatorStack.Count == 0)
                        {
                            Globals.operatorStack.Push(a[i]);
                        }
                        else
                        {
                            if (P.Precedence(a[i]) > P.Precedence(Globals.operatorStack.Peek()))
                            {
                                Globals.operatorStack.Push(a[i]);
                            }
                            else
                            {
                                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
                                Globals.operatorStack.Push(a[i]);
                            }
                        }
                        break;
                    case '+':
                        if (Globals.operatorStack.Count == 0)
                        {
                            Globals.operatorStack.Push(a[i]);
                        }
                        else
                        {
                            if (P.Precedence(a[i]) > P.Precedence(Globals.operatorStack.Peek()))
                            {
                                Globals.operatorStack.Push(a[i]);
                            }
                            else
                            {
                                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
                                Globals.operatorStack.Push(a[i]);
                            }
                        }
                        break;
                    case '-':
                        if (Globals.operatorStack.Count == 0)
                        {
                            Globals.operatorStack.Push(a[i]);
                        }
                        else
                        {
                            if (P.Precedence(a[i]) > P.Precedence(Globals.operatorStack.Peek()))
                            {
                                Globals.operatorStack.Push(a[i]);
                            }
                            else
                            {
                                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
                                Globals.operatorStack.Push(a[i]);
                            }
                        }
                        break;
                    case ')':
                        temp = Globals.operatorStack.Pop().ToString();
                        while (temp != "(")
                        {
                            Globals.Expression.Enqueue(temp.ToString());
                            temp = Globals.operatorStack.Pop().ToString();
                        }
                        break;
                    case ' ': //if user enters a space in between, it should be skipped
                        break;
                    case '.': //this hasn’t been handled as of now, so it is being skipped
                        break;
                    default: //we have a digit
                        string d = string.Empty;
                        MatchCollection col = Regex.Matches(a, "[0-9]+");
                        // bool value=;
                        if (flag < col.Count)//(i < a.Length) //we can have multiple digits and they should be combined to a single number
                        {
                            //if (int.TryParse(a[i].ToString(), out b))
                            {
                                //d += a[i]; i++; 
                                d = col[flag].Value;
                                flag++;
                            }
                            if (d.Length > i)
                                i = d.Length - 1;

                            //else
                            //{
                            //    i++; 
                            //    break;
                            //}

                        }
                        Globals.Expression.Enqueue(d);
                        //  i--;
                        break;
                }
                i++;
            }
            while (Globals.operatorStack.Count != 0) //Add operators remaining in the stack to the expression
            {
                Globals.Expression.Enqueue(Globals.operatorStack.Pop().ToString());
            }

            //Display Postfix Expression
            //Console.WriteLine("Postfix Expression: ");
            //foreach (string c in Globals.Expression)
            //    Console.Write(c + " ");
            //Console.WriteLine();

            //Calculate the result by evaluating the postfix expression
            while (Globals.Expression.Count > 0)
            {
                temp = Globals.Expression.Dequeue();
                switch (temp)
                {
                    case "+":
                        j = Globals.operandStack.Pop();
                        result = Globals.operandStack.Pop() + j;
                        Globals.operandStack.Push(result);
                        break;
                    case "-":
                        j = Globals.operandStack.Pop();
                        result = Globals.operandStack.Pop() - j;
                        Globals.operandStack.Push(result);
                        break;
                    case "*":
                        j = Globals.operandStack.Pop();
                        result = Globals.operandStack.Pop() * j;
                        Globals.operandStack.Push(result);
                        break;
                    case "/":
                        j = Globals.operandStack.Pop();
                        result = Globals.operandStack.Pop() / j;
                        Globals.operandStack.Push(result);
                        break;
                    case "^":
                        j = Globals.operandStack.Pop();
                        result = Math.Pow(Globals.operandStack.Pop(), j);
                        Globals.operandStack.Push(result);
                        break;
                    default: Globals.operandStack.Push(double.Parse(temp));
                        break;
                }
            }
            result = Globals.operandStack.Pop();
            return result;
        }

        public int Precedence(char p)
        {
            switch (p)
            {
                case '+': return 1;
                case '-': return 1;
                case '*': return 2;
                case '/': return 2;
                case '^': return 3;
                default: return 0;
            }
        }
    }
}
