﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    public class Class1
    {
        public static void Main()
        {
            Calculator cal = new Calculator();        
            object result = TestDuration();
        //  object result=   TestUtilization();
          Console.WriteLine(result);
        }

        private static object TestUtilization()
        {

            MetricTransactionMappingInfo formulaMapinfo = new MetricTransactionMappingInfo();
            formulaMapinfo.MetricParamFieldsMappings = new List<MetricParamMappingInfo>();
            ProcessTransactionInfo transactionifno = new ProcessTransactionInfo();
            transactionifno.ProductiveHRs = 6;
            transactionifno.loggedInHrs = 2;
            transactionifno.HT = 2;
            transactionifno.AuxHRs = 2;
            transactionifno.TotalProductiveHRs = 40;
            transactionifno.Processedby = "test";
            transactionifno.ProcessedOn = "test";
            //formulaMapinfo.Formula = "x+y+z";
            MetricParamMappingInfo testobj = new MetricParamMappingInfo();
            testobj.Index = 1;
            testobj.MetricParameterName = "SumofActualProductiveHrs";
            testobj.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            testobj.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "TotalProductiveHRs", ParameterFieldValue = transactionifno.TotalProductiveHRs });

            MetricParamMappingInfo testobj1 = new MetricParamMappingInfo();
            testobj1.Index = 2;
            testobj1.MetricParameterName = ConstMathfunction.Divide;
            testobj1.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            testobj1.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = ConstMathfunction.Divide, ParameterFieldValue = 0 });

            MetricParamMappingInfo testobj2 = new MetricParamMappingInfo();
            testobj2.Index = 3;
            testobj2.MetricParameterName = "StdWorkingHrs";
            testobj2.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            testobj2.ParamfieldFormula = "a+ b+z-q";
            testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "ProdcutiveHRs", ParameterFieldValue = transactionifno.ProductiveHRs });
            testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 2, ParameterFieldName = "AuxTime", ParameterFieldValue = transactionifno.AuxHRs});
            testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 3, ParameterFieldName = "LogTime", ParameterFieldValue = transactionifno.loggedInHrs });
            testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 4, ParameterFieldName = "LogTime", ParameterFieldValue = transactionifno.loggedInHrs });


            formulaMapinfo.MetricParamFieldsMappings.Add(testobj);
            formulaMapinfo.MetricParamFieldsMappings.Add(testobj1);
            formulaMapinfo.MetricParamFieldsMappings.Add(testobj2);
            IMetricfactory obj = new Metricfactory();
            object result = obj.GetMetrics(MetricTypes.Availability).Calculate(formulaMapinfo, transactionifno);
            return result;
           
        }

        private static object TestDuration()
        {
            DurationBasedAggregation drtn=new DurationBasedAggregation();
            List<ProcessTransactionInfo> transactionifnolist = new List<ProcessTransactionInfo>();
            MetricDurationRangeInfo formulaMapinfo = new MetricDurationRangeInfo(); 
          
            ProcessTransactionInfo transactionifno = new ProcessTransactionInfo();          
            transactionifno.ProductiveHRs = 6;          
            transactionifno.loggedInHrs = 2;
            transactionifno.HT = 2;
            transactionifno.AuxHRs = 2;
            transactionifno.TotalProductiveHRs = 40;
            transactionifno.Processedby = "test";
            transactionifno.ProcessedOn = "10/5/2017";
            transactionifnolist.Add(transactionifno);

            ProcessTransactionInfo transactionifno1 = new ProcessTransactionInfo();
            transactionifno1.ProductiveHRs = 6;
            transactionifnolist.Add(transactionifno1);
           // transactionifno1.
            //formulaMapinfo.Formula = "x+y+z";
            //MetricParamMappingInfo testobj = new MetricParamMappingInfo();
            //testobj.Index = 1;
            //testobj.MetricParameterName = "SumofActualProductiveHrs";
            //testobj.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            //testobj.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "TotalProductiveHRs", ParameterFieldValue = transactionifno.TotalProductiveHRs });

            //MetricParamMappingInfo testobj1 = new MetricParamMappingInfo();
            //testobj1.Index = 2;
            //testobj1.MetricParameterName = ConstMathfunction.Divide;
            //testobj1.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            //testobj1.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = ConstMathfunction.Divide, ParameterFieldValue = 0 });

            //MetricParamMappingInfo testobj2 = new MetricParamMappingInfo();
            //testobj2.Index = 3;
            //testobj2.MetricParameterName = "StdWorkingHrs";
            //testobj2.MetricParamFields = new List<MetricCalculator.MetricParamFieldInfo>();
            //testobj2.ParamfieldFormula = "a+ b+z-q";
            //testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 1, ParameterFieldName = "ProdcutiveHRs", ParameterFieldValue = transactionifno.ProductiveHRs });
            //testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 2, ParameterFieldName = "AuxTime", ParameterFieldValue = transactionifno.AuxHRs });
            //testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 3, ParameterFieldName = "LogTime", ParameterFieldValue = transactionifno.loggedInHrs });
            //testobj2.MetricParamFields.Add(new MetricParamFieldInfo() { Index = 4, ParameterFieldName = "LogTime", ParameterFieldValue = transactionifno.loggedInHrs });


            formulaMapinfo.AggregationName = "Summation";
            formulaMapinfo.DurationRange.Add("startdate", DateTime.Today.AddDays(-2));
            formulaMapinfo.DurationRange.Add("enddate", DateTime.Today.AddDays(1));
            formulaMapinfo.RangeFieldName = "ProductiveHRs";  
            IMetricfactory obj = new Metricfactory();
            object result = drtn.Calculate(formulaMapinfo, transactionifnolist);
            return result;

        }
    }
}
