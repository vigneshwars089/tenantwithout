﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricCalculator
{
    class constant
    {
    }

    public struct STDBaseProcessMetrics
    {
       
        /// <summary>
        /// Utilization formula - Actual / Target(STD)
        /// </summary>
        public const string Utilization = "a/b";


        /// <summary>
        /// Average handling time
        /// </summary>
        public const string AHT = "a/b";


        /// <summary>
        /// Turn Around Time 
        /// </summary>
        public const string TAT = "+";


        /// <summary>
        /// Turn Around Time 
        /// </summary>
        public const string Minus = "_";

        public const string Divide = "/";

    }

    public struct ConstMathfunction
    {
        public const string Dot = ".";
        public const string Plus = "+";
        public const string Minus = "_";
        public const string Divide = "/";
        public const string Multiplication = "*";

        public const string Percentage = "%";
        public const string PostiviteNNegate = "+/_";
        public const string OpenCurve = "(";
        public const string EndCurve = ")";
        public const string Equalto = "=";
        public const string Clear = "";
    }

    public struct DurationRange
    {
        /// <summary>
        /// DateTime.Today - 1
        /// </summary>
        public const int Daily = 1;
        public const int Weekly = 7;//DateTime.Today-7
        public const int Monthly = 30;//DateTime.Today-30
        public const int Quarterly = 120;//DateTime.Today-90
        public const int yearly = 365;//DateTime.Today-365
    }

    public struct MetricTypes
    {
        public const string Utilization = "Utilization";
        public const string Average_Handling_Time = "AHT";
        public const string Turn_Around_Time = "TAT";
        public const string Productivity = "Productivity";
        public const string Accuracy = "Accuracy";
        public const string Availability = "Availability";
        public const string Ageing = "Ageing";


    }

    }

