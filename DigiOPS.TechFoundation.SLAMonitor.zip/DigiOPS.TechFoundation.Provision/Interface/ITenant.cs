﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public interface ITenant
    {
        string GetTenantConnectionString(string AppId, int TenantId);
        TenantInfo SaveTenantDetails(TenantInfo ObjTenantInfo);//TenantInfo
        // TenantInfo GetTenantDBInfo(TenantInfo MultiTenancyInfo);
        TenantInfo GenerateDataBase(TenantInfo MultiTenancyInfo);

    }
}
