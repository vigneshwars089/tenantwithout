﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public interface IProvisioning
    {
        string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt);
        List<ProgramFeatureSetUp> GetProgramFeatures(int programId, string AppID, string TenantID);      

    }
}
