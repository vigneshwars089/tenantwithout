﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public class ProgramFeaturesProvision : BaseProvisioning
    {
        ProgramFeaturesDataAccess progda = new ProgramFeaturesDataAccess();
        public override string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt)
        {
            return progda.AddUpdateProgramFeatures(programEnt);
        }
        public override List<ProgramFeatureSetUp> GetProgramFeatures(int programId, string AppID, string TenantID)
        {
            return progda.GetProgramFeatures(programId,AppID,TenantID);
        }

    }
}
