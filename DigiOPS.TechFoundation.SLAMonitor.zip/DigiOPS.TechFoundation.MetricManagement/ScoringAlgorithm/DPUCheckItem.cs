﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    public class DPUCheckItem : DPUScoreAlgorithm
    {

        public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();    
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._totAppDefects = objAuditDataEntity.AuditedList
                                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage == -1).Count();
            scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage == -1 && m.CriticalityType == "Fatal").Count();

            
            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            else
            {
               
                    scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;

        }

        public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo _AuditData)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();   
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._totAppDefects = _AuditData.AuditedList
                                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage == -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Count();
            scoringAlgorithmInfo._CriticalityChecked = _AuditData.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage == -1 && m.CriticalityType == "Fatal").Count();

            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
               
            }
            else
            {
                    scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;
            
        }
    }
}
