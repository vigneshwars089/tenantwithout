﻿
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    public class DPOGroup : DPOScoreAlgorithm
    {
       
            ILoggingFactory objLogging = new LoggingFactory();
           
        /// <summary>
        /// Calculate Quality score
        /// </summary>
            /// <param name="objAuditDataEntity">AuditDataEntity</param>
            /// <param name="objScoringAlgorithmInfo">ScoringAlgorithmInfo</param>
            /// <returns>ScoringAlgorithmInfo</returns>
            public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
            {
                ScoringOutput objScoringOutput = new ScoringOutput();
                ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();

                objScoringAlgorithmInfo._totErrorField = 0;
                objScoringAlgorithmInfo._ErrorFieldScore = 0.0;
                objScoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

                objScoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                              .Where(m => m.GroupWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
               
                try
                {
                    var TotalDefectsGroupWeightages = (from c in objAuditDataEntity.AuditedList.Where(m => m.GivenWeightage != -1)//.Select(x => x.GroupWeightage).Sum();

                                                       group c by new { c.DOGroupID, c.GroupWeightage } into g
                                                       select g.Key.GroupWeightage).Sum();


                    var TotalDefectsAPPandNonAPP = from c in objAuditDataEntity.AuditedList.Where(m => m.GivenWeightage != -1)
                                                   group c by new { c.DOGroupID, c.GroupWeightage } into g
                                                   select new
                                                   {

                                                       GroupID = g.Key.DOGroupID,

                                                       NoofApplicable = g.Count(),
                                                       NoofError = g.Count(oi => oi.GivenWeightage == 0),
                                                       GivenWeightage = g.Key.GroupWeightage

                                                   };

                    var SumGroupScore = from c in TotalDefectsAPPandNonAPP


                                        group c by new { c.GroupID } into g
                                        select (new
                                        {

                                            GroupID = g.Key.GroupID,

                                            TotalCalculatedScore = g.Sum(oi => (float)(((float)((oi.NoofApplicable - oi.NoofError)) / (float)(oi.NoofApplicable)) * (float)(oi.GivenWeightage)))


                                        });

                    var TotalDefectsCalculatedGroupWeightages = SumGroupScore.Select(p => p.TotalCalculatedScore).Sum();

                    var QualityScore = ((TotalDefectsCalculatedGroupWeightages / TotalDefectsGroupWeightages) * 100);


                    if (objScoringAlgorithmInfo._CriticalityChecked > 0)
                    {
                        objScoringOutput.QualityScore = 0.0;
                        
                    }
                    else
                    {
                        objScoringAlgorithmInfo._QualityScore = QualityScore;
                        objScoringOutput.QualityScore = QualityScore;
                        objScoringOutput.QualityScore = Math.Round(objScoringAlgorithmInfo._QualityScore, 4);
                       
                    }
                }
                catch(Exception ex)
                {
                    objLogging.GetLoggingHandler("Log4Net").LogException(ex);
                }
                objScoringOutput.ResultStatus = true;
                return objScoringOutput;
            }
    }
}
