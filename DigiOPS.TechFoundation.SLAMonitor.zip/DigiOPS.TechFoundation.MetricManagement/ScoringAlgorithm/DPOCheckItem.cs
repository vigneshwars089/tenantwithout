﻿
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    public class DPOCheckItem : DPOScoreAlgorithm
    {
       // LogInfo objLogInfo = new LogInfo();
        ILoggingFactory objLogging = new LoggingFactory();

        /// <summary>
        /// Calculate Quality score
        /// </summary>
            /// <param name="objAuditDataEntity">AuditDataEntity</param>
            /// <param name="objScoringAlgorithmInfo">ScoringAlgorithmInfo</param>
            /// <returns>ScoringAlgorithmInfo</returns>
        public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();

            objScoringAlgorithmInfo._totOpp = 0;
            objScoringAlgorithmInfo._totAppOpp = 0;
            objScoringAlgorithmInfo._totNotAppOpp = 0;
            objScoringAlgorithmInfo._totAppDefects = 0;
            objScoringAlgorithmInfo._totAppNoDefects = 0;

            objScoringAlgorithmInfo._totOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totNotAppOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppDefectsWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppNoDefectsWithEmp_W = 0.0;

            objScoringAlgorithmInfo._totOpp = objAuditDataEntity.AuditedList.Count();
            objScoringAlgorithmInfo._totAppOpp = objAuditDataEntity.AuditedList.Count(m => m.GivenWeightage != -1);
            objScoringAlgorithmInfo._totNotAppOpp = objScoringAlgorithmInfo._totOpp - objScoringAlgorithmInfo._totAppOpp;
            objScoringAlgorithmInfo._totAppDefects = objAuditDataEntity.AuditedList
                                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1).Count();
            objScoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
            objScoringAlgorithmInfo._totAppNoDefects = objScoringAlgorithmInfo._totAppOpp - objScoringAlgorithmInfo._totAppDefects;

            try
            {
                objScoringAlgorithmInfo._totOpp_W = objAuditDataEntity.AuditedList.Sum(m => m.MaxWeightage);
                objScoringAlgorithmInfo._totAppOpp_W = objAuditDataEntity.AuditedList.Where(m => m.GivenWeightage != -1).Sum(m => m.MaxWeightage);
                objScoringAlgorithmInfo._totNotAppOpp_W = objScoringAlgorithmInfo._totOpp_W - objScoringAlgorithmInfo._totAppOpp_W;
                objScoringAlgorithmInfo._totAppDefects_W = objAuditDataEntity.AuditedList
                    .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1).Sum(m => m.MaxWeightage - m.GivenWeightage);
                objScoringAlgorithmInfo._totAppNoDefects_W = objScoringAlgorithmInfo._totAppOpp_W - objScoringAlgorithmInfo._totAppDefects_W;
                               
                if (objScoringAlgorithmInfo._CriticalityChecked > 0)
                {                  
                    objScoringOutput.QualityScore = 0.0;

                }
                else
                {
                    objScoringAlgorithmInfo._QualityScore = objScoringAlgorithmInfo._totAppDefects == 0 ? 1 : Convert.ToDouble(objScoringAlgorithmInfo._totAppNoDefects) / Convert.ToDouble(objScoringAlgorithmInfo._totAppOpp);

                    objScoringOutput.QualityScore = Math.Round(objScoringAlgorithmInfo._QualityScore, 4) * 100;

                }
            
               
            }
            catch (Exception ex)
            {
                objLogging.GetLoggingHandler("Log4Net").LogException(ex);
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;

        }

              
        /// <summary>
        /// Calculate Criticality Quality score
        /// </summary>
            /// <param name="objAuditDataEntity">AuditDataEntity</param>
            /// <param name="objScoringAlgorithmInfo">ScoringAlgorithmInfo</param>
            /// <returns>ScoringAlgorithmInfo</returns>
        public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();

            objScoringAlgorithmInfo._totOpp = 0;
            objScoringAlgorithmInfo._totAppOpp = 0;
            objScoringAlgorithmInfo._totNotAppOpp = 0;
            objScoringAlgorithmInfo._totAppDefects = 0;
            objScoringAlgorithmInfo._totAppNoDefects = 0;

            objScoringAlgorithmInfo._totOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totNotAppOppWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppDefectsWithEmp_W = 0.0;
            objScoringAlgorithmInfo._totAppNoDefectsWithEmp_W = 0.0;
            try
            {


                objScoringAlgorithmInfo._totAppOpp = objAuditDataEntity.AuditedList.Count(m => m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal"));

                objScoringAlgorithmInfo._totAppDefects = objAuditDataEntity.AuditedList
                                        .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Count();
                objScoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                        .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
                objScoringAlgorithmInfo._totAppNoDefects = objScoringAlgorithmInfo._totAppOpp - objScoringAlgorithmInfo._totAppDefects;
                               

                if (objScoringAlgorithmInfo._CriticalityChecked > 0)
                {
                    objScoringOutput.QualityScore = 0.0;               
                }
                else
                {
                   objScoringAlgorithmInfo._QualityScore = objScoringAlgorithmInfo._totAppDefects == 0 ? 1 : Convert.ToDouble(objScoringAlgorithmInfo._totAppNoDefects) / Convert.ToDouble(objScoringAlgorithmInfo._totAppOpp);
                   objScoringOutput.QualityScore = Math.Round(objScoringAlgorithmInfo._QualityScore, 4) * 100;
                }
            }
            catch (Exception ex)
            {
                objLogging.GetLoggingHandler("Log4Net").LogException(ex);
            }

            objScoringOutput.ResultStatus = true;
            return objScoringOutput;
                       
            }


        }
    }

