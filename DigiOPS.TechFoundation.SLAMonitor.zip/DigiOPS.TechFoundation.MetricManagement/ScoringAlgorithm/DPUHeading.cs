﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    public class DPUHeading : DPUScoreAlgorithm
    {

        public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppHeadingsDefects = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                           .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
                     

            var _Headings = objAuditDataEntity.AuditedList.GroupBy(m => m.ParentDOId).ToArray();

            foreach (var _Heading in _Headings)
            {
                double _Heading_W = _Heading
                                    .Select(m => m.MaxWeightage)
                                    .FirstOrDefault();


                int _AppHeadingDefects = _Heading
                                           .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                           .GroupBy(x => x.DOGroupID)
                                           .Count();


                scoringAlgorithmInfo._totAppHeadingsDefects = scoringAlgorithmInfo._totAppHeadingsDefects + _AppHeadingDefects;
            }

            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            else
            {
               
                    scoringAlgorithmInfo._QualityScore =scoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;            
                 
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;
        }

        public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo _AuditData)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;
            scoringAlgorithmInfo._totAppHeadingsDefects = 0;


            scoringAlgorithmInfo._CriticalityChecked = _AuditData.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
                       

            var _Headings = _AuditData.AuditedList.Where(m => m.CriticalityType == "Critical" || m.CriticalityType == "Fatal").GroupBy(m => m.ParentDOId).ToArray();

            foreach (var _Heading in _Headings)
            {
                double _Heading_W = _Heading.Where(m => m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")
                                    .Select(m => m.MaxWeightage)
                                    .FirstOrDefault();

                int _AppHeadingDefects = _Heading
                                           .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1 && (x.CriticalityType == "Critical" || x.CriticalityType == "Fatal"))
                                           .GroupBy(x => x.DOGroupID)
                                           .Count();

                scoringAlgorithmInfo._totAppHeadingsDefects = scoringAlgorithmInfo._totAppHeadingsDefects + _AppHeadingDefects;

            }


            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            else
            {
                
                    scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 100 : 0;
                    objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
                                  
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;
        }        
    }
}
