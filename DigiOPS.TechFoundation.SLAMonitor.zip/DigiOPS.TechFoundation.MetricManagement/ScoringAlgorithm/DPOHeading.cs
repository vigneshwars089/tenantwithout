﻿
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    public class DPOHeading : DPOScoreAlgorithm
    {
       
            ILoggingFactory objLogging = new LoggingFactory();
           
            /// <summary>
            /// Calculate Quality score
            /// </summary>
            /// <param name="objAuditDataEntity">AuditDataEntity</param>
            /// <param name="objScoringAlgorithmInfo">ScoringAlgorithmInfo</param>
            /// <returns>ScoringAlgorithmInfo</returns>
            public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
            {
                ScoringOutput objScoringOutput = new ScoringOutput();
                ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();

                objScoringAlgorithmInfo._QualityScore = 0.0;
                objScoringAlgorithmInfo._totAppHeadings = 0;               
                objScoringAlgorithmInfo._totAppHeadingsDefects = 0;
                objScoringAlgorithmInfo._totAppHeadingsNoDefects = 0;
                objScoringAlgorithmInfo._totErrorField = 0;

                
                objScoringAlgorithmInfo._ErrorFieldScore = 0.0;
                objScoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

                objScoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                              .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();
                                
                try
                {
                    var _Headings = objAuditDataEntity.AuditedList.GroupBy(m => m.ParentDOId).ToArray();
                    foreach (var _Heading in _Headings)
                    {
                        double _Heading_W = _Heading
                                               .Select(m => m.MaxWeightage)
                                               .FirstOrDefault();
                        int _AppHeading = _Heading
                                            .Where(x => x.GivenWeightage != -1)
                                            .GroupBy(x => x.DOGroupID)
                                            .Count();

                        int _AppHeadingDefects = _Heading
                                                   .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                                   .GroupBy(x => x.DOGroupID)
                                                   .Count();
                        int _AppHeadingsNoDefects = 0;


                        _AppHeadingsNoDefects = (_AppHeadingDefects > 0) || (_AppHeading == 0) ? 0 : 1;

                        objScoringAlgorithmInfo._totAppHeadingsNoDefects = objScoringAlgorithmInfo._totAppHeadingsNoDefects + _AppHeadingsNoDefects;
                    }

                    if (objScoringAlgorithmInfo._CriticalityChecked > 0)
                        {
                            objScoringAlgorithmInfo._QualityScore = 0.0;
                            objScoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                            objScoringOutput.QualityScore = objScoringAlgorithmInfo._QualityScore;
                          
                        }
                        else
                        {
                            objScoringAlgorithmInfo._QualityScore = objScoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 1 : (Convert.ToDouble(objScoringAlgorithmInfo._totAppHeadingsNoDefects) / Convert.ToDouble(objScoringAlgorithmInfo._totAppHeadings));
                            objScoringAlgorithmInfo._QualityScore = Math.Round(objScoringAlgorithmInfo._QualityScore, 4) * 100;
                            objScoringOutput.QualityScore = objScoringAlgorithmInfo._QualityScore;
                        }
                }
                catch (Exception ex)
                {
                    objLogging.GetLoggingHandler("Log4Net").LogException(ex);
                }
                objScoringOutput.ResultStatus = true;
                return objScoringOutput;
            }


            /// <summary>
            /// Calculate Criticality Quality score
            /// </summary>
            /// <param name="objAuditDataEntity">AuditDataEntity</param>
            /// <param name="objScoringAlgorithmInfo">ScoringAlgorithmInfo</param>
            /// <returns>ScoringAlgorithmInfo</returns>
            public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo objAuditDataEntity)
            {
                ScoringOutput objScoringOutput = new ScoringOutput();
                ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();

                objScoringAlgorithmInfo._QualityScore = 0.0;
                objScoringAlgorithmInfo._totHeadings = 0;
                objScoringAlgorithmInfo._totNotAppHeadings = 0;
                objScoringAlgorithmInfo._totAppHeadings = 0;
                objScoringAlgorithmInfo._totAppHeadingsDefects = 0;
                objScoringAlgorithmInfo._totAppHeadingsNoDefects = 0;
                objScoringAlgorithmInfo._totErrorField = 0;

                objScoringAlgorithmInfo._ErrorFieldScore = 0.0;
                objScoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

                objScoringAlgorithmInfo._totHeadings = objAuditDataEntity.AuditedList.Where(m => m.CriticalityType == "Critical" || m.CriticalityType == "Fatal").GroupBy(m => m.DOGroupID).Count();
                objScoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                               .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();

                             
                var _Headings = objAuditDataEntity.AuditedList.Where(m => m.CriticalityType == "Critical" || m.CriticalityType == "Fatal").GroupBy(m => m.ParentDOId).ToArray();

                 foreach (var _Heading in _Headings)
                 {

                     double _Heading_W = _Heading.Where(m => m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")
                                                .Select(m => m.MaxWeightage)
                                                .FirstOrDefault();
                    
                            int _AppHeading = _Heading
                                                .Where(x => x.GivenWeightage != -1 && (x.CriticalityType == "Critical" || x.CriticalityType == "Fatal"))
                                                .GroupBy(x => x.DOGroupID)
                                                .Count();

                            int _AppHeadingDefects = _Heading
                                                       .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1 && (x.CriticalityType == "Critical" || x.CriticalityType == "Fatal"))
                                                       .GroupBy(x => x.DOGroupID)
                                                       .Count();

                            int _AppHeadingsNoDefects = 0;

                            
                                    _AppHeadingsNoDefects = (_AppHeadingDefects > 0) || (_AppHeading == 0) ? 0 : 1;
                                    objScoringAlgorithmInfo._totAppHeadingsNoDefects = objScoringAlgorithmInfo._totAppHeadingsNoDefects + _AppHeadingsNoDefects;

                                    objScoringAlgorithmInfo._totNotAppHeadings = objScoringAlgorithmInfo._totHeadings - objScoringAlgorithmInfo._totAppHeadings;
                 }
               
               

                if (objScoringAlgorithmInfo._CriticalityChecked > 0)
                {
                    objScoringAlgorithmInfo._QualityScore = 0.0;
                    objScoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                    objScoringOutput.QualityScore = objScoringAlgorithmInfo._QualityScore;
                 }
                else
                {
                    objScoringAlgorithmInfo._QualityScore = objScoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 1 : (Convert.ToDouble(objScoringAlgorithmInfo._totAppHeadingsNoDefects) / Convert.ToDouble(objScoringAlgorithmInfo._totAppHeadings));

                    objScoringAlgorithmInfo._QualityScore = Math.Round(objScoringAlgorithmInfo._QualityScore, 4) * 100;
                    objScoringOutput.QualityScore = objScoringAlgorithmInfo._QualityScore;
                }

                objScoringOutput.ResultStatus = true;
                return objScoringOutput;
            }
    }
}
