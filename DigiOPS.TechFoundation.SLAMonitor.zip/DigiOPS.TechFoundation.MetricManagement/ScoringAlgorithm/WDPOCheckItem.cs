﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
   public class WDPOCheckItem: WDPOScoreAlgorithm
    {

       public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
       {
           ScoringOutput objScoringOutput = new ScoringOutput();
           ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();
           DetailsEntity objDetailsEntity=new DetailsEntity();
           List<DetailsEntity> lstComb = new List<DetailsEntity>();

           scoringAlgorithmInfo._QualityScore = 0.0;
           scoringAlgorithmInfo._CriticalityChecked = 0;
           scoringAlgorithmInfo._totAppDefects = 0;
           scoringAlgorithmInfo._totAppOpp_W = 0.0;
           scoringAlgorithmInfo._totAppDefects_W = 0.0;
           scoringAlgorithmInfo._totAppNoDefects_W = 0.0;
           scoringAlgorithmInfo._totAppOppWithEmp_W = 0.0;
           scoringAlgorithmInfo._totAppDefectsWithEmp_W = 0.0;
           scoringAlgorithmInfo._totAppNoDefectsWithEmp_W = 0.0;

           scoringAlgorithmInfo._totErrorField = 0;
           scoringAlgorithmInfo._ErrorFieldScore = 0.0;
           scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;


           scoringAlgorithmInfo._totAppDefects = objAuditDataEntity.AuditedList
                                           .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1).Count();
           scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                  .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();


           scoringAlgorithmInfo._totAppOpp_W = objAuditDataEntity.AuditedList.Where(m => m.GivenWeightage != -1).Sum(m => m.MaxWeightage);
           scoringAlgorithmInfo._totAppDefects_W = objAuditDataEntity.AuditedList
               .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1).Sum(m => m.MaxWeightage - m.GivenWeightage);
           scoringAlgorithmInfo._totAppNoDefects_W = scoringAlgorithmInfo._totAppOpp_W - scoringAlgorithmInfo._totAppDefects_W;
           
           if (scoringAlgorithmInfo._CriticalityChecked > 0)
           {
               scoringAlgorithmInfo._QualityScore = 0.0;
               scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           else
           {
               scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects_W == 0.0 ? 1 : (scoringAlgorithmInfo._totAppNoDefects_W / scoringAlgorithmInfo._totAppOpp_W);

               scoringAlgorithmInfo._QualityScore = Math.Round(scoringAlgorithmInfo._QualityScore, 4) * 100;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           objScoringOutput.ResultStatus = true;
           return objScoringOutput;
       }

       public override ScoringOutput GenerateCriticalityQualityScore(ScoringInfo _AuditData)
       {
           ScoringOutput objScoringOutput = new ScoringOutput();
           ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

           scoringAlgorithmInfo._QualityScore = 0.0;
           scoringAlgorithmInfo._CriticalityChecked = 0;
           scoringAlgorithmInfo._totAppDefects = 0;
           scoringAlgorithmInfo._totAppOpp_W = 0.0;
           scoringAlgorithmInfo._totAppDefects_W = 0.0;
           scoringAlgorithmInfo._totAppNoDefects_W = 0.0;
           scoringAlgorithmInfo._totAppOppWithEmp_W = 0.0;
           scoringAlgorithmInfo._totAppDefectsWithEmp_W = 0.0;
           scoringAlgorithmInfo._totAppNoDefectsWithEmp_W = 0.0;
           scoringAlgorithmInfo._totErrorField = 0;
           scoringAlgorithmInfo._ErrorFieldScore = 0.0;
           scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;


           scoringAlgorithmInfo._totAppDefects = _AuditData.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Count();
           scoringAlgorithmInfo._CriticalityChecked = _AuditData.AuditedList
                                  .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();


           scoringAlgorithmInfo._totAppOpp_W = _AuditData.AuditedList.Where(m => m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Sum(m => m.MaxWeightage);

           scoringAlgorithmInfo._totAppDefects_W = _AuditData.AuditedList
               .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && (m.CriticalityType == "Critical" || m.CriticalityType == "Fatal")).Sum(m => m.MaxWeightage - m.GivenWeightage);
           scoringAlgorithmInfo._totAppNoDefects_W = scoringAlgorithmInfo._totAppOpp_W - scoringAlgorithmInfo._totAppDefects_W;

           if (scoringAlgorithmInfo._CriticalityChecked > 0)
           {
               scoringAlgorithmInfo._QualityScore = 0.0;
               scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           else
           {
               scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppDefects_W == 0.0 ? 1 : (scoringAlgorithmInfo._totAppNoDefects_W / scoringAlgorithmInfo._totAppOpp_W);

               scoringAlgorithmInfo._QualityScore = Math.Round(scoringAlgorithmInfo._QualityScore, 4) * 100;
               objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
           }
           objScoringOutput.ResultStatus = true;
           return objScoringOutput;

       }
       
   }
}
