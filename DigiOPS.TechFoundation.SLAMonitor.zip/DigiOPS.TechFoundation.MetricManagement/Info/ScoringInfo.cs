﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
      [Serializable]
        public class ScoringInfo 
        {
          public ScoringInfo() //Included by 572814 for Metric Management
            {
                AuditedList = new List<DetailsEntity>();              
              
            }

            public List<DetailsEntity> AuditedList { get; set; }
            public string _strAuditlogic { get; set; }
            public string _strScoringLogic { get; set; }   
            public string _IsCriticalApp { get; set; }

            
        }



      public class DetailsEntity : ScoringInfo
        {
           public string Auditlogic { get; set; } 
            public float GivenWeightage { get; set; } // Weitage provided on selecting the rating 1- yes 0 -No 
           // public Boolean DefectNA { get; set; }  // Should be considerd for score calculation 
            public float MaxWeightage { get; set; } // Maximum configured for CTQ -1 yes
            public int DOGroupID { get; set; } // Grouping CTQ with Heading 
            public int ParentDOId { get; set; }       //If its is CTQ , Parent id - Heading Id ,if it Heading ParentId - Category Id    
            private string criticalityType = "";
            public string CriticalityType   // Critical , Non-Critical , Fatal 
            {
                get { return criticalityType; }
                set { criticalityType = value; }
            }           
            public float GroupWeightage { get; set; } // Group Based defined for more heading 
           // public float CalculatedGroupWeightage { get; set; } // Weigtage provided for groups 
        
        }

    }

