﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.MetricManagement
// Class Name(s) :WDPOScoreAlgorithm
// Author : Sujitha
// Creation Date : 17/4/2017
// Purpose : Base Method for WDPO
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////

using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    public struct S_auditingLogic
    {

        public const string DPO = "DPO";
        public const string DPU = "DPU";
        public const string WDPO = "WDPO";
        public const string Combined = "COMBINED";
        public const string DeductiveWDPO = "DEDUCTIVEWDPO";

    }

    public struct S_scoreLogic
    {

        public const string HEADING = "HEADING BASED";
        public const string CHECKPOINT = "CHECKPOINT BASED";
        public const string GROUP = "GROUP BASED";

    }


    public class ScoringAlgorithmFactory : IScoringAlgorithmFactory
    {

        public IScoringAlgorithm GetScoringHandler(ScoringInfo objScoringInfo)
        {
            if (objScoringInfo == null)
            {
                return new BaseScoringAlgorithm();

            }
            string scoreLogic = objScoringInfo._strScoringLogic;
            string auditLogic = objScoringInfo._strAuditlogic;
            BaseScoringAlgorithm objBaseScoringAlgorithm = new BaseScoringAlgorithm();
            ScoringOutput objResponseInfo = new ScoringOutput();
            if ((scoreLogic == "" || String.IsNullOrEmpty(scoreLogic)) || (auditLogic == "" || String.IsNullOrEmpty(auditLogic)))
            {
                return new BaseScoringAlgorithm();
                //objResponseInfo.ErrorMessage.Append("Input's can't be null");
                //objResponseInfo.ResultStatus = false;
            }
            else if ((scoreLogic.ToUpper().Trim() != "HEADING BASED" && scoreLogic.ToUpper().Trim() != "CHECKPOINT BASED" && scoreLogic.ToUpper().Trim() != "GROUP BASED") || (auditLogic.ToUpper().Trim() != "DPO" && auditLogic.ToUpper().Trim() != "WDPO" && auditLogic.ToUpper().Trim() != "DPU" && auditLogic.ToUpper().Trim() != "COMBINED" && auditLogic.ToUpper().Trim() != "DEDUCTIVEWDPO"))
            {
                return new BaseScoringAlgorithm();

            }
            
            else
            {
                switch (auditLogic.ToUpper().Trim())
                {
                    case S_auditingLogic.DPO:
                        switch (scoreLogic.ToUpper().Trim())
                        {
                            case S_scoreLogic.HEADING:
                                return new DPOHeading();
                            case S_scoreLogic.CHECKPOINT:
                                return new DPOCheckItem();
                            case S_scoreLogic.GROUP:
                                return new DPOGroup();
                            default:
                                return null;
                        }

                    case S_auditingLogic.DPU:
                        switch (scoreLogic.ToUpper().Trim())
                        {
                            case S_scoreLogic.HEADING:
                                return new DPUHeading();
                            case S_scoreLogic.CHECKPOINT:
                                return new DPUCheckItem();
                            default:
                                return null;
                        }
                    case S_auditingLogic.WDPO:
                        switch (scoreLogic.ToUpper().Trim())
                        {
                            case S_scoreLogic.HEADING:
                                return new WDPOHeading();
                            case S_scoreLogic.CHECKPOINT:
                                return new WDPOCheckItem();
                            default:
                                return null;
                        }
                    case S_auditingLogic.DeductiveWDPO:
                        switch (scoreLogic.ToUpper().Trim())
                        {
                            case S_scoreLogic.HEADING:
                                return new DeductiveWDPOHeading();
                            case S_scoreLogic.CHECKPOINT:
                                return new DeductiveWDPOCheckItem();
                            default:
                                return null;
                        }
                    case S_auditingLogic.Combined:

                        return new CombinedScore();
                    default:
                        return null;



                }

            }
            return null;
        }


        //public IScoringAlgorithm GetScoringHandler(List<ScoringInfo> objScoringInfo)
        //{
        //    if (objScoringInfo == null)
        //    {
        //        return new BaseScoringAlgorithm();

        //    }
        //    string scoreLogic = objScoringInfo._strScoringLogic;
        //    string auditLogic = objScoringInfo._strAuditlogic;
        //    BaseScoringAlgorithm objBaseScoringAlgorithm = new BaseScoringAlgorithm();
        //    ScoringOutput objResponseInfo = new ScoringOutput();
        //    if ((scoreLogic == "" || String.IsNullOrEmpty(scoreLogic)) || (auditLogic == "" || String.IsNullOrEmpty(auditLogic)))
        //    {
        //        return new BaseScoringAlgorithm();
        //        //objResponseInfo.ErrorMessage.Append("Input's can't be null");
        //        //objResponseInfo.ResultStatus = false;
        //    }
        //    else if ((scoreLogic != "HEADING BASED" && scoreLogic != "CHECKPOINT BASED" && scoreLogic != "GROUP BASED") || (auditLogic != "DPO" && auditLogic != "WDPO" && auditLogic != "DPU"))
        //    {
        //        return new BaseScoringAlgorithm();

        //    }
        //    else
        //    {
        //        switch (auditLogic)
        //        {
        //            case S_auditingLogic.DPO:
        //                switch (scoreLogic)
        //                {
        //                    case S_scoreLogic.HEADING:
        //                        return new DPOHeading();
        //                    case S_scoreLogic.CHECKPOINT:
        //                        return new DPOCheckItem();
        //                    case S_scoreLogic.GROUP:
        //                        return new DPOGroup();
        //                    default:
        //                        return null;
        //                }

        //            case S_auditingLogic.DPU:
        //                switch (scoreLogic)
        //                {
        //                    case S_scoreLogic.HEADING:
        //                        return new DPUHeading();
        //                    case S_scoreLogic.CHECKPOINT:
        //                        return new DPUCheckItem();
        //                    default:
        //                        return null;
        //                }
        //            case S_auditingLogic.WDPO:
        //                switch (scoreLogic)
        //                {
        //                    case S_scoreLogic.HEADING:
        //                        return new WDPOHeading();
        //                    case S_scoreLogic.CHECKPOINT:
        //                        return new WDPOCheckItem();
        //                    default:
        //                        return null;
        //                }
        //            default: return null;

        //        }

        //    }
        //    return null;
        //}

        //public ScoringOutput GetScoring(string scoreLogic, string auditLogic, ScoringInfo objAuditDataEntity)
        //{
        //    BaseScoringAlgorithm objBaseScoringAlgorithm = new BaseScoringAlgorithm();
        //    ScoringOutput objResponseInfo = new ScoringOutput();

        //    objResponseInfo = objBaseScoringAlgorithm.Validation(scoreLogic, auditLogic, objAuditDataEntity);
        //    if (objResponseInfo.ResultStatus == true)
        //    {
        //       objResponseInfo= GetScoringHandler(scoreLogic, auditLogic, objAuditDataEntity).CalculateQualityScore(objAuditDataEntity);
        //       objResponseInfo.ResultStatus = true;
        //    }

        //    return objResponseInfo;
        //}

    }
}
