﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.ComponentModel;
using System.Data;
//using System.Drawing;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.Configuration
{
    public class HierarchyBulkConfiguration : BaseCustomConfiguration
    {
        string SheetName = "Template";
        LoggingFactory objloggingfactory = new LoggingFactory();
        LogInfo objlog = new LogInfo();

        public override string Configuration(string ExcelFilePath, string ExcelTemplate, string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo, byte[] bt)
        {
            string strMessage = "";
            DataSet ds = new DataSet();
            Dictionary<string, DataTable> dictData = new Dictionary<string, DataTable>();
            try
            {
               
                //string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
                string ExcelTemplateSource = ExcelSourceTemplate;
                ExcelTemplate excelTemplate = new ExcelTemplate();
                string strDataSet = string.Empty;
                string strProcDetails = string.Empty;
                string strError = string.Empty;


                excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
                excelTemplate.Workbook = new List<WorkbookTemplate>()
                        {
                            excelTemplate.Workbook.Where(W=>W.Template_Name==ExcelTemplate).SingleOrDefault()
                        };

                //ExcelRead ER = new ExcelRead();
                dictData = ReadExcelData(excelTemplate, ExcelFilePath,bt);
                //dictData = ReadExcelData(excelTemplate, ExcelFilePath);
                DataTable dt1 = dictData["Process"];
                DataTable dt2 = dictData["SubProcess"];
                try
                {
                    var dataValue = (from DataRow dr in dt1.Rows
                                     where (dr["ProcessName"].ToString().Length > 50)
                                     select (string)dr["ProcessName"]).ToList().FirstOrDefault();


                    if (!string.IsNullOrEmpty(dataValue))
                    {
                        return "3";
                    }
                }
                catch
                {
 
                }

                DataSet objTablesData = new DataSet();

                objTablesData.Tables.Add(dt1);
                objTablesData.Tables.Add(dt2);

                HierarchyDataAccess HD = new HierarchyDataAccess(objBaseInfo.TenantName, objBaseInfo.AppID);
                ds = HD.InsertHierarchyrans(objTablesData,objBaseInfo);

                int errorCount = 0;
                foreach (DataTable dtExcelData in ds.Tables)
                {
                    if (dtExcelData.Rows.Count > 0)
                    {
                        WriteToExcel(dtExcelData, Errorpath + dtExcelData.TableName + ".xls", SheetName);
                        errorCount = errorCount + 1;
                    }
                }
                if (errorCount > 0)
                {
                    strMessage = "2";
                }
                else
                {
                    strMessage = "1";
                }
               

            }

            catch (Exception excep)
            {                
                objloggingfactory.GetLoggingHandler("Log4net").LogException(excep); 
                throw excep;
            }
            //return ds;
            //return dictData;
            return strMessage;
        }
        

    }
}
