﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
//using System.Text;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.Configuration
{
    public class UserBulkConfiguration : BaseCustomConfiguration
    {
        string SheetName = "Template";
        LoggingFactory objloggingfactory = new LoggingFactory();
        LogInfo objlog = new LogInfo();
       

        public override string Configuration(string ExcelFilePath, string ExcelTemplate,string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo,byte[] bt)
        {
            UserConfigurationDAO UC = new UserConfigurationDAO(objBaseInfo.TenantName,objBaseInfo.AppID);
           // UserConfigurationDAO UC1 = new UserConfigurationDAO(objBaseInfo.AppID, objBaseInfo.TenantID);
           
            string strMessage = ""; 
            DataSet ds = new DataSet();
            Dictionary<string, DataTable> dictData = new Dictionary<string, DataTable>();
            try
            {

                //string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
                string ExcelTemplateSource = ExcelSourceTemplate;
                ExcelTemplate excelTemplate = new ExcelTemplate();
                string strDataSet = string.Empty;
                string strProcDetails = string.Empty;
                string strError = string.Empty;
                var dataValue = (dynamic)null; 

                excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
                excelTemplate.Workbook = new List<WorkbookTemplate>()
                        {
                            excelTemplate.Workbook.Where(W=>W.Template_Name==ExcelTemplate).SingleOrDefault()
                        };

               
                dictData = ReadExcelData(excelTemplate, ExcelFilePath,bt);
                DataTable dt1 = dictData["User"];
                DataTable dt2 = dictData["UserGroup"];
                DataTable dt3 = dictData["UserGroup-UserMapping"];
                DataTable dt4 = dictData["UserRoleMapping"];
                DataTable dt5 = dictData["RolePermissionMapping"];

                try
                {
                    dataValue = (from DataRow dr in dt1.Rows
                                 where (DateTime.Parse(dr["Effective From"].ToString()).Date < DateTime.Now.Date)// (DateTime)dr["Effective From"] == DateTime.Today
                                 select (string)dr["User Name"]).ToList().FirstOrDefault();

                    if (!string.IsNullOrEmpty(dataValue))
                    {
                        return "3";
                    }
                }
                catch
                {
 
                }

                DataSet objTablesData = new DataSet();

                objTablesData.Tables.Add(dt1);
                objTablesData.Tables.Add(dt2);
                objTablesData.Tables.Add(dt3);
                objTablesData.Tables.Add(dt4);
                objTablesData.Tables.Add(dt5);
                               
             
                ds = UC.InsertUserDetails(objTablesData);
                int errorCount = 0;
                foreach (DataTable dtExcelData in ds.Tables)
                {
                    if (dtExcelData.Rows.Count>0)
                    {
                        WriteToExcel(dtExcelData, Errorpath + dtExcelData.TableName + ".xls", SheetName);
                        errorCount = errorCount + 1;
                    }                  
                }
                if (errorCount>0)
                {
                    strMessage = "2";
                }
                else
                {
                    strMessage = "1";
                }
                
               
            }
            catch (Exception excep)
            {              
                objloggingfactory.GetLoggingHandler("Log4net").LogException(excep); 
                throw excep;
            }
            //return ds;   
            return strMessage;
        }
             
       
    }
}


    

