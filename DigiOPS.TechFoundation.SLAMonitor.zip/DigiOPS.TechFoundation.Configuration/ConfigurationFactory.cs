﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
    
    public class ConfigurationFactory :IConfigurationFactory
    {

        public ICustomConfiguration GetConfigurationHandler(string configurationType, string configurationLevel)
        {
            // ICustomConfiguration objcustomconfigFactory = null;

            switch (configurationType)
            {
                case S_Config_Type.Manual:
                    switch (configurationLevel)
                    {
                        case S_ConfigurationLevel.DynamicField:
                            return new DynamicFieldsConfiguration();

                        case S_ConfigurationLevel.ApplicationSettings:
                            return new ApplicationSettingsConfiguration();

                        case S_ConfigurationLevel.ProductionSettings:
                            return new ProductionSettingsConfiguration();
                        case S_ConfigurationLevel.Manualhierarchy:
                            return new ManualHierarchyConfiguration();
                        case S_ConfigurationLevel.WorkflowQCConfiguration:
                            return new WorkflowQCConfiguration();
                        case S_ConfigurationLevel.DataElementConfiguration:
                            return new DataElementConfiguration();
                        case S_ConfigurationLevel.EMailConfiguration:
                            return new ProgramConfiguration();

                        default:
                            return null;
                    }

                case S_Config_Type.BulkUpload:
                    switch (configurationLevel.ToUpper())
                    {
                        case S_ConfigurationLevel.AUDIT:
                            return new AuditBulkConfiguration();

                        case S_ConfigurationLevel.USER:
                            return new UserBulkConfiguration();

                        case S_ConfigurationLevel.HIERARCHY:
                            return new HierarchyBulkConfiguration();

                        case S_ConfigurationLevel.DataElementBulkConfiguration:
                            return new DataElementBulkConfiguration();

                        default:
                            return null;
                    }


                default:
                    return null;
            }

            //   return objcustomconfigFactory;
        }

    }
}


