﻿using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Configuration
{
    public class MailBoxConfiguration : BaseCustomConfiguration
    {
        MailBoxConfigurationDataAccess objMBDA1 = new MailBoxConfigurationDataAccess();

        //public override ResponseInfo HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, int TenantId)
        //{
        //    ResponseInfo objResponseInfo = new ResponseInfo();
        //    objResponseInfo.ErrorMessage = new StringBuilder();
        //    int result = 0;
        //    if ((HierarchyLevel)!=0 || string.IsNullOrEmpty(HierarchyLevelName) || string.IsNullOrEmpty(HierarchyName) || string.IsNullOrEmpty(HierarchyDesc) || (IsActive == null) || string.IsNullOrEmpty(createdby) || string.IsNullOrEmpty(tenantname) || string.IsNullOrEmpty(parenthierarchy) || string.IsNullOrEmpty(parenthierarchyvalue) || string.IsNullOrEmpty(HierarchyPOC) || string.IsNullOrEmpty(appId) || TenantId == 0)
        //         objResponseInfo.ErrorMessage.Append("Inputs are null");
        //    else if ((HierarchyLevel!=0 && string.IsNullOrEmpty(HierarchyLevelName) && string.IsNullOrEmpty(HierarchyName) && string.IsNullOrEmpty(tenantname) && string.IsNullOrEmpty(appId) && TenantId == 0) || appId != null && HierarchyLevel != null && tenantname != null && HierarchyLevelName != null && HierarchyName!=null)
        //        objResponseInfo.ErrorMessage.Append("Inputs are null");
        //    else
        //   result= objMBDA1.HierarchyCreation(HierarchyLevel, HierarchyLevelName, HierarchyName, HierarchyDesc, IsActive, createdby, tenantname, parenthierarchy,parenthierarchyvalue, HierarchyPOC, appId, TenantId);
        //    if (result == 0)
        //        objResponseInfo.ResultStatus = false;
        //    else
        //    {
        //        objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
        //    }
        //    return objResponseInfo;
        //}

        //public override ResponseInfo GetMailBoxLoginDetails(string LoginEmailId, string pd, string TenantName, bool islocked, bool isactive, string appId, int TenantId)
        //{
        //    ResponseInfo objResponseInfo = new ResponseInfo();
        //    objResponseInfo.ErrorMessage=new StringBuilder();
        //    int result = 0;
        //    if (string.IsNullOrEmpty(LoginEmailId) || string.IsNullOrEmpty(pd) || string.IsNullOrEmpty(TenantName) || (islocked == null) || isactive == null || string.IsNullOrEmpty(appId) || TenantId == 0)
        //        objResponseInfo.ErrorMessage.Append("Inputs are null");
        //    else if ((string.IsNullOrEmpty(LoginEmailId) && string.IsNullOrEmpty(pd) && string.IsNullOrEmpty(TenantName)) || LoginEmailId != null && pd != null && TenantName!=null)
        //        objResponseInfo.ErrorMessage.Append("Inputs are null");
        //    else
        //    result = objMBDA1.GetMailBoxLoginDetails( LoginEmailId, pd, TenantName, islocked, isactive, appId, TenantId);
        //    if (result == 0)
        //        objResponseInfo.ResultStatus = false;
        //    else
        //    {
        //        objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
        //    }
        //    return objResponseInfo;
        //}

        //public override ResponseInfo GetMailBoxConfigurationDetails(MailFeatureEntity objMailBoxConfigurationEntity)
        //{
        //    ResponseInfo objResponseInfo = new ResponseInfo();
        //    objResponseInfo.ErrorMessage = new StringBuilder();
        //    int result = 0;
        //    if (objMailBoxConfigurationEntity != null)            
        //        result = objMBDA1.GetMailBoxConfigurationDetails
        //            (objMailBoxConfigurationEntity.MailBoxName, objMailBoxConfigurationEntity.MailBoxAddress, objMailBoxConfigurationEntity.Domain, objMailBoxConfigurationEntity.MailBoxFolderPath, objMailBoxConfigurationEntity.TATInHours, objMailBoxConfigurationEntity.TATInSeconds,
        //            objMailBoxConfigurationEntity.TimeZone, objMailBoxConfigurationEntity.CreatedById, objMailBoxConfigurationEntity.CreatedDate, objMailBoxConfigurationEntity.IsQCRequired, objMailBoxConfigurationEntity.IsActive,
        //        objMailBoxConfigurationEntity.IsReplyNotRequired, objMailBoxConfigurationEntity.IsMailTriggerRequired, objMailBoxConfigurationEntity.Offset, objMailBoxConfigurationEntity.IsEMailBoxAddressOptional, objMailBoxConfigurationEntity.IsVOCSurvey, objMailBoxConfigurationEntity.IsADLogin, objMailBoxConfigurationEntity.IsSubjectEditable, objMailBoxConfigurationEntity.IsGMBtoGMB, objMailBoxConfigurationEntity.IsCustomizableCaseId, objMailBoxConfigurationEntity.IsConversationHistory, objMailBoxConfigurationEntity.TenantName, objMailBoxConfigurationEntity.AppId, objMailBoxConfigurationEntity.TenantId,
        //        objMailBoxConfigurationEntity.HierarchyValuetobeTakenName, objMailBoxConfigurationEntity.HierarchyLevelNameValuetobeTaken);
        //    if (result != 0)
        //    {
        //        objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
        //    }
        //    else
        //    { objResponseInfo.ErrorMessage.Append("Inputs are null"); objResponseInfo.ResultStatus = false; }
        //    return objResponseInfo;
        //}

        //public override TenantInfo GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel)
        //{
        //    TenantInfo objTenantInfo = new TenantInfo();
        //    try
        //    {
        //        objTenantInfo = objMBDA1.GetHierarchy(TenantName, HierarchyName, HierarchyLevel);
        //    }
        //    catch (Exception ex)
        //    { }
        //   return objTenantInfo;
        //}

       


       
    }
}
