﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Logging;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DigiOPS.TechFoundation.ExceptionHandling;
using System.IO;
using System.Text.RegularExpressions;
using System.Net.Mail;
using System.Net;
using System.Globalization;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
   public class DynamicFieldsConfiguration :BaseCustomConfiguration
    {      
             public Database Db = DatabaseFactory.CreateDatabase("Conn");
             LoggingFactory objloggingfactory = new LoggingFactory();
             EMTConfigurationRepository objemt = new EMTConfigurationRepository();
             AUDITConfigurationRepository objaudit = new AUDITConfigurationRepository();

           public override void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements)
           {
               switch (fieldconfig.AppID)
               {
                   case S_AppIDConfiguration.EMT:
                       {    
                           string strStatusVal = "0";
                           DataSet dsControls = new DataSet();
                         //ArrayList dataElementsArrayList = new ArrayList();
                           List<DataElementEntity> dataElementsList = new List<DataElementEntity>();
                           try
                           {    
                               DataTable datatab=new DataTable();
                               DataElementEntity DataElement = new DataElementEntity();
                               DataElement = (DataElementEntity)fieldconfig;
                               if (!string.IsNullOrEmpty(DataElement.CaseID))
                               {
                                   Hashtable hs = new Hashtable();
                                   hs.Add("@CaseID", Convert.ToInt32(DataElement.CaseID));
                                   
                                       
                                       dsControls = objemt.GetDynamicPageControls(hs);
                                  // dsControls = new EMTmethod().GetDynamicPageControls(hs);
                                   try
                                   {
                                   if (dsControls != null && dsControls.Tables.Count > 0 && dsControls.Tables[0].Rows.Count > 0)//INPUT
                                   {
                                       for (int iCnt = 0; iCnt <= dsControls.Tables[0].Rows.Count - 1; iCnt++)
                                       {
                                           DataElement = new DataElementEntity();
                                           DataElement.DynamicFieldMasterId = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString() + "_" + dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString();
                                           DataElement.fieldname = dsControls.Tables[0].Rows[iCnt]["FieldAliasName"].ToString();
                                           DataElement.FieldTypeID = dsControls.Tables[0].Rows[iCnt]["FieldType"].ToString();
                                           DataElement.FieldDataTypeID = dsControls.Tables[0].Rows[iCnt]["FieldDataType"].ToString();
                                           if (dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != string.Empty)
                                               DataElement.FieldMaxLength = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString());
                                           else
                                               DataElement.FieldMaxLength = 0;

                                           DataElement.FieldMasterId = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString());

                                           if (!string.IsNullOrEmpty(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString()))
                                               DataElement.ValidationTypeID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString());
                                           else
                                               DataElement.ValidationTypeID = 0;

                                           if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"] != null)
                                           {
                                               if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != string.Empty)
                                                   DataElement.FieldPrivilageId = Convert.ToInt32(dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString());
                                               else
                                                   DataElement.FieldPrivilageId = 0;
                                           }
                                           else
                                               DataElement.FieldPrivilageId = 0;

                                           if (DataElement.RoleName != null && DataElement.RoleName.ToString() != "4")
                                           {
                                               DataElement.FieldPrivilageId = 0;
                                           }

                                           if (!string.IsNullOrWhiteSpace(dsControls.Tables[0].Rows[iCnt]["Value"].ToString()))
                                               DataElement.Value = dsControls.Tables[0].Rows[iCnt]["Value"].ToString();
                                           else
                                               DataElement.Value = string.Empty;

                                           dataElementsList.Add(DataElement);    
                                       }
                                   }
                                   }
                                   catch(NullReferenceException ex)
                                   {
                                       DataElement.ErrorMessage.Append("Null");
                                   }
                               }

                               DataElements = dataElementsList;
                           }
                           catch (NullReferenceException ex)
                           {

                           }
                           finally
                           {
                               strStatusVal = "0";
                               dsControls.Dispose();
                           }
                       } break;

                   case S_AppIDConfiguration.QUART:
                       {
                           
                           

                           DataTable dt = null;
                           // List<DataElementEntity> baseList = new <DataElementEntity>();
                           List<DataElementEntity> baseList = new List<DataElementEntity>();
                           
                           try
                           {

                               dt = objaudit.GetDataElementRecordList(fieldconfig);                                   
                                   baseList = MapToDataElementList(dt).Cast<DataElementEntity>().ToList();   
                                   List<DataElementEntity> dataElementsList = new List<DataElementEntity>();
                                   DataElements = baseList;
                           }
                           catch (InvalidCastException ex)
                           {

                               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);                               

                           }
                           catch (Exception ex)//QuartException
                           {

                               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                               
                           }
                           finally
                           {                               
                           }

                       }
                       break;


               }

        }

           public override void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value)
           {
               switch (fieldconfig.AppID)
               {
                   case S_AppIDConfiguration.EMT:
                       {
                           int returnvalue;
                           string strdefaultValue = string.Empty;
                           int chkactive;
                           try
                           {
                               DataElementEntity DataElement = new DataElementEntity();
                               DataElement = (DataElementEntity)fieldconfig;
                               if (DataElement.CountryID != null && DataElement.MailBoxID != null)
                               {
                                   int CountryID = Int32.Parse(DataElement.CountryID.ToString());
                                   int MailBoxID = Int32.Parse(DataElement.MailBoxID.ToString());

                                   if (!string.IsNullOrEmpty(DataElement.fieldname))
                                   {
                                       string LoginId = DataElement.UserId;
                                       Hashtable hs = new Hashtable();
                                       hs.Add("@CountryID", CountryID);
                                       hs.Add("@MailboxID", MailBoxID);
                                       if (!string.IsNullOrEmpty(DataElement.defaultValue))
                                           strdefaultValue = DataElement.defaultValue;
                                       else
                                           strdefaultValue = "";
                                       hs.Add("@defaultValue", strdefaultValue);

                                       string fldname = DataElement.fieldname.Trim().ToString();

                                       if (fldname.Contains(" "))
                                       {
                                           fldname = fldname.Replace(" ", "");
                                       }


                                       hs.Add("@FieldName", fldname);
                                       hs.Add("@FieldAliasName", DataElement.fieldname.ToString());

                                       hs.Add("@FieldTypeId", Convert.ToInt32(DataElement.FieldTypeID.ToString()));
                                       hs.Add("@FieldDataTypeID", Convert.ToInt32(DataElement.FieldDataTypeID.ToString()));
                                       hs.Add("@ValidationTypeID", Convert.ToInt32(DataElement.ValidationTypeID.ToString()));
                                       if (DataElement.FieldTypeID.Trim().ToLower() == "1" || DataElement.FieldTypeID.Trim().ToLower() == "1")
                                       {
                                           if (!string.IsNullOrWhiteSpace(DataElement.FieldMaxLength.ToString()))
                                               hs.Add("@TextLength", Convert.ToInt32(DataElement.FieldMaxLength.ToString()));

                                           else
                                               hs.Add("@TextLength", 0);
                                       }
                                       if (DataElement.chkactive == true)
                                       {
                                           chkactive = 1;
                                       }
                                       else
                                       {
                                           chkactive = 0;
                                       }

                                       if (DataElement.Mandatory == true)
                                           hs.Add("@Mandatory", 1);
                                       else
                                           hs.Add("@Mandatory", 2);

                                       hs.Add("@Active", chkactive);
                                       hs.Add("@CreatedBy", LoginId);
                                       if (DataElement.btnMap == "Configure")
                                       {
                                           returnvalue = objemt.ConfigureFieldtoMailbox(hs);
                                           if (returnvalue == 1)//MAPPING SUCCESS
                                           {
                                               value = returnvalue.ToString();
                                               // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name configuration is successful');", true);
                                           }
                                           else if (returnvalue == 3)//MAPPING FAILURE
                                           {
                                               value = returnvalue.ToString();
                                               // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name already exists to the mailbox');", true);
                                           }
                                           else
                                           {
                                               value = returnvalue.ToString();
                                               // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name already exists as a master,Please enter any other field name');", true);

                                           }
                                           // Clearfields();
                                           // BindMailBoxcateMapgrid();
                                       }
                                       else // update section
                                       {
                                           hs.Add("@FieldMasterId", DataElement.FieldMasterId);
                                           returnvalue = objemt.UpdateConfigureFieldstoMailbox(hs);
                                           if (returnvalue == 0)//UPDATE FAILS
                                           {
                                               //  ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                                               //   BindMailBoxcateMapgrid();
                                               // DataElement.btnMap = "Configure";
                                               value = returnvalue.ToString();
                                           }
                                           if (returnvalue == 1)//UPDATE SUCCESS
                                           {
                                               //   ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                                               //   Clearfields();
                                               //  BindMailBoxcateMapgrid();
                                               // DataElement.btnMap = "Configure";
                                               value = returnvalue.ToString();
                                           }
                                           else if (returnvalue == 3 || returnvalue == 4)//Already Mapped
                                           {
                                               //   ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name is already available to the Selected MailBox or as a master value');", true);
                                               // DataElement.btnMap = "Update";
                                               //  BindMailBoxcateMapgrid();
                                               //  Clearfields();
                                               value = returnvalue.ToString();
                                           }
                                       }

                                   }
                                   else
                                   {
                                       //    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Enter Field name');", true);
                                   }
                               }
                               else
                               {
                                   //  ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select country and mailbox');", true);
                               }
                           }
                           catch (Exception Ex)
                           {
                               //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | btnMap_Click()");
                               //Response.Redirect("~/Errors/Error.aspx", false);
                           }




                       } break;
                   case S_AppIDConfiguration.QUART:
                       {
                           Log4NetLogger ProxyLogger = new Log4NetLogger();

                           string entityName = fieldconfig.GetType().Name;
                           ProxyLogger.Log.Info(entityName + " - Calling.");
                           string createRecVal = string.Empty;
                           //DataElementDAO dedao = new DataElementDAO();
                           //if (objBase.ViewName == "SetRanking")
                           //    createRecVal = dedao.SetUpdateSequence(objBase);
                           //else
                           try
                           {
                               createRecVal = objaudit.CUDDataElementRecord(fieldconfig);
                           }
                           catch (InvalidCastException Ex)
                           {
                               ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
                           }
                           //catch (QuartException Ex)
                           //{
                           //  ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
                           //}
                           finally
                           {
                               value = createRecVal;

                               // dedao = null;
                           }
                       } break;


                   default:
                       //  proxyLogger.Log.Info("Default value matched in set Entity  " + EntityName);
                       break;





               }




           }     






           //public string CUDDataElementRecord(ConfigurationInfo DataElementEnt)//to write the fields for quart
           //{
           //    Log4NetLogger proxyLogger = new Log4NetLogger();

           //    string resultValue = "-1";
           //    XElement Parent = new XElement("root");//Xattribute used to convert load this as xml document
           //    XElement root = new XElement("xmlArguments");
           //    proxyLogger.Log.Info("DataElementDAO - CUDDataElementRecord - Called.");
           //    try
           //    {
           //        const string SP_SET_TRANSELEMENTCONFIG = "USP_SET_TRANSELEMENTCONFIG";
           //        const string ACTION_Insert = "INSERT";
           //        const string PAR_iReturnValue = "iReturnValue";


           //        DataElementEntity _DataElement = new DataElementEntity();
           //        _DataElement = (DataElementEntity)DataElementEnt;
           //        using (SqlConnection SqlConnection = new SqlConnection(Db.ConnectionString))
           //        {
           //            SqlConnection.Open();
           //            SqlCommand command = new SqlCommand(SP_SET_TRANSELEMENTCONFIG, SqlConnection);
           //            command.CommandType = CommandType.StoredProcedure;


           //            root.Add(new XAttribute("iElementId", (DataElementEnt.eventAction == ACTION_Insert) ? 0 : _DataElement.ElementId));

           //            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.ElementName)))
           //                root.Add(new XAttribute("szElementName", Convert.ToString(_DataElement.ElementName)));

           //            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.FieldType)))
           //                root.Add(new XAttribute("FieldType", Convert.ToString(_DataElement.FieldType)));

           //            root.Add(new XAttribute("iElementTypeId", (_DataElement.ElementTypeId == 0) ? 0 : _DataElement.ElementTypeId));

           //            if (_DataElement.DataTypeId.Equals(0))
           //                root.Add(new XAttribute("iDataTypeId", 0));
           //            else
           //                root.Add(new XAttribute("iDataTypeId", Convert.ToString(_DataElement.DataTypeId)));

           //            if (!string.IsNullOrEmpty(_DataElement.splChars))
           //                root.Add(new XAttribute("szSplChars", Convert.ToString(_DataElement.splChars)));

           //            root.Add(new XAttribute("iElementLength", (_DataElement.ElementLength == 0) ? 0 : _DataElement.ElementLength));

           //            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.CodeGroupId)))
           //                root.Add(new XAttribute("szCodeGroupId", Convert.ToString(_DataElement.CodeGroupId)));

           //            root.Add(new XAttribute("iSequenceNo", (_DataElement.SequenceNo == 0) ? 0 : _DataElement.SequenceNo));
           //            root.Add(new XAttribute("bMandatoryElement", _DataElement.MandatoryElement));
           //            root.Add(new XAttribute("bAuditFormElement", _DataElement.AuditFormElement));
           //            root.Add(new XAttribute("bUniqueElement", _DataElement.UniqueElement));
           //            root.Add(new XAttribute("bGridViewElement", _DataElement.GridViewElement));
           //            root.Add(new XAttribute("bReportableField", _DataElement.IsReportField));
           //            root.Add(new XAttribute("bSearchableElement", _DataElement.SearchableElement));
           //            root.Add(new XAttribute("bSamplingThreshold", _DataElement.SamplingThreshold));
           //            root.Add(new XAttribute("bIsDirectAuditLevel", _DataElement.IsDirectAuditLevel));

           //            if (_DataElement.DirectAuditLevelId.Equals(0))
           //                root.Add(new XAttribute("iDirectAuditLevelId", "0"));
           //            else
           //                root.Add(new XAttribute("iDirectAuditLevelId", _DataElement.DirectAuditLevelId));

           //            if (!string.IsNullOrEmpty(_DataElement.minAuditRange))
           //                root.Add(new XAttribute("szMinAuditRange", Convert.ToString(_DataElement.minAuditRange)));
           //            if (!string.IsNullOrEmpty(_DataElement.maxAuditRange))
           //                root.Add(new XAttribute("szMaxAuditRange", Convert.ToString(_DataElement.maxAuditRange)));
           //            if (!string.IsNullOrEmpty(_DataElement.minSamplingRange))
           //                root.Add(new XAttribute("szMinSamplingRange", Convert.ToString(_DataElement.minSamplingRange)));
           //            if (!string.IsNullOrEmpty(_DataElement.maxSamplingRange))
           //                root.Add(new XAttribute("szMaxSamplingRange", Convert.ToString(_DataElement.maxSamplingRange)));
           //            if (!string.IsNullOrEmpty(_DataElement.DataEntryRoleId))
           //                root.Add(new XAttribute("szRoleIds", Convert.ToString(_DataElement.DataEntryRoleId)));
           //            else
           //                root.Add(new XAttribute("szRoleIds", string.Empty));

           //            root.Add(new XAttribute("iSubProcessId", (DataElementEnt._SubProcessID == 0) ? 0 : DataElementEnt._SubProcessID));

           //            root.Add(new XAttribute("bIsActive", true));

           //            if (!string.IsNullOrEmpty(_DataElement.createdBy))
           //                root.Add(new XAttribute("iCreatedBy", _DataElement.createdBy));

           //            if (!string.IsNullOrEmpty(_DataElement.modifiedBy))
           //                root.Add(new XAttribute("iModifiedBy", _DataElement.modifiedBy));

           //            root.Add(new XAttribute("szOpertaionName", Convert.ToString(DataElementEnt.eventAction)));
           //            root.Add(new XAttribute("iRectrictedElementCount", Convert.ToString(DataElementEnt._ElementCount)));
           //            Parent.Add(root);
           //            command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
           //            SqlParameter outprm = new SqlParameter(PAR_iReturnValue, SqlDbType.Int, 100);
           //            //     SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);

           //            outprm.Direction = ParameterDirection.Output;
           //            command.Parameters.Add(outprm);

           //            command.ExecuteNonQuery();
           //            resultValue = outprm.Value.ToString();
           //        }


           //    }
               
           //    catch (Exception Ex)//QuartException
           //    {
           //        //throw new QuartException(ex.Message, ex.InnerException);
           //    }
           //    return resultValue;
           //}


           internal List<ConfigurationInfo> MapToDataElementList(DataTable dt)
           {
               List<ConfigurationInfo> baseEntityList = new List<ConfigurationInfo>();
               baseEntityList = (from p in dt.AsEnumerable()
                                 select new DataElementEntity
                                 {
                                     ElementId = p.Table.Columns.Contains("iElementId") == true ? Convert.ToInt32(p["iElementId"] == DBNull.Value ? 0 : p["iElementId"]) : 0,
                                     ElementName = p.Table.Columns.Contains("szElementName") == true ? Convert.ToString(p["szElementName"] == DBNull.Value ? string.Empty : p["szElementName"]) : string.Empty,
                                     FieldType = p.Table.Columns.Contains("szFieldType") == true ? Convert.ToString(p["szFieldType"] == DBNull.Value ? string.Empty : p["szFieldType"]) : string.Empty,
                                     DisplayName = p.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]) : string.Empty,
                                     ElementLength = p.Table.Columns.Contains("iElementLength") == true ? Convert.ToInt32(p["iElementLength"] == DBNull.Value ? 0 : p["iElementLength"]) : 0,
                                     CodeGroupId = p.Table.Columns.Contains("szCodeGroupId") == true ? Convert.ToString(p["szCodeGroupId"] == DBNull.Value ? string.Empty : p["szCodeGroupId"]) : string.Empty,
                                     SequenceNo = p.Table.Columns.Contains("iSequenceNo") == true ? Convert.ToInt32(p["iSequenceNo"] == DBNull.Value ? 0 : p["iSequenceNo"]) : 0,
                                     MandatoryElement = p.Table.Columns.Contains("bMandatoryElement") == true ? Convert.ToBoolean(p["bMandatoryElement"]) : false,
                                     AuditFormElement = p.Table.Columns.Contains("bAuditFormElement") == true ? Convert.ToBoolean(p["bAuditFormElement"] == DBNull.Value ? false : p["bAuditFormElement"]) : false, //AuditFormElement

                                     RoleNames = p.Table.Columns.Contains("szRoleIdName") == true ? Convert.ToString(p["szRoleIdName"] == DBNull.Value ? string.Empty : p["szRoleIdName"]) : string.Empty,
                                     DataEntryRoleId = p.Table.Columns.Contains("szDataEntryByIds") == true ? Convert.ToString(p["szDataEntryByIds"] == DBNull.Value ? string.Empty : p["szDataEntryByIds"]) : string.Empty,

                                     UniqueElement = p.Table.Columns.Contains("bUniqueElement") == true ? Convert.ToBoolean(p["bUniqueElement"]) : false,
                                     SearchableElement = p.Table.Columns.Contains("bSearchableElement") == true ? Convert.ToBoolean(p["bSearchableElement"]) : false,
                                     GridViewElement = p.Table.Columns.Contains("bGridViewElement") == true ? Convert.ToBoolean(p["bGridViewElement"]) : false,
                                     IsReportField = p.Table.Columns.Contains("bIsReportField") == true ? Convert.ToBoolean(p["bIsReportField"]) : false,
                                     SamplingThreshold = p.Table.Columns.Contains("bSamplingThreshold") == true ? Convert.ToBoolean(p["bSamplingThreshold"]) : false,
                                     minSamplingRange = p.Table.Columns.Contains("szSamplingThresholdMin") == true ? Convert.ToString(p["szSamplingThresholdMin"] == DBNull.Value ? string.Empty : p["szSamplingThresholdMin"]) : string.Empty,
                                     maxSamplingRange = p.Table.Columns.Contains("szSamplingThresholdMax") == true ? Convert.ToString(p["szSamplingThresholdMax"] == DBNull.Value ? string.Empty : p["szSamplingThresholdMax"]) : string.Empty,
                                     selectedDataElementTypeId = p.Table.Columns.Contains("iElementTypeId") == true ? Convert.ToInt32(p["iElementTypeId"] == DBNull.Value ? 0 : p["iElementTypeId"]) : 0,
                                     selectedDataElementTypeName = p.Table.Columns.Contains("szElementTypeName") == true ? Convert.ToString(p["szElementTypeName"] == DBNull.Value ? string.Empty : p["szElementTypeName"]) : string.Empty,
                                     ElementIsList = p.Table.Columns.Contains("bIsList") == true ? Convert.ToBoolean(p["bIsList"]) : false,
                                     selectedDataTypeId = p.Table.Columns.Contains("iDataTypeId") == true ? Convert.ToInt32(p["iDataTypeId"] == DBNull.Value ? 0 : p["iDataTypeId"]) : 0,
                                     selectedDataTypeName = p.Table.Columns.Contains("szDataTypeName") == true ? Convert.ToString(p["szDataTypeName"] == DBNull.Value ? string.Empty : p["szDataTypeName"]) : string.Empty,
                                     splChars = p.Table.Columns.Contains("szValidChars") == true ? Convert.ToString(p["szValidChars"] == DBNull.Value ? string.Empty : p["szValidChars"].ToString().Replace("|", "")) : string.Empty,
                                     IsDirectAuditLevel = p.Table.Columns.Contains("bDirectAuditReq") == true ? Convert.ToBoolean(p["bDirectAuditReq"] == DBNull.Value ? false : p["bDirectAuditReq"]) : false,
                                     DirectAuditLevel = p.Table.Columns.Contains("DirectAuditLevel") == true ? Convert.ToString(p["DirectAuditLevel"] == DBNull.Value ? string.Empty : p["DirectAuditLevel"]) : string.Empty,
                                     DirectAuditLevelId = p.Table.Columns.Contains("DirectAuditLevelId") == true ? Convert.ToInt32(p["DirectAuditLevelId"] == DBNull.Value ? 0 : p["DirectAuditLevelId"]) : 0,
                                     minAuditRange = p.Table.Columns.Contains("szAuditMin") == true ? Convert.ToString(p["szAuditMin"] == DBNull.Value ? string.Empty : p["szAuditMin"]) : string.Empty,
                                     maxAuditRange = p.Table.Columns.Contains("szAuditMax") == true ? Convert.ToString(p["szAuditMax"] == DBNull.Value ? string.Empty : p["szAuditMax"]) : string.Empty,
                                     selectedSubProcessName = p.Table.Columns.Contains("szSubProcessName") == true ? Convert.ToString(p["szSubProcessName"] == DBNull.Value ? string.Empty : p["szSubProcessName"]) : string.Empty,
                                     selectedProcessId = p.Table.Columns.Contains("iProcessId") == true ? Convert.ToInt32(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]) : 0,
                                     selectedProcessName = p.Table.Columns.Contains("szProcessName") == true ? Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]) : string.Empty,
                                     selectedProgramId = p.Table.Columns.Contains("siProgramId") == true ? Convert.ToInt32(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]) : 0,
                                     selectedProgramName = p.Table.Columns.Contains("szProgramName") == true ? Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]) : string.Empty,
                                     isActive = p.Table.Columns.Contains("bIsActive") == true ? Convert.ToBoolean(p["bIsActive"]) : false,

                                     createdBy = p.Table.Columns.Contains("iCreatedBy") == true ? Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]) : string.Empty,
                                     createdDate = p.Table.Columns.Contains("dsCreatedDate") == true ? Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]) : DateTime.MinValue,
                                     modifiedBy = p.Table.Columns.Contains("iModifiedBy") == true ? Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]) : string.Empty,
                                     modifiedDate = p.Table.Columns.Contains("dsModifiedDate") == true ? Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]) : DateTime.MinValue,
                                     _TotalRows = p.Table.Columns.Contains("TotalRows") == true ? Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]) : 0,
                                 }).Cast<ConfigurationInfo>().ToList();




               return baseEntityList;
           }

       


   



    }
}
