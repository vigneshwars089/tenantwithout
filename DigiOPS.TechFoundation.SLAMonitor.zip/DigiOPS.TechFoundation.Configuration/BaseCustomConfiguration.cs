﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Xml.Linq;
using DigiOPS.TechFoundation.DataTransfer;

namespace DigiOPS.TechFoundation.Configuration
{
    public abstract class BaseCustomConfiguration : ICustomConfiguration
    {
        public virtual string Configuration(string ExcelFilePath, string ExcelTemplate, string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo, byte[] bt)
        {
            //UserConfigurationDAO UC = new UserConfigurationDAO(objBaseInfo.AppID, objBaseInfo.TenantID);
            return null;
        }
       
        public Dictionary<string, DataTable> ReadExcelData(ExcelTemplate excelTemplate, string ExcelFilePath,byte[] bt)
        {
            try
            {
                Dictionary<string, DataTable> dicDT = new Dictionary<string, DataTable>();
               // using (var stream = File.Open(ExcelFilePath, FileMode.OpenOrCreate,FileAccess.Read))
                //{
                MemoryStream stream = new MemoryStream();
                stream.Write(bt, 0, bt.Length); 
                    //FileStream stream = File.Open(ExcelFilePath, FileMode.Open, FileAccess.Read);
                IExcelDataReader excelReader = null;

                if (ExcelFilePath.ToLower().EndsWith("xlsx"))
                    excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream); //Reading from a OpenXml Excel file (2007 format; *.xlsx)
                else if (ExcelFilePath.ToLower().EndsWith("xls"))
                    excelReader = ExcelReaderFactory.CreateBinaryReader(stream); //Reading from a binary Excel file ('97-2003 format; *.xls)
                DataSet result = excelReader.AsDataSet();
                excelReader.IsFirstRowAsColumnNames = false;
                if (excelTemplate.Workbook.Count > 0 && result.Tables.Count > 0)
                {
                    for (int i = 0; i < excelTemplate.Workbook[0].WorkSheet.Count; i++)
                    {
                        DataTable dTab = new DataTable();
                        dTab.TableName = excelTemplate.Workbook[0].WorkSheet[i].WorkSheetName;
                        //inserting the header row
                        for (int Col = 0; Col < excelTemplate.Workbook[0].WorkSheet[i].columnTemplate.Count; Col++)
                            dTab.Columns.Add(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate[Col].Col_header_name);
                        int TabIndex = GetTableIndex(result.Tables, dTab.TableName);
                        if (TabIndex >= 0)
                        {
                            DataTable tempTab = result.Tables[TabIndex].Rows.Cast<DataRow>().
                                                            Where(row => !row.ItemArray.
                                                                All(field => field is System.DBNull)).
                                                            CopyToDataTable();
                            foreach (var column in result.Tables[TabIndex].Columns.Cast<DataColumn>().ToArray())
                            {
                                if (result.Tables[TabIndex].AsEnumerable().All(dr => dr.IsNull(column)))
                                    result.Tables[TabIndex].Columns.Remove(column);
                            }

                            int HeaderStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Header_Row_No.ToString()) - 1;
                            int DataStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Data_Start_Row) - 1;
                            dTab = ReadDataToTable(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate, tempTab, dTab, HeaderStartRow, DataStartRow);

                        }
                        dTab.AcceptChanges();
                        dicDT.Add(dTab.TableName.ToString(), dTab);
                    }
                }
                    stream.Close();
                excelReader.Close();
                //}
               
                //                log.InfoFormat("BGV Reading completed for the file: {0}", ExcelFilePath);
                return dicDT;
            }
            catch (Exception ex)
            {
                //        log.Error(ex.Message);
                //       log.Error(ex.StackTrace);
                throw ex;
            }
        }

        public int GetTableIndex(DataTableCollection dataTableCollection, string sheetName)
        {
            for (int ctr = 0; ctr <= dataTableCollection.Count && ctr < dataTableCollection.Count; ctr++)
            {
                if (dataTableCollection[ctr].TableName.Trim().ToLower() == sheetName.Trim().ToLower())
                    return ctr;
            }
            return -1;
        }
        public int GetHeaderStartRow(string DataStartRowVal, DataTable tempTab, List<ColumnTemplate> columnTemplates)
        {
            try
            {
                int ColHeaderRow = -1;
                Dictionary<string, int> ColHeaderDict = new Dictionary<string, int>();
                if (DataStartRowVal == null)
                    return ColHeaderRow;
                else
                {
                    if (int.TryParse(DataStartRowVal.Trim(), out ColHeaderRow))
                        return ColHeaderRow;
                    else
                    {
                        foreach (ColumnTemplate colTemplate in columnTemplates)
                        {
                            bool flag = false;
                            string columnheadername = colTemplate.Col_header_name;
                            for (int row = 0; row < tempTab.Rows.Count; row++)
                            {
                                for (int col = 0; col < tempTab.Columns.Count; col++)
                                {
                                    string colName = tempTab.Rows[row].ItemArray[col].ToString().Trim().ToUpper();
                                    if (colName == columnheadername.Trim().ToUpper())
                                    {
                                        ColHeaderDict.Add(columnheadername, row);
                                        break;
                                    }
                                }
                                if (flag)
                                    break;
                            }
                        }
                        ColHeaderRow = Convert.ToInt32(ColHeaderDict.OrderByDescending(r => r.Value)
                                        .Select(r => r.Value)
                                        .Take(1));
                        return ColHeaderRow;
                    }
                }
            }
            catch (Exception ex)
            {
                // log.Error(ex.Message);
                // log.Error(ex.StackTrace);
                throw ex;
            }
        }

        public DataTable ReadDataToTable(List<ColumnTemplate> columnTemplates, DataTable tempTab, DataTable dTab, int HeaderStartRow, int DataStartRow)
        {
            try
            {
                int rowRange = tempTab.Rows.Count;
                int colRange = tempTab.Columns.Count;
                Dictionary<int, string> columnIndex = new Dictionary<int, string>();
                foreach (ColumnTemplate colTemplate in columnTemplates)
                {
                    if (colTemplate.Readiability.Equals("T"))
                    {
                        string columnheadername = colTemplate.Col_header_name;
                        int columnnumber = -1;
                        for (int j = 0; j < colRange; j++)
                        {
                            string colName = tempTab.Rows[HeaderStartRow].ItemArray[j].ToString().Trim().ToUpper();
                            if (colName == columnheadername.Trim().ToUpper())
                            {
                                columnnumber = j;
                                break;
                            }
                        }
                        if (columnnumber != -1)
                            columnIndex.Add(columnnumber, "T");
                        else
                            columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "F");
                    }
                    else
                        columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "T");
                }

                //Extract Data
                for (int rowIndex = DataStartRow; rowIndex < rowRange; rowIndex++)
                {
                    DataRow dRow = dTab.NewRow();
                    int colinc = 0;
                    foreach (var pair in columnIndex)
                    {
                        if (pair.Key <= colRange && pair.Value == "T")
                        {
                            dRow[colinc++] = tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString().Trim();
                            //Console.WriteLine(tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString());
                        }
                        else
                            dRow[colinc++] = string.Empty;
                    }
                    if (!dRow.ItemArray.All(i => (i is DBNull || string.Compare(i as string, string.Empty) == 0)))
                    {
                        dTab.Rows.Add(dRow);
                        dTab.AcceptChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                //log.Error(ex.Message);
                //log.Error(ex.StackTrace);
                throw ex;
            }
            return dTab;
        }

        public void WriteToExcel(DataTable dtExcelData, string Errorpath, string sheetName)
        {
            //string strMessage = "";
            //ICollaborationFactory objCollaboration = new CollaborationFactory();
            //objCollaboration.GetExcelHandler().WriteToHtmlFormatExcel(dtExcelData, Errorpath, sheetName);
            //objCollaboration = null;
            DataTransferInfo dataTransferinfo = new DataTransferInfo();
            dataTransferinfo.ExcelExportType = "Excel";
            dataTransferinfo.DataTable = dtExcelData;
            dataTransferinfo.DestinationExcelFilePath = Errorpath;
            dataTransferinfo.ExcelSheetName = sheetName;
            DataTransferFactory ccft = new DataTransferFactory();
            IDataTransfer dataTransfer = ccft.GetFileDataTransferHandler("Excel");
            dataTransfer.TransformSourceDataInfo(dataTransferinfo);



            //strMessage = "File uploaded successfully with valid records only. Please refer Log !";
            //return strMessage;
        }

        public virtual void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements)
        {

        }

        public virtual void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value)
        {

        }

        void ICustomConfiguration.ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements)
        {
            throw new NotImplementedException();
        }

        void ICustomConfiguration.WriteConfiguration(ConfigurationInfo fieldconfig, ref string value)
        {
            throw new NotImplementedException();
        }
       public virtual string AddUpdateProgram(ProgramEntity programEnt)
       {
           return null;
       }
       public virtual string DeleteProgram(int programid, string modifiedby, string eventAction, string AppID, string TenantID)
       {
           return null;
       }
       public virtual List<List<ProgramEntity>> GetProgramList(ManualHierarchyInfo objinfo)
       {
           return null;
       }
       public virtual string AddUpdateProcess(ProcessEntity objprocess)
       {
           return null;
       }
       public virtual string DeleteProcess(int processid, string eventAction, string ModifiedBy, string AppID, string TenantID)
       {
           return null;
       }
       public virtual List<ProcessEntity> GetProcessList(ManualHierarchyInfo objinfo)
       {
           return null;
       }
       public virtual string AddUpdateSubProcess(SubProcessEntity objsubprocess)
       {
           return null;
       }
       public virtual string DeleteSubProcess(int subprocessid, string eventAction, string ModifiedBy, string ModifiedDate, string AppID, string TenantID)
       {
           return null;
       }
       public virtual List<SubProcessEntity> GetSubProcessList(ManualHierarchyInfo objinfo)
       {
           return null;
       }
       public virtual List<List<ProcessEntity>> GetProcessUsergrp(ManualHierarchyInfo objinfo)
       {
           return null;
       }
       public virtual string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig)
       {
           return null;
       }
       public virtual List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo)
       {
           return null;
       }
       public virtual string AddUpdateDataElement(List<DataElementEntity> DataElements)
       {
           return null;
       }
       public virtual List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj)
       {
           return null;
       }
       //public virtual string DeleteDataelemnt(int ElemtId, string eventAction, string modifiedBy, string AppID, int TenantID)
       //{
       //    return null;
       //}
       public virtual DataSet BulkUploadDataElement(Template objtemplate)
       {
           return null;
       }
       public virtual List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, string TenantID)
       {
           return null;
       }
       public virtual List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, string TenantID)
       {
         return null;
       }
       public virtual string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, string TenantID)
       {
           return null;
       }
       public virtual List<DataElementEntity> GetDirectAuditLevelList(int SubProcessID, string AppID, string TenantID)
       {
           return null;
       }
       public virtual string SetRanking(ElementSequence ElementSequence, string AppID, string TenantID)
       {
           return null;
       }
       public virtual string AddList(CodesEntity ListItem)
       {
           return null;
       }
       public virtual CodeGroupEntity GetAddListViewModel(CodeGroupEntity _Codes)
       {
           return null;
       }
       public virtual bool IsAutoAudit(DataElementInfo obj)
       {
           return false;
       }
       public virtual string DeleteDataelemnt(List<DataElementEntity> DataElements, string modifiedBy, string AppID, string TenantID)
       {
           return null;

       }
       public virtual List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj)
       {
           return null;

       }

       public virtual ResponseInfo HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, string TenantId)
         {
           return null;

       }
       public virtual ResponseInfo MailBoxDetails(TenantInfo objTenantInfo)
       {
           return null;

       }

       public virtual ResponseInfo MailBoxCredentials(MailFeatureEntity objMailBoxConfigurationEntity)
       {
           return null;

       }

       public virtual ResponseInfo AuditSettings(MailFeatureEntity objMailBoxConfigurationEntity)
       {
           ResponseInfo objResponseInfo = new ResponseInfo();

           return objResponseInfo;
       }

       public virtual ResponseInfo Set_ZoneANDMenu_Deatils(TenantInfo objTenantInfo)
       {
           ResponseInfo objResponseInfo = new ResponseInfo();

           return objResponseInfo;
       }
       public virtual TenantInfo GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel)
       {
           return null;

       }
       public virtual TenantInfo GetMailBoxConfiguration(string TenantName)
       {
           return null;

       }
       public virtual TenantInfo GetTenantConfiguration(string TenantName)
       {
           return null;

       }
       public virtual TenantInfo Get_ZoneANDMenuDeatils(string TenantName)
       {
           return null;

       }
       public virtual TenantInfo GetLookUp(string TenantName, string LookUpName, int LookUpLevel)
       {
           return null;

       }
       public virtual ResponseInfo SetLookup(int LookupLevel, string LookupLevelName, string LookupName, string LookupDesc, string LookupValue, bool IsActive, string createdby, string tenantname, string parentLookup, string parentLookupvalue, string appId, string TenantId)
       {
           return null;

       }

       public virtual ResponseInfo InsertIntoPM(string ZoneName, string AccountName, string ProgramName, DateTime From, DateTime To, string CreadtedBy, string ModifedBy, string ConnectionString)
       {
           return null;

       }
       public virtual ResponseInfo SetProgramFeatures(TenantInfo objBaseT, string connectionString)
       {
           return null;

       }
    }
}
