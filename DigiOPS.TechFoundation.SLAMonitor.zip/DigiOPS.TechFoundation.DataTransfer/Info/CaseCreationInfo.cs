﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
   public class CaseCreationInfo : BaseInfo
    {
       public int RecordId { get; set; }
       public string UpdateTransactionRecordId { get; set; }
       public string sortOrder { get; set; }
       public string sortColumn { get; set; }
       public int? startRowIndex { get; set; }
       public string message { get; set; }
       public string Search {get; set;}
       public string SYSUSERID { get; set; }
       public string SUBPROCESSID { get; set; }
      // public List<ElementData> ElementDataList { get; set; }

    }
    
}
