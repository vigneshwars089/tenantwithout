﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.DataTransfer
// Class Name(s) :CaseHandling
// Author : Sujitha
// Creation Date : 5/9/2017
// Purpose : CRUD Operation Methods for CaseHandling
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//9-May-2017    Sujitha     CaseHandling            Added CaseHandling methods  
//////////////////////////////////////////////////////////////////////////////////////////////////////
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :CaseHandling.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :CaseHandling
    // Author : Sujitha
    // Creation Date : 
    // Purpose : For the case creation of Quart
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //9-May-2017    Megha     CreateCases            Added CreateCases method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class CaseHandling : BaseCaseCreation
    {
        #region DECLARATION
        //EntityConfiguration objBAL = new EntityConfiguration();
        HttpContext httpContext = HttpContext.Current;
        private int CurrentSubProcessId = 0;
        private string CurrentUserId = string.Empty;
        List<List<BaseEntity>> objBaseList = new List<List<BaseEntity>>();
        BaseEntity objBase = new BaseEntity();
        DataSet ds = new DataSet();
        string ciphertext;//= System.Configuration.ConfigurationManager.AppSettings[Constants.CIPHERPASSWORD];
        //LoggingFactory objloggingfactory = new LoggingFactory();
        Log4NetLogger ProxyLogger = new Log4NetLogger();
        TransRecordData record = new TransRecordData();
        List<BaseEntity> baseList = null;
        DigiOPS.TechFoundation.DataAccessLayer.CaseHandler objCaseHandler = new DigiOPS.TechFoundation.DataAccessLayer.CaseHandler();

        #endregion

        public override string CreateCases(ElementDatas elementdata)  //SetTransactionCreation-TransactionCreationController
        {
            string result = string.Empty;
            string message = string.Empty;
            bool isSearchPage = false;
            string processeddate = string.Empty;
            int RecordId = 0;
            string RecordId1;

            TransRecordData objRecord = new TransRecordData();
            TransStatusData objStatus = new TransStatusData();
            List<TransElementData> objTransElementList = new List<TransElementData>();
            string CurrentUserId = string.Empty;
            try
            {



                if (elementdata.USERID != null)//Constants.SYSUSERID != null)
                {
                    CurrentUserId = elementdata.USERID;//Convert.ToString((httpContext.ApplicationInstance.Session[Constants.SYSUSERID]));
                }
                else
                {
                    CurrentUserId = "0";
                }

                objRecord.byTransactionTypeId = 1;
                objRecord.StatusId = 2;

                objRecord.CoreTransStatusId = 0;
                objRecord.CoreTransStatusReason = null;
                objRecord.PeerCheckerId = 0;
                objRecord.SLACategoryId = 0;
                objRecord.Comment = null;

                objRecord.ProcessedBy = CurrentUserId;
                objRecord.ModifiedBy = CurrentUserId;

                objStatus.StatusId = 1;
                objStatus.PrevStatusId = 1;

                objStatus.StatusEndDate = DateTime.Now;
                objStatus._TotalRows = 0;

                TransElementData objTransElement = null;
                List<TransElementItemData> objTransItemList = null;
                TransElementItemData ItemData = null;


                for (int i = 0; i < elementdata.Items.Count; i++)
                {
                    if (elementdata.Items[i].ElementId == "hdnEditMode")
                    {
                        objRecord.IsEdit = Convert.ToBoolean(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "hdnResetMode")
                    {
                        objRecord.IsReset = Convert.ToBoolean(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "hdnRecordid")
                    {
                        if (isSearchPage == true)
                        {
                            RecordId1 = EncodeDecode.QueryStringDecode(HttpUtility.UrlDecode(elementdata.Items[i].ElementValue), ciphertext);
                            objRecord.RecordId = Convert.ToInt32(RecordId1);
                        }
                        else
                        {
                            if (objRecord.IsEdit == true)
                            {
                                RecordId1 = EncodeDecode.QueryStringDecode(HttpUtility.UrlDecode(elementdata.Items[i].ElementValue), ciphertext);
                                objRecord.RecordId = Convert.ToInt32(RecordId1);
                            }
                            else
                            {
                                if (elementdata.Items[i].ElementValue != null)
                                {
                                    objRecord.RecordId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                                }
                                else
                                {
                                    objRecord.RecordId = 0;
                                }
                            }
                        }
                    }
                    else if (elementdata.Items[i].ElementId == "hdnSearchPage")
                    {
                        if (elementdata.Items[i].ElementValue == "SearchCall")
                        {
                            isSearchPage = true;
                        }
                    }
                    else if (elementdata.Items[i].ElementId == "ddlReference")
                    {
                        objRecord.CoreTransStatusId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "txtReason")
                    {
                        objRecord.CoreTransStatusReason = Convert.ToString(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "hdnSubprocessid")
                    {
                        if (elementdata.Items[i].ElementValue != "")
                        {
                            if (isSearchPage == true)
                            {
                                string SubProcessId = EncodeDecode.QueryStringDecode(HttpUtility.UrlDecode(elementdata.Items[i].ElementValue), ciphertext);
                                objRecord.SubProcessId = Convert.ToInt32(SubProcessId);
                                objStatus.SubProcessId = Convert.ToInt32(SubProcessId);
                            }
                            else
                            {
                                if ((objRecord.IsEdit == true) /*|| (objRecord.IsReset == true)*/)
                                {
                                    string SubProcessId = EncodeDecode.QueryStringDecode(HttpUtility.UrlDecode(elementdata.Items[i].ElementValue), ciphertext);
                                    objRecord.SubProcessId = Convert.ToInt32(SubProcessId);
                                    objStatus.SubProcessId = Convert.ToInt32(SubProcessId);
                                }
                                else
                                {
                                    objRecord.SubProcessId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                                    objStatus.SubProcessId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                                }
                            }
                        }
                    }
                    else if (elementdata.Items[i].ElementId == "txtComments")
                    {
                        if (elementdata.Items[i].ElementValue == null)
                            objRecord.Comment = null;
                        else
                            objRecord.Comment = elementdata.Items[i].ElementValue.ToString();
                    }
                    else if (elementdata.Items[i].ElementId == "txtProcessedDateandTime")
                    {
                        objRecord.ProcessedDate = elementdata.Items[i].ElementValue;
                        processeddate = elementdata.Items[i].ElementValue;
                    }
                    else if (elementdata.Items[i].ElementId == "txtReceivedDateTime")
                    {
                        objRecord.ReceivedDate = elementdata.Items[i].ElementValue;
                    }
                    else if (elementdata.Items[i].ElementId == "txtEmployee")
                    {
                        objRecord.NoOfEmployee = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "txtLines")
                    {
                        objRecord.NoofLine = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "ddlReason")
                    {
                        objRecord.CoreTransStatusReasonId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "txtPeerChecker")
                    {
                        objRecord.PeerCheckerId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else if (elementdata.Items[i].ElementId == "ddlSLAActivity")
                    {
                        objRecord.SLACategoryId = Convert.ToInt32(elementdata.Items[i].ElementValue);
                    }
                    else
                    {
                        objTransElement = new TransElementData();
                        objTransElement.RecordId = objRecord.RecordId;
                        objTransElement._TotalRows = 0;
                        if (elementdata.Items[i].IsList == false)
                        {
                            objTransElement.ElementId = Convert.ToInt32(elementdata.Items[i].ElementId);
                            objTransElement.ElementData = elementdata.Items[i].ElementValue;
                            objTransElement.IsMultiItemValue = elementdata.Items[i].IsList;
                            objTransElement.ModifiedBy = CurrentUserId;
                            objTransElement.ProcessedDate = processeddate;
                        }
                        else
                        {
                            Guid recordguid = Guid.NewGuid();
                            objTransItemList = new List<TransElementItemData>();
                            objTransElement.ElementId = Convert.ToInt32(elementdata.Items[i].ElementId);
                            objTransElement.ElementData = null;
                            if (elementdata.Items[i].ElementItemValue != null)
                            {
                                if (elementdata.Items[i].ElementItemValue.Length > 0)
                                {
                                    objTransElement.ElementData = elementdata.Items[i].ElementItemValue.Replace("|", ",");
                                }
                            }
                            objTransElement.IsMultiItemValue = elementdata.Items[i].IsList;
                            objTransElement.ModifiedBy = CurrentUserId;
                            objTransElement.GuidTransElement = recordguid;
                            objTransElement.ProcessedDate = processeddate;
                            string[] arrayOfElementValue;
                            if (elementdata.Items[i].ElementValue != null)
                            {
                                arrayOfElementValue = elementdata.Items[i].ElementValue.Split('|');
                                for (int j = 0; j < arrayOfElementValue.Length; j++)
                                {
                                    ItemData = new TransElementItemData();
                                    ItemData.CodeId = Convert.ToInt32(arrayOfElementValue[j]);
                                    ItemData.ElementId = Convert.ToInt32(elementdata.Items[i].ElementId);
                                    string[] arrayOfElementItemValue;
                                    if (elementdata.Items[i].ElementItemValue != null)
                                    {
                                        arrayOfElementItemValue = elementdata.Items[i].ElementItemValue.Split('|');
                                        ItemData.ItemValue = Convert.ToString(arrayOfElementItemValue[j]);
                                    }
                                    ItemData.ModifiedBy = CurrentUserId;
                                    ItemData.GuidItemData = recordguid;
                                    ItemData._TotalRows = 0;
                                    objTransItemList.Add(ItemData);
                                }

                                objTransElement.elementItemDataList = objTransItemList;
                            }
                        }
                        objTransElementList.Add(objTransElement);
                    }
                }
                if (objRecord.IsEdit == true)
                {
                    objStatus.StatusId = 2;
                    objStatus.PrevStatusId = 2;
                }
                else
                {
                    objStatus.StatusId = 1;
                    objStatus.PrevStatusId = 1;
                }
                objRecord.TransElement = objTransElementList;
                objRecord.TransStatus = objStatus;

                if (objRecord.CoreTransStatusReasonId == null)
                    objRecord.CoreTransStatusReasonId = 0;



                List<TransRecordData> lstRecord = new List<TransRecordData>();
                StringBuilder sb = new StringBuilder();

                //  record = (TransRecordData)objBase;
                lstRecord.Add(objRecord);

                sb.Append("<root>");
                foreach (TransRecordData item in lstRecord)
                {
                    sb.Append(item.ToXml());
                }
                sb.Append("</root>");
                result = objCaseHandler.SetTransRecordData("INSERT", sb.ToString(), 0, "");

                if (objRecord.IsEdit == false)
                {
                    if (result == Constants.SUCCESS)
                        message = Constants.MSG_TransactionCreation_CreatedSuccessfully;
                    else if (result == Constants.FAILURE)
                        message = Constants.MSG_TransactionCreation_CreatedFailed;
                    else if (result == Constants.ALREADYEXISTS)
                        message = Constants.MSG_TransactionCreation_ALREADY_EXISTS;
                }
                else
                {
                    if (result == Constants.SUCCESS)
                        message = Constants.MSG_TransactionCreation_UpdatedSuccessfully;
                    else if (result == Constants.FAILURE)
                        message = Constants.MSG_TransactionCreation_UpdationFailed;
                    else if (result == Constants.ALREADYEXISTS)
                        message = Constants.MSG_TransactionCreation_ALREADY_EXISTS;
                    else if (result == Constants.USER_NOT_EXISTS)
                        message = Constants.MSG_TransactionCreation_NotExists;
                }

            }
            catch (FormatException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (OverflowException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (InvalidCastException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentNullException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (NullReferenceException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return result;

        }




        public override string Update(CaseCreationInfo casecreationinfo)
        {

            string Search = "";
            string result = null;
            int subprocessid = CurrentSubProcessId;
            string subprocess = string.Empty;
            string RecordNum = casecreationinfo.UpdateTransactionRecordId;
            string action = Constants.EDIT;
            try
            {
                if (Search == "")
                {
                    Search = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(Search, ciphertext));
                }
                RecordNum = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(RecordNum.ToString(), ciphertext));
                subprocess = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(subprocessid.ToString(), ciphertext));
                action = HttpUtility.UrlEncode(EncodeDecode.QueryStringEncode(action.ToString(), ciphertext));

                List<TransRecordData> lstRecord = new List<TransRecordData>();
                StringBuilder sb = new StringBuilder();
                string viewname = objBase.ViewName;
                record = (TransRecordData)objBase;
                lstRecord.Add(record);
                int RecordId = record.RecordId;

                sb.Append("<root>");

                foreach (TransRecordData item in lstRecord)
                {
                    sb.Append(item.ToXml());
                }
                sb.Append("</root>");
                result = objCaseHandler.SetTransRecordData("UPDATE", sb.ToString(), RecordId, viewname);

                //if (Request.IsAjaxRequest())
                //{
                //   // return Json(new { redirectToUrl = Url.Action("Home", new { SubProcessId = subprocess, RecordId = RecordNum, ActionName = action, SearchPage = Search }) });
                //}


            }
            catch (InvalidCastException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentNullException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (NullReferenceException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            //  RedirectToAction("Home", new { SubProcessId = subprocess, RecordId = RecordNum, ActionName = action, SearchPage = Search });
            return result;
        }


        public override string Delete(CaseCreationInfo casecreationinfo)
        {

            string message = string.Empty;
            string result = string.Empty;
            TransRecordData objRecord = new TransRecordData();
            try
            {
                objRecord.RecordId = casecreationinfo.RecordId;
                objBase = (TransRecordData)objRecord;
                objBase.eventAction = Constants.ACTION_Delete;
                if (objBase.eventAction == Constants.ACTION_Delete)
                {
                    if (objBase.ViewName != "SearchDelete")
                    {
                        result = objCaseHandler.DeleteTransaction((TransRecordData)objBase);
                    }
                }
                //string result = objBAL.SetEntity(objBase);
                //if (result == Constants.SUCCESS)
                //{
                //    message = Constants.MSG_TransactionCreation_DeletedSuccessfully;
                //}
                //else if (result == Constants.FAILURE)
                //{
                //    message = Constants.MSG_TransactionCreation_DeletionFailed;
                //}
            }
            catch (InvalidCastException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentNullException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (NullReferenceException ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            //return PartialView(Constants.Partial_TRANSACTIONS, GetTransactionsList(null, null, 0, message));
            return result;
        }

        public override void Search(CaseCreationInfo casecreationinfo)
        {
            //throw new NotImplementedException();
        }

        public override void Purge(CaseCreationInfo casecreationinfo)
        {
            //throw new NotImplementedException();
        }

      
        /// <summary>
        /// Used to disable the upload option in user interface
        /// </summary>
        /// <param name="ProgramID">int</param>
        /// <returns>returns the flag as upload option is disabled or not </returns>
        protected bool DisableUpload(int ProgramID)
        {
            bool isDisable = false;

            try
            {
                if (ProgramID != 0)
                {
                    string XMLconfigpath = ConfigurationManager.AppSettings["BatchFeedTimeslot"];
                    XElement rootheader = XElement.Load(HttpContext.Current.Server.MapPath(XMLconfigpath));

                    var allrootProgram =
                                   from e in rootheader.Elements("Program")
                                   where ((string)e.Attribute("id") == ProgramID.ToString())
                                   select e;

                    if (allrootProgram != null)
                    {
                        var ElementCount = allrootProgram.Descendants("timeslot").Count();
                        for (int i = 0; i < ElementCount; i++)
                        {
                            if (ElementCount != 0)
                            {
                                var StartTime = allrootProgram.Descendants("timeslot").ElementAt(i).Attribute("starttime").Value;
                                var EndTime = allrootProgram.Descendants("timeslot").ElementAt(i).Attribute("endtime").Value;
                                var CurrentTime = DateTime.Now.ToString("hh:mm:ss tt");
                                if ((DateTime.Parse(CurrentTime) >= DateTime.Parse(StartTime)) && (DateTime.Parse(CurrentTime) <= DateTime.Parse(EndTime)))
                                {
                                    isDisable = true;
                                    break;
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
            }
            return isDisable;
        }
              

    }
}
