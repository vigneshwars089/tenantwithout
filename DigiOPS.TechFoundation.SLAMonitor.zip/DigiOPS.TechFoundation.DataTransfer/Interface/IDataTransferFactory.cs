﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface IDataTransferFactory
    {
        IDataTransfer GetFileDataTransferHandler(string Type);
        IMailDataTransfer GetMailDataTransferHandler(string Type);
        ICaseCreation CaseCreationHandler(string Type);
    }
}
