﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface IMailDataTransfer 
    {
        DataTransferInfo ReadAttachementfromSource(EMailInfo emailInfo);
         DataTransferInfo ReadfromSource(EMailInfo EMailInfo);
         DataTransferInfo TransformSourceDataInfo(MoveMailsInfo MoveMailsInfo);
         DataTransferInfo CreateCaseforSourceData(EmailResponceInfo eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid);

         DataTransferInfo SavetoDestination();

         DataTransferInfo UploadToServer();

         DataTransferInfo DownloadtoClient();


    }
}
